
/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : IMPEnoviaClientWrapper.java
 * DESCRIPTION  : Client to call enovia restful service
 * 
 * USAGE        : java -jar ${PATH}/imp.jar
 *              
 * CREATED      : 17-August-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * HISTORY:
 * 
 * Name                     Modified Date                 Description
 * 
 * Sai Prasad               17-Aug-2016                   Initial version.
 * Aravala Raju             06-Sep-2016                   Replaced sun.misc.BASE64Encoder with Java 8 equivalent
 * Sai Prasad               13-Sep-2016                   Modified method isIPOwner for getting response as JSON
 * Aravala Raju             15-Sep-2016                   Added method to check authroization and get QA validataion inputs in single call
 * Kesava Chekka            21-Nov-2016                   IMPBRCM-47,48 
 * Kesava Chekka            25-Nov-2016					  IMPBRCM-47,48,Implemented Webservice for getting Local Cache path and IP Actual Location.
 * Krishna Durgasi          08-08-2017					  Added for SWIMP-1
 * Udaya                    11-Aug-2017					  Added for SWIMP-39
 * Madhusmita M             25-Sep-2017                   Added for SWIMP-53
 * Mahammed Irshad K S		31-Jul-2018					  Added method getWaterMarkString for SWIMP-222
 * Manish					25-JAN-2019					  Modified/Added code for SWIMP-321
 * Mahammed Irshad K S		21-Nov-2018					  Added method checkAccessForObject for the SWIMP-262
 * Mahammed Irshad K S		21-Nov-2018					  Modified the method isDTreeOwner and getIPOwnerDetails for SWIMP-262
 * Mahammed Irshad K S		10-Dec-2018					  Removed the method isIPOwner, isDTreeOwner, getIPOwnerDetails as part of code clean up.
 * Mahammed Irshad K S		28-Jan-2020					  Added method getTechStacks for SWIMP-425
 *------------------------------------------------------------------------------------------------------------------------------------------
 */
package com.broadcom.impcli.enovia;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.LinkedHashMap;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.broadcom.impcli.client.IMPCommon;
import com.broadcom.impcli.client.IMPConstants;
import com.broadcom.impcli.client.IMPException;
import com.broadcom.impcli.client.IMPLog;
import com.broadcom.utility.Utility;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

import com.sun.jersey.core.util.MultivaluedMapImpl;


import java.util.LinkedHashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.lang.StringUtils;



import com.sun.jersey.api.representation.Form;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;


import java.nio.charset.StandardCharsets;

import java.util.Properties;





/**
 * The Class Enovia Client wrapper
 */
public class IMPEnoviaClientWrapper implements IMPConstants {

  private static String strSwitchUser = "";
  private static String strServerError = "Internal Server Error:  ";
	private static final String STR_TAG = "Tag";
  /**
   * Gets the str switch user.
   *
   * @return the str switch user
   */
  public static String getStrSwitchUser() {
    return strSwitchUser;
  }

  /**
   * Sets the str switch user.
   *
   * @param strSwitchUser the new str switch user
   */
  public static void setStrSwitchUser(String strSwitchUser) {
    IMPEnoviaClientWrapper.strSwitchUser = strSwitchUser;
  }

  /**
   * This is a constructor.
   *
   * @return the IMP service web resource
   */
  public IMPEnoviaClientWrapper() {
    // constructor
  }

  private static Logger log = LoggerFactory.getLogger(IMPEnoviaClientWrapper.class);

  /**
   * Gets the IMP service web resource.
   *
   * @param sOperation the s operation
   * @return the IMP service web resource
   * @throws Exception the exception
   */
  public WebResource getIMPServiceWebResource(String sOperation) throws WebApplicationException {
    Client client = Client.create();

    if (sOperation == null) {
      log.error("Operation parameter is null");
      throw new WebApplicationException();
    }
    return client.resource(IMP_SERVICE_URL + sOperation);
  }


  /*
   * This method is used to get the actual user from the unix shell who executes the imp commands.
   */

  /**
   * This method is used to get the actual user from the unix shell who executes the imp commands.
   *
   * @return the IP user details
   * @throws IOException the exception
   */

  public String getUserFromCLI() throws IMPException {
    IMPCommon commonObj = new IMPCommon();
    String sUserName = "";
    BufferedReader br = null;
    String sLinuxEnv = null;
    String sWhoamiValue = null;
    try {
      sLinuxEnv = System.getenv("SITE_VAR");
      ProcessBuilder pb = new ProcessBuilder("/bin/whoami");
      Process process = pb.start();
      if (process.waitFor() == 0) {
        br = new BufferedReader(new InputStreamReader(process.getInputStream()));
        sWhoamiValue = br.lines().collect(Collectors.joining(System.lineSeparator())).trim();
      } else {
        throw new InterruptedException("Failed to get the user.");
      }
      if ("AVAGO".equalsIgnoreCase(sLinuxEnv)) {
        sUserName = sWhoamiValue;
      } else if ("BRCM".equalsIgnoreCase(sLinuxEnv)) {
        IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
        WebResource webResource1 = impEnoClient.getIMPServiceWebResource("oktaID");
        MultivaluedMapImpl params1 = new MultivaluedMapImpl();
        com.sun.jersey.api.representation.Form formData =
            new com.sun.jersey.api.representation.Form();
        formData.add("oktaName", sWhoamiValue);
        ClientResponse response = webResource1.queryParams(params1).accept("application/json")
            .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
            .post(ClientResponse.class, formData);
        org.codehaus.jettison.json.JSONObject retJson =
            new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
        String sRtnUserName = (String) retJson.get(IMP_MESSAGE);
        if (response.getStatus() != 200) {
          throw new IMPException(strServerError + sRtnUserName);
        }        
        if (sRtnUserName.isEmpty()) {
          log.error(IMPCommon.displayExitCode(11));
          commonObj.exitSystem(11);
        } else {
          sUserName = sRtnUserName;
        }
      } else {
        log.error(IMPCommon.displayExitCode(12));
        commonObj.exitSystem(12);
      }
    } catch (IOException | InterruptedException | ClientHandlerException | UniformInterfaceException
        | JSONException e) {
      log.error("Exception in getUserFromCLI:", e);
      throw new IMPException(e.getMessage());
    }
    if (!strSwitchUser.isEmpty()) {
      sUserName = strSwitchUser;
    }
    return sUserName.trim();
  }



  /**
   * This method is used to get the actual user from the unix shell who executes the imp commands.
   *
   * @return the IP user details
   * @throws IOException the exception
   */

  public String getDomainNameFromCLI() throws IMPException {
    IMPCommon commonObj = new IMPCommon();
    String strDomainNameVal = "";
    BufferedReader br = null;
    String strUserPublishsite = "";
    try {
      ProcessBuilder pb = new ProcessBuilder("/bin/domainname");
      Process process = pb.start();
      if (process.waitFor() == 0) {
        br = new BufferedReader(new InputStreamReader(process.getInputStream()));
        strDomainNameVal = br.lines().collect(Collectors.joining(System.lineSeparator())).trim();
      } else {
        throw new InterruptedException("Failed to get the domain name .");
      }
      if (strDomainNameVal != null && !"".equals(strDomainNameVal)
          && strDomainNameVal.length() > 0) {
        IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
        WebResource webResource =
            impEnoClient.getIMPServiceWebResource("getPublishSiteFromUnixDomain");
        MultivaluedMapImpl params = new MultivaluedMapImpl();
        com.sun.jersey.api.representation.Form formData =
            new com.sun.jersey.api.representation.Form();
        formData.add("strUnixDomain", strDomainNameVal);
        formData.add(IMP_ENV, IMP_CLI_ENV);
        ClientResponse response = webResource.queryParams(params).accept("application/json")
            .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
            .post(ClientResponse.class, formData);
        org.codehaus.jettison.json.JSONObject retJson =
            new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
        if (response.getStatus() != 200) {
          throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
        }
        strUserPublishsite = (String) retJson.get(IMP_PUBLISHSITE);
      } else {
        log.error(IMPCommon.displayExitCode(12));
        commonObj.exitSystem(12);
      }
    } catch (IOException | InterruptedException | ClientHandlerException | UniformInterfaceException
        | JSONException e) {
      log.error("Exception in getDomainNameFromCLI:", e);
      throw new IMPException(e.getMessage());
    }
    return strUserPublishsite;
  }

  /**
   * Gets the IP attribute value.
   *
   * @param sIPName the s IP name
   * @param sAttributeName the s attribute name
   * @return the IP attribute value
   * @throws IMPException the IMP exception
   */
  public String getIPAttributeValue(String sIPName, String sAttributeName) throws IMPException {
    String sRtnMessage;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("ipAttributes");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add(IMP_CONST_IP_NAME, sIPName);
      params.add("AttributeName", sAttributeName);
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      org.codehaus.jettison.json.JSONObject retJson =
          new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
      sRtnMessage = (String) retJson.get(sAttributeName);
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in getIPAttributeValue:", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }
  
  //Added for SWIMP-1 start
  /**
   * Gets the WaterMark Info.
   *
   * @param sUniqueWaterMarkID 
   * @return the WaterMark Info
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject getWaterMarkInfo(String sWaterMarkIDs, String sAttributeName)
	        throws IMPException {
	        org.codehaus.jettison.json.JSONObject retJson = null;
	        try {
	          IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
	          WebResource webResource = impEnoClient.getIMPServiceWebResource("wmInfo");

	          MultivaluedMapImpl params = new MultivaluedMapImpl();
	          params.add("WaterMarkIDs", sWaterMarkIDs);
	          params.add("AttributeName", sAttributeName);
	          ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
	                  .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
	          retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
	          if (response.getStatus() != 200) {
	            throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
	          }
	        } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
	            log.error("Exception in getIPAttributeValue:", exp);
	            throw new IMPException(exp.getMessage());
	          }
	        return retJson;
	      }
//Added for SWIMP-1 end
  
  /**
   * Gets the deprecated by IPs.
   *
   * @param sIPID the s IPID
   * @return the deprecated by List
   * @throws IMPException the IMP exception
   */
  public List<String> getDeprecatedBy(String sIPID) throws IMPException {
	  List<String> lsDeprecatedBy = new ArrayList<>();
	    try {
	      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
	      WebResource webResource = impEnoClient.getIMPServiceWebResource("GetDeprecatedBy");

	      MultivaluedMapImpl params = new MultivaluedMapImpl();
	      params.add(IMP_CONST_IP_NAME, sIPID);

	      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
	          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
	      org.codehaus.jettison.json.JSONObject retJson =
	          new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
	      if (response.getStatus() != 200) {
	        throw new IMPException(strServerError + retJson);
	      }  
	      Object oDeprecatedBy =  retJson.get("DeprecatedBy");
	      if(oDeprecatedBy instanceof JSONArray) {
	    	  lsDeprecatedBy = Utility.parseJSONArraytoList((JSONArray)oDeprecatedBy);
	      }
	      
	    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
	    	 log.error("Exception in getDeprecatedBy:", exp);
	         throw new IMPException(exp.getMessage());
	    }
	    return lsDeprecatedBy;
	  }

  /**
   * Gets the IP Replicated Locations.
   *
   * @param sIPName the s IP name
   * @param strRevision the published tag
   * @return the Replicated Locations.
   * @throws IMPException the IMP exception
   */
  public String getIPReplicatedLocations(String sIPName, String strRevision) throws IMPException {
    String sRtnMessage = "";
    org.codehaus.jettison.json.JSONObject retJson;
    try {

      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("getIPRepLocs");

      MultivaluedMapImpl params = new MultivaluedMapImpl();

      // Pass form field values
      com.sun.jersey.api.representation.Form formData =
          new com.sun.jersey.api.representation.Form();
      formData.putSingle(IMP_CONST_IP_NAME, sIPName);
      formData.putSingle(IMP_CONST_IP_TAG, strRevision);
      formData.putSingle(IMP_ENV, IMP_CLI_ENV);
      
      ClientResponse response = webResource.queryParams(params).accept("application/json")
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
      sRtnMessage = (String) retJson.get(IMP_REPLOC);
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in getIPReplicatedLocations:", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }

  /**
   * Gets the IP Publish Site.
   *
   * @param sIPName the s IP name
   * @return the IP Publish Site.
   * @throws IMPException the IMP exception
   */
  public String getIPPublishSite(String sIPName) throws IMPException {
    String sRtnMessage = "";
    org.codehaus.jettison.json.JSONObject retJson;
    try {

      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("getIPPublishSite");

      MultivaluedMapImpl params = new MultivaluedMapImpl();

      // Pass form field values
      com.sun.jersey.api.representation.Form formData =
          new com.sun.jersey.api.representation.Form();
      formData.putSingle(IMP_CONST_IP_NAME, sIPName);
      formData.putSingle(IMP_ENV, IMP_CLI_ENV);

      ClientResponse response = webResource.queryParams(params).accept("application/json")
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
      sRtnMessage = (String) retJson.get("strPublishSite");
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in getIPPublishSite:", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }

  /**
   * Gets the IP Local Cache Path.
   *
   * @param strPublishSite the s Publish Site.
   * @return the Local Cache Path.
   * @throws IMPException the IMP exception
   */
  public String getLocalCachePath(String strPublishSite) throws IMPException {
    String sRtnMessage = "";
    org.codehaus.jettison.json.JSONObject retJson;
    try {

      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("getLocalCachePath");

      MultivaluedMapImpl params = new MultivaluedMapImpl();

      // Pass form field values
      com.sun.jersey.api.representation.Form formData =
          new com.sun.jersey.api.representation.Form();
      formData.putSingle("strPublishSite", strPublishSite);
      formData.putSingle(IMP_ENV, IMP_CLI_ENV);
      
      ClientResponse response = webResource.queryParams(params).accept("application/json")
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
      sRtnMessage = (String) retJson.get("strLocalCache");
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in getLocalCachePath:", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }
   /**
   * Gets the recommended revision for the branch
   *
   * @param sIPName the s IP name
   * @param sBranch the branch specified
   * @return the recommended revision for the branch
   * @throws IMPException the IMP exception
   */
  
  public org.codehaus.jettison.json.JSONObject getRecommendedRevision(String sIPName, String sIPBranch)
        throws IMPException {
        org.codehaus.jettison.json.JSONObject retJson = null;
        try {
          IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
          WebResource webResource = impEnoClient.getIMPServiceWebResource("recommendedrevision");

          MultivaluedMapImpl params = new MultivaluedMapImpl();
          params.add(IMP_CONST_IP_NAME, sIPName);
          params.add("IPBranch", sIPBranch);
          ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
              .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
          retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
          if (response.getStatus() != 200) {
            throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
          }
        } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
          throw new IMPException("Exception in getRecommendedRevision:", exp);
        }
        return retJson;
      }

  /**
   * Gets the IP owner details.
   *
   * @param sIPName the s IP name
   * @param sTag the s tag
   * @param isTagSpecified the is tag specified
   * @return the attribute details of qa failure
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject getQAFailureMsg(String sIPName, String sTag, boolean isTagSpecified)
      throws IMPException {
    org.codehaus.jettison.json.JSONObject retJson;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("IsQAFailures");

      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add(IMP_CONST_IP_NAME, sIPName);
      params.add("Tag", "\"" + sTag + "\"");
      params.add("tagSpecified", isTagSpecified);       
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      throw new IMPException("Exception in getQAFailureMsg:", exp);
    }
    return retJson;
  }


  /**
   * Check out and check in spec.
   *
   * @param sFileName the s file name
   * @param sFilePath the s file path
   * @param specName the spec name
   * @param sEvent the s event
   * @param specVersion the spec version
   * @param sComment the s comment
   * @return the string
   * @throws IMPException the IMP exception
   */
  //Modified for 491---Start
  public String checkOutAndCheckInSpec(String sFileName, String sFilePath, String specName,
      String sEvent, String specVersion, String sComment) throws IMPException {
	String sRtnMessage;
    String sUserName = getUserFromCLI();
    org.codehaus.jettison.json.JSONObject retJson;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("checkoutandcheckin");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add("FileName", sFileName);
      params.add("FilePath", sFilePath);
      params.add("SpecName", specName);
      params.add("UserName", sUserName);
      params.add("Event", sEvent);
      params.add("SpecVersion", specVersion);
      //Added/Modified for 491---Start
      params.add("Comment", sComment);
      //Added/Modified for 491---End
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      sRtnMessage = (String) retJson.get(IMP_MESSAGE);
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + sRtnMessage);
      }      
      Utility.setStrSFTPHost(retJson.get("canonical").toString());
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in checkOutAndCheckInSpec:", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }

  /**
   * Check out and check in spec.
   *
   * @param specName the spec name
   * @param sComment the s comment
   * @return the string
   * @throws IMPException the IMP exception
   */
  public String createDtreeSpec(String specName, String sComment) throws IMPException {
    String sRtnMessage;
    String sUserName = getUserFromCLI();
    org.codehaus.jettison.json.JSONObject retJson;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("createDTreeSpec");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add("SpecName", specName);
      params.add("UserName", sUserName);
      params.add("Comment", sComment);
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      sRtnMessage = (String) retJson.get(IMP_MESSAGE);
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + sRtnMessage);
      }      
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in createDtreeSpec: ", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }


  /**
   * Check admin access.
   *
   * @param sUserName the s user name
   * @param sPassword the s password
   * @return the string
   * @throws IMPException the IMP exception
   */
  public String checkAdminAccess(String sUserName, String sPassword) throws IMPException {
    String sRtnMessage;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("checkAdminAccess");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      String sAuthentication = encodePassword(sUserName, sPassword);
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + sAuthentication).get(ClientResponse.class);
      org.codehaus.jettison.json.JSONObject retJson =
          new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      sRtnMessage = (String) retJson.get(IMP_MESSAGE);
      if (response.getStatus() != 200) {
        throw new IMPException("Invalid username/password");
      }
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in checkAdminAccess: ", exp);
      throw new IMPException(exp.getMessage());
    }
    return sRtnMessage;
  }


  /**
   * Gets the latest spec version.
   *
   * @param strSpecName the str spec name
   * @param strSpecVersion the str spec version
   * @return the latest spec version
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject getLatestSpecVersion(String strSpecName,
      String strSpecVersion) throws IMPException {
    org.codehaus.jettison.json.JSONObject retJson;
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("latestspecversion");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add("SpecName", strSpecName);
      params.add("SpecVersion", strSpecVersion);
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }
    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
      log.error("Exception in getLatestSpecVersion: ", exp);
      throw new IMPException(exp.getMessage());
    }
    return retJson;
  }


  /**
   * create Verification Meta Data
   *
   * @param sIPName the s IP name
   * @param sProjectName the s project name
   * @param strDryRun the str dry run
   * @param sEnv the s env
   * @return the org.codehaus.jettison.json. JSON object
   * @throws IMPException the IMP exception
   */
  //Renamed the method name for SWIMP-75
  //Modified Method Signature SWIMP-321
  public org.codehaus.jettison.json.JSONObject createVerificationMetaData(String sProjectName,
		  String strDryRun, String sEnv, String sFilePath,String sIPID, String sTag, String sLineage,String mmpObjid,String sHIPIDInfo) throws IMPException {
	  org.codehaus.jettison.json.JSONObject retJson;
	  String sUserName = getUserFromCLI();
	  try {
		  IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
		  WebResource webResource = impEnoClient.getIMPServiceWebResource("createVerificationMetaData");

		  MultivaluedMapImpl params = new MultivaluedMapImpl();

		  params.add("ProjectName", sProjectName);
		  params.add("UserName", sUserName);
		  params.add("DryRun", strDryRun);
		  params.add("ENV", sEnv);
		  params.add("FilePath", sFilePath);   //Added for SWIMP-321
		  params.add("HIPId", sIPID);
		  params.add("sTag", sTag);
		  com.sun.jersey.api.representation.Form formData =
				  new com.sun.jersey.api.representation.Form();

		  formData.putSingle("Lineage", sLineage);
		  formData.putSingle("wmobjinfo", mmpObjid);
		  formData.putSingle("HIPIDInfo", sHIPIDInfo);
		  ClientResponse response = webResource.queryParams(params).accept("application/json")
				  .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
		  retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
		  if (response.getStatus() != 200) {
			  throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
		  }
	  } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
		  throw new IMPException("Exception in creation of Verification Meta Data:   ", exp);
	  }
	  return retJson;
  }

  private String encodePassword(String sEnoviaUserName, String sEnoviaPassword) {
    String authString = sEnoviaUserName + ":" + sEnoviaPassword;
    Encoder encoder = Base64.getEncoder();
    String authStringEncoded = encoder.encodeToString(authString.getBytes());
    // +"@SC@"+sSecurityContext
    return authStringEncoded;
  }

  /**
   * Gets the ModuleUrl and Return the sValue.
   *
   * @param sValue the s value
   * @return the domain name
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public String getModuleUrlvalue(String sValue) throws IOException {
    String sModuleUrlvalue = "";
    try {
      sModuleUrlvalue = getIPAttributeValue(sValue, "attribute[DesignSync URL]");
      if (null != sModuleUrlvalue && sModuleUrlvalue.contains(";Trunk:Latest")) {
        sModuleUrlvalue = sModuleUrlvalue.substring(0, sModuleUrlvalue.indexOf(";Trunk"));
      }
    } catch (Exception e) {
      log.error("" + e);
    }
    return sModuleUrlvalue;
  }

  /**
   * Webservice wrapper.
   *
   * @param strResourceName the str resource name
   * @param formData the form data
   * @return the org.codehaus.jettison.json. JSON object
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject webserviceWrapper(String strResourceName,
      com.sun.jersey.api.representation.Form formData) throws IMPException {
    org.codehaus.jettison.json.JSONObject retJson = null;
    try {
      WebResource webResource = getIMPServiceWebResource(strResourceName);

      // Pass multiple Query Params
      MultivaluedMapImpl queryParams = new MultivaluedMapImpl();

      ClientResponse response = webResource.queryParams(queryParams).accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
      }      
    } catch (IMPException | ClientHandlerException | UniformInterfaceException | JSONException e) {
      throw new IMPException(e);
    }
    return retJson;
  }
  

  /**
   * Delete on exit.
   *
   * @param strFileDir the str file dir
   * @throws IMPException the IMP exception
   */
  public void deleteOnExit(String strFileDir) throws IMPException {
    try {
      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
      WebResource webResource = impEnoClient.getIMPServiceWebResource("deleteDirectory");
      MultivaluedMapImpl params = new MultivaluedMapImpl();
      params.add("FileDir", strFileDir);
      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      if (response.getStatus() != 200) {
        throw new IMPException("Failed: " + response.getStatus());
      }
    } catch (ClientHandlerException | UniformInterfaceException exp) {
      log.error("Exception in getLatestSpecVersion: ", exp);
      throw new IMPException(exp.getMessage());
    }
  }
  
  /**
   * Checks if is object available.
   *
   * @param strObjectName the str object name
   * @return the string
   * @throws IMPException the IMP exception
   */
  public String isObjectAvailable(String strObjectName) throws IMPException {
    String strReturn = "";
    IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
    try {
      WebResource webResource = enoClient.getIMPServiceWebResource("ObjectExists");
      // Pass multiple Query Params
      MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
      queryParams.add("ObjectName", strObjectName);

      ClientResponse response = webResource.queryParams(queryParams).accept(MediaType.TEXT_PLAIN)
          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
      org.codehaus.jettison.json.JSONObject retJson =
          new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException("Failed : HTTP error code : " + response.getStatus());
      }
      strReturn = (String) retJson.get("message");
    } catch (ClientHandlerException | UniformInterfaceException | JSONException e) {
      IMPLog.error("Exception in object Avaialability: " + e);
      throw new IMPException(e.getMessage());
    }
    return strReturn;
  }
  
  /**
   * Execute post prepare sa.
   *
   * @param strIPID the str IPID
   * @param sIPDir the s IP dir
   * @return the int
   * @throws IMPException the IMP exception
   */
  public int executePostPrepareSa(String strIPID, String sIPDir) throws IMPException {
    IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
    int iReturn = 1;
    try {
      WebResource webResource = impEnoClient.getIMPServiceWebResource("preparesaPostProcess");
      com.sun.jersey.api.representation.Form formData =
          new com.sun.jersey.api.representation.Form();

      formData.putSingle("IPID", strIPID);
      formData.putSingle("UserName", IMPCommon.getImpUser());
      formData.putSingle("IPDIR", sIPDir);

      ClientResponse response = webResource.accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
      IMPLog.trace("Prepare-Sa PostProcess Response status: " + response.getStatus());
      if (response.getStatus() != 200) {
        throw new IMPException("Post process operation failed: " + response.getStatus());
      } else {
        iReturn = 0;
      }
    } catch (ClientHandlerException | UniformInterfaceException ie) {
      throw new IMPException(ie);
    }
    return iReturn;
  }
  
  /**
   * Added for SWIMP-39: verify-ip should be logged in the CLI history start 
   * Execute post verify ip.
   *
   * @param strIPID the str IPID
   * @param sIPDir the s IP dir
   * @return the int
   * @throws IMPException the IMP exception
   */
   //Modified for SWIMP-136
  public int executePostVerifyIP(String sVerifyID, String sGDSPath, String sProjectName, String sIPIDs, String sENV, String sProjectType, String strDLCOUTCDL, String strDLCOUTOAS, String ipScoreResultsOutput, String strLLCOASOutput) throws IMPException {
    IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
    int iReturn = 1;
    try {
    	IMPLog.trace("verify-ip PostProcess Response status: ");
    	WebResource webResource = impEnoClient.getIMPServiceWebResource("verifyipPostProcess");
    	com.sun.jersey.api.representation.Form formData =
          new com.sun.jersey.api.representation.Form();

    	formData.putSingle("VerifyID", sVerifyID);
    	formData.putSingle("UserName", IMPCommon.getImpUser());
    	formData.putSingle("GDSPath", sGDSPath);
    	//Added for SWIMP-136
    	formData.putSingle("ProjectName", sProjectName);
    	formData.putSingle("IPIds", sIPIDs);
    	formData.putSingle("ENV", sENV);
    	formData.putSingle("ProjectType", sProjectType); //Added for SWIMP-31:P2
		formData.putSingle("DLCOutForCDL", strDLCOUTCDL);
		formData.putSingle("DLCOutForOAS", strDLCOUTOAS);
		formData.putSingle("ipScoreResultsOutput", ipScoreResultsOutput);
		formData.putSingle("strLLCOASOutput", strLLCOASOutput);
    	ClientResponse response = webResource.accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
    	IMPLog.trace("verify-ip PostProcess Response status: " + response.getStatus());
    	if (response.getStatus() != 200) {
        throw new IMPException("verify-ip Post process operation failed: " + response.getStatus());
    	} else {
        iReturn = 0;
    	}
    	} catch (ClientHandlerException | UniformInterfaceException ie) {
      throw new IMPException(ie);
    }
    return iReturn;
  }
  
public  Map<String, Object> validateDownload(String sEvent, String ipId, String sIPbranch, String sTag, String sForProject, String sFoundry,
			String sTechnologyProcessNode, String sTechnologySubProcess, String sSubscriptionUser)
			throws IMPException, IOException {
		String sRtnMessage = "";
		Map<String, Object> strReturnMap;
		IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		try {
			WebResource webResource = enoClient.getIMPServiceWebResource("preDownload");
			MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
			queryParams.add("ipId", ipId);
			queryParams.add("ipBranch", sIPbranch);
			queryParams.add("ipTag", sTag);
			queryParams.add("forProject", sForProject);
			queryParams.add("foundry", sFoundry);
			queryParams.add("processNode", sTechnologyProcessNode);
			queryParams.add("subProcess", sTechnologySubProcess);
			queryParams.add(IMP_CONST_U_NAME, getUserFromCLI());
			queryParams.add(IMP_CONST_EVENT, sEvent);
			queryParams.add(IMP_ENV, IMP_CLI_ENV);
			//Added for SWIMP-166
			queryParams.add(IMP_SUBSCRIPTIONUSER, sSubscriptionUser);

			ClientResponse response = webResource.queryParams(queryParams).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			JSONObject retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			ObjectMapper mapper = new ObjectMapper();
			strReturnMap = mapper.readValue(retJson.toString(), new TypeReference<Map<String, Object>>() {
			});
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + sRtnMessage);
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			exp.printStackTrace();
			throw new IMPException("Exception in isIPOwner:", exp);
		}
		return strReturnMap;
	}
  
  
  
  /**
   * Checks whether user can run verify ip on SoC at Fabrication state
   *
   * @param sProjectName the SoC name
   * @param strDryRun the dry run
   * @return the string
   * @throws IMPException the IMP exception
 * @throws IOException 
 * @throws JsonMappingException 
 * @throws JsonParseException 
   */
public Map<String, Object> checkForVerifyIPRun(String sProjectName, String sTag, String sWaterMarks) throws IMPException, IOException {
	String sRtnMessage = "";
	Map<String, Object> strReturnMap = null;
	try {
		IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
		WebResource webResource = impEnoClient.getIMPServiceWebResource("checkForVerifyIPRun");
		MultivaluedMapImpl params = new MultivaluedMapImpl();
		params.add("ProjectName", sProjectName);
		params.add("Tag", sTag);
		params.add("WaterMarks", sWaterMarks);
		ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
				.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
		org.codehaus.jettison.json.JSONObject retJson = new org.codehaus.jettison.json.JSONObject(
				response.getEntity(String.class));
		ObjectMapper mapper = new ObjectMapper();
		strReturnMap = mapper.readValue(retJson.toString(), new TypeReference<Map<String, Object>>() {
		});
		if (response.getStatus() != 200) {
			throw new IMPException(strServerError + sRtnMessage);
		}
	} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
		log.error("Exception in checkForVerifyIPRun: ", exp);
		throw new IMPException(exp.getMessage());
	}
	return strReturnMap;
}
  //Added for SWIMP-87: Starts
  /**
   * Gets the unique IPPrefix value from platform
   *
   * @param string IPName
   * @return the unique IPPrefix
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject getIPPrefix(String sIPID) throws IMPException {
	    org.codehaus.jettison.json.JSONObject retJson = null;
	        try {
	          IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
	          WebResource webResource = impEnoClient.getIMPServiceWebResource("getIPPrefix");

	          MultivaluedMapImpl params = new MultivaluedMapImpl();
	          params.add("IPID", sIPID);
	          ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
	              .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
	          retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
	          if (response.getStatus() != 200) {
	            throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
	          }
	        } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
	          throw new IMPException("Exception in gettingIPPrefix:", exp);
	        }
	        return retJson;
	      }
  //Added for SWIMP-87: Ends

  //Added for SWIMP-154:Starts
  /**
   * Gets the IP and its revision details for the watermark
   *
   * @param string sWatermark the watermark string
   * @return the IP and its revision details
   * @throws IMPException the IMP exception
   */
  public org.codehaus.jettison.json.JSONObject getIPRevisionforWatermark(String sWatermark)
	      throws IMPException {
	    org.codehaus.jettison.json.JSONObject retJson;
	    try {
	      IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
	      WebResource webResource = impEnoClient.getIMPServiceWebResource("getIPRevisionForWatermark");

	      MultivaluedMapImpl params = new MultivaluedMapImpl();
	      params.add("WATERMARK", sWatermark);
	      ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
	          .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
	      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
	      if (response.getStatus() != 200) {
	        throw new IMPException(strServerError + response.getStatus());
	      }
	    } catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
	      throw new IMPException("Exception in getIPRevisionforWatermark:", exp);
	    }
	    return retJson;
	  }
//Added for SWIMP-154:S Ends
  
	// Added for SWIMP-56:Starts
	/**
	 * Gets the SoC or IP details for the SoC or IP ID
	 *
	 * @param string sIPorSOCName the SoC/IP ID string
	 * @return the SoC/IP Info details
	 * @throws IMPException the IMP exception
	 */
	public org.codehaus.jettison.json.JSONObject getInfoOfIPSOC(String strResourceName,MultivaluedMapImpl params)
			throws IMPException {

		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource(strResourceName);
			ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException("getting info failed: " + response.getStatus());
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException ie) {
			throw new IMPException(ie);
		}
		return retJson;
	}
	// Added for SWIMP-56:Ends
	
	
	//Added for SWIMP-222:Starts
	/**
	 * Gets the WaterMark details for the IP product with corresponding revision
	 *
	 * @param string
	 *            sIPName the IPProduct Name string
	 * @param string
	 *            sTag the RevisionTag Name string
	 * @return the Watermark details
	 * @throws IMPException
	 *             the IMP exception
	 */
	public org.codehaus.jettison.json.JSONObject getWaterMarkString(String sIPName, String sTag) throws IMPException {
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("getWaterMarkValues");

			MultivaluedMapImpl params = new MultivaluedMapImpl();
			params.add(IMP_CONST_IP_NAME, sIPName);
			params.add("Tag", sTag);
			ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in getWaterMarkString:", exp);
		}
		return retJson;
	}
	//Added for SWIMP-222:Ends	
	
	
	//Added for SWIMP-262: Starts
	/**
	 * Checks the access for Enovia Objects and gets the access return code
	 *
	 * @param sUserName
	 * @param sObjectType
	 * @param sObjectName
	 * @param sCommand
	 * @param sEvent
	 * @return JSONObject
	 * @throws IMPException the IMP exception
	 */
	public org.codehaus.jettison.json.JSONObject checkAccessForObject(String sUserName, String sObjectType, String sObjectName,
			String sCommand, String sEvent) throws IMPException {
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("checkAccessForObject");

			MultivaluedMapImpl params = new MultivaluedMapImpl();
			params.add(IMP_CONST_U_NAME, sUserName);
			params.add(IMP_CONST_OBJECTTYPE, sObjectType);
			params.add(IMP_CONST_OBJECTNAME, sObjectName);
			params.add(IMP_CONST_COMMAND, sCommand);
			params.add(IMP_CONST_EVENT, sEvent);
			params.add(IMP_CONST_SPECVERSION, IMP_CONST_TYPE_IMPDTREESPEC.equals(sObjectType) ? "*" : "");

			ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(
					response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError);
			}
			
			if(IMP_CONST_TYPE_IMPDTREESPEC.equals(sObjectType)) {
				Utility.setStrSFTPHost(retJson.get("canonical").toString());
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in checkAccessForObject:", exp);
		}
		return retJson;
	}
	//Added for SWIMP-262: Ends


	//Added for SWIMP-425: Starts
	/**
	 * Method is for getting technology stack values for input IP
	 *
	 * @param sIPID, IPID
	 * @return JSONObject
	 * @throws IMPException the IMP exception
	 */
	public org.codehaus.jettison.json.JSONObject getTechStacks(String sIPID) throws IMPException {
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("getIPTechStackValues");

			MultivaluedMapImpl params = new MultivaluedMapImpl();
			params.add("IPName", sIPID);
			ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in getTechStacks:", exp);
		}
		return retJson;
	}
	
		public org.codehaus.jettison.json.JSONObject getSoCTechStacks(String sSOCID) throws IMPException {
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("getSoCTechStackValues");
			MultivaluedMapImpl params = new MultivaluedMapImpl();
			params.add("SOCNAME", sSOCID);
			ClientResponse response = webResource.queryParams(params).accept(MediaType.TEXT_PLAIN)
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in getSoCTechStacks:", exp);
		}
		return retJson;
	}
	
	
	public void setDLCAttributesToVerifyid(String sVerifyid, String iDCLCDLResult, String strDCLCDLOutput, String iDCLOASResult, String strDCLOASOutput) throws IMPException {
		
		try {
			com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("setDLCAttributesToVerifyid");
			formData.putSingle("sVerifyid", sVerifyid);
			formData.putSingle("iDCLCDLResult", iDCLCDLResult);
			formData.putSingle("strDCLCDLOutput", strDCLCDLOutput);
			formData.putSingle("iDCLOASResult", iDCLOASResult);
			formData.putSingle("strDCLOASOutput", strDCLOASOutput);
			ClientResponse response = webResource.accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
			if (response.getStatus() != 200) {
                throw new IMPException("verify-ip Post process operation failed: " + response.getStatus());
			}
		} catch (IMPException exp) {
			throw new IMPException("Exception in setDLCAttributesToVerifyid:", exp);
		}
	}
	
	
	public void setLLCAttributesToVerifyid(String sVerifyid, String iLLCOASResult, String strLLCOASOutput) throws IMPException {
		
		try {
			com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("setLLCAttributesToVerifyid");
			formData.putSingle("sVerifyid", sVerifyid);
			formData.putSingle("iLLCOASResult", iLLCOASResult);
			formData.putSingle("strLLCOASOutput", strLLCOASOutput);
			ClientResponse response = webResource.accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
			if (response.getStatus() != 200) {
                throw new IMPException("verify-ip Post process operation failed: " + response.getStatus());
			}
		} catch (IMPException exp) {
			throw new IMPException("Exception in setLLCAttributesToVerifyid:", exp);
		}
	}
	
	
	public void setIpScoreAttributesToVerifyid(String sVerifyid, String sIpScoreResults) throws IMPException {
		
		try {
			com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("setIpScoreAttributesToVerifyid");
			formData.putSingle("sVerifyid", sVerifyid);
			formData.putSingle("mIpScoreOutput", sIpScoreResults);
			ClientResponse response = webResource.accept("application/json")
          .header("authorization", "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
			
			if (response.getStatus() != 200) {
                throw new IMPException("verify-ip Post process operation failed: " + response.getStatus());
			}
		} catch (IMPException exp) {
			throw new IMPException("Exception in setIpScoreAttributesToVerifyid:", exp);
		}
	}
	
	
	//Added for SWIMP-425:Ends

	// Added for SWIMP-31
	public org.codehaus.jettison.json.JSONObject getHIPData(Map<String, String> mWMStrings, String sIPID) throws IMPException { //Modified for SWIMP-568
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("getHIPStructureBasedonWMStrings");

			MultivaluedMapImpl params = new MultivaluedMapImpl();

			com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();

			formData.putSingle("WMStrings", Utility.convertWMMapToString(mWMStrings));
			formData.putSingle("IPID", sIPID); //Added for SWIMP-568
			ClientResponse response = webResource.queryParams(params).accept("application/json")
					.header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class))
					.getJSONObject("wmReturnData");
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in getHIPData:   ", exp);
		}
		return retJson;
	}
	



//Added for SWIMP-883: Start

@SuppressWarnings({"unchecked"})
public Map<String, Object> downloadSsgqiCfgFile(String ipName, String revision, String targetDir) throws IMPException {

    ClientResponse response = null;

    final Map<String, Object> result = new LinkedHashMap<>();
    result.put("ssgqiCfgCheckoutDir", targetDir); // local dir (what caller expects)

    String serverCheckoutDir = null;
    String fileName = null;

    try {
        java.nio.file.Files.createDirectories(java.nio.file.Paths.get(targetDir));

        // 1) Checkout metadata from server
        final Form formData = new Form();
        formData.add(IMP_CONST_IP_NAME, ipName);
        formData.add(STR_TAG, revision);
        formData.add("UserName", IMPCommon.getImpUser());

        response = getIMPServiceWebResource("checkoutSSGQICfgYaml")
                .accept("application/json")
                .type("application/x-www-form-urlencoded")
                .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
                .post(ClientResponse.class, formData);

        final int httpStatus = response.getStatus();
        final String body;
        try {
            body = response.getEntity(String.class);
        } catch (Exception e) {
            throw new IMPException("checkout response read failed", e);
        }

        if (httpStatus != 200) {
            throw new IMPException("SWIMP-883: checkout failed HTTP=" + httpStatus + " body=" + body);
        }

        final org.codehaus.jettison.json.JSONObject json =
                new org.codehaus.jettison.json.JSONObject(body == null ? "{}" : body);

        final String status = json.optString("ssgqiCfgStatus", "ERROR");
        final String message = json.optString("message", "");
        serverCheckoutDir = json.optString("ssgqiCfgCheckoutDir", "");
        fileName = json.optString("ssgqiCfgFileName", "");

        result.put("ssgqiCfgStatus", status);
        result.put("message", message);
        result.put("ssgqiCfgFileName", fileName);
        result.put("serverCheckoutDir", serverCheckoutDir);

        if (!"Success".equals(status) || org.apache.commons.lang.StringUtils.isBlank(fileName)) {
            return result;
        }

        final java.io.File localTargetFile = new java.io.File(targetDir, fileName);

        // 2) Attempt A: local/NFS copy
        if (org.apache.commons.lang.StringUtils.isNotBlank(serverCheckoutDir)) {
            final java.io.File serverFile = new java.io.File(serverCheckoutDir, fileName);
            if (serverFile.isFile()) {
                java.nio.file.Files.copy(
                        serverFile.toPath(),
                        localTargetFile.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );

                if (localTargetFile.isFile() && localTargetFile.length() > 0) {
                    result.put("savedFile", localTargetFile.getAbsolutePath());
                    result.put("downloadMethod", "local_copy");

                    // Cleanup (best-effort, non-blocking)
                    try { deleteOnExit(serverCheckoutDir); } catch (Exception e) { IMPLog.warn("SWIMP-883: cleanup failed: " + e.getMessage()); }

                    return result;
                }
            }
        }

        // 3) Attempt B: SFTP
        if (org.apache.commons.lang.StringUtils.isBlank(serverCheckoutDir)) {
            result.put("downloadMethod", "none");
            result.put("downloadMessage", "No serverCheckoutDir returned");
            return result;
        }

        com.jcraft.jsch.Session session = null;
        com.jcraft.jsch.Channel channel = null;
        com.jcraft.jsch.ChannelSftp sftp = null;

        try {
            // Decode password (raw/base64/ENC(...))
            final String passRaw = IMP_CLI_SERVER_PASS;
            final String s = (passRaw == null) ? "" : passRaw.trim();
            final String password;

            if (s.isEmpty()) {
                password = "";
            } else if (s.startsWith("ENC(") && s.endsWith(")")) {
                password = s; // TODO: replace with decrypt utility
            } else {
                String decodedCandidate;
                try {
                    byte[] decoded = java.util.Base64.getDecoder().decode(s);
                    decodedCandidate = new String(decoded, java.nio.charset.StandardCharsets.UTF_8);
                } catch (Exception ignore) {
                    decodedCandidate = null;
                }

                if (decodedCandidate != null && !decodedCandidate.isEmpty()) {
                    int printable = 0;
                    for (int i = 0; i < decodedCandidate.length(); i++) {
                        char c = decodedCandidate.charAt(i);
                        if (c >= 32 && c <= 126) printable++;
                    }
                    double ratio = (double) printable / (double) decodedCandidate.length();
                    password = (ratio > 0.85) ? decodedCandidate : s;
                } else {
                    password = s;
                }
            }

            final String host = IMP_CLI_SERVER_HOST;
            final int port = 22;
            final String user = IMP_CLI_SERVER_USER;

            final com.jcraft.jsch.JSch jsch = new com.jcraft.jsch.JSch();
            session = jsch.getSession(user, host, port);

            final java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking", "no");
            config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
            session.setConfig(config);

            session.setPassword(password);
            session.connect(30_000);

            channel = session.openChannel("sftp");
            channel.connect(30_000);
            sftp = (com.jcraft.jsch.ChannelSftp) channel;

            sftp.cd(serverCheckoutDir);
            sftp.get(fileName, localTargetFile.getAbsolutePath());

            result.put("downloadMethod", "sftp");

            if (localTargetFile.isFile() && localTargetFile.length() > 0) {
                result.put("savedFile", localTargetFile.getAbsolutePath());

                // Cleanup (best-effort, non-blocking)
                try { deleteOnExit(serverCheckoutDir); } catch (Exception e) { IMPLog.warn("cleanup failed: " + e.getMessage()); }

                return result;
            }

            result.put("downloadMessage", "SFTP completed but file missing/empty");
            return result;

        } catch (Exception e) {
            result.put("downloadMethod", "sftp");
            result.put("downloadMessage", "SFTP download failed: " + e.getMessage());
            return result; // non-blocking

        } finally {
            try { if (sftp != null) sftp.exit(); } catch (Exception ignore) {}
            try { if (channel != null) channel.disconnect(); } catch (Exception ignore) {}
            try { if (session != null) session.disconnect(); } catch (Exception ignore) {}
        }

    } catch (com.sun.jersey.api.client.ClientHandlerException
             | com.sun.jersey.api.client.UniformInterfaceException
             | org.codehaus.jettison.json.JSONException e) {
        throw new IMPException("Failed to download SSGQI config file", e);
    } catch (Exception e) {
        throw new IMPException("Failed to download SSGQI config file", e);
    } finally {
        if (response != null) {
            try { response.close(); } catch (Exception ignore) {}
        }
    }
}

public void setSSGQIAttributesToVerifyid(String sVerifyid,
                                        String iSSGQIResult,
                                        String strSSGQIOutput) throws IMPException {

    try {
        com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
        IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();

        WebResource webResource = impEnoClient.getIMPServiceWebResource("setSSGQIAttributesToVerifyid");

        formData.putSingle("sVerifyid", sVerifyid);
        formData.putSingle("iSSGQIResult", iSSGQIResult);
        formData.putSingle("strSSGQIOutput", strSSGQIOutput);

        ClientResponse response = webResource.accept("application/json")
            .header("authorization", "Basic " + IMP_AUTH_USER)
            .post(ClientResponse.class, formData);

        if (response.getStatus() != 200) {
            throw new IMPException("verify-ip Post process operation failed: " + response.getStatus());
        }

    } catch (IMPException exp) {
        throw new IMPException("Exception in setSSGQIAttributesToVerifyid:", exp);
    }
}


// ==================== Modified executeCSKValidateBOM (added verifyId) ====================
/**
 * Execute CSK Validate BOM to convert Excel to JSON
 *
 * @param excelPath Path to Excel file on server
 * @param jsonPath Path where JSON output should be saved (still passed, but file may not be written)
 * @param sheetName Sheet name to process
 * @param verifyId ID of the verify object; if provided, the JSON is stored in its attribute
 * @return true if successful
 * @throws IMPException
 */
public boolean executeCSKValidateBOM(String excelPath, String sheetName, String verifyId) throws IMPException {
    try {
        IMPLog.info("Executing CSK Validate BOM for Excel: " + excelPath);
        WebResource webResource = getIMPServiceWebResource("executeCSKValidateBOM");
        com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
        formData.add("excelPath", excelPath);
        formData.add("sheetName", sheetName != null ? sheetName : "Sheet1");
        if (verifyId != null && !verifyId.trim().isEmpty()) {
            formData.add("verifyId", verifyId);
        }

       
        ClientResponse response = webResource
            .accept(MediaType.APPLICATION_JSON)
            .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
            .post(ClientResponse.class, formData);
       
        if (response.getStatus() == 200) {
            String responseBody = response.getEntity(String.class);
            JSONObject jsonResponse = new JSONObject(responseBody);
            if (jsonResponse.has("status") && "Success".equals(jsonResponse.getString("status"))) {
                IMPLog.info("Successfully converted Excel to JSON" + 
                            (verifyId != null ? " and stored in attribute of " + verifyId : ""));
                return true;
            } else {
                String errorMsg = jsonResponse.has("message") ? jsonResponse.getString("message") : "Unknown error";
                IMPLog.error("Failed to convert Excel to JSON: " + errorMsg);
                return false;
            }
        } else {
            IMPLog.error("Failed to execute CSK Validate BOM. HTTP Status: " + response.getStatus());
            return false;
        }
       
    } catch (Exception e) {
        IMPLog.error("Exception in executeCSKValidateBOM: " + e.getMessage());
        throw new IMPException("Exception in executeCSKValidateBOM: " + e.getMessage(), e);
    }
}



//Added for SWIMP-883: End




	//Added for SWIMP-884 to get SoC details for config file
	public org.codehaus.jettison.json.JSONObject getSoCDetails(String sSOCID) throws IMPException {
		org.codehaus.jettison.json.JSONObject retJson;
		try {
			IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
			WebResource webResource = impEnoClient.getIMPServiceWebResource("getSocDetails");
			MultivaluedMapImpl params = new MultivaluedMapImpl();
			params.add("socId", sSOCID);
			ClientResponse response = webResource.queryParams(params).header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).get(ClientResponse.class);
			retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
			if (response.getStatus() != 200) {
				throw new IMPException(strServerError + retJson.getString(IMP_MESSAGE));
			}
		} catch (ClientHandlerException | UniformInterfaceException | JSONException exp) {
			throw new IMPException("Exception in getSoCDetails:", exp);
		}
		return retJson;
	}

}
