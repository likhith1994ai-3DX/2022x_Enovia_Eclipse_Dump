
/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : IMPRESTfulServiceImpl.java
 * DESCRIPTION  : Enovia RESTful Web Service.
 * 
 *              
 * CREATED      : 17-August-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * HISTORY:
 * 
 * Name                     Modified Date                 Description
 * 
 * TECHMAHINDRA             17-Aug-2016                   Initial version.
 * Sai Prasad               14-Dec-2016                   Modified getDTreeSpecs method for the bug fix 582
 * Sai Prasad               21-Feb-2017                   Added logger to write the error to the console and catalina.out. Bug 995
 * KrishnaD                 08-Aug-2017                	  Added for Watermarking Multiple GDS files SWIMP-1
 * Udaya                    11-Aug-2017					  Added for SWIMP-39
 * Abhay                    15-SEP-2017                   Modified methods postProcessPublish, getWaterMarkGDSFileInfo, getAttributesForQAFailures, createWaterMarkString, getWaterMarkString and getListOfWaterMarks for SWIMP-1 changing name of attribute
 * Madhusmita M             25-Sep-2017                   Added for SWIMP-53
 * Mahammed Irshad			24-Aug-2018					  Added the method getWaterMarkValuesForIPProduct for SWIMP-222
 * Manish					25-JAN-2019					  Modified/Added code for SWIMP-321
 * Mahammed Irshad K S		22-Nov-2018					  Added methods hasAccessToEnoviaObject and isUsersAvailable for SWIMP-262
 * Mahammed Irshad K S		10-Dec-2018					  Removed the methods isDTreeSpecOwner, isIPOwnerOrCoOwner and isSOCAvailable as part of code clean up.
 * Mahammed Irshad K S		09-Jan-2019					  Modified the method isUsersAvailable for SWIMP-262.
 * Manish					25-JAN-2019					  Modified/Added code for SWIMP-284
 * Mahammed Irshad K S		04-May-2019					  Modified the method getIPDataforQAValidation and added constants for SWIMP-359
 * Manish					08-May-2019					  Replaced deprecated method authenticate with getAuthenticatedContext.
 * Mahammed Irshad K S		28-Jan-2020					  Added methods getTechStacksForIP and getIPProductAttributeValues for SWIMP-425
 * Mahammed Irshad K S		28-Jan-2020					  Modified method hasAccessToEnoviaObject and added constants for SWIMP-425
 * Mahammed Irshad K S		12-May-2020					  Modified method verifyipPostProcess, socProjectVerificationStatus and added constants for SWIMP-322
 * Mahammed Irshad K S		14-Jul-2020					  Modified method isPreApproveList for SWIMP-31
 * Mahammed Irshad K S		01-Dec-2020					  Modified method checkForVerifyIPRun and convertWMStringToMap for SWIMP-31 (Phase-2)
 * Mahammed Irshad K S		18-Mar-2021					  Added constants and modified methods checkForVerifyIPRun and getHIPStructureBasedonWMStrings for SWIMP-564
 * Mahammed Irshad K S		15-May-2021					  Modified method createVerificationMetaData and added a constant for SWIMP-531 (Change Request)
 * Milind Chavan		    07-June-2022	              Modified method getIPIDs to handle multi-value issue	for ITOPS-1253
 * Pavan Kosuru		        24-June-2022	              Change the logger logic from Log4j to JUL(java.util.logging) 1)logger.debug is replaced with logger.info 2) logger.error is replaced with logger.log	for ITOPS-1289 *------------------------------------------------------------------------------------------------------------------------------------------
 */
package com.broadcom.imp.platform.rest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Map.Entry;
import java.util.TreeMap;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Form;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;

import com.broadcom.imp.platform.rest.exception.IMPServiceException;
import com.dassault_systemes.platform.restServices.RestService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.okta.sdk.clients.AuthApiClient;
import com.okta.sdk.exceptions.ApiException;
import com.okta.sdk.framework.ApiClientConfiguration;
import com.okta.sdk.models.auth.AuthResult;

import matrix.db.BusinessObject;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringList;


/**
 * The Class IMPRESTfulServiceImpl.
 * 
 * Base class for IMP RESTful Service implementation
 */
public class IMPRESTfulServiceImpl extends RestService {
	
  private static String strIPOwner = "IP_OWNER";
  private static String strBusinessUnit = "bu";
  private static String strTechnologyStack = "technology_stacks";
  private static String strFoundry = "foundry";
  private static String strNode = "node";
  private static String strSubProcess = "sub_process";
  private static String strMetalStack = "metal_stack";
  private static String strPolyOrientation = "poly_orientation";
  private static String strQaValInput = "QA_VAL_INPUT";
  private static String strMessage = "message";
  private static String strError = "error";     //Added for SWIMP-369
  static final String OUTMSG = "out-message";
  private static String strContentType = "Content-Type";
  private static String strMediaType = "application/json";
  
  private static String strAllRevisions = "IP_REVISIONS";
  static final String IPNAME = "IPName";
  static final String SOCNAME = "SOCNAME";
  static final String USRNAME = "UserName";
  static final String VAULT_SERV_PROD = "vault_eServiceProduction";
  static final String SERV_PROD ="eService Production";
  static final String IMP_ENV = "IMP_ENV";
  static final String EXEC_SUCC  = "Execution Successful";
  //Added for the SWIMP-262: Starts
  static final String CONST_PROJECTNAME = "ProjectName";
  static final String CONST_EVENT = "Event";
  static final String CONST_COMMAND = "Command";
  static final String CONST_OBJECTTYPE = "ObjectType";
  static final String CONST_OBJECTNAME = "ObjectName";
  static final String TYPE_IMP_IPPRODUCT = "IMP_IPProduct";
  static final String TYPE_IMP_SOC = "IMP_SoC";
  //Added for SWIMP-827 : New imp query for SoCs in Fabrication state : STARTS
  static final String CONST_WILDCARD_FOR_SFR = "*";
  //Added for SWIMP-827 : New imp query for SoCs in Fabrication state : ENDS
  static final String TYPE_IMP_DTREESPEC = "IMP_DirectoryTreeSpec";
  static final String CONST_SPECVERSION = "SpecVersion";
  //Added for the SWIMP-262: Ends
  
  static final String REL_UTIL_JPO = "IMP_IPReleaseUtil";
  static final String IPSEARCH_UTIL_JPO = "IMP_IPSearchUtil";
  static final String IPVERIFICATION_JPO = "IMP_IPVerification";
  static final String CLI_QRY_SERVICE_JPO = "IMP_CLI_QueryServices";
  static final String FABRICATION_APPRVL_JPO = "IMP_FabricationApprovals";
  static final String IPPRODUCT_UTIL_JPO = "IMP_IPProductUtil";
  static final String IMP_UTILITY_JPO = "IMP_Utility"; //Added for SWIMP-322
  
  static final String IPPRODUCT_TYPE = "type_IMP_IPProduct";
  static final String SOC_TYPE ="type_IMP_SoC";
  static final String PERSON_TYPE = "type_Person";
  static final String DTREE_SPEC_TYPE ="type_IMP_DirectoryTreeSpec";
  static final String WMSTR_TYPE = "type_IMP_WaterMarkString";
  static final String IP_BRANCH_TYPE = "type_IMP_Branch";
  
  static final String OBJ_ID =  "objectId";
  static final String IPTAG = "IMP_IPTag";
  static final String IPTAG_ATTR = "attribute[IMP_IPTag]";
  static final String IPID_ATTR = "id";
  static final String IPNAME_ATTR = "name";
  
  static final String UTILITY_JPO = "IMP_Utility";//Added for SWIMP-136
  static final String strPath = "sPath";
  static final String strPubDocs = "sPubDocs";
  //Added for SWIMP-56:Starts
  static final String CONTEXT = "Context";
  static final String OBJECTLIST = "objectList";
  static final String IMPCRON_JPO= "IMP_Cron_Job";
  static final String STR_SUBPROCESS = "IMP_SubProcess";
  static final String STR_PRODUCTDIVISION = "IMP_ProductDivision";
  static final String STR_IMPIPNAME = "sIMPIPName";
  static final String STR_IMPFOUNDRY = "sIMPFoundry";
  static final String STR_IMPPROCESSNODE = "sIMPProcessNode";
  static final String STR_IMPSUBPROCESS = "sIMPSubProcess";
  static final String STR_IMPMETALSTACK = "sIMPMetalStack";
  static final String STR_IMPPRODUCTDIVISION = "sIMPProductDivision";
  static final String STR_IMPIPSOURCE = "sIPSource";
  static final String STR_VENDOR = "sVendor";
  //Added for SWIMP-56:Ends
  private static Logger logger = Logger.getLogger(IMPRESTfulServiceImpl.class.getName());
  private static final List<String> LIST_REMOVE_ATTRIBUTES_FROM_PROTECTED_SOC = new ArrayList<>(Arrays.asList("co_owners","ip_subscriptions","replication_location","user_access","user_access_requests","soc_ip_verifications","quality_classes","bu_access","bu_access_requests"));
  
  //Added for SWIMP-166 - s
  static final String PROJECT = "Project";
  static final String SUBSCRIPTIONUSER = "SubscriptionUser";
  //Added for SWIMP-166 - e
  //Added for SWIMP-284 - s
  static final String PROJECTTYPE = "ProjectType";
  static final String PROJECTID = "ProjectId";
  //Added for SWIMP-284 - e
  //Added for SWIMP-89:Starts
  static final String IMP_TECHSTACKUTIL_JPO = "IMP_TechStackUtil";
  //Added for SWIMP-89:Ends
  private static String strIOType = "io_type"; // Added for SWIMP-281
  
//Added for SWIMP-267 - s
  static final String IMP_UPDATEPERSONDETAILS_JPO = "IMP_UpdatePersonDetails";
  //Added for SWIMP-267 - e

  //Added for SWIMP-359 - s
  private static String strIPAccessControlProtection = "IP_ACCESS_CONTROL_PROTECTION";
  private static String strIPPrefixLength = "IP_PREFIX_LENGTH";
  //Added for SWIMP-359 - e

  //Added for SWIMP-425: Starts
  private static final String ATTRIBUTE_IMP_IPSOURCE = "attribute[IMP_IPSource]";
  private static final String ATTRIBUTE_IMP_IPTYPE = "attribute[IMP_IPType]";
  //Added for SWIMP-425: Ends
  
  //Added for SWIMP-322: Starts
  private static final String RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS = "relationship_IMP_VerifyRunDetectedIPs";
  //Added for SWIMP-322: Ends

  //Added for SWIMP-31: Starts
  private static final String ATTRIBUTE_IMP_PRODUCTTYPE = "attribute[IMP_ProductType]";
  private static final String ATTRIBUTE_IMP_PRODUCTTYPE_RANGE_BLOCKIP = "Block IP";
  private static final String STRING_EQUALS_WITHQUOTE = " == '";
  private static final String STRING_IPIDS = "IPIds";
  private static final String STRING_VERIFYID = "VerifyID";
  private static final String SYMBOL_CARET = "^";
  private static final String SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION = "attribute[IMP_AllowIPVerification]";
  private static final String STRING_WMSTRINGS = "WMStrings";
  //Added for SWIMP-31: Ends

  //Added for SWIMP-564: Starts
  private static final String KEY_OPERATION = "Operation";
  private static final String EVENT_VERIFYHIP = "Verify-HIP";
  //Added for SWIMP-564: Ends

  private static final String KEY_DECLARED_USAGE = "DECLARED_USAGE";//Added for SWIMP-531
  private static final String KEY_STR_SOCNAME = "strSoCName"; //Added for SWIMP-570
  private static final String EVENT_QUERY = "Query"; //Added for SWIMP-570
  private static final String KEY_IP_STRUCTURE = "ip_structure"; //Added for SWIMP-570
  private static final String ATTRIBUTE_IMP_LIBRARY = "attribute[IMP_Library]"; //Added for SWIMP-720
  
//Added for SWIMP-827 : New imp query for SoCs in Fabrication state : STARTS
  private static final String STR_WILDCARD_FOR_SFR = "*";
  private static final String STR_NAME = "name";
  private static final String STR_SCHEMANAME = "type";
  private static final String STR_CURRENTSTATE = "current";
  private static final String STR_STATE_FABRICATION = "Fabrication";
  private static final String STR_OWNER = "owner";
  private static final String STR_FROM_DATE = "fromDate";
  private static final String STR_TO_DATE = "toDate";
  private static final String STR_USERNAME = "User";
  //Added for SWIMP-827 : New imp query for SoCs in Fabrication state : ENDS
  
  //Added for SWIMP-848
  private static final String STR_PROJECTID_KEY="ProjectID";
  private static final String STR_IPPRODUCTID_KEY="IPProductID";
  static final String IMP_IPRELEASEUTIL_JPO = "IMP_IPReleaseUtil";
  //private static final String STR_INCOMPATIBLE_SYMBOL = "!";
  //Added for SWIMP-848
  
  //Added for SWIMP-882
  static final String strSFTPSSGQICfgPath = "sFTPSSGQICfgPath";
  static final String strSFTPSSGQICfgFileName = "sFTPSSGQICfgFileName";
  //Added for SWIMP-882
  
  // Added for SWIMP-883   Start 
  
  static final String STR_SSGQI_CFG_CHECKOUT_DIR = "checkoutDir";
  static final String STR_SSGQI_CFG_FILE_NAME = "fileName";
  static final String STR_SSGQI_CFG_STATUS = "status";
  static final String STR_TAG = "Tag";

//Added for SWIMP-883   END
  /**
   * Instantiates a new IMPRES tful service impl.
   */
  public IMPRESTfulServiceImpl() {
    logger.setLevel(Level.ALL);
  }


  @SuppressWarnings("unchecked")
	private Map<String, Object> getUserDetails(matrix.db.Context context, String sUserName)
			throws  FrameworkException {
		Map<String, Object> hmData = new HashMap<>();
		String sAttrEmailAddress = PropertyUtil.getSchemaProperty(context, "attribute_EmailAddress");
		StringList slPersonDetails = new StringList("attribute[" + sAttrEmailAddress + "]");
		slPersonDetails.add("attribute[IMP_EMP_DISPLAY_NAME]");
		MapList mlPersonList = DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, PERSON_TYPE),
				sUserName, "*", "*", "*", null, false, slPersonDetails);
		if (!mlPersonList.isEmpty())
			hmData = (Map<String, Object>) mlPersonList.get(0);
		return hmData;
	}

  /**
   * Gets the object exist.
   *
   * @param req the req
   * @param sObjName the s obj name
   * @return the object exist
   * @throws IMPServiceException the IMP service exception
   * @throws FrameworkException the framework exception
   */
  @GET
  @Path("/ObjectExists")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getObjectExist(@Context HttpServletRequest req,
      @QueryParam("ObjectName") String sObjName) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    String isExist = "false";
    try (matrix.db.Context context = getAuthenticatedContext(req, false)){ //Modified for 2019x upgrade
      String sWhere = "attribute[IMP_ProductType]=='Block IP'";
      Pattern typePattern =
          new Pattern(PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE));
      typePattern.addPattern(PropertyUtil.getSchemaProperty(context, SOC_TYPE));
      StringList slObjDetails = new StringList(DomainConstants.SELECT_ID);
	  MapList mlObjectList = DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), sObjName,
          "*", "*", "*", sWhere, false, slObjDetails);
      if (!mlObjectList.isEmpty()) {
    	  isExist = "true";
      } else {
              MapList mlSocObjectList = DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, SOC_TYPE), sObjName,
            "*", "*", "*", null, false, slObjDetails);
        isExist = mlSocObjectList.isEmpty() ? "false" : "true";
      }
      returnObj.put(strMessage, isExist);
    } catch (JSONException | FrameworkException ex) {
    	logger.log(Level.SEVERE, ex.getMessage(), ex);
      throw new IMPServiceException(ex);
    } 
   
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  /**
   * Post prepare sa.
   *
   * @param req the req
   * @param form the form
   * @return the response
   * @throws MatrixException the matrix exception
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/preparesaPostProcess")
  public Response postPrepareSa(@Context HttpServletRequest req,
    jakarta.ws.rs.core.Form form) throws Exception {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(req, false)){//Modified for 2019x upgrade
     //String strIPID = form.asMap().getFirst("IPID");
     //String strUserName = form.asMap().getFirst(USRNAME);
     //String strIPDIR = form.asMap().getFirst("IPDIR");
	  String strIPID = form.asMap().getFirst("IPID");
	  String strUserName = form.asMap().getFirst(USRNAME);
	  String strIPDIR = form.asMap().getFirst("IPDIR");
	  
      StringList slObjDetails = new StringList(DomainConstants.SELECT_ID);
      MapList mlIPObjectList = DomainObject.findObjects(context,
          PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), strIPID, "*", "*", "*",
          null, false, slObjDetails);
      if (!mlIPObjectList.isEmpty()) {
        ContextUtil.pushContext(context, strUserName, "",
            PropertyUtil.getSchemaProperty(context, VAULT_SERV_PROD));
        Map mpIPData = (Map) mlIPObjectList.get(0);
        String strObjId = mpIPData.get(DomainConstants.SELECT_ID).toString();
        Map mpData = new HashMap();
        mpData.put("IPID", strObjId);
        mpData.put("COMMENTS", "--ip-id " + strIPID + " --ip-dir " + strIPDIR);
        mpData.put("OPERATION", "prepare-sa");
        JPO.invoke(context, IPVERIFICATION_JPO, null, "updateAuditRecords", JPO.packArgs(mpData));
      }

    } catch (FrameworkException ie) {
      throw new IMPServiceException(ie);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Post Process - IP Publish.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param form the form
   * @param sUserName the s user name
   * @param sEvent the s event
   * @return the response
   * @throws UnknownHostException 
   * @throws JSONException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/ipPublishPostProcess")
  public Response postProcessPublish(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
  		@QueryParam(IPNAME) String sIPName, jakarta.ws.rs.core.Form form,
  		@QueryParam(USRNAME) String sUserName, @QueryParam("Event") String sEvent)
  		throws IMPServiceException, JSONException, UnknownHostException {
    int iAccess = 1;
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    InetAddress sHostName = InetAddress.getLocalHost();
    returnObj.put("canonical", sHostName.getCanonicalHostName());
    Map <String,String> mWMFile = new HashMap<>(); //Added for SWIMP-1
    //Added for SWIMP-113	start  
      HashMap hmUpdateData = new HashMap();
	  //String sPubDocs=form.asMap().getFirst(strPubDocs);
	  //String sPath=form.asMap().getFirst(strPath);
      //Added for SWIMP-882
      String sSFTPSSGQICfgPath = form.asMap().getFirst(strSFTPSSGQICfgPath);
      String sSFTPSSGQICfgFileName = form.asMap().getFirst(strSFTPSSGQICfgFileName);
      if(!StringUtils.isEmpty(sSFTPSSGQICfgFileName)) {
    	  hmUpdateData.put(strSFTPSSGQICfgFileName, sSFTPSSGQICfgFileName);  
      } else {
    	  hmUpdateData.put(strSFTPSSGQICfgFileName, "");  
      }
      if(!StringUtils.isEmpty(sSFTPSSGQICfgPath)) {
    	  hmUpdateData.put(strSFTPSSGQICfgPath, sSFTPSSGQICfgPath);    
      } else {
    	  hmUpdateData.put(strSFTPSSGQICfgPath, "");
      }
      //Added for SWIMP-882
	  String sPubDocs = form.asMap().getFirst(strPubDocs);
	  String sPath = form.asMap().getFirst(strPath);
	  if (!StringUtils.isEmpty(sPubDocs)) {
		  hmUpdateData.put(strPubDocs, sPubDocs);
	  } else{
		  hmUpdateData.put(strPubDocs, "");
	  }
	  if (!StringUtils.isEmpty(sPath)) {
		  hmUpdateData.put(strPath, sPath);
	  } else{
		 hmUpdateData.put(strPath, ""); 
	  }
	//Added for SWIMP-113 end
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      /*
       * Handle any attributes further - add the specific attributes to the map
       */
      String sIsIPPrefixed = form.asMap().getFirst("IMP_IsPrefixed");
      String sGDSVersion = form.asMap().getFirst("IMP_GDSVersion");
      String sQualityClass = form.asMap().getFirst("IMP_QualityClass");
      String sTag = form.asMap().getFirst(IPTAG);
      String sQAStatus = form.asMap().getFirst("IMP_IPQAStatus");
      String sQASummary = form.asMap().getFirst("IMP_IPQASummary");
      String sPublishComments = form.asMap().getFirst("IMP_IPPublishComments");
      String tempmWMFile = form.asMap().getFirst("IMP_IPRevisionWatermark");//Added for SWIMP-1
      String sWmDerivedFrom = form.asMap().getFirst("IMP_WMDerivedFrom");
      //Added for SWIMP-1 for changinge attribute name IMP_IPRevisionWatermark
      mWMFile = convertWMStringToMap(tempmWMFile);//Added for SWIMP-1
      String sPreapproveList = form.asMap().getFirst("IMP_Preapprove");
      String sContxEnv = form.asMap().getFirst(IMP_ENV);
      String sRecommended = form.asMap().getFirst("RecommendedRevision");
      String sDefaultRevision = form.asMap().getFirst("DefaultRevision");
	  String sAlert = form.asMap().getFirst("IMP_Alert");
	  
	  //Added for SWIMP-385 - s
	  String sIMPVersion = form.asMap().getFirst("IMP_Version");
	  String sIMPCommandline = form.asMap().getFirst("IMP_Commandline");
	  String sIMPIPDir = form.asMap().getFirst("IMP_IPDir");
	  String sIMPUsernameDomain = form.asMap().getFirst("IMP_UsernameDomain");
	  //Added for SWIMP-385 - e
	  
	  //Added for SWIMP-31 -s
	  String schildIPsToConnect = form.asMap().getFirst("childIPsToConnect");
	  String sLineageInfo = form.asMap().getFirst("LineageInfo");
	  String sImpMissingProgenyInstanceWarning = form.asMap().getFirst("IMP_MISSING_PROGENY_INSTANCE_WARNING");
	  String sIMPUnknownComponentWatermark = form.asMap().getFirst("IMPUnknownComponentWatermark");
	  String sIsRevisionPublishedAsHIP = form.asMap().getFirst("IsRevisionPublishedAsHIP");
	  //Added for SWIMP-31 -e

	  if (!StringUtils.isEmpty(sIsIPPrefixed)) {
        hmUpdateData.put("IMP_IsPrefixed", sIsIPPrefixed);
      }
      if (!StringUtils.isEmpty(sGDSVersion)) {
        hmUpdateData.put("IMP_GDSVersion", sGDSVersion);
      }
      if (!StringUtils.isEmpty(sQualityClass)) {
        hmUpdateData.put("IMP_QualityClass", sQualityClass);
      }
      if (!StringUtils.isEmpty(sTag)) {
        hmUpdateData.put(IPTAG, sTag);
      }
      if (!StringUtils.isEmpty(sQAStatus)) {
        hmUpdateData.put("IMP_IPQAStatus", sQAStatus);
      }
      if (!StringUtils.isEmpty(sQASummary )) {
        hmUpdateData.put("IMP_IPQASummary", sQASummary);
      }
      if (!StringUtils.isEmpty(sPublishComments)) {
        hmUpdateData.put("IMP_IPPublishComments", sPublishComments);
      }
      //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
      if (mWMFile !=null && !mWMFile.isEmpty()) {
        hmUpdateData.put("IMP_IPRevisionWatermark", mWMFile);
      }
      //Added for SWIMP-849
      if (!StringUtils.isEmpty(sWmDerivedFrom)) {
          hmUpdateData.put("IMP_WMDerivedFrom", sWmDerivedFrom);
        }
      if (!StringUtils.isEmpty(sPreapproveList)) {
        hmUpdateData.put("IMP_Preapprove", sPreapproveList);
      }
      if (!StringUtils.isEmpty(sContxEnv)) {
        hmUpdateData.put(IMP_ENV, sContxEnv);
      }
      if (!StringUtils.isEmpty(sRecommended)) {
          hmUpdateData.put("RecommendedRevision", sRecommended);
      }
      if (!StringUtils.isEmpty(sDefaultRevision)) {
          hmUpdateData.put("DefaultRevision", sDefaultRevision);
      }
	  
	  if (!StringUtils.isEmpty(sAlert)) {
          hmUpdateData.put("IMP_Alert", sAlert);
        }
	  
	  if(!StringUtils.isEmpty(schildIPsToConnect)) {
		  hmUpdateData.put("childIpsToConnect", schildIPsToConnect);
	  }
	  if(!StringUtils.isEmpty(sLineageInfo)) {
		  hmUpdateData.put("lineageMapInfo", sLineageInfo);
	  }
	  if(!StringUtils.isEmpty(sImpMissingProgenyInstanceWarning)) {
		  hmUpdateData.put("IMP_MISSING_PROGENY_INSTANCE_WARNING", sImpMissingProgenyInstanceWarning);
	  }
	  if(!StringUtils.isEmpty(sIMPUnknownComponentWatermark)) {
		  hmUpdateData.put("IMPUnknownComponentWatermark", sIMPUnknownComponentWatermark);
	  }
		hmUpdateData.put("IsRevisionPublishedAsHIP", sIsRevisionPublishedAsHIP);
	  	//Added for SWIMP-385 - s
		hmUpdateData.put("IMP_Version", sIMPVersion);
		hmUpdateData.put("IMP_Commandline", sIMPCommandline);
		hmUpdateData.put("IMP_IPDir", sIMPIPDir);
		hmUpdateData.put("IMP_UsernameDomain", sIMPUsernameDomain);
		//Added for SWIMP-385 - e
	  
      if (!hmUpdateData.isEmpty()) {
        hmUpdateData.put(IPNAME, sIPName);
        hmUpdateData.put("User", sUserName);
		
        Map mpInfo;
        String strRepLocations = "";
        String sReleaseId = "";

        //Added for SWIMP-113
		List<String> lsFinalDocuments = new ArrayList<>();
		String sUploadStatus="";
		//Added for SWIMP-882
		String sSSGQIStatus="";
		String sSSGQIFileName="";

        iAccess = getAccessForIP(context, sIPName, sEvent, sUserName);
        if (iAccess == 0) {
        	
        	MapList retunMapList = JPO.invoke(context, REL_UTIL_JPO, null,
              "connectBranchAndReleaseAfterPublish", JPO.packArgs(hmUpdateData), MapList.class);
          if (retunMapList != null) {
            mpInfo = (Map) retunMapList.get(0);
            strRepLocations = (String) mpInfo.get("strRepLocations");
            sReleaseId = (String) mpInfo.get("releaseId");
            //Added for SWIMP-113			
            lsFinalDocuments = (ArrayList) mpInfo.get("lsFinalDocuments");
		    sUploadStatus = (String) mpInfo.get("sUploadStatus");
		    
		    //Added for SWIMP-882
		    sSSGQIStatus = (String) mpInfo.get("SSGQI Status");
		    sSSGQIFileName = (String) mpInfo.get("SSGQI FileName");
		    
		  }
          returnObj.put("strRepLocations", strRepLocations);
          returnObj.put("releaseId", sReleaseId);
          returnObj.put("code", Integer.valueOf(0));
          returnObj.put(strMessage, EXEC_SUCC);
		//Added for SWIMP-113
		  returnObj.put("lsFinalDocuments", lsFinalDocuments);
		  returnObj.put("sUploadStatus", sUploadStatus);
		  
		//Added for SWIMP-882
		  returnObj.put("SSGQI Status", sSSGQIStatus);
		  returnObj.put("SSGQI FileName", sSSGQIFileName);
		//Added for SWIMP-882
		  
        } else if (iAccess == 1) {
          returnObj.put("code", Integer.valueOf(1));
          returnObj.put(strMessage, "Not Authorized to update the attributes");
        } else {
          returnObj.put("code", Integer.valueOf(2));
          returnObj.put(strMessage, "Not Available");//Modified for SWIMP-262
        }
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "No attributes to update");
      }
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in postProcessPublish:   ", exception);
      throw new IMPServiceException(exception);
    }finally {
		try {
			if (!StringUtils.isEmpty(sPath)) {
				logger.info("Deleting temp dir: " + sPath);
				deleteOnExit(sPath);
				logger.info("Deleted temp dir: " + sPath);

			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception in deleting the files/folder in server ", e);
		}
	}
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  //Modified the method for SWIMP-262: Removed user active check as we are checking this in IMP.java.
  private static int getAccessForIP(matrix.db.Context context, String sIPName, String sEvent,
		  String sUserName) throws IMPServiceException {
	  int iReturn = 0;
	  HashMap hmData = new HashMap();
	  try {
		  hmData.put(CONTEXT, sUserName);
		  hmData.put(CONST_OBJECTTYPE, TYPE_IMP_IPPRODUCT);
		  hmData.put(CONST_OBJECTNAME, sIPName);
		  hmData.put(CONST_COMMAND, sEvent);
		  ContextUtil.pushContext(context, sUserName, "", SERV_PROD);//Modified for 2019x Upgrade
		  iReturn = JPO.invoke(context, "IMP_SecurityCheck", null, "checkAccessForIPSoCDTreeSpec",
				  JPO.packArgs(hmData));
	  } catch (Exception me) {
		  logger.log(Level.SEVERE, "Exception in getAccessForIP:   ", me);
		  throw new IMPServiceException(me);
	  }
	  return iReturn;
  }

  /**
   * Gets the attributes for IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param sAttributeValue the s attribute value
   * @return the attributes for IP
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings("rawtypes")
  @GET
  @Path("/ipAttributes")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getAttributesForIP(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam(IPNAME) String sIPName, @QueryParam("AttributeName") String sAttributeValue) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade

      StringList slIPDetails = new StringList();
      slIPDetails.add(sAttributeValue);
      MapList mlIPObjects = DomainObject.findObjects(context, "*", sIPName, null, "*",
          context.getVault().getName(), null, true, slIPDetails);
      if (!mlIPObjects.isEmpty()) {
        Map mIPInfo = (Map) mlIPObjects.get(0);
        returnObj.put(sAttributeValue, mIPInfo.get(sAttributeValue).toString());
      }
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in getAttributesForIP:   ", e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  //Added for SWIMP-1 start
  /**
   * Gets the GDS file info for WM Obj.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @return the attribute info for WM Obj
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings("rawtypes")
  @GET
  @Path("/wmInfo")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getWaterMarkGDSFileInfo(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("WaterMarkIDs") String sWaterMarkIDs, @QueryParam("AttributeName") String sAttributeValue) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      StringList slWMDetails = new StringList();
      slWMDetails.add(sAttributeValue);
      StringTokenizer strToken = new StringTokenizer(sWaterMarkIDs, ",");
      Map <String,String> mWMFile = new HashMap<>();//Added for SWIMP-1	  
      while (strToken.hasMoreTokens()) {
        String token = strToken.nextToken();
        String sWhere;
        MapList mlWMObjects = null;
        //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
        if (UIUtil.isNotNullAndNotEmpty(token) && token.length() >= 0) {
        	sWhere = "attribute[IMP_IPXWaterMark]==" + "\"" + token.trim() + "\" || attribute[IMP_IPRevisionWatermark]==" + "\"" + token.trim() + "\"";
        	mlWMObjects = DomainObject.findObjects(context, "IMP_IP_Watermark", "*", "*", "*", context.getVault().getName(), sWhere,
                  false, slWMDetails);
        }
        if (null != mlWMObjects && !mlWMObjects.isEmpty()) {
          Map mWMInfo = (Map) mlWMObjects.get(0);
          String sWMAttrInfo = (String) mWMInfo.get(sAttributeValue);
          if (UIUtil.isNotNullAndNotEmpty(sWMAttrInfo) && sWMAttrInfo.length() >= 0) {
        	  mWMFile.put(sWMAttrInfo,token.trim());//Added for SWIMP-1
          } else {
        	  mWMFile.put("singleDesignFile",token.trim());//Added for SWIMP-1
          }
        }
      }
      
    returnObj.put("mWMFile", convertWMMapToString(mWMFile));//Added for SWIMP-1
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in getAttributesForIP:   ", e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
      //Added for SWIMP-1 end

  /**
   * Gets the deprecated by IP for an given IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the IP name
   * @return the deprecated by list
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  @GET
  @Path("/GetDeprecatedBy")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getDeprecatedIP(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam(IPNAME) String sIPID) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
    
      HashMap hmArgsMap = new HashMap();
      hmArgsMap.put("IPID", sIPID);
    
      List<String> lsDeprecatedBy = JPO.invoke(context, "IMP_IPDeprecate", null,
            "getDeprecatedByForIP", JPO.packArgs(hmArgsMap), List.class);      

      returnObj.put("DeprecatedBy", lsDeprecatedBy);
    
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in getDeprecatedIP:   ", e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Gets the IP data for QA validation.
   * This method is modified for fixing the sonar issues and parameterized the variables, SWIMP-359
   *
   * @param context the context
   * @param sIPName the s IP name
   * @param sUserName the s user name
   * @return the IP data for QA validation
   * @throws IMPServiceException the exception
   */
  @SuppressWarnings("unchecked")
  private org.codehaus.jettison.json.JSONObject getIPDataforQAValidation(matrix.db.Context context,
      String sIPName, String sUserName) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try {
      StringList slPersonDetails = new StringList(1);
      slPersonDetails.add(DomainConstants.SELECT_ID);
      slPersonDetails.add(DomainConstants.SELECT_OWNER);
      MapList mlPersonList =
          DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, PERSON_TYPE),
              sUserName, "*", "*", "*", null, false, slPersonDetails);
      if (!mlPersonList.isEmpty()) {
        ContextUtil.pushContext(context, sUserName, "", SERV_PROD);//Modified for 2019x upgrade
        StringList slIPDetails = new StringList(1);
        slIPDetails.add(DomainConstants.SELECT_ID);
        slIPDetails.add(DomainConstants.SELECT_OWNER); //Added-882
        slIPDetails.add("attribute[IMP_ProductDivision]");
        slIPDetails.add("attribute[IMP_AccessControl_Protection]");
		slIPDetails.add("attribute[IMP_IPPrefix]"); //Added for SWIMP-359
		slIPDetails.add("attribute[IMP_RequireQualityClass]"); //Added for SWIMP-432

        MapList mlIPObjects = DomainObject.findObjects(context,
            PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), sIPName, null, "*",
            context.getVault().getName(), null, true, slIPDetails);
        if (!mlIPObjects.isEmpty()) {
          Map<String, String> mIPInfo = (Map<String, String>) mlIPObjects.get(0);
          String sIPid = mIPInfo.get(DomainConstants.SELECT_ID);
          String sIPOwner = mIPInfo.get(DomainConstants.SELECT_OWNER); //Added-882
          String sBU = mIPInfo.get("attribute[IMP_ProductDivision]");
          String sAccessControlProtection = mIPInfo.get("attribute[IMP_AccessControl_Protection]");
		  String sIpPrefix = mIPInfo.get("attribute[IMP_IPPrefix]"); //Added for SWIMP-359
		  String sRequireQualityClass = mIPInfo.get("attribute[IMP_RequireQualityClass]"); //Added for SWIMP-432

          Map<String, String> hmPkArgs = new HashMap<>();
          hmPkArgs.put(OBJ_ID, sIPid);

          MapList mlTechStacks = JPO.invoke(context, IMP_TECHSTACKUTIL_JPO, null,
              "getTechStackObjects", JPO.packArgs(hmPkArgs), MapList.class);
          Map<String, String> mTechStack;
          returnObj.put(strIPOwner, sIPOwner); //Added-882
          returnObj.put(strBusinessUnit, sBU);
          returnObj.put(strIPAccessControlProtection, sAccessControlProtection); //Replaced the hard-coded key string to constant, SWIMP-359
		  returnObj.put(strIPPrefixLength, sIpPrefix.length()); //Added for SWIMP-359
		  returnObj.put("REQUIRE_QUALITY_CLASS", sRequireQualityClass); //Added for SWIMP-432

          org.codehaus.jettison.json.JSONArray jaTechStack =
              new org.codehaus.jettison.json.JSONArray();

          for (int i = 0; i < mlTechStacks.size(); i++) {
            org.codehaus.jettison.json.JSONObject jEachTechStack =
                new org.codehaus.jettison.json.JSONObject();
            mTechStack = (Map<String, String>) mlTechStacks.get(i);
            String sFoundry = mTechStack.get("attribute[IMP_Foundry]");
            String sProcessNode = mTechStack.get("attribute[IMP_ProcessNode]");
            String sSubProcess = mTechStack.get("attribute[IMP_SubProcess]");
            String sMetalStack = mTechStack.get("attribute[IMP_MetalStack]");
            String sPolyOrientation = mTechStack.get("attribute[IMP_PolyOrientation]");
			Object oIOType =  mTechStack.get("attribute[IMP_IOType]");
            String sIOType;
            StringList slIOType;
            if (oIOType instanceof StringList) {
                slIOType = (StringList) oIOType;
                sIOType = FrameworkUtil.join(slIOType, "~");
            } else {
                sIOType = (String) oIOType;
            }
            jEachTechStack.put(strFoundry, sFoundry);
            jEachTechStack.put(strNode, sProcessNode);
            jEachTechStack.put(strSubProcess, sSubProcess);
            jEachTechStack.put(strMetalStack, sMetalStack);
            jEachTechStack.put(strIOType, sIOType);			
            jEachTechStack.put(strPolyOrientation, sPolyOrientation);
            jaTechStack.put(jEachTechStack);
            
          }
          returnObj.put(strTechnologyStack, jaTechStack);
        }
      } else {
        throw new IMPServiceException("No Person object found");
      }
    } catch (Exception me) {
      logger.log(Level.SEVERE, "Exception in getIPDataforQAValidation:   ", me);
      throw new IMPServiceException(me);
    }
    return returnObj;
  }



  /**
   * Gets the attributes for QA failures.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param sTag the s tag
   * @param isTagSpecified the is tag specified
   * @return the attributes for QA failures
   * @throws Exception the exception
   */
  @GET
  @Path("/IsQAFailures")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  @SuppressWarnings({"rawtypes", "unchecked"})
  public Response getAttributesForQAFailures(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam(IPNAME) String sIPName, @QueryParam("Tag") String sTag, @QueryParam("tagSpecified") boolean isTagSpecified) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      HashMap hmPackData = new HashMap();
      hmPackData.put(IPNAME, sIPName);
      hmPackData.put(IPTAG, sTag);
      hmPackData.put("isTagSpecified", isTagSpecified);
      MapList retunMapList = JPO.invoke(context, REL_UTIL_JPO, null,
          "getAttributevaluesInIPRelease", JPO.packArgs(hmPackData), MapList.class);
        Map mpInfo = (Map) retunMapList.get(0);
        //Added for SWIMP-133 : Starts
        boolean bBranchExists = (boolean) mpInfo.get("BranchExists");
        boolean bAnyRevisionPublishedforBranch = (boolean) mpInfo.get("AnyRevisionPublishedforBranch");
        String sBranchName = (String) mpInfo.get("BranchName");
        
        returnObj.put("BRANCHEXISTS", bBranchExists);
        returnObj.put("ANYREVISIONPUBLISHEDFORBRANCH", bAnyRevisionPublishedforBranch);
        returnObj.put("BRANCHNAME", sBranchName);

        if(!bBranchExists || !bAnyRevisionPublishedforBranch){
	        String ipProductType = JPO.invoke(context, REL_UTIL_JPO, null, "getProductTypeForIP",
	                JPO.packArgs(hmPackData), String.class); //Added for 1211
	        String ipProductWMSeed = JPO.invoke(context, REL_UTIL_JPO, null, "getWatermarkSeedForIP",
	                    JPO.packArgs(hmPackData), String.class); //Added for 1211
            returnObj.put("PRODUCTTYPE",ipProductType ); //Added for 1211
            returnObj.put("sIPIDWMSeed",ipProductWMSeed ); //Added for SWIMP-1
            returnObj.put("IPTAG", "");
        }else {//SWIMP-133 : Ends
	        String sIPQAStatus = (String) mpInfo.get("IMP_IPQAStatus");
	        String sIPQASummary = (String) mpInfo.get("IMP_IPQASummary");
	        String sIPTag = (String) mpInfo.get(IPTAG);
	        //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
	        String sIPWaterMark = (String) mpInfo.get("IMP_IPRevisionWatermark");
	        String sOriginated = (String) mpInfo.get(DomainConstants.SELECT_ORIGINATED);
	        String sCurrent = (String) mpInfo.get(DomainConstants.SELECT_CURRENT);
	        String sObjName = (String) mpInfo.get("ReleaseObjectName");
	        String sIsPrefixed = (String) mpInfo.get("IMP_IsPrefixed"); // Added for bug 762
			String sInactiveRev = (String) mpInfo.get("Inactive_Rev");
			String sIPIDWMSeed = (String) mpInfo.get("sIPIDWMSeed");//Added for SWIMP-1
			// Added for bug IMPBRCM-1057
	        boolean isAllRevInactive = (boolean) mpInfo.get("AllRevisionsInactive");
	        boolean bRevExists = (boolean) mpInfo.get("RevisionExists");

	        String sAlert = (String) mpInfo.get("IMP_Alert");
	        String sIPTopcell =  (String) mpInfo.get("IMP_Topcell"); //Added for SWIMP-88
			String sMissingProgenyInstanceWarn = (String) mpInfo.get("MissingProgenyInstanceWarn");//Added for SWIMP-569
			String sUnknownWMWarn = (String) mpInfo.get("UnknownWMWarn");//Added for SWIMP-569
			HashMap<String, String> designFileMappingToWM = new HashMap<String, String>();
			designFileMappingToWM = (HashMap<String, String>) mpInfo.get("IMP_DesignFileMappingToFile");//Added for SWIMP-849
			String wmDerivedFrom = (String) mpInfo.get("WMDerivedFrom");//Added for SWIMP-849
	        returnObj.put("IPQASTATUS", sIPQAStatus);
	        returnObj.put("IPQASUMMARY", sIPQASummary);
	        returnObj.put("IPTAG", sIPTag);
	        returnObj.put("ORIGINATED", sOriginated);
	        returnObj.put("WATERMARK", sIPWaterMark);
	        returnObj.put("CURRENT", sCurrent);
	        returnObj.put("OBJNAME", sObjName);
	        returnObj.put("ISPREFIXED", sIsPrefixed); // Added for bug 762
			returnObj.put("INACTIVEREV", sInactiveRev);
			// Added for bug IMPBRCM-1057
	        returnObj.put("ALL_REVISIONSINACTIVE", isAllRevInactive);
	        returnObj.put("REVISIONEXISTS", bRevExists);
	        returnObj.put("REVALERT", sAlert);
	        returnObj.put("sIPIDWMSeed",sIPIDWMSeed );//Added for SWIMP-1
	        returnObj.put("TOPCELL", sIPTopcell); //Added for SWIMP-88
			returnObj.put("MISSING_PROGENY", sMissingProgenyInstanceWarn); //Added for SWIMP-569
			returnObj.put("UNKNOWN_WM", sUnknownWMWarn); //Added for SWIMP-569
			returnObj.put("DesignFileMappingToWM", designFileMappingToWM); //Added for SWIMP-849
			returnObj.put("WMDerivedFrom", wmDerivedFrom); //Added for SWIMP-849
        }
      
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in getAttributesForQAFailures:   ", e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Check pre-approve list.
   * Modified for SWIMP-31 & Code alignment has been done.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws JSONException 
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @POST
  @Path("/isPreApproveList")
  @SuppressWarnings({"unchecked"})
  public Response isPreApproveList(
		  @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
		  jakarta.ws.rs.core.Form form) throws IMPServiceException {
	  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
	  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
		  StringBuilder strReturn = new StringBuilder();
		  String strPreApprove = form.asMap().getFirst("PreapproveList");

		  List<String> alPreApproveList = new ArrayList<>();
		  StringTokenizer st = new StringTokenizer(strPreApprove, ",");

		  while (st.hasMoreTokens()) {
			  String token = st.nextToken();
			  alPreApproveList.add(token);
		  }

		  StringList slIPDetails = new StringList();
		  slIPDetails.add(DomainConstants.SELECT_NAME);

		  //Modified for SWIMP-31: Starts
		  String strProjectName = "";
		  String strWhereCondition = DomainConstants.SELECT_TYPE + STRING_EQUALS_WITHQUOTE + TYPE_IMP_SOC + "' || (" + DomainConstants.SELECT_TYPE + STRING_EQUALS_WITHQUOTE + TYPE_IMP_IPPRODUCT + "' && "
				  + ATTRIBUTE_IMP_PRODUCTTYPE + STRING_EQUALS_WITHQUOTE + ATTRIBUTE_IMP_PRODUCTTYPE_RANGE_BLOCKIP + "')";
		  MapList mlSoCHIPObjects = DomainObject.findObjects(context, "*", strPreApprove, "*", "*", SERV_PROD, strWhereCondition, true, slIPDetails);

		  Iterator<Map<String, String>> itrSocHIPObjects = mlSoCHIPObjects.iterator();
		  while (itrSocHIPObjects.hasNext()) {
			  Map<String, String> map = itrSocHIPObjects.next();
			  strProjectName = map.get(IPNAME_ATTR);
			  //Added for SWIMP-31: Starts
			  if (alPreApproveList.contains(strProjectName)) {
				  alPreApproveList.remove(strProjectName);
			  }
			  //Added for SWIMP-31: Ends
		  }

		  //Added for SWIMP-31: Starts
		  if (!alPreApproveList.isEmpty()) {
			  for (String sPreApprove : alPreApproveList) {
				  strReturn.append(",").append(sPreApprove);
			  }
		  }
		  //Added for SWIMP-31: Ends
		  //Modified for SWIMP-31: Ends
		  returnObj.put(strMessage, strReturn);
	  } catch (Exception exception) {
		  logger.log(Level.SEVERE, "Exception in isPreApproveList:   ", exception);
		  throw new IMPServiceException(exception);
	  }
	  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * getIPID names.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws IMPServiceException the IMP service exception
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws FrameworkException the framework exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @POST
  @Path("/ipids")
  public Response getIPIDs(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
   
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){ //Modified for 2019x Upgrade
      String strType = PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE);
      StringList objectSelects = new StringList();
      objectSelects.add(IPNAME_ATTR);
      objectSelects.add(IPID_ATTR);
      objectSelects.add("current");
      //Added for SWIMP-16 - Start
      objectSelects.add("from[IMP_Deprecate].to");
      objectSelects.add("to[IMP_Deprecate].from");      
      //Added for SWIMP-16 - End
      // Modified for bug 952
      String sUserName = form.asMap().getFirst(USRNAME); //Added for 1086
      String sIMPFoundry = form.asMap().getFirst("IMP_Foundry");
      String sIMPProcessNode = form.asMap().getFirst("IMP_ProcessNode");
      String sIMPSubProcess = form.asMap().getFirst(STR_SUBPROCESS);
      String sIMPProductDivision = form.asMap().getFirst(STR_PRODUCTDIVISION);
      String sIMPMetalStack = form.asMap().getFirst("IMP_MetalStack"); // Added for 957
      String sIMPIPName = form.asMap().getFirst("IMP_IPName");      
      
      //Added for 979 :Start
      String sIPSource = form.asMap().getFirst("IMP_IPSource");
      String sVendor = form.asMap().getFirst("IMP_Vendor");
      Map<String, String> mInputArgs = new HashMap<>();
      mInputArgs.put(STR_IMPIPNAME, sIMPIPName);
      mInputArgs.put(STR_IMPFOUNDRY, sIMPFoundry);
      mInputArgs.put(STR_IMPPROCESSNODE, sIMPProcessNode);
      mInputArgs.put(STR_IMPSUBPROCESS, sIMPSubProcess);
      mInputArgs.put(STR_IMPMETALSTACK, sIMPMetalStack);
      mInputArgs.put(STR_IMPPRODUCTDIVISION, sIMPProductDivision);
      mInputArgs.put(STR_IMPIPSOURCE, sIPSource);
      mInputArgs.put(STR_VENDOR, sVendor);
      String whereExp = getWhereStringForBuVendorTechStack(context, mInputArgs,returnObj);
		
	  //Added for 1086 : Starts
      ContextUtil.pushContext(context, sUserName, "", PropertyUtil.getSchemaProperty(context, VAULT_SERV_PROD));
	  //Added for 1086 : Ends
      
	  // Added for ITOPS-1253 : Starts
	  StringList multivalueSelectList = new StringList(2);
	  multivalueSelectList.add("from[IMP_Deprecate].to");
	  multivalueSelectList.add("to[IMP_Deprecate].from");
	  // Added for ITOPS-1253 : End
      
	  // findObjects api call modified for ITOPS-1253
      MapList mlIPObjects = DomainObject.findObjects(context, strType, "*", "*", "*",
          context.getVault().getName(), whereExp, true, objectSelects, multivalueSelectList);
      mlIPObjects.sortStructure(IPNAME_ATTR, "ascending", "string");
      
      Iterator itr = mlIPObjects.iterator();
      Map<String, Object> mpFinalData = new LinkedHashMap<>();
      Map<String, Object> mpDeprecationData = new LinkedHashMap<>();
      StringBuilder sbResult = new StringBuilder();
      sbResult.append(System.lineSeparator());
      //Added for SWIMP-16 - End
      Map<String, List<String>> mpDeprecation;
      

      while (itr.hasNext()) {
    	
        Map mIPInfo = (Map) itr.next();
        mpDeprecation =getDepricationData(mIPInfo);
        List<String> lsDeprecates = mpDeprecation.get("deprecates");
		List<String> lsDeprecatedBy = mpDeprecation.get("deprecated_by");
        
        sbResult.append((String) mIPInfo.get(IPNAME_ATTR));
        sbResult.append(" (").append((String) mIPInfo.get("current"));        
        if(!lsDeprecatedBy.isEmpty()){
        	sbResult.append(", Deprecated by: "+lsDeprecatedBy.toString().substring(1, lsDeprecatedBy.toString().length()-1));
        }
        if(!lsDeprecates.isEmpty()){
        	sbResult.append(", Deprecates: "+lsDeprecates.toString().substring(1, lsDeprecates.toString().length()-1));
        }        
        sbResult.append(")");
        sbResult.append(System.lineSeparator());
        mpFinalData.put(mIPInfo.get(IPNAME_ATTR).toString(), mIPInfo.get("current").toString());
        mpDeprecationData.put(mIPInfo.get(IPNAME_ATTR).toString(), mpDeprecation);
       
      }
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put(strMessage, sbResult);
      returnObj.put(OUTMSG, mpFinalData);
      returnObj.put("deprecation", mpDeprecationData);             
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getAttributesForQAFailures:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


	private Map<String, List<String>> getDepricationData(@SuppressWarnings("rawtypes") Map mIPInfo) {
		Map<String, List<String>> mpDeprecation = new LinkedHashMap<>();

		StringList strDeprecatesList = (StringList) mIPInfo.get("from[IMP_Deprecate].to");
		StringList strDeprecateByList = (StringList) mIPInfo.get("to[IMP_Deprecate].from");
		List<String> lsDeprecates = getListValues(strDeprecatesList);
		List<String> lsDeprecatedBy = getListValues(strDeprecateByList);

		mpDeprecation.put("deprecates", lsDeprecates);
		mpDeprecation.put("deprecated_by", lsDeprecatedBy);
		return mpDeprecation;
	}

	private List<String> getListValues(StringList envList) {
		List<String> newList = new ArrayList<>();
		String strVal = null;
		if (envList != null && !envList.isEmpty()) {
			for (Object oVal : envList) {
				strVal = (String) oVal;
				if (UIUtil.isNotNullAndNotEmpty(strVal) && !newList.contains(strVal)) {
					newList.add(strVal);
				}
			}
		}
		Collections.sort(newList);
		return newList;
	}

	private Boolean getBUTechStackWhereClause(matrix.db.Context context, StringBuilder strWhereExpression,
			String attrFunction, String attrName, String valPassed) throws MatrixException {
		boolean validValue = false;
		String qry;
		String qryForNull;
		if (STR_PRODUCTDIVISION.equals(attrName)) {
			qry = ("attribute[IMP_ProductDivision]=='%s'&&");
			qryForNull = ("attribute[IMP_ProductDivision]==''&&");
		} else {
			qry = ("from[IMP_TechStack]=='True'&&from[IMP_TechStack].to.attribute[" + attrName + "]=='%s'&&");
			qryForNull = "(from[IMP_TechStack]=='False'||from[IMP_TechStack].to.attribute[" + attrName + "]=='')&&";
		}

		if (!"null".equals(valPassed) && !"temp".equals(valPassed)) {
			@SuppressWarnings("rawtypes")
			HashMap validValueMap = JPO.invoke(context, IPSEARCH_UTIL_JPO, null, attrFunction, null,
					java.util.HashMap.class);
			validValue = validValueMap.containsValue(valPassed);
			String val = validValue ? valPassed : "INVALID_VALUE";
			strWhereExpression.append(String.format(qry, val));
		} else if ("null".equals(valPassed)) {
			strWhereExpression.append(qryForNull);
			validValue = true;
		}
		return validValue;
	}

/**
   * Post Process - IP Publish.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param form the form
   * @param sUserName the s user name
   * @param sEvent the s event
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/createBranchAndReleasePostPublish")
  public Response createBranchAndReleasePostPublish(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam(IPNAME) String sIPName, jakarta.ws.rs.core.Form form,
      @QueryParam(USRNAME) String sUserName, @QueryParam("Event") String sEvent)
      throws IMPServiceException {    
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      HashMap hmUpdateData = new HashMap();
      String sTag = form.asMap().getFirst(IPTAG);
      if (sTag != null && !sTag.isEmpty()) {
        hmUpdateData.put(IPTAG, sTag);
      }
      String sFromTag = form.asMap().getFirst("IMP_BranchParent");
      if (sFromTag != null && !sFromTag.isEmpty()) {
        hmUpdateData.put("IMP_BranchParent", sFromTag);
      }
      if (!hmUpdateData.isEmpty()) {
        hmUpdateData.put(IPNAME, sIPName);
        hmUpdateData.put("User", sUserName);
        if ("Branch".equals(sEvent)) {
          // Modified for 965
          JPO.invoke(context, REL_UTIL_JPO, null, "createBranchAndReleasePostPublish",
              JPO.packArgs(hmUpdateData), Map.class);
          returnObj.put("code", Integer.valueOf(0));
          returnObj.put(strMessage, EXEC_SUCC);
        }
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "No attributes to update");
      }
    } catch (jakarta.ws.rs.WebApplicationException webAppException) {
      logger.log(Level.SEVERE, "WebApplicationException in creating branch:   ", webAppException);
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in creating branch:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * Check-in and Check out spec.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sFileName the s file name
   * @param sFilePath the s file path
   * @param specName the spec name
   * @param sUserName the s user name
   * @param sEvent the s event
   * @param sSpecVersion the s spec version
   * @param sComment the s comment
   * @return the response
   * @throws IMPServiceException the IMP service exception
   * @throws UnknownHostException the unknown host exception
   * @throws JSONException the JSON exception
   */
  @SuppressWarnings({"rawtypes"}) // Modified for 821 -- Start --
  @GET
  @Path("/checkoutandcheckin")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response checkinAndCheckoutDTreeSpec(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("FileName") String sFileName, @QueryParam("FilePath") String sFilePath,
      @QueryParam("SpecName") String specName, @QueryParam(USRNAME) String sUserName,
      @QueryParam("Event") String sEvent, @QueryParam("SpecVersion") String sSpecVersion,
      @QueryParam("Comment") String sComment)
      throws IMPServiceException {
    
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

    
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
    	InetAddress sHostName = InetAddress.getLocalHost();
        sHostName.getHostName();
        returnObj.put("canonical", sHostName.getCanonicalHostName());
        returnObj.put("ip_address", sHostName.getHostAddress());
      String sWhere = null;
      StringList slIPDetails = new StringList(DomainConstants.SELECT_ID);
      Set<PosixFilePermission> perms =
          PosixFilePermissions.fromString("rwxrwxrwx");
      FileAttribute<Set<PosixFilePermission>> attr =
          PosixFilePermissions.asFileAttribute(perms);
      String sDownloadPath = "SPEC_"+System.nanoTime();
      java.nio.file.Path temp = Paths.get(sFilePath).resolve(sDownloadPath);
      
      if("*".equals(sSpecVersion)){
        sWhere = "revision==last";
      }
      MapList mlIPObjects = DomainObject.findObjects(context,
          PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), specName, sSpecVersion, "*",
          context.getVault().getName(), sWhere, true, slIPDetails);

      if (!mlIPObjects.isEmpty()) {
        Map mpInfo = (Map) mlIPObjects.get(0);
        String sId = (String) mpInfo.get(DomainConstants.SELECT_ID);
        
        if ("checkout".equals(sEvent)) {
          Files.createDirectories(temp, attr);
          String strMqlCmd = "checkout bus " + sId + " server format yaml " + temp.toString();
          MqlUtil.mqlCommand(context, false, strMqlCmd, false);
          returnObj.put(strMessage, sDownloadPath);
        } else if ("checkin".equals(sEvent)) {
         String strMqlCmd = "checkin bus %s format yaml " + sFilePath + "/" + sFileName;
          DomainObject dom = new DomainObject(sId);
          String sFilename = dom.getInfo(context, DomainConstants.SELECT_FILE_NAME);
          String revId = sId;
          if ("*".equals(sSpecVersion) && !sFilename.isEmpty()) {
              BusinessObject bos = dom.reviseObject(context, false);
              String sNewRevisionId = bos.getObjectId(context);
              DomainObject domRevObj = new DomainObject(sNewRevisionId);
              domRevObj.setOwner(context, sUserName);
              //Added/Modified for 491---Start
              domRevObj.setAttributeValue(context, "IMP_Comment", sComment);
              //Added/Modified for 491---End
              revId = sNewRevisionId;
          } 
          MqlUtil.mqlCommand(context, false, String.format(strMqlCmd, revId), false);
          returnObj.put(strMessage, "Success");
          deleteOnExit(sFilePath);
        }
      }
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in checkincheckout:   ", exception);
      throw new IMPServiceException(exception);
    }
	// End -- Bug 821
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  // Added for bug 821
  /**
   * Delete on exit.
   *
   * @param sFileDir the s file dir
   * @return the string
   * @throws IMPServiceException 
   * @throws InterruptedException 
   * @throws Exception the exception
   */
  @GET
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  @Path("/deleteDirectory")
  public String deleteOnExit(@QueryParam("FileDir") String sFileDir) throws IMPServiceException{
    String sReturn = "";
    try {
      File file = new File(sFileDir);
      if (file.exists()) {
        Process process = Runtime.getRuntime().exec("rm -rf " + sFileDir);
        int iValue = process.waitFor();
        if (iValue == 0) {
          sReturn = "Deleted";
        } else {
          sReturn = "Not Deleted";
        }
      }
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in deleteOnExit:   ", e);
      throw new IMPServiceException(e);
    }
    return sReturn;
  }
  

  /**
   * Check-in and Check out spec.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param specName the spec name
   * @param sUserName the s user name
   * @param sComment the s comment
   * @return the response
   * @throws JSONException 
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @GET
  @Path("/createDTreeSpec")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response createDTreeSpec(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("SpecName") String specName, @QueryParam(USRNAME) String sUserName,
      @QueryParam("Comment") String sComment) throws  IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {//Modified for 2019x upgrade
      ContextUtil.pushContext(context, sUserName, "", SERV_PROD);
      String sWhere = "revision==last";
      StringList slIPDetails = new StringList(DomainConstants.SELECT_ID);
      boolean bDtreeRole = PersonUtil.hasAssignment(context, "IMP_DTreeGroup");
      if(bDtreeRole){
        MapList mlIPObjects = DomainObject.findObjects(context,
            PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), specName, "*", "*",
            context.getVault().getName(), sWhere, true, slIPDetails);

        if (mlIPObjects.isEmpty()) {
          DomainObject dom = new DomainObject();
          dom.createObject(context,
              PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), specName, "1.0",
              PropertyUtil.getSchemaProperty(context, "policy_IMP_DirectoryTreeSpec"),
              SERV_PROD);
          dom.setDescription(context, sComment);
          dom.setOwner(context, sUserName);
          dom.setAttributeValue(context, "IMP_LatestVersion", "1.0"); // Added for User story 65
          returnObj.put("code", Integer.valueOf(0));
          returnObj.put(strMessage, "Directory tree spec " + specName + " created successful");
        } else {
          returnObj.put("code", Integer.valueOf(2));
          returnObj.put(strMessage, "Directory tree spec '"+specName+"' already exists"); // Error message correction.
        }
      }  else {
        returnObj.put("code", Integer.valueOf(3));
        returnObj.put(strMessage, "Not authorized to perform this operation"); // Error message correction.
      }
    } catch (jakarta.ws.rs.WebApplicationException webAppException) {
      logger.log(Level.SEVERE, "WebApplicationException in createDTreeSpec:   ", webAppException);
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in createDTreeSpec:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Post Process - IP Publish.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param strSpecName the str spec name
   * @param strSpecVersion the str spec version
   * @return the response
   * @throws JSONException 
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes"})
  @GET
  @Path("/latestspecversion")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getDirectoryTreeSpecVersion(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("SpecName") String strSpecName, @QueryParam("SpecVersion") String strSpecVersion) throws IMPServiceException
       {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      StringList slIPDetails = new StringList(DomainConstants.SELECT_LATEST_REVISION);
      slIPDetails.add(DomainConstants.SELECT_FILE_NAME);
      slIPDetails.add(DomainConstants.SELECT_CURRENT);
      MapList mlIPObjects;
      if ("*".equals(strSpecVersion)) {
        mlIPObjects = DomainObject.findObjects(context,
            PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), strSpecName,
            strSpecVersion, "*", context.getVault().getName(), "revision==last", true, slIPDetails);
			//SWIMP-666- start
			if (!mlIPObjects.isEmpty()) {
				Map mpInfo = (Map) mlIPObjects.get(0);
				String sLastRevision = (String) mpInfo.get(DomainConstants.SELECT_LATEST_REVISION);
				StringList slFileName = (StringList) mpInfo.get(DomainConstants.SELECT_FILE_NAME);
				String sCurrent = (String) mpInfo.get(DomainConstants.SELECT_CURRENT);
				returnObj.put("code", "0");
				returnObj.put("last_rev", sLastRevision);
				returnObj.put("filename", slFileName.get(0));
				returnObj.put(strMessage, sCurrent);
				returnObj.put("version", "");
			 } else {
				returnObj.put("code", "1");
				returnObj.put(strMessage, "does not exist"); // Modified for bug 821
				returnObj.put("filename", "No file");
				returnObj.put("version", "");
			 }
			 //SWIMP-666 - end
      } else {
		
		//SWIMP-666 - start
		mlIPObjects = DomainObject.findObjects(context,
            PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), strSpecName,
            "*", "*", context.getVault().getName(), null, true, slIPDetails);
		if(!mlIPObjects.isEmpty()){
			mlIPObjects = DomainObject.findObjects(context,
            PropertyUtil.getSchemaProperty(context, DTREE_SPEC_TYPE), strSpecName,
            strSpecVersion, "*", context.getVault().getName(), null, true, slIPDetails);
			if (!mlIPObjects.isEmpty()) {
				Map mpInfo = (Map) mlIPObjects.get(0);
				String sLastRevision = (String) mpInfo.get(DomainConstants.SELECT_LATEST_REVISION);
				StringList slFileName = (StringList) mpInfo.get(DomainConstants.SELECT_FILE_NAME);
				String sCurrent = (String) mpInfo.get(DomainConstants.SELECT_CURRENT);
				returnObj.put("code", "0");
				returnObj.put("last_rev", sLastRevision);
				returnObj.put("filename", slFileName.get(0));
				returnObj.put(strMessage, sCurrent);
				returnObj.put("version", "");
			 } else {
				returnObj.put("code", "1");
				returnObj.put(strMessage, "does not exist"); // Modified for bug 821
				returnObj.put("filename", "No file");
				returnObj.put("version", "version does not exist");
			 }
			
		} else {
			    returnObj.put("code", "1");
				returnObj.put(strMessage, "does not exist"); // Modified for bug 821
				returnObj.put("filename", "No file");
				returnObj.put("version", "");
		}
		//SWIMP-666- End
      }
      
    } catch (jakarta.ws.rs.WebApplicationException webAppException) {
      logger.log(Level.SEVERE, "WebApplicationException in getDirectoryTreeSpecVersion:   ", webAppException);
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getDirectoryTreeSpecVersion:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  /**
   * Gets the recommended revision for branch.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param sBranch the branch
   * @return the recommended revision for the Branch
   * @throws Exception the exception
   */
  //Added for SWIMP-53: Starts
  @GET
  @Path("/recommendedrevision")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  @SuppressWarnings({"rawtypes"})
  
  public Response getRecommendedRevisionFromBranch(
          @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
          @QueryParam(IPNAME) String sIPName, @QueryParam("IPBranch") String sIPBranch) throws IMPServiceException {
        org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
        try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
          
          Map<String,String> hmPackData = new HashMap <>();
          hmPackData.put(IPNAME, sIPName);
          hmPackData.put("IPBranch", sIPBranch);
          MapList retunMapList = JPO.invoke(context, REL_UTIL_JPO, null,
                  "getRecommendedRevisionsofBranch", JPO.packArgs(hmPackData), MapList.class);
            if (!retunMapList.isEmpty()) {
              Map mpInfo = (Map) retunMapList.get(0);
              String sRecommendedRev = (String) mpInfo.get("Recommendedrevision");
              returnObj.put("RECOMMENDEDREV", sRecommendedRev);
            } 
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Exception in Getting Recommended Revisions:   ", e);
            throw new IMPServiceException(e);
        }
          return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
        }
  //Added for SWIMP-53: Ends

  /**
   * Send notification.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sIPName the s IP name
   * @param sProjectName the s project name
   * @param sUserName the s user name
   * @param strDryRun the str dry run
   * @param strENV the str ENV
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  //Renamed the service name for SWIMP-75
  @Path("/createVerificationMetaData")
  //public Response sendNotification(
  //Modified Method Signature SWIMP-321
  public Response createVerificationMetaData(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
		  @QueryParam("ProjectName") String sProjectName, @QueryParam(USRNAME) String sUserName,
		  @QueryParam("DryRun") String strDryRun, @QueryParam("ENV") String strENV,
		  @QueryParam("FilePath") String sFilePath, jakarta.ws.rs.core.Form form, @QueryParam("sTag") String sTag, @QueryParam("HIPId") String sHIP)
				  throws IMPServiceException {
	  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
	  
	  boolean isTechStackSame = false;
	  
	  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
		  //SWIMP-94
		  logger.info("createVerificationMetaData process started .....");

		  HashMap hmArgsData = new HashMap();
		  hmArgsData.put(CONST_PROJECTNAME, StringUtils.isNotBlank(sProjectName) ? sProjectName : sHIP); //Added for SWIMP-31 (Phase - 2)
		  hmArgsData.put(USRNAME, sUserName);
		  hmArgsData.put("mode", strDryRun);
		  hmArgsData.put("ENV", strENV);
		  hmArgsData.put("FilePath", sFilePath);    //Added for SWIMP-321
		  hmArgsData.put("sTag", sTag);
		  String strLineage = form.asMap().getFirst("Lineage");
		  String smpObjId = form.asMap().getFirst("wmobjinfo");
		  String sHIPIdInfo = form.asMap().getFirst("HIPIDInfo");
		  Map<String,String> sWMObjIds = convertWMStringToMap(smpObjId);
		  hmArgsData.put("Lineage", strLineage);
		  hmArgsData.put("HIPIdInfo", sHIPIdInfo);
		  Map mpReturnData = new HashMap();
		  //SWIMP-94
		  logger.info("Invoking  FABRICATION_APPROVAL JPO.....");
		  if (strLineage != null) {
			  mpReturnData = JPO.invoke(context, FABRICATION_APPRVL_JPO, null, "executeFabricationApproval",
					  JPO.packArgs(hmArgsData), Map.class);
		  }
		  List<Map> lsMapList = new ArrayList<>();
		  if (!mpReturnData.isEmpty()) {
			  Map<String,Object> mpRetData;
			  StringList slSelects = new StringList();
			  //Modified for IMPBRCM-1093 Starts
			  StringList sIPSelects = new StringList();
			  sIPSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
			  //Modified for IMPBRCM-1093 Ends
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.name");
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPName]");
			  slSelects.add(IPTAG_ATTR);
			  slSelects.add("attribute[IMP_Alert]");//Added for IMPBRCM-1166
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.owner");
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_ProductDivision]");
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPSource]");
			  slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_Vendor]");
			   //Added For SWIMP-578 Start
			  slSelects.add("to[IMP_IPBranchRelease].from.id");
			   //Added For SWIMP-578 End
			  if (!sWMObjIds.isEmpty()) {
				  Map<String, String> mpRefCount = sWMObjIds;
				  String finalrfCount = null;
				  for (Map.Entry<String, String> entry : sWMObjIds.entrySet()) {
					  String sObjId = entry.getKey();
					  DomainObject domObj = new DomainObject(sObjId);

					  // Added for 1062 : Starts
					  for (Map.Entry<String, String> entry1 : mpRefCount.entrySet()) {
						  String strObjId = entry1.getKey();
						  String refvalue = entry1.getValue();
						  if (strObjId.equals(sObjId) && !refvalue.isEmpty()) {
							  finalrfCount = refvalue;
						  }
					  }
					  //Added for 1062         
					  //Modified for IMPBRCM-1093 Starts
					  //Added for SWIMP-1 starts
					  StringList wmobjectselects = new StringList();
					  wmobjectselects.add("to[IMP_IP_Watermark].from.id");
					  //Added for SWIMP-568 : Starts
					  wmobjectselects.add("attribute[IMP_IPID]");
					  wmobjectselects.add("attribute[IMP_IPTag]");
					  wmobjectselects.add("attribute[IMP_Design_File]");
					  wmobjectselects.add("attribute[IMP_IPXWaterMark]");
					  wmobjectselects.add("attribute[IMP_IPRevisionWatermark]");
					  //Added for SWIMP-568 : Ends
					  Map relObjectDetails = domObj.getInfo(context, wmobjectselects);
					  String sReleaseID = (String) relObjectDetails.get("to[IMP_IP_Watermark].from.id");
					  String sDesignFile = (String) relObjectDetails.get("attribute[IMP_Design_File]");

					  //Added for SWIMP-568 : Starts
					  String sIPXWaterMark = (String) relObjectDetails.get("attribute[IMP_IPXWaterMark]");
					  String sIPRevisionWatermark = (String) relObjectDetails.get("attribute[IMP_IPRevisionWatermark]");
					  //Added for SWIMP-568 : Ends
					  DomainObject domReleaseObject = new DomainObject(sReleaseID);
					  mpRetData = domReleaseObject.getInfo(context, slSelects);

					  StringList slWMs = domReleaseObject.getInfoList(context, "from[IMP_IP_Watermark].to.id");

					  Map sIPObjMap = domReleaseObject.getInfo(context,sIPSelects);
					  //Added for SWIMP-1 ends
					  String sIPObjID = (String) sIPObjMap.get("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
					  //Added For SWIMP-578 Start
					  //Added for SWIMP-848 Start
					  String sProjectID = (String) mpReturnData.get(STR_PROJECTID_KEY);
					  //Added for SWIMP-848 End
					  if(UIUtil.isNotNullAndNotEmpty(sProjectID) && UIUtil.isNotNullAndNotEmpty(sIPObjID)) {
						  HashMap hmData = new HashMap();
						  hmData.put(STR_PROJECTID_KEY, sProjectID);
						  hmData.put(STR_IPPRODUCTID_KEY, sIPObjID);
						  isTechStackSame = (Boolean)JPO.invoke(context, IMP_IPRELEASEUTIL_JPO, null, "isWebServiceSocHIPIPTechStackSame", JPO.packArgs(hmData), Boolean.class);
						  if (!isTechStackSame) {
							  mpRetData.put("sIncompatible", "Yes");
						  } else {
							  mpRetData.put("sIncompatible", "No");
						  }
					  }
					  String strIPBranchId = (String) mpRetData.get("to[IMP_IPBranchRelease].from.id");
					  HashMap mpBranchMap = new HashMap();
					  mpBranchMap.put("IPID", strIPBranchId);
					  mpBranchMap.put("isBranch","true");
					  String sLatestRevision = JPO.invoke(context, FABRICATION_APPRVL_JPO, null, "getLatestRevisionofIP",
							  JPO.packArgs(mpBranchMap), String.class);
						 //Added For SWIMP-578 End
					  HashMap mpIPMap = new HashMap();
					  mpIPMap.put("IPID", sIPObjID);
					  mpIPMap.put(OBJ_ID, sIPObjID);
					  //SWIMP-94
					  logger.info("Invoking IPDeprecation JPO.....");
					  List<String> lsDeprecatedBy = JPO.invoke(context, "IMP_IPDeprecate", null, "getDeprecatedBy",
							  JPO.packArgs(mpIPMap), List.class); 
					  mpRetData.put("LATREV",sLatestRevision);
					  mpRetData.put("REFCOUNT", finalrfCount); //Added for 1062
					  mpRetData.put("DesignFile",sDesignFile);//Added for SWIMP-1
					  mpRetData.put("DeprecatedBy", lsDeprecatedBy);
					  mpRetData.put("noOfGDsFiles", slWMs.size());//Added for SWIMP-1
					  //Modified for IMPBRCM-1093 Ends
					  //Added for SWIMP-568 : Starts
					  mpRetData.put("IPXWaterMark", sIPXWaterMark);
					  mpRetData.put("IPRevisionWatermark", sIPRevisionWatermark);
					  //Added for SWIMP-568 : Ends
					  lsMapList.add(mpRetData);         
				  }
			  }
		  }

		  returnObj.put("MapList", lsMapList);
		  returnObj.put("Unavailable", mpReturnData.get("Unavailable"));
		  returnObj.put(STRING_VERIFYID, mpReturnData.get(STRING_VERIFYID)); //Added for 1062
		  returnObj.put(strMessage, mpReturnData.get("Return-Message"));
		  //Added for SWIMP-75
		  returnObj.put(STRING_IPIDS, mpReturnData.get(STRING_IPIDS));
		  returnObj.put(KEY_DECLARED_USAGE, new org.codehaus.jettison.json.JSONObject((Map<String, String>) mpReturnData.get(KEY_DECLARED_USAGE))); //Added for SWIMP-531
	  } catch (Exception e) {
		  logger.log(Level.SEVERE, "Exception in createVerificationMetaData:   ", e);
		  throw new IMPServiceException(e);
	  }
	  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  //Added for SWIMP-87: Starts
  /**
   * Getunique prefix from platform
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @GET
  @Path("/getIPPrefix")
 public Response getIPPrefix(
          @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
          @QueryParam("IPID") String sIPID) throws IMPServiceException {
        org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
        String strReturn = "";
        try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
          
          Map<String,String> hmPackData = new HashMap <>();
          hmPackData.put("IPID", sIPID);
          strReturn = JPO.invoke(context, IPPRODUCT_UTIL_JPO, null, "uniquePrefix",
    	          JPO.packArgs(hmPackData), String.class);
          returnObj.put("IPPrefix", strReturn);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Exception in Getting ipPrefix   ", e);
            throw new IMPServiceException(e);
        }
          return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
        }
  //Added for SWIMP-87: Ends
  
  
   /**
   * RecommendedRevisions of an IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes"})
  @POST
  @Path("/ISRecommendedRevisions")
  public Response getRecommendedRevisions(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    // Modified for 750
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    Map<String, Object> hmTagPreData = null;
    Map<String, Object> hmFinalData = new LinkedHashMap<>();
    Map<String, Object> hmBranchData = new LinkedHashMap<>();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String strIPIDName = form.asMap().getFirst("IPID");
      StringBuilder strReturn = new StringBuilder("IPID:-" + strIPIDName);
      strReturn.append(System.lineSeparator());
      strReturn.append("--------------------------------------------------------------------------");
      strReturn.append(System.lineSeparator());
      strReturn.append("Branch\t\t" + "Tag\t\t\t\t" + "Pre-approved List");
      strReturn.append(System.lineSeparator());
      strReturn.append("--------------------------------------------------------------------------");
      strReturn.append(System.lineSeparator());
      String strBranchRelationship = "IMP_IPBranch";
      String strBranchType = "IMP_Branch";
      StringList objectSelect = new StringList();
      objectSelect.add(IPID_ATTR);
      MapList mMapList = DomainObject.findObjects(context, "IMP_IPProduct", strIPIDName, "A", "*",
          "*", null, false, objectSelect);
      if (!mMapList.isEmpty()) {
        Map mapIPID = (Map) mMapList.get(0);
        String strIPID = (String) mapIPID.get(IPID_ATTR);
        StringList objectSelects = new StringList();
        objectSelects.add(IPNAME_ATTR);
        objectSelects.add(IPID_ATTR);
        objectSelects.add(IPTAG_ATTR);
        DomainObject masterObject = new DomainObject(strIPID);
        // getRelatedObjects(Context context, String relationshipPattern, String typePattern,
        // StringList objectSelects, StringList relationshipSelects,boolean getTo, boolean getFrom,
        // short recurseToLevel, String objectWhere, String relationshipWhere, int limit)
        MapList mlBranchObjects = masterObject.getRelatedObjects(context, strBranchRelationship,
            strBranchType, objectSelects, null, true, true, (short) 1, null, null, 100);
        Iterator itrBranchObjects = mlBranchObjects.iterator();
        hmBranchData = new LinkedHashMap<>(); 
        while (itrBranchObjects.hasNext()) {         
          Map map = (Map) itrBranchObjects.next();
          String strBranchName = (String) map.get(IPTAG_ATTR);
          strReturn.append(strBranchName).append(System.lineSeparator()); // Added for 720
          
          String strBranchID = (String) map.get(IPID_ATTR);
          String strBranchRelationshipRelease = "IMP_IPBranchRelease";
          String strBranchTypeRelease = "IMP_IPRelease";
          StringList objectSelectsBranchRelease = new StringList();
          objectSelectsBranchRelease.add(IPTAG_ATTR);
          objectSelectsBranchRelease.add("attribute[IMP_Preapprove]");
          objectSelectsBranchRelease.add(IPID_ATTR);
          DomainObject branchReleaseObject = new DomainObject(strBranchID);
          MapList mlBranchReleaseObject = branchReleaseObject.getRelatedObjects(context,
              strBranchRelationshipRelease, strBranchTypeRelease, objectSelectsBranchRelease, null,
              true, true, (short) 1, null, null, 100);
          Iterator itrBranchReleaseObjects = mlBranchReleaseObject.iterator();
          hmTagPreData = new LinkedHashMap<>();
          while (itrBranchReleaseObjects.hasNext()) {
            String sOutData;
            Map mapBranchRelease = (Map) itrBranchReleaseObjects.next();
            String strBranchReleaseTag = (String) mapBranchRelease.get(IPTAG_ATTR);
            String strBranchReleasePreapprove =
                (String) mapBranchRelease.get("attribute[IMP_Preapprove]");
            strReturn.append("\t\t").append(strBranchReleaseTag);
            int iLength = strBranchReleaseTag.length();
            if (strBranchReleasePreapprove.isEmpty()) {
              // Modified for 510
              if (iLength <= 7) {
            	  strReturn.append("\t\t\t\t<<NONE>>\n");
              } else {
            	  strReturn.append("\t\t\t<<NONE>>\n");
              }
              sOutData = "null";
            } else {
              sOutData = strBranchReleasePreapprove;
              // Modified for 510
              if (iLength <= 7) {
            	  strReturn.append("\t\t\t\t" + strBranchReleasePreapprove + "\n");
              } else {
            	  strReturn.append("\t\t\t" + strBranchReleasePreapprove + "\n");
              }
            }
            hmTagPreData.put(strBranchReleaseTag, sOutData);
          }
          hmBranchData.put(strBranchName, hmTagPreData);
        }
        hmFinalData.putAll(hmBranchData);
      }
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put(strMessage, strReturn);
      returnObj.put(OUTMSG, hmFinalData);
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getRecommendedRevisions:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * get okta ID.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws JSONException 
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes"})
  @POST
  @Path("/oktaID")
  @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
  public Response getOktaID(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
    jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      String strOktaID = "";
      //String strName = form.getFirst("oktaName");
	  String strName = form.asMap().getFirst("oktaName");
      String strType = "Person";
      StringList objectSelect = new StringList();
      objectSelect.add(IPID_ATTR);
      objectSelect.add(IPNAME_ATTR);
      
      String strWhereExpression = "name==" + strName;
      MapList mMapList = DomainObject.findObjects(context, strType, "*", "-", "*", "*",
              strWhereExpression, false, objectSelect);
      if(mMapList.isEmpty())
      {
    	  strWhereExpression = "attribute[IMP_BroadcomUnixLogin]==" + strName;
    	  mMapList = DomainObject.findObjects(context, strType, "*", "-", "*", "*",
    			  strWhereExpression, false, objectSelect);
      }
      if(!mMapList.isEmpty()){
        Map map = (Map) mMapList.get(0);
        strOktaID = (String) map.get(IPNAME_ATTR);
        returnObj.put(strMessage, strOktaID);
      } else {
        returnObj.put(strMessage, strOktaID);
      }
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getOktaID:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }



  /**
   * Audit Record while consume.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/ConsumeAuditRecord")
  public Response consumeAuditRecord(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
	HashMap hmUpdateData = new HashMap();
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String sIPName = form.asMap().getFirst("sIPName");
      String sTag = form.asMap().getFirst("sTag");
      String sOktaID = form.asMap().getFirst("sOktaID");
      String strAction = form.asMap().getFirst("strAction");
      String strENV = form.asMap().getFirst(IMP_ENV);
      String sProject = form.asMap().getFirst(PROJECT);
      String sComment = form.asMap().getFirst("Comment");
      hmUpdateData.put("sIPName", sIPName);
      hmUpdateData.put("sTag", sTag);
      hmUpdateData.put("sOktaID", sOktaID);
      hmUpdateData.put("strAction", strAction);
      hmUpdateData.put(IMP_ENV, strENV);
      hmUpdateData.put(PROJECT, sProject);
      hmUpdateData.put("Comment", sComment);
      JPO.invoke(context,REL_UTIL_JPO , null, "consumeAuditRecord",
          JPO.packArgs(hmUpdateData), String.class);
	  //Added for SWIMP-284 - s
	  String strProjectType = form.asMap().getFirst(PROJECTTYPE);
      String strProjectid = form.asMap().getFirst(PROJECTID);
	  //Added for SWIMP-284 - e
      //Added for SWIMP-166 - s
      String  strSubscriptionUser = form.asMap().getFirst(SUBSCRIPTIONUSER);
      returnObj.put("SubscriptionUserResp", consumeAutoSubsciption(context, sIPName, sOktaID, sTag, sProject, strProjectType, strProjectid, strSubscriptionUser ));
      returnObj.put("AllowSoCToSubscibeIP", validateSoCToSubscribeIP(context, sProject));
      //Added for SWIMP-166 - e      
      returnObj.put(strMessage, "Successful");
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in consumeAuditRecord:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * getIPID names.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @return the response
   * @throws IMPServiceException the IMP generic exception
   */
  @SuppressWarnings({"rawtypes"})
  @POST
  @Path("/dtreespec")
  @Produces ("application/json")
  public Response getDTreeSpecs(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    
    StringBuilder sbReturn = new StringBuilder();
    Map<String, Object> hmFinalData = new LinkedHashMap<>();
    Map<String, Object> hmData = null;
    sbReturn.append(System.lineSeparator());
    sbReturn.append(System.lineSeparator() + "Spec Name     Latest Version    Description"); // Added for bug 738
    StringList objectSelects = new StringList(DomainConstants.SELECT_NAME);
    objectSelects.add(DomainConstants.SELECT_DESCRIPTION);
    objectSelects.add("attribute[IMP_LatestVersion]");
    String sWhere = "revision==Last";
    // Modified the below logic for the bug 582 and 738,
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
      MapList mlIPObjects =
          DomainObject.findObjects(context, "IMP_DirectoryTreeSpec", "*", sWhere, objectSelects);
      Iterator itr = mlIPObjects.iterator();
      while (itr.hasNext()) {
        hmData = new LinkedHashMap<>();
        Map mIPInfo = (Map) itr.next();
        String strName = mIPInfo.get(DomainConstants.SELECT_NAME).toString();
        String strLatestversion = mIPInfo.get("attribute[IMP_LatestVersion]").toString(); // Added for bug 738
        String strDescription = mIPInfo.get(DomainConstants.SELECT_DESCRIPTION).toString();
        String indent= "                    ";
        String indentForRev= "            ";
        int iLength = indent.length();
        int nLength = strName.length();
        if(nLength < iLength) {
          String sRevIndent = indent.substring(0, iLength - nLength);
          String sDecIndent = indentForRev.substring(0, indentForRev.length() - strLatestversion.length());
          sbReturn.append(System.lineSeparator());
          sbReturn.append(strName);
          sbReturn.append(sRevIndent);
          sbReturn.append(strLatestversion);
          sbReturn.append(sDecIndent);
          sbReturn.append(strDescription);          
        }      
        hmData.put("latest_version", strLatestversion);
        hmData.put("description", strDescription);
        hmFinalData.put(strName, hmData);
      }
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put(strMessage, sbReturn);
      returnObj.put("message-out", hmFinalData);
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getDTreeSpecs:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  /**
   * getRelatedIPSocs of an IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @POST
  @Path("/getRelatedIPSocs")
  public Response getRelatedIPSocs(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
	  // Changed for 410
      String strIPIDName = form.asMap().getFirst("IPID");
      String strYamlRequest = form.asMap().getFirst("YamlRequest");
      HashMap<String, String> hmArg = new HashMap<>();
      hmArg.put("IPID", strIPIDName);
      hmArg.put("YamlRequest", strYamlRequest);
      Map retunMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null,
          "getRelatedIPSocs", JPO.packArgs(hmArg), Map.class);
      Map<String, Object> hmRetunData = new LinkedHashMap<>();
      if (!retunMap.isEmpty()) {
        returnObj.put(strMessage, (List<String>) retunMap.get(strMessage)); //Added for SWIMP-525
        hmRetunData = (Map<String, Object>) retunMap.get(OUTMSG);
        returnObj.put(OUTMSG, hmRetunData);
      } else {
        returnObj.put(strMessage, new ArrayList<>()); //Added for SWIMP-525
        returnObj.put(OUTMSG, hmRetunData);
      }
      returnObj.put("code", Integer.valueOf(0));
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getRelatedIPSocs:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * GetSoCIPRevisions of an IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @POST
  @Path("/GetSoCIPRevisions")
  public Response getSocIPRevisions(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    HashMap hmUpdateData = new HashMap();
    List<Map> lsOutFile = new ArrayList<>();
    List<Map<String, Object>> lsIPHierarchy = new ArrayList<>(); //Added for SWIMP-570
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String strSoCName = form.asMap().getFirst(CONST_PROJECTNAME);
      //Added for SWIMP-570 : Starts
      String strHIPID = form.asMap().getFirst("ip_id");
      String strHIPTag = form.asMap().getFirst("ip_revision");
      //Added for SWIMP-570 : Ends

      hmUpdateData.put(KEY_STR_SOCNAME, strSoCName); //Modified for SWIMP-570
      //Added for SWIMP-570 : Starts
      hmUpdateData.put("IPID", strHIPID);
      hmUpdateData.put("IPTag", strHIPTag);
      //Added for SWIMP-570 : Ends

      String retunMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "getRelatedIPofSoC",
          JPO.packArgs(hmUpdateData), String.class);
      returnObj.put(strMessage, retunMap);
      
      lsOutFile = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "getYamlOutForConsumedIP",
          JPO.packArgs(hmUpdateData), List.class); // Added for bug 969
      
      returnObj.put(OUTMSG, lsOutFile);

      //Added for SWIMP-570 : Starts
      String sType = "";
      String sName = "";
      String sRevision = "";
      String sProjectID = "";
      if (StringUtils.isNotBlank(strSoCName)) {
    	  sType = TYPE_IMP_SOC;
    	  sName = strSoCName;
      } else {
    	  sType = TYPE_IMP_IPPRODUCT;
    	  sName = strHIPID;
    	  sRevision = "A";
      }
      BusinessObject boObject = new BusinessObject(sType, //Type
    		  sName, //Name
    		  sRevision, //Revision
    		  PropertyUtil.getSchemaProperty(context, VAULT_SERV_PROD)); //Vault
      if (boObject.exists(context)) {
    	  DomainObject domIPObj = new DomainObject(boObject);
    	  sProjectID = domIPObj.getInfo(context, DomainConstants.SELECT_ID);
      }
      Map<String, String> hmArgsData = new HashMap<>();
      hmArgsData.put("ID", sProjectID);
      hmArgsData.put(CONST_PROJECTNAME, sName);
      hmArgsData.put("Tag", strHIPTag);
      hmArgsData.put(KEY_OPERATION, EVENT_QUERY); //Added for SWIMP-570
      Map<String, Object> returnMap = new HashMap<>();
      if (TYPE_IMP_IPPRODUCT.equals(sType)) {
    	  returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getHIPStructure4VerifyIP", JPO.packArgs(hmArgsData), Map.class);
      } else {
    	  returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getSoCHierarchyStructure", JPO.packArgs(hmArgsData), Map.class);
      }
      lsIPHierarchy.add(returnMap);
      returnObj.put(KEY_IP_STRUCTURE, returnMap);
      //Added for SWIMP-570 : Ends

    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getSocIPRevisions:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * checkin public Documents while publish.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/publicDocuments")
  public Response publicDocuments(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    HashMap hmUpdateData = new HashMap();
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String sIPName = form.asMap().getFirst("sIPName");
      String sPath = form.asMap().getFirst(strPath);
      String sUser = form.asMap().getFirst("sUser"); // Added for 984 and 985

      hmUpdateData.put("sIPName", sIPName);
      hmUpdateData.put(strPath, sPath);
      hmUpdateData.put("sUser", sUser); // Added for 984 and 985
      Map mpReturnData = JPO.invoke(context, IPVERIFICATION_JPO, null, "checkinPublicDocumentsToIP",
          JPO.packArgs(hmUpdateData), Map.class);
      returnObj.put(strMessage, mpReturnData);
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in publicDocuments:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Checks if the context user is IP owner or co owner.
   *
   * @param req the req
   * @return the string
   * @throws JSONException 
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @GET
  @Path("/checkAdminAccess")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response checkAdminAccess(@Context HttpServletRequest req) throws IMPServiceException  {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(req, false)){// Modified for 2019x Upgrade
      boolean bRole = PersonUtil.hasAssignment(context, "VPLMProjectAdministrator");
      boolean bRole1 =
          PersonUtil.hasAssignment(context, "ctx::VPLMProjectAdministrator.Broadcom Ltd.IMP_IPSpace");
      if (bRole1 || bRole) {
        returnObj.put("code", Integer.valueOf(0));
        returnObj.put(strMessage, "Is Admin");
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "Is not Admin");
      }
    } catch (Exception exp) {
      logger.log(Level.SEVERE, "Exception in checkAdminAccess:   ", exp);
      throw new IMPServiceException(exp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * Soc Project Verification Status Notification.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param strSoCName the str so C name
   * @return the response
   * @throws IMPServiceException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"deprecation", "rawtypes"})
  @POST
  @Path("/socProjectVerificationStatus")
  public Response socProjectVerificationStatus(@Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("ProjectName") String strSoCName) throws IMPServiceException  {

    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String sTypeIPRelease = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
	  //Modified for SWIMP-46
      String sRelIPVerificationForSoc =
          PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPVerificationStatusForSoC");
      String sTypeIPBranch = PropertyUtil.getSchemaProperty(context, IP_BRANCH_TYPE);
      String sTypeWaterMark = PropertyUtil.getSchemaProperty(context, "type_IMP_IP_Watermark");//added for SWIMP-1
      //Modified for SWIMP-322, Replaced the IMP_IPSoCApprovalStatus with attribute_IMP_ApprovalStatus
      String sAttrIPSocApprovalStatus =
          PropertyUtil.getSchemaProperty(context, "attribute_IMP_ApprovalStatus");
      String sPolicySOC = PropertyUtil.getSchemaProperty("policy_IMP_SoC");
      String sStateFabrication = "state_Fabrication";
      String strFabrication =
          FrameworkUtil.lookupStateName(context, sPolicySOC, sStateFabrication);
      String sTypeIMPSoC = PropertyUtil.getSchemaProperty(context, SOC_TYPE);

      StringList slObjSel = new StringList(DomainConstants.SELECT_ID);
      String sRev = "";
      MapList mlObjects = DomainObject.findObjects(context, sTypeIMPSoC, strSoCName, sRev, "*",
          SERV_PROD, null, false, slObjSel);
      if (!mlObjects.isEmpty()) {
        Map mp = (Map) mlObjects.get(0);
        String strObjId = (String) mp.get(DomainConstants.SELECT_ID);
        DomainObject db = new DomainObject(strObjId);
        String doSOCId = db.getId(context);
        DomainObject masterObject = new DomainObject(doSOCId);
        String sObjectState = masterObject.getInfo(context, DomainObject.SELECT_CURRENT);
        int sPending = 0;
        int sApproved = 0;
        int sRejected = 0;
        Map sSoCMap;
        String sIPStatus;
        String strTotalPendingIpsConnectedtoSoC;
        String strTotalApprovedIpsConnectedtoSoC;
        String strTotalRejectedIpsConnectedtoSoC;
        String strTotalIpsConnectedtoSoC;
        int strTotalIps;
        Pattern typePattern = new Pattern(sTypeIPRelease);
        typePattern.addPattern(sTypeIPBranch);
        typePattern.addPattern(sTypeWaterMark);//added for SWIMP-1
        if (sObjectState.equalsIgnoreCase(strFabrication)) {
          // Modified for IMPBRCM-641 & IMPBRCM-488 Starts
          StringList slRelSelects = new StringList(10);
          slRelSelects.add("attribute[" + sAttrIPSocApprovalStatus + "]");
          MapList resultListForSoC =
              masterObject.getRelatedObjects(context, sRelIPVerificationForSoc, // relationship
                  // pattern
                  typePattern.getPattern(), // type pattern
                  null, // Object selects
                  slRelSelects, // relationship selects
                  true, // from
                  false, // to
                  (short) 1, // expand level
                  null, // object where
                  null, // relationship where
                  0); // limit

          strTotalIps = resultListForSoC.size();
          strTotalIpsConnectedtoSoC = Integer.toString(strTotalIps);

          Iterator itrSoc = resultListForSoC.iterator();
          while (itrSoc.hasNext()) {
            sSoCMap = (Map) itrSoc.next();
            sIPStatus = (String) sSoCMap.get("attribute[" + sAttrIPSocApprovalStatus + "]");

            switch (sIPStatus) {
              case "Approved":
                sApproved++;
                break;
              case "Pending":
                sPending++;
                break;
              default:
                sRejected++;
            }
          }
          strTotalPendingIpsConnectedtoSoC = Integer.toString(sPending);
          strTotalApprovedIpsConnectedtoSoC = Integer.toString(sApproved);
          strTotalRejectedIpsConnectedtoSoC = Integer.toString(sRejected);
          // Adding IP status to returnObject
          returnObj.put("Total IPs", strTotalIpsConnectedtoSoC);
          returnObj.put("IPs Approved", strTotalApprovedIpsConnectedtoSoC);
          returnObj.put("IPs Rejected", strTotalRejectedIpsConnectedtoSoC);
          returnObj.put("IPs Pending", strTotalPendingIpsConnectedtoSoC);
          // Modified for IMPBRCM-641 & IMPBRCM-488 Ends
        } else {
          returnObj.put(strMessage,
              "SOC '" + strSoCName + "' is not in '" + strFabrication + "'");
        }
      } else {
        returnObj.put(strMessage, "SOC '" + strSoCName + "' does not exist in IMP");
      }     
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in socProjectVerificationStatus:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  
  /**
   * Gets the IP revisions.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the IP revisions
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @POST
  @Path("/getIPRevisions")
  public Response getIPRevisions(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    HashMap hmUpdateData = new HashMap();
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String strIPName = form.asMap().getFirst("IPID");
      hmUpdateData.put("strIPName", strIPName);

      Map retunMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null,
          "getRelatedBranchObjects", JPO.packArgs(hmUpdateData), Map.class);
      returnObj.put(strMessage, retunMap);

    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getIPRevisions:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Checks if is SOC available.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param strIPId the str IP id
   * @param strTag the str tag
   * @return the response
   * @throws JSONException 
   * @throws Exception the exception
   */
  @SuppressWarnings("rawtypes")
  @GET
  @Path("/watermarkstring")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response getWaterMarkString(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      @QueryParam("IPID") String strIPId, @QueryParam("TAG") String strTag) throws IMPServiceException  {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      StringList slWMDetails = new StringList();
      slWMDetails.add(DomainConstants.SELECT_ID);
      //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
      slWMDetails.add("attribute[IMP_IPRevisionWatermark].value");
      MapList mlWMObjects = DomainObject.findObjects(context,
          PropertyUtil.getSchemaProperty(context, "type_IMP_WaterMarkString"), strIPId, strTag, "*",
          context.getVault().getName(), null, true, slWMDetails);
      if (mlWMObjects.isEmpty()) {
        returnObj.put("Value", " ");
      } else {
        Map mp = (Map) mlWMObjects.get(0);
        //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
        String strValue = (String) mp.get("attribute[IMP_IPRevisionWatermark].value");
        returnObj.put("Value", strValue);
      }
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in getWaterMarkString:   ", e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  
  /**
   * Gets the list of water marks.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @return the list of water marks
   * @throws IMPServiceException the IMP service exception
   */
  @SuppressWarnings("rawtypes")
  @POST
  @Path("/getListofwatermarks")
  public Response getListOfWaterMarks(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest) throws IMPServiceException  {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      //Modified for SWIMP-1 s
      Pattern typePattern = new Pattern(PropertyUtil.getSchemaProperty(context, "type_IMP_IP_Watermark"));
      StringList slObjectSelects = new StringList(1);
      //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
      slObjectSelects.add("attribute[IMP_IPRevisionWatermark]");
      //Modified for SWIMP-1 e
      String sWhere = "attribute[IMP_IPRevisionWatermark]!=''";
      List<String> lsWaterMarks = new ArrayList<>();
      MapList mlObjects = DomainObject.findObjects(context, typePattern.getPattern(), "*",
          "A", "*", SERV_PROD, sWhere, true, slObjectSelects);
      if(!mlObjects.isEmpty()){
        Iterator itr = mlObjects.iterator();
        while (itr.hasNext()) {
          Map mpReleaseInfo = (Map) itr.next();
          //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
          String strAttrWaterMarkID = mpReleaseInfo.get("attribute[IMP_IPRevisionWatermark]").toString();
          lsWaterMarks.add(strAttrWaterMarkID);
        }
        returnObj.put(strMessage, lsWaterMarks);
      } else {
        returnObj.put(strMessage, lsWaterMarks);
      }
      returnObj.put("code", Integer.valueOf(0));
    } catch (FrameworkException | JSONException e) {
      logger.log(Level.SEVERE, "Exception in getListOfWaterMarks "+ e);
      throw new IMPServiceException(e);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

 //Added for SWIMP-154:Starts 
  /**
   * Get IP Revision for Watermark
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param sWatermark the String Watermark
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings("rawtypes")
  @GET
  @Path("/getIPRevisionForWatermark")
 public Response getIPRevisionForWatermark(
          @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
          @QueryParam("WATERMARK") String sWatermark) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade

      Map<String,String> hmPackData = new HashMap <>();
      hmPackData.put("Watermark", sWatermark);
      Map returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getIPRevisionForWatermark",
	          JPO.packArgs(hmPackData), Map.class);
      if (!returnMap.isEmpty()) {
          String sIPID = (String) returnMap.get("IPID");
          returnMap.remove("IPID");
          hmPackData.clear();
          hmPackData.put("strIPName", sIPID);
          Map ipDataMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null,
              "getRelatedBranchObjects", JPO.packArgs(hmPackData), Map.class);
          Map mIPData = (Map)ipDataMap.get("IPData");
          returnObj.put("IPData", mIPData);
          returnObj.put("IPID", sIPID);
          returnObj.put("IPRevisionData", returnMap);
          returnObj.put("code", Integer.valueOf(0));
        } else
        {
        	returnObj.put("code", Integer.valueOf(1));
        }
    } catch (Exception e) {
        logger.log(Level.SEVERE, "Exception in Getting IP revision for Watermark   ", e);
        throw new IMPServiceException(e);
    }
      return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
}
//Added for SWIMP-154:Ends

  /**
   * IP External Report - Returns Json String for the given IP.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @GET
  @Path("/getIpDetails")
  public Response getIpDetails(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x upgrade
    	String ipId = form.asMap().getFirst("ipId");
      String sIPId = getIpId(context,ipId);
      
      if (!StringUtils.isEmpty(sIPId)) {
          HashMap hmJSONArgs = new HashMap();
          hmJSONArgs.put(OBJ_ID, sIPId);
          Map strResult = JPO.invoke(context, REL_UTIL_JPO, null,
              "getJSONStringForIPProductInfo", JPO.packArgs(hmJSONArgs), Map.class);

          returnObj.put("JSONStringForIP", strResult);
          returnObj.put("code", Integer.valueOf(0));
          returnObj.put(strMessage, EXEC_SUCC);
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "No IP Found with given IP name.");
      }
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getIpDetails:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }
  
  
  /**
   * IP External Report - Returns Json String for the given SoC.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @GET
  @Path("/getSocDetails")
  public Response getSocDetails(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,@QueryParam("socId") String strSoCName) throws IMPServiceException {
    String strReturn = "";
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      HashMap hmGetSoCID = new HashMap();
      //String strSoCName = form.asMap().getFirst("socId");
      hmGetSoCID.put("strSoCName", strSoCName);
      strReturn = JPO.invoke(context, REL_UTIL_JPO, null,
          "getSoCIdFromSoCName", JPO.packArgs(hmGetSoCID), java.lang.String.class);

      if (strReturn != null && !"".equals(strReturn) && strReturn.length() > 0) {
          HashMap hmJSONArgs = new HashMap();
          hmJSONArgs.put(OBJ_ID, strReturn);
          Map strResult = JPO.invoke(context, REL_UTIL_JPO, null,
              "getJSONStringForSoCInfo", JPO.packArgs(hmJSONArgs), Map.class);

          returnObj.put("JSONStringForSoC", strResult);
          returnObj.put("code", Integer.valueOf(0));
          returnObj.put(strMessage, EXEC_SUCC);
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "No SoC Found with given SoC name.");
      }
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getSocDetails:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * IP External Report - Returns Json String for the given IP Branch And Release Info.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @GET
  @Path("/getIpReleases")
  public Response getIpReleases(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      String sIpId = getIpId(context, form.asMap().getFirst("ipId"));
      
      if (!StringUtils.isEmpty(sIpId)) {
        HashMap hmJSONArgs = new HashMap();
        hmJSONArgs.put(OBJ_ID, sIpId);
        String strResult = JPO.invoke(context, REL_UTIL_JPO, null,
            "getJSONStringForIPProductBranchAndReleaseInfo", JPO.packArgs(hmJSONArgs),
            java.lang.String.class);
        returnObj.put("JSONStringForIPReleaseInfo", strResult);
        returnObj.put("code", Integer.valueOf(0));
        returnObj.put(strMessage, EXEC_SUCC);
      } else {
        returnObj.put("code", Integer.valueOf(1));
        returnObj.put(strMessage, "No IP Found with given IP name.");
      }
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getIpReleases:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * IP Replicated Locations.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/getIPRepLocs")
  public Response sendNotification(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    String strReturn = "";
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      HashMap hmGetRepLoc = new HashMap();
      String strIPName = form.asMap().getFirst(IPNAME);
      String strIPTag = form.asMap().getFirst("IPTag");
      String sContextEnv = form.asMap().getFirst(IMP_ENV);
            
      hmGetRepLoc.put("strIPName", strIPName);
      hmGetRepLoc.put("strIPTag", strIPTag);
      hmGetRepLoc.put(IMP_ENV,sContextEnv);
      strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "getReplicationLocations",
          JPO.packArgs(hmGetRepLoc), String.class);
      returnObj.put("strRepLocations", strReturn);
      returnObj.put("code", Integer.valueOf(0));

    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in sendNotification:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Gets the service account details.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the service account details
   * @throws Exception the exception
   */
  @POST
  @Path("/GetServiceAccountDetails")
  public Response getServiceAccountDetails(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      HashMap<String, String> hmPackData = new HashMap<>();
      String strEnv = form.asMap().getFirst("env");      
      hmPackData.put("env", strEnv);      
      String retunMap =
          JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "encodePassword", JPO.packArgs(hmPackData), String.class);
      returnObj.put(strMessage, retunMap);
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getServiceAccountDetails:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }


  /**
   * Unix Domain Mapping to Publish Site.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/getPublishSiteFromUnixDomain")
  public Response getPublishSiteFromUnixDomain(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    String strReturn = "";
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){//Modified for 2019x Upgrade
      HashMap hmGetPublishSite = new HashMap();
      String strUnixDomain = form.asMap().getFirst("strUnixDomain");
      String sContextEnv = form.asMap().getFirst(IMP_ENV);
      hmGetPublishSite.put("strUnixDomain", strUnixDomain);
      hmGetPublishSite.put(IMP_ENV,sContextEnv);
      strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "getSiteForUniXDomain",
          JPO.packArgs(hmGetPublishSite), String.class);
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put("strPublishSite", strReturn);
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getPublishSiteFromUnixDomain:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * Gets the module URL.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the module URL
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @POST
  @Path("/GetModuleURL")
  public Response getModuleURL(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    HashMap hmUpdateData = new HashMap();
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){// Modified for 2019x Upgrade
      String strIPName = form.asMap().getFirst("sIPName");
      hmUpdateData.put("strIPName", strIPName);
      String returnMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "getIPObjectDetails",
          JPO.packArgs(hmUpdateData), String.class);
      returnObj.put(strMessage, returnMap);
    } catch (Exception jpoExp) {
      logger.log(Level.SEVERE, "Exception in getModuleURL:   ", jpoExp);
      throw new IMPServiceException(jpoExp);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * URL Mapping to Publish Site.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/getIPPublishSite")
  public Response getIPPublishSite(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws IMPServiceException {
    String strReturn = "";
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {//Modified for 2019x Upgrade
      HashMap hmGetPublishSite = new HashMap();
      String strIPName = form.asMap().getFirst(IPNAME);
      String sContextEnv = form.asMap().getFirst(IMP_ENV);      
      hmGetPublishSite.put(IPNAME, strIPName);
      hmGetPublishSite.put(IMP_ENV,sContextEnv);
      strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "getIPPublishSite",
          JPO.packArgs(hmGetPublishSite), String.class);
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put("strPublishSite", strReturn);
    } catch (Exception exception) {
      logger.log(Level.SEVERE, "Exception in getModuleURL:   ", exception);
      throw new IMPServiceException(exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  /**
   * URL Mapping to Publish Site.
   *
   * @param paramHttpServletRequest the param http servlet request
   * @param form the form
   * @return the response
   * @throws JSONException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/getLocalCachePath")
  public Response getLocalCachePath(
      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
      jakarta.ws.rs.core.Form form) throws  JSONException {
    String strReturn = "";
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){// Modified for 2019x Upgrade
      HashMap hmGetLocCache = new HashMap();
      String strPublishSite = form.asMap().getFirst("strPublishSite");
      String sContextEnv = form.asMap().getFirst(IMP_ENV);
      hmGetLocCache.put("strPublishSite", strPublishSite);
      hmGetLocCache.put(IMP_ENV,sContextEnv);
      strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "getLocalCacheFromPublishSite",
          JPO.packArgs(hmGetLocCache), String.class);
      returnObj.put("code", Integer.valueOf(0));
      returnObj.put("strLocalCache", strReturn);
    } catch (Exception exception) {
      returnObj.put("code", Integer.valueOf(500));
      returnObj.put(strMessage, "EXCEPTION: " + exception.getMessage());
      logger.log(Level.SEVERE, "Exception in getLocalCachePath:   ", exception);
    }
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  } 

  // Added for user story 224
  /**
   * Get All details of IP and SOC from IMP.
   *
   * @param req the req
   * @param strInputData
   * @return the string
   * @throws IOException
   * @throws MatrixException 
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @GET
  @Path("/GetAllDetailsFromIMP")
	public Response getAllDetailsFromIMP(@Context HttpServletRequest req, @Context HttpHeaders headers,
			@QueryParam("DATA") String strInputData,
			@QueryParam(USRNAME) String strInputUserName, @QueryParam("OBJECTTYPE") String strInputObjectType)
					throws IMPServiceException {
	  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
	  matrix.db.Context context =null;
	  try {
		  Map<String, String> mpUserDetails = getUserNameAndPassword(headers);//Fetching the user details from restful header
		  Map<String, Object> mpReturnContext = getValidUserContext(req, mpUserDetails,
				  strInputUserName); //Added for SWIMP-56. Validates from type and creates the context
		  context = (matrix.db.Context) mpReturnContext.get(CONTEXT);//Fetching the context
		  if (context != null) {//Modified for SWIMP-56 
			  HashMap<String, String> hmJPOArgsData = new HashMap<>();
			  StringList slObjectSelects = new StringList(DomainObject.SELECT_ID);
			  slObjectSelects.add(DomainObject.SELECT_TYPE);
			  slObjectSelects.add(DomainObject.SELECT_MODIFIED);
			  List<Map> lsReturn = new ArrayList<>();
			  if (strInputObjectType == null || strInputObjectType.isEmpty()) {//Added for SWIMP-56. Setting the Object Type
				  String strSOCType = PropertyUtil.getSchemaProperty(context, SOC_TYPE);
				  String strIPProductType = PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE);
				  Pattern typePattern = new Pattern(strIPProductType);
				  typePattern.addPattern(strSOCType);
				  strInputObjectType = typePattern.getPattern();
			  }
			  // modified for SWIMP-183
			  MapList mlObjects = DomainObject.findObjects(context, strInputObjectType, // type pattern  Modified for SWIMP-56
					  strInputData, // name of object
					  "*", // revision of object
					  "*", // owner pattern
					  SERV_PROD, // vault pattern 
					  null, // where expression
					  null, // query name
					  true, // expand type
					  slObjectSelects, // object select
					  (short) 1// limit
					  );
			  if (!mlObjects.isEmpty()) {
				  Map mpData = (Map) mlObjects.get(0);
				  String strObjId = mpData.get(DomainObject.SELECT_ID).toString();
				  String strObjType = mpData.get(DomainObject.SELECT_TYPE).toString();
				  String strModified = mpData.get(DomainObject.SELECT_MODIFIED).toString();
				  hmJPOArgsData.put(OBJECTLIST, strObjId);//Modified for SWIMP-56
				  hmJPOArgsData.put("modifiedDate", strModified);
				  MapList mpReturnList = JPO.invoke(context, IMPCRON_JPO, null, "getIPSOCDetailsFromDB",
						  JPO.packArgs(hmJPOArgsData), MapList.class);
				  String sUserName = (String) mpReturnContext.get(USRNAME);
				  returnObj = processCacheDataForIPSoC(context,mpReturnList, strObjType,sUserName);//Added for SWIMP-56
			  } else {
				  returnObj.put("data", lsReturn);
			  }
		  } else {

			returnObj.put(strError, mpReturnContext.get(strError));   //Modified for SWIMP-369
				
		  }

	  } catch (Exception exp) {
		  logger.log(Level.SEVERE, "Exception in getAllDetailsFromIMP:   ", exp);
		  throw new IMPServiceException(exp);
	  } finally {
		  if (context != null) {
			  try {
				  ContextUtil.popContext(context);
			  } catch (Exception e) {
				  logger.log(Level.SEVERE, "Exception while poping out context in getAllDetailsFromIMP:   ", e);
			  }
		  }
	  }
	  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

/**
 * Gets the all details from IMP with date.
 *
 * @param req the req
 * @param strFromDate the str from date
 * @param strToDate the str to date
 * @param strDateFor the str date for
 * @param strInputData the str input data
 * @param sIMPFoundry the str foundry
 * @param sIMPProcessNode the str processnode
 * @param sIMPSubProcess the str subprocess
 * @param sIMPProductDivision the str Business Unit
 * @param sIMPMetalStack the str Metal stack
 * @param sIMPIPName the str IP Name
 * @param sIPSource the str IP Source
 * @param sVendor the str Vendor
 * @param sIPSOCID the str IP/SoC Id 
 * @return the all details from IMP with date
 * @throws JSONException
 * @throws IOException
 * @throws MatrixException 
 * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  @GET
  @Path("/GetAllDetailsFromIMPWithDate")
	public Response getAllDetailsFromIMPWithDate(@Context HttpServletRequest req, @Context HttpHeaders headers,
			@QueryParam("FROM_DATE") String strFromDate, @QueryParam("TO_DATE") String strToDate,
			@QueryParam("DATE_FOR") String strDateFor, @QueryParam("DATA") String strInputData,
			@QueryParam(USRNAME) String strInputUserName, @QueryParam("IMP_Foundry") String sIMPFoundry,
			@QueryParam("IMP_ProcessNode") String sIMPProcessNode,@QueryParam(STR_SUBPROCESS) String sIMPSubProcess,
			@QueryParam(STR_PRODUCTDIVISION) String sIMPProductDivision,@QueryParam("IMP_MetalStack") String sIMPMetalStack,
			@QueryParam("IMP_IPName") String sIMPIPName,@QueryParam("IMP_IPSource") String sIPSource,
			@QueryParam("IMP_Vendor") String sVendor, @QueryParam("IMP_ID") String sIPSOCID)
			throws IMPServiceException {
		org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		matrix.db.Context context = null;
		try {
			System.out.println("===========GetAllDetailsFromIMPWithDate:: service method invoked ========");
			Map<String, String> mpUserDetails = getUserNameAndPassword(headers);
			Map<String, Object> mpReturnContext = getValidUserContext(req, mpUserDetails, strInputUserName); // Modified for SWIMP-245
			context = (matrix.db.Context) mpReturnContext.get(CONTEXT);// Fetching the context
			if (context != null) {// Modified for SWIMP-245
				String strDate;
				String sWhere = null;
				if ("Modified".equalsIgnoreCase(strDateFor)) {
					System.out.println("===========GetAllDetailsFromIMPWithDate:: Modified Data ========");
					strDate = "modified";
				} else if ("Created".equalsIgnoreCase(strDateFor)) {
					strDate = "originated";
				} else {
					returnObj.put(strMessage,
							"Invalid input data for DATE_FOR; provide Modified or Created as an input");
					return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
				}
				if (StringUtils.isBlank(strInputUserName) || "eps_integration".equalsIgnoreCase(strInputUserName)) {
					sWhere = strDate + ">='" + strFromDate + "'&&" + strDate + "<='" + strToDate + "'";
				} else if (StringUtils.isBlank(sIPSOCID)) {
					Map<String, String> mInputArgs = new HashMap<>();
					mInputArgs.put(STR_IMPIPNAME, sIMPIPName);
					mInputArgs.put(STR_IMPFOUNDRY, sIMPFoundry);
					mInputArgs.put(STR_IMPPROCESSNODE, sIMPProcessNode);
					mInputArgs.put(STR_IMPSUBPROCESS, sIMPSubProcess);
					mInputArgs.put(STR_IMPMETALSTACK, sIMPMetalStack);
					mInputArgs.put(STR_IMPPRODUCTDIVISION, sIMPProductDivision);
					mInputArgs.put(STR_IMPIPSOURCE, sIPSource);
					mInputArgs.put(STR_VENDOR, sVendor);
					sWhere = getWhereStringForBuVendorTechStack(context, mInputArgs,
							returnObj);

				}
				StringList slObjectSelects = new StringList(DomainObject.SELECT_ID);
				slObjectSelects.add(DomainObject.SELECT_MODIFIED);
				slObjectSelects.add(DomainConstants.SELECT_NAME);
				slObjectSelects.add(DomainConstants.SELECT_ID);
				slObjectSelects.add("current");

				String strType = "SOC".equalsIgnoreCase(strInputData)
						? PropertyUtil.getSchemaProperty(context, SOC_TYPE)
						: PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE);
				String strName = StringUtils.isBlank(sIPSOCID) ? "*" : sIPSOCID;
				List<Map> lsMapData = new ArrayList<>();
				MapList mlObjects = DomainObject.findObjects(context, strType, strName, "*", "*", SERV_PROD,
						sWhere, true, slObjectSelects);
				Iterator iterate = mlObjects.iterator();
				String strObjId;
				// modified for SWIMP-183 -START
				StringBuilder strSBObjectList = null;
				while (iterate.hasNext()) {
					Map mObjectDetails = (Map) iterate.next();
					strObjId = mObjectDetails.get(DomainObject.SELECT_ID).toString();
					if (strSBObjectList != null) {
						strSBObjectList.append(",");
					} else {
						strSBObjectList = new StringBuilder();
					}
					strSBObjectList.append(strObjId);
				}
				if (StringUtils.isBlank(strFromDate) && StringUtils.isBlank(strToDate) && !mlObjects.isEmpty()) {
					mlObjects.sort(DomainConstants.SELECT_MODIFIED, "descending", "Date");
					Map mEndDetails = (Map) mlObjects.get(0);
					strToDate = mEndDetails.get(DomainObject.SELECT_MODIFIED).toString();
					Map mStartDetails = (Map) mlObjects.get(mlObjects.size() - 1);
					strFromDate = mStartDetails.get(DomainObject.SELECT_MODIFIED).toString();
				}

				if (strSBObjectList != null) {
					Map<String, String> hmJPOArgsData = new HashMap<>();
					hmJPOArgsData.put(OBJECTLIST, strSBObjectList.toString());
					hmJPOArgsData.put("fromDate", strFromDate);
					hmJPOArgsData.put("toDate", strToDate);
					hmJPOArgsData.put("dateFor", strDateFor);
					hmJPOArgsData.put("objectType", strType);
					lsMapData = JPO.invoke(context, IMPCRON_JPO, null, "getIPSOCDetailsFromDB",
							JPO.packArgs(hmJPOArgsData), MapList.class);
					if (lsMapData.isEmpty()) {
						returnObj.put("data", "No data found.");
					}
				}
				if (("IMP_SoC").equalsIgnoreCase(strType)) {// Modified for SWIMP-245
					List<Map> lsTempData = new ArrayList<>();
					String sUserName = (String) mpReturnContext.get(USRNAME);
					for (Map tempMap : lsMapData) {
						lsTempData.add(processSoCOutputWhenAccessIsProtected(context, tempMap, sUserName));
					}
					lsMapData.clear();
					lsMapData.addAll(lsTempData);
				}
				// modified for SWIMP-183 --END
				//Added for SWIMP-369 --START
				if (lsMapData.size() == 1) {
					Map<String, Object> mIpInfo = lsMapData.get(0);
					if (mIpInfo.get("error:") != null) {
						returnObj.put(strError, (String) mIpInfo.get("error:"));
					} else {
						String verifyIPLogs = "";
				          Map<String, String> hmJPOArgsData = new HashMap<>();
				          for (Map verificationDataMap : lsMapData) {
				            List<Map> lsVerificationData = (List<Map>)verificationDataMap.get("soc_ip_verifications");
				            if (lsVerificationData != null)
				              for (Map<String, String> verification : lsVerificationData) {
				                hmJPOArgsData.put("sVerifyid", (String)verification.get("request_id"));
				                verifyIPLogs = (String)JPO.invoke(context, "IMP_IPVerification", null, "getVerifyIPLogsForEPSWithVerifyid", 
				                    JPO.packArgs(hmJPOArgsData), String.class);
				                System.out.println("===========GetAllDetailsFromIMPWithDate:: verifyIPLogs ========"+verifyIPLogs);
				                verification.put("verifyIP_logs", verifyIPLogs);
				              }  
				          }
						returnObj.put(strInputData.toLowerCase() + "_data", lsMapData);
					}
				} else {
					String verifyIPLogs = "";
			          Map<String, String> hmJPOArgsData = new HashMap<>();
			          for (Map verificationDataMap : lsMapData) {
			            List<Map> lsVerificationData = (List<Map>)verificationDataMap.get("soc_ip_verifications");
			            if (lsVerificationData != null)
			              for (Map<String, String> verification : lsVerificationData) {
			                hmJPOArgsData.put("sVerifyid", (String)verification.get("request_id"));
			                verifyIPLogs = (String)JPO.invoke(context, "IMP_IPVerification", null, "getVerifyIPLogsForEPSWithVerifyid", 
			                    JPO.packArgs(hmJPOArgsData), String.class);
			                System.out.println("===========GetAllDetailsFromIMPWithDate:: verifyIPLogs ========"+verifyIPLogs);
			                verification.put("verifyIP_logs", verifyIPLogs);
			              }  
			          } 
					returnObj.put(strInputData.toLowerCase() + "_data", lsMapData);
				}
				//Added for SWIMP-369 --END
			} else {
				returnObj.put(strError, mpReturnContext.get(strError));  //Modified for SWIMP-369
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in getAllDetailsFromIMPWithDate:   ", exp);
			throw new IMPServiceException(exp);
		} finally {
			if (context != null) {
				try {
					ContextUtil.popContext(context);
				} catch (FrameworkException e) {
					logger.log(Level.SEVERE, "Exception in getAllDetailsFromIMPWithDate while poping out context:   ", e);
				}
			}
		}
		return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	}

@SuppressWarnings("rawtypes")
  private Map getUserNameAndPassword(@Context HttpHeaders headers){
    Map<String, String> mReturn = new HashMap<>();
    List<String> authHeaders = headers.getRequestHeader(HttpHeaders.AUTHORIZATION);
    String decodedAuth = "";
    if(!authHeaders.isEmpty()) {
    String authString = authHeaders.get(0);
    if (authString != null && !authString.isEmpty()) {
      String[] authParts = authString.split("\\s+");
      String authInfo = authParts[1];
      // Decode the data back to original string
      byte[] bytes;
      bytes = new Base64().decode(authInfo);
      decodedAuth = new String(bytes);
    }
    String user  = decodedAuth.substring(0,decodedAuth.indexOf(':'));
    String pass  = decodedAuth.substring(decodedAuth.indexOf(':')+1, decodedAuth.length());
    mReturn.put("username", user);
    mReturn.put("password", pass);
    }
    return mReturn;
  }
          
  private boolean getOktaAuthentication(String user, String pass) {
    boolean bStatus = false;
    if (pass.isEmpty()) {
      return bStatus;
    }
    String resultCode = validateUser(user, pass);
    if ("SUCCESS".equalsIgnoreCase(resultCode)) {
      bStatus = true;
      logger.info("User Authenticated");
    } else if ("E0000004".equalsIgnoreCase(resultCode)) {
      logger.info("userid and/or pwd failed to be authenticated");
    } else if ("E0000007".equalsIgnoreCase(resultCode)) {
      logger.info("URL failed");
    } else if ("E0000011".equalsIgnoreCase(resultCode)) {
      logger.info("API key failed");
    } else {
      logger.info("Unknown Response Code");
    }
    return bStatus;
  }

  private String validateUser(String username, String password){
    String status = "BLANK";
    try {
      ApiClientConfiguration oktaSettings = new ApiClientConfiguration("https://broadcom.okta.com",
          "00Zb8EmUxbMGiUAKfgB1dI55wyqK0LlG909JGYbTwz");
      AuthApiClient authClient = new AuthApiClient(oktaSettings);
      AuthResult result = null;
      try {
        result = authClient.authenticate(username, password, "");
      } catch (ApiException e) {
        logger.log(Level.SEVERE, e.getMessage());
        logger.log(Level.SEVERE, "AgileLDAPLogin: Failed while trying to AUthenticate user from OKTA"
            + username + e.getMessage());
        status = e.getErrorResponse().getErrorCode();
      } catch (IOException e) {
        logger.log(Level.SEVERE, e.getMessage(),e);
        logger.log(Level.SEVERE, "AgileLDAPLogin: Failed while trying to Authenticate user from OKTA"
            + username + e.getMessage());
        status = "IOException";
      }
      if (result != null) {
        status = result.getStatus();
      }
    } catch (Exception e) {
      logger.log(Level.SEVERE, "Exception in validateUser: "+ e);
    }
    return status;
  }

  private static Properties loadFromFile(String filename) throws IOException {
    InputStream stream = IMPRESTfulServiceImpl.class.getResourceAsStream("/" + filename);
    Properties config = new Properties();
    config.load(stream);
    return config;
  }

  private static String getPropertyValue(String propertyKey) throws IOException {
    String sReturn = "";
    Properties props = loadFromFile("impService.properties");
    if (!propertyKey.isEmpty()) {
      sReturn = props.getProperty(propertyKey);
    }
    return sReturn;
  }

  public static String getDecodePass() throws IOException {
    String decodedAuth;
    byte[] bytes;
    bytes = new Base64().decode(getPropertyValue("IMP_SERVICE_PHRASE"));
    decodedAuth = new String(bytes);
    return decodedAuth;
  }

  /**
   * Added for SWIMP-39: verify-ip should be logged in the CLI history start
   * Post verify ip.
   *
   * @param req the req
   * @param form the form
   * @return the response
   * @throws MatrixException the matrix exception
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes"})
  @POST
  @Path("/verifyipPostProcess")
  public Response verifyipPostProcess(@Context HttpServletRequest req,
		  jakarta.ws.rs.core.Form form) throws Exception {
	  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
	  try (matrix.db.Context context = getAuthenticatedContext(req, false)) { //Modified for 2019x Upgrade
		  logger.info("verifyipPostProcess started");
		  String strVerifyID = form.asMap().getFirst("VerifyID");
		  String strUserName = form.asMap().getFirst(USRNAME);
		  String strGDSPath = form.asMap().getFirst("GDSPath");
		  //SWIMP-94
		  String strProjectName = form.asMap().getFirst("ProjectName");
		  String sProjectType = form.asMap().getFirst("ProjectType"); //Added for SWIMP-31(Phase-2)
		  String strDLCOutForCDL = form.asMap().getFirst("DLCOutForCDL");
		  String strDLCOutForOAS = form.asMap().getFirst("DLCOutForOAS");
		  String ipScoreResultsOutput = form.asMap().getFirst("ipScoreResultsOutput");
		  String strLLCOASOutput = form.asMap().getFirst("strLLCOASOutput");
		  logger.info("strVerifyID .. "+strVerifyID);
		  logger.info("strUserName .. "+strUserName);
		  logger.info("strGDSPath .. "+strGDSPath);
		  //SWIMP-94 
		  logger.info("Project Type .. "+sProjectType); //Added for SWIMP-31(Phase-2)
		  logger.info("Project Name .. "+strProjectName);
		  StringList slObjDetails = new StringList(DomainConstants.SELECT_ID);
		  slObjDetails.add(DomainConstants.SELECT_ID);
		  String strRel = PropertyUtil.getSchemaProperty(context, RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS); //Modified for SWIMP-322
		  slObjDetails.add("from[" + strRel + "].to.attribute[IMP_IPID]");
		  slObjDetails.add("from[" + strRel + "].to.attribute[IMP_IPTag]"); //SWIMP-576
		  MapList mlIPObjectList = DomainObject.findObjects(context,
				  PropertyUtil.getSchemaProperty(context, "type_IMP_VerifyRun"), strVerifyID, "*", "*", "*",
				  null, false, slObjDetails);

		  logger.info("mlIPObjectList.."+mlIPObjectList);
		  if (!mlIPObjectList.isEmpty()) {
			  ContextUtil.pushContext(context, strUserName, "",
					  PropertyUtil.getSchemaProperty(context, VAULT_SERV_PROD));
			  Map mpIPData = (Map) mlIPObjectList.get(0);
			  String strIPName = mpIPData.get("from[" + strRel + "].to.attribute[IMP_IPID]").toString();
			  String strIPTag = mpIPData.get("from[" + strRel + "].to.attribute[IMP_IPTag]").toString(); //SWIMP-576
			  mlIPObjectList = DomainObject.findObjects(context,
					  PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), strIPName.trim(), "*", "*", "*",
					  null, false, slObjDetails);
			  if (!mlIPObjectList.isEmpty()) {
				  mpIPData = (Map) mlIPObjectList.get(0);
				  String strObjId = mpIPData.get(DomainConstants.SELECT_ID).toString();
				  Map mpData = new HashMap();
				  mpData.put("IPID", strObjId);
					mpData.put("COMMENTS", "--project: " + strProjectName + ";  --ip-id:  " + strIPName.trim()
							+ "; --ip-tag: " + strIPTag.trim() + "; --ip-dir: " + strGDSPath); // Modified for SWIMP-576
				  mpData.put("OPERATION", "verify-ip");
				  //SWIMP-94
				  logger.info("Invoking IP Verification JPO for updateAuditRecords....."); 
				  JPO.invoke(context, IPVERIFICATION_JPO, null, "updateAuditRecords", JPO.packArgs(mpData));
			  }
		  }
		  //Added for SWIMP-136 start

		  String sProjectName = form.asMap().getFirst("ProjectName");
		  String sIPIDs = form.asMap().getFirst(STRING_IPIDS);
		  String strENV = form.asMap().getFirst("ENV");

		  if(!"".equals(sIPIDs)) {
			  String sVerifyName = sIPIDs.substring(0, sIPIDs.indexOf(SYMBOL_CARET));
			  HashMap hmArgsData1 = new HashMap();
			  JSONObject mpData = new JSONObject();
			  mpData.put("ProjectName", sProjectName);
			  mpData.put("ProjectType", sProjectType); //Added for SWIMP-31(Phase-2)
			  mpData.put("VerifyName",sVerifyName);
			  mpData.put("context", strUserName);
			  mpData.put("ENV", strENV); 
			  mpData.put("KEY_DLCOutForCDL", strDLCOutForCDL);
			  mpData.put("KEY_DLCOutForOAS", strDLCOutForOAS);
			  mpData.put("KEY_ipScoreResultsOutput", ipScoreResultsOutput);
			  mpData.put("KEY_strLLCOASOutput", strLLCOASOutput);

			  hmArgsData1.put("inputparam", mpData.toString());
			  hmArgsData1.put("ENV", strENV);
			  hmArgsData1.put("PROCESSOR_TYPE", "JPO");
			  hmArgsData1.put("PROCESSOR", "IMP_FabricationApprovals:sendVerifyIPEmailNotification");
			  hmArgsData1.put("REQName", "VerifyIP:SendEmail");
			  hmArgsData1.put("EVENT", "VerifyIP");
			  hmArgsData1.put("sIPIDs", sIPIDs);
			  //SWIMP-94
			  logger.info("Invoking IMP Utility JPO for send Asynchronous Email Job.....");
			  JPO.invoke(context, IMP_UTILITY_JPO, null, "sendAsyncEmailJob",
					  JPO.packArgs(hmArgsData1), String.class); //Modified for SWIMP-322        
		  }
		  //Added for Jira 136 ends
	  } catch (FrameworkException ie) {
		  throw new IMPServiceException(ie);
	  } 
	  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
  }

  //Added for SWIMP-1 s
  public static Map<String, String> convertWMStringToMap(String strToConvertIntoMap)  {
	  Map<String, String> mpReturn = new HashMap<>();
	  //Modified for SWIMP-31 (Phase-2): Starts
	  if (StringUtils.isNotEmpty(strToConvertIntoMap)) {
		  for (String sWM : strToConvertIntoMap.split("\\|")) {
			  if (sWM.indexOf('^') > -1) {
				  mpReturn.put(sWM.split("\\^")[0], sWM.split("\\^")[1]);
			  }
		  }
	  }
	  //Modified for SWIMP-31 (Phase-2): Ends
	  return mpReturn;
  }
 
 public static String convertWMMapToString(Map<String, String> wmMap) {
	  StringBuilder sRevisionWaterMarkID = new StringBuilder();
	  if (null!=wmMap) {
		 for(Map.Entry<String,String> pair : wmMap.entrySet()){
	         sRevisionWaterMarkID.append(pair.getKey());
	         sRevisionWaterMarkID.append("^");
	         sRevisionWaterMarkID.append(pair.getValue());
	         sRevisionWaterMarkID.append("|");
	         }
	  }
	  return sRevisionWaterMarkID.toString();
 }
  //Added for SWIMP-1 e
  
 /**
  * Checks whether user can run verify ip on SoC at Fabrication state
  *
  * @param req the req
  * @return the string
  * @throws JSONException 
  * @throws IMPServiceException 
  * @throws Exception the exception
  */  
 @GET
 @Path("/checkForVerifyIPRun")
 @Consumes(MediaType.TEXT_PLAIN)
 @Produces(MediaType.TEXT_PLAIN)
 @SuppressWarnings("unchecked")
 public Response checkForVerifyIPRun(@Context HttpServletRequest req, @QueryParam("ProjectName") String sProjectName,
		 @QueryParam("Tag") String sTag, @QueryParam("WaterMarks") String sWaterMarks)
				 throws IMPServiceException, JSONException {
	 org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();

	 Map<String,Object> map = null;
	 //SWIMP-94
	 logger.info("Event:VerifyIP");
	 try (matrix.db.Context context = getAuthenticatedContext(req, false)){//Modified for 2019x Upgrade
		 //SWIMP-94
		 logger.info("checkForVerifyIPRun process  started .....");
		 Map<String, Object> returnMap = new HashMap<>();
		 String sProjectType = "HIP"; //Added for SWIMP-31(Phase-2)

		 if (StringUtils.isBlank(sTag) && StringUtils.isNotBlank(sProjectName)) { // Added if condition for SWIMP-31 (Phase-2)
			 StringList slSoCObjDetails = new StringList(DomainConstants.SELECT_ID);
			 slSoCObjDetails.add(SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION);
			 MapList mlSocObjectList = DomainObject.findObjects(context,
					 PropertyUtil.getSchemaProperty(context, SOC_TYPE), sProjectName, "*", "*", "*", null, false,
					 slSoCObjDetails);
			 String sProjectID = "";
			 if (!mlSocObjectList.isEmpty()) {
				 sProjectType = "SOC"; //Added for SWIMP-31(Phase-2)
				 map = (Map<String, Object>) mlSocObjectList.get(0);
				 sProjectID = (String) map.get(DomainConstants.SELECT_ID); //Added for SWIMP-568
				 returnObj.put("SoCHIPVerifyStatus", map.get(SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION));
			 }
			 //Added for SWIMP-31
			 Map<String, String> mWMStrings = convertWMStringToMap(sWaterMarks);
			 Map<String, Object> hmArgsData = new HashMap<>(); //Modified for SWIMP-564
			 hmArgsData.put(STRING_WMSTRINGS, mWMStrings); //Modified for SWIMP-564
			 hmArgsData.put("ID", sProjectID); //Modified for SWIMP-568
			 returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getSoCHIPStructure", JPO.packArgs(hmArgsData), Map.class); //Modified for SWIMP-31(Phase-2)
			 //Added for SWIMP-31
		 } else { //Added for SWIMP-31
			 Map<String, String> hmArgsData = new HashMap<>();
			 hmArgsData.put("ProjectName", sProjectName);
			 hmArgsData.put("Tag", sTag);
			 hmArgsData.put(KEY_OPERATION, EVENT_VERIFYHIP); //Added for SWIMP-564
			 returnObj.put("SoCHIPVerifyStatus", JPO.invoke(context, REL_UTIL_JPO , null, "isHIPandTagValid", JPO.packArgs(hmArgsData), String.class));
			 returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getHIPStructure4VerifyIP", JPO.packArgs(hmArgsData), Map.class);
		 }
		 returnObj.put("wmReturnData", returnMap);
		 returnObj.put("ProjectType", sProjectType); //Added for SWIMP-31(Phase-2)
	 } catch (Exception exp) {
		 logger.log(Level.SEVERE, "Exception in checkForVerifyIPRun:   ", exp);
		 throw new IMPServiceException(exp);
	 }
	 return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
 }


  //Added for SWIMP-119 Starts
  @GET
  @Path("/preDownload")
  @Consumes(MediaType.TEXT_PLAIN)
  @Produces(MediaType.TEXT_PLAIN)
  public Response preDownload(@Context HttpServletRequest req,
      @Context HttpHeaders headers, @QueryParam("ipId") String ipID, @QueryParam("ipBranch") String ipBranch, @QueryParam("ipTag") String ipTag, @QueryParam("forProject") String forProject, @QueryParam("foundry") String foundry, 
      @QueryParam("processNode") String processNode,

      @QueryParam("subProcess") String subProcess, @QueryParam(USRNAME) String sUserName,
      @QueryParam("Event") String sEvent, @QueryParam(IMP_ENV) String strENV , @QueryParam(SUBSCRIPTIONUSER) String sSubscriptionUser)
			throws IMPServiceException {
		String exitCode = "EXIT_CODE";
		JSONObject returnObj = new JSONObject();

		int iAccess = 1;
		try (matrix.db.Context context = getAuthenticatedContext(req, false)) {//Modified for 2019x Upgrade
			iAccess = getAccessForIP(context, ipID, sEvent, sUserName);
			String sIPObjId = getIpId(context, ipID);
			String forProjectObjID = getForProjectID(context,forProject);
			
			if (iAccess == 0 && !StringUtils.isEmpty(sIPObjId)) {
				if(StringUtils.isEmpty(forProjectObjID)) {
					returnObj.put(exitCode, Integer.valueOf(2));
				}else {
					String sIPBranch = StringUtils.isEmpty(ipBranch) ? "Trunk" : ipBranch;
					iAccess = checkBranch(context,sIPObjId,sIPBranch);
					if(iAccess == 0 ) {
						iAccess = validTechStack(context, foundry, processNode, subProcess) ? 0 : 4;
						returnObj.put(exitCode,Integer.valueOf(iAccess));
						if(iAccess == 0) {
							returnObj.put("ipData", getIPCoreData(context, sIPObjId, strENV, sIPBranch));
							returnObj.put("forProjectData", getIPSoCCoreData(context, forProjectObjID, strENV, sIPBranch));
							//Added for SWIMP-166 - s
							returnObj.put("UnAvailableUserList", getUserUnAvailableList(context, sSubscriptionUser));
							//To compare techstack of SoC & IP
							returnObj.put("IsSocIPTechStackSame",
									isSocIPTechStackSame(context, ipID, forProject, sSubscriptionUser));
							//Added for SWIMP-166 - e
						}
					}else {
						returnObj.put(exitCode,Integer.valueOf(iAccess));
					}
				}
			} else {
				returnObj.put(exitCode, Integer.valueOf(1));
				returnObj.put(strMessage, getIPAccessMessage(iAccess));
			}

		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in isIPOwnerOrCoOwner:   ", exp);
			throw new IMPServiceException(exp);
		}
		return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	}
 	
	private String getIPAccessMessage(int iAccess) {
		String msg;
		switch (iAccess) {
		case 1:
			msg = "Not Authorized";
			break;
		case 5:
			msg = "User not available";
			break;
		case 6:
			msg = "IP Inactive";
			break;
		case 9:
			msg = "User Restricted";
			break;
		default:
			msg = "Not Available";
			break;
		}
		return msg;
	}

	private String getIpId(matrix.db.Context context, String ipID) throws Exception {
    	Map<String,String> hmGetIPID = new HashMap<>();
	      hmGetIPID.put("strIPName", ipID);
	      return JPO.invoke(context, REL_UTIL_JPO, null, "getIPIdFromIPName",
	          JPO.packArgs(hmGetIPID), String.class);
	}

	//Added for SWIMP-119
 	@SuppressWarnings("unchecked")
	private boolean validTechStack(matrix.db.Context context, String usrEntrdFoundry, String usrEntrdProcessNode,
			String usrEntrdSubProcess) throws Exception {
		boolean validData = StringUtils.isEmpty(usrEntrdFoundry) && StringUtils.isEmpty(usrEntrdProcessNode) && StringUtils.isEmpty(usrEntrdSubProcess); 
		if (!validData) {
			Map<String, Object> prcMap; 
			Map<String, Object> techStackDetailsMap = getTechStackMap(context);
			
			if (StringUtils.isEmpty(usrEntrdFoundry)) {
				for (Object proObj : techStackDetailsMap.values()) {
					prcMap = (Map<String, Object>) proObj;
					validData = validTechStackChildData(prcMap,usrEntrdProcessNode,usrEntrdSubProcess);
					if(validData)
						break;
				}
			}else {
				validData = techStackDetailsMap.containsKey(usrEntrdFoundry);
				if(validData) {
					prcMap = (Map<String, Object>) techStackDetailsMap.get(usrEntrdFoundry);
					validData = validTechStackChildData(prcMap,usrEntrdProcessNode,usrEntrdSubProcess);
				}
			}
		}
		return validData;
	}
 	
	@SuppressWarnings("unchecked")
	private boolean validTechStackChildData(Map<String, Object> prcMap, String usrEntrdProcessNode, String usrEntrdSubProcess) {
		boolean vaildChild = StringUtils.isEmpty(usrEntrdProcessNode) && StringUtils.isEmpty(usrEntrdSubProcess);
		if (StringUtils.isEmpty(usrEntrdProcessNode)) {
			for (Object subProcList : prcMap.values()) {
				vaildChild = StringUtils.isEmpty(usrEntrdSubProcess) || ((List<String>) subProcList).contains(usrEntrdSubProcess);
				if (vaildChild)
					break;
			}
		} else {
			vaildChild = prcMap.containsKey(usrEntrdProcessNode);
			if (vaildChild)
				vaildChild = StringUtils.isEmpty(usrEntrdSubProcess) || ((List<String>) prcMap.get(usrEntrdProcessNode)).contains(usrEntrdSubProcess);
		}
		return vaildChild;
	}

	@SuppressWarnings("unchecked")
	private Map<String, Object> getTechStackMap(matrix.db.Context context) throws Exception {
 		Map<String,Object> techStackDetailsMap = new HashMap<>();
 		Map<String,String> hmArgs = new HashMap<>();
		Map<String,String> foundryMap = JPO.invoke(context, "IMP_IPSearchUtil", null, "getFoundryValues", null, java.util.HashMap.class);
		Map<String,Object> childMap;
		for (String foundryValue : foundryMap.values()) {
			hmArgs.put("foundry", foundryValue);
			hmArgs.put("techstack_Tag", STR_SUBPROCESS);
			childMap = JPO.invoke(context, "IMP_TechStackUtil", null, "getTechStackDetails",
						JPO.packArgs(hmArgs), Map.class);
				techStackDetailsMap.put((String) foundryValue, childMap);
			}
		return techStackDetailsMap;
	}
	
	
	//Added for SWIMP-119
		private Map<String,Object> getIPSoCCoreData(matrix.db.Context context, String sObjID, String strENV, String sIPBranch)  throws IMPServiceException {
				
			Map<String,Object> returnSoCDetailsMap = new HashMap<>();
			try {
				DomainObject domParentObj = DomainObject.newInstance(context, sObjID);
				String sParentType = domParentObj.getInfo(context, DomainConstants.SELECT_TYPE);
				
				if (sParentType.equalsIgnoreCase(PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE))) 
					returnSoCDetailsMap = getIPCoreData(context, sObjID, strENV, sIPBranch);
				else if (sParentType.equalsIgnoreCase(PropertyUtil.getSchemaProperty(context, SOC_TYPE)))
					returnSoCDetailsMap = getSoCCoreData(context, sObjID);
			} catch (FrameworkException e) {			
				logger.log(Level.SEVERE, "MatrixException in getSoCCoreData:   ", e);
				throw new IMPServiceException("Exception in getIPSoCCoreData : " + e);
			} catch (Exception e) {
				logger.log(Level.SEVERE, "Exception in getIPSoCCoreData:   ", e);
				throw new IMPServiceException("Exception in getIPSoCCoreData : " + e);
			}
			return returnSoCDetailsMap;
		}

	//Added for SWIMP-119
	@SuppressWarnings("unchecked")
	private Map<String,Object> getSoCCoreData(matrix.db.Context context, String socObjID)  throws IMPServiceException {
			
		HashMap<String,String> hmArgs = new HashMap<>();
		hmArgs.put("socObjID", socObjID);
		Map<String,Object> returnSoCDetailsMap = new HashMap<>();
			
		try {
			returnSoCDetailsMap = JPO.invoke(context, REL_UTIL_JPO, null, "getSoCCoreData", JPO.packArgs(hmArgs), Map.class);
		} catch (MatrixException e) {			
			logger.log(Level.SEVERE, "MatrixException in getSoCCoreData:   ", e);
			throw new IMPServiceException("Exception in getSoCCoreData : " + e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception in getSoCCoreData:   ", e);
			throw new IMPServiceException("Exception in getSoCCoreData : " + e);
		}
		return returnSoCDetailsMap;
	}
	 	
	//Added for SWIMP-119
	@SuppressWarnings("unchecked")
	private Map<String,Object> getIPCoreData(matrix.db.Context context, String ipObjID, String strENV, String sIPBranch)  throws IMPServiceException {
		
 		Map<String,String> hmArgs = new HashMap<>();
		hmArgs.put("ipObjID", ipObjID);
		hmArgs.put(IMP_ENV, strENV);
		hmArgs.put("ipBranch", sIPBranch);
		Map<String,Object> returnIPDetailsMap = new HashMap<>();
		
		try {
			returnIPDetailsMap = JPO.invoke(context, REL_UTIL_JPO, null, "getIPCoreData", JPO.packArgs(hmArgs), Map.class);
		} catch (MatrixException e) {			
			logger.log(Level.SEVERE, "MatrixException in getIPCoreData:   ", e);
			throw new IMPServiceException("Exception in getIPCoreData : " + e);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception in getIPCoreData:   ", e);
			throw new IMPServiceException("Exception in getIPCoreData : " + e);
		}
		return returnIPDetailsMap;
 	}
	
 	@SuppressWarnings("unchecked")
	private String getForProjectID(matrix.db.Context context, String forProject) throws IMPServiceException {
		String forProjectID = "";
		Map<String,Object> mpInfo = null;
		
		try {
			StringList slObjSelects = new StringList(DomainConstants.SELECT_ID);
			MapList mlObjectList = DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, SOC_TYPE), forProject, "*", "*", "*", null, false,
					slObjSelects);
			if (!mlObjectList.isEmpty()) {
				mpInfo = (Map<String,Object>) mlObjectList.get(0);
				forProjectID = (String) mpInfo.get(DomainConstants.SELECT_ID);
			} else {
				String sWhere = "attribute[IMP_ProductType]=='Block IP'";
				mlObjectList = DomainObject.findObjects(context, PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), forProject, "*", "*", "*", sWhere, false,
						slObjSelects);
				if (!mlObjectList.isEmpty()) {
					mpInfo = (Map<String,Object>) mlObjectList.get(0);
					forProjectID = (String) mpInfo.get(DomainConstants.SELECT_ID);
				}
			}
		} catch (FrameworkException e) {
			logger.log(Level.SEVERE, "Exception in getForProjectID:   ", e);
			throw new IMPServiceException("Exception in getForProjectID : " + e);
		}
		return forProjectID;
	}
 	
 	private int checkBranch(matrix.db.Context context, String ipObjID, String sIPBranch) throws IMPServiceException {
 		int iReturn = 0;
		String relBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String typeBranch = PropertyUtil.getSchemaProperty(context, IP_BRANCH_TYPE);
		  
		try {
			DomainObject domIPObj = new DomainObject(ipObjID);
			
			StringBuilder sbWhere = new StringBuilder();
	        sbWhere.append(IPTAG_ATTR).append(" == '");
	        sbWhere.append(sIPBranch.trim());
	        sbWhere.append("'");

	        StringList slObjSelects = new StringList();
	        slObjSelects.addElement(DomainConstants.SELECT_ID);
	        
	        MapList mlRelatedObjList = domIPObj.getRelatedObjects(context, relBranch, typeBranch,
	                slObjSelects, null, false, true, (short) 1, sbWhere.toString(), null, 0);
	        if (mlRelatedObjList.isEmpty())
	        	iReturn = 3;
		
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception in getForProjectID:   ", e);
			throw new IMPServiceException("Exception in getForProjectID : " + e);
		}
		return iReturn;
	}
 		
	// Added for SWIMP-55:Starts
	public boolean hasAccesstoObject(matrix.db.Context context, String sObjId)
			throws MatrixException {
		boolean hasAccess = false;
		String[] args = { sObjId };
		String strReturn = JPO.invoke(context, "IMP_SecurityCheck", null, "hasPolicyAccessForObject", args,
				String.class);
		if (("true").equalsIgnoreCase(strReturn)) {
			hasAccess = true;
		}
		return hasAccess;
	}
	// Added for SWIMP-55:Ends
	
	//Added for SWIMP-56:Starts
		@SuppressWarnings("resource")
		private Map<String, Object> getValidUserContext(HttpServletRequest req,
				Map<String, String> mpUserDetails, String strInputUserName)
						throws IOException, MatrixException {
			Map<String, Object> mpLocalMap = new HashMap<>();
			String sContextUser = mpUserDetails.get("username");
			String sContextPass = mpUserDetails.get("password");
			matrix.db.Context context = new matrix.db.Context("");
			if (!mpUserDetails.isEmpty()) {
				if (("bcadmin").equalsIgnoreCase(sContextUser)) {
					if(!StringUtils.isBlank(strInputUserName)){
						context = getAuthenticatedContext(req, false);
						ContextUtil.pushContext(context, strInputUserName, "", SERV_PROD);
						mpLocalMap.put(CONTEXT, context);
						mpLocalMap.put(USRNAME, strInputUserName);
					} else {
						mpLocalMap.put(strError, "Please provide Username");  //Modified for SWIMP-369
						mpLocalMap.put(CONTEXT, null);
					}
				} else {
					if (getOktaAuthentication(sContextUser, sContextPass)) {
						String sContPass = getDecodePass();
						ContextUtil.pushContext(context, sContextUser, sContPass, SERV_PROD);
						mpLocalMap.put(CONTEXT, context);
						mpLocalMap.put(USRNAME, sContextUser);
					} else {
						mpLocalMap.put(strError, "Invalid username/password");  //Modified for SWIMP-369
						mpLocalMap.put(CONTEXT, null);
					}
				}
			} else {
				mpLocalMap.put(strError, "Please provide Username and Password");  //Modified for SWIMP-369
				mpLocalMap.put(CONTEXT, null);
			}
			return mpLocalMap;
		}
		

		@SuppressWarnings("unchecked")
		private org.codehaus.jettison.json.JSONObject processCacheDataForIPSoC(matrix.db.Context context,MapList mpReturnList, String strObjType , String sUserName)
				throws JSONException, MatrixException {
			org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
			if (!mpReturnList.isEmpty()) {
				Map<String, Object> mlocalMap = (Map<String, Object>) mpReturnList.get(0);
				if ("IMP_IPProduct".equals(strObjType)) {
					returnObj.put("ip_data", mlocalMap);
				} else if ("IMP_SoC".equals(strObjType)) {
					String verifyIPLogs = "";
			          Map<String, String> hmJPOArgsData = new HashMap<>();
			            List<Map> lsVerificationData = (List<Map>)mlocalMap.get("soc_ip_verifications");
			            if (lsVerificationData != null)
			              for (Map<String, String> verification : lsVerificationData) {
			                hmJPOArgsData.put("sVerifyid", (String)verification.get("request_id"));
			                verifyIPLogs = (String)JPO.invoke(context, "IMP_IPVerification", null, "getVerifyIPLogsForEPSWithVerifyid", 
			                    JPO.packArgs(hmJPOArgsData), String.class);
			                System.out.println("===========processCacheDataForIPSoC:: verifyIPLogs ========"+verifyIPLogs);
			                verification.put("verifyIP_logs", verifyIPLogs);
			              }  
					returnObj.put("soc_data", processSoCOutputWhenAccessIsProtected(context,mlocalMap,sUserName));
				}
			} else {
				returnObj.put("data", "No data found.");
			}
			return returnObj;

		}
		//Added for SWIMP-56:Ends
	
	// Added for SWIMP-55:Starts
	@SuppressWarnings("unchecked")
	private Map<String, Object> processSoCOutputWhenAccessIsProtected(matrix.db.Context context,
			Map<String, Object> mSoCOutput, String sUserName) throws MatrixException {
		boolean bIsAdmin =  PersonUtil.hasAssignment(context, "ctx::VPLMProjectAdministrator.Broadcom Ltd.IMP_IPSpace");
		if(!bIsAdmin) {
			String accessControlProtection = (String) mSoCOutput.get("access_control_protection");
			if (("Protected").equalsIgnoreCase(accessControlProtection)) {
				String sOwner = (String) mSoCOutput.get("owner");
				String sObjId = (String) mSoCOutput.get("objectid");
				List<String> lCoOwners = (List<String>) mSoCOutput.get("co_owners");
				List<String> lUserAccess = (List<String>) mSoCOutput.get("user_access");
				if (!sOwner.equals(sUserName) && !lCoOwners.contains(sUserName) && !lUserAccess.contains(sUserName)
						&& !hasAccesstoObject(context, sObjId)) {
					LIST_REMOVE_ATTRIBUTES_FROM_PROTECTED_SOC.forEach(mSoCOutput::remove);
				}
			}
		}
		return mSoCOutput;
	}
	// Added for SWIMP-55:Ends

	/**
	 * Added for SWIMP-166
	 *
	 * @param req
	 *            the req
	 * @param sIPName
	 *            the IP name
	 * @param sUserName
	 *            the user name
	 * @param sTag
	 *            the tag name
	 * @param sProject
	 *            the project name
	 * @param sSubscriptionUser
	 *            the Subscription User list
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	public String consumeAutoSubsciption(matrix.db.Context context, String sIPName, String sUserName, String sTag,
			String sProject, String sProjectType, String sProjectid, String sSubscriptionUser) throws IMPServiceException {
		String strReturn = "";
		HashMap<String, String> hmData = new HashMap<>();
		try {
			if (UIUtil.isNotNullAndNotEmpty(sSubscriptionUser)) {
				hmData.put(IPNAME, sIPName);
				hmData.put(IPTAG, sTag);
				hmData.put(USRNAME, sUserName);
				hmData.put(PROJECT, sProject);
				//Added for SWIMP-284 - s
				hmData.put(PROJECTTYPE, sProjectType);
				hmData.put(PROJECTID, sProjectid);
				//Added for SWIMP-284 - e
				hmData.put(SUBSCRIPTIONUSER, sSubscriptionUser.trim());
				strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "consumeAutoSubsciption", JPO.packArgs(hmData),
						String.class);
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in consumeAutoSubsciption:   ", exp);
			throw new IMPServiceException(exp);
		}
		return strReturn;
	}

	/**
	 * Added for SWIMP-166
	 *
	 * @param req
	 *            the req
	 * @param sSpecName
	 *            the s spec name
	 * @param sIPName
	 *            the IP name
	 * @param sProject
	 *            the SoC/Project name
	 * @param sSubscriptionUser
	 *            the subscription user list
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */

	private String isSocIPTechStackSame(matrix.db.Context context, String sIPName, String sProject,
			String sSubscriptionUser) throws IMPServiceException {
		String strReturn = "";
		HashMap<String, String> hmData = new HashMap<>();
		try {
			if (!StringUtils.isEmpty(sSubscriptionUser.trim())) {
				hmData.put(IPNAME, sIPName);
				hmData.put(PROJECT, sProject);
				strReturn = JPO.invoke(context, REL_UTIL_JPO, null, "getIncompatibleTechStack", JPO.packArgs(hmData),
						String.class);
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in IsSocIPTechStackSame:   ", exp);
			throw new IMPServiceException(exp);
		}
		return strReturn;
	}

	/**
	 * Added for SWIMP-166
	 *
	 * @param req
	 *            the req
	 * @param sSpecName
	 *            the s spec name
	 * @param sIPName
	 *            the IP name
	 * @param sProject
	 *            the SoC/Project name
	 * @return the string
	 * @throws Exception
	 *             the exception
	 */
	private String getUserUnAvailableList(matrix.db.Context context, String sSubscriptionUser)
			throws IMPServiceException {
		HashMap<String, String> hmData = new HashMap<>();
		String strReturn = "";
		try {
			if (!StringUtils.isEmpty(sSubscriptionUser.trim())) {
				hmData.put(SUBSCRIPTIONUSER, sSubscriptionUser);
				strReturn = JPO.invoke(context, IPPRODUCT_UTIL_JPO, null, "getUnAvailableUserList",
						JPO.packArgs(hmData), String.class);
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in getUserUnAvailableList:   ", exp);
			throw new IMPServiceException(exp);
		}
		return strReturn;
	}

	/**
	 * Added for SWIMP-166
	 *
	 * @param context
	 *            the req
	 * @param strSoCName
	 *            the SoC/Project Name
	 * @return the string
	 * @throws MatrixException
	 *             the exception
	 */
	private String validateSoCToSubscribeIP(matrix.db.Context context, String strSoCName) throws IMPServiceException {
		String sReturnMsg = "";
		HashMap<String, String> hmGetSoCID = new HashMap<>();
		try {
			hmGetSoCID.put("strSoCName", strSoCName);
			String strSoCId = JPO.invoke(context, REL_UTIL_JPO, null, "getSoCIdFromSoCName", JPO.packArgs(hmGetSoCID),
					java.lang.String.class);
			if (UIUtil.isNotNullAndNotEmpty(strSoCId)) {
				DomainObject doSoC = DomainObject.newInstance(context, strSoCId);
				String sAllowIPVerify = doSoC.getInfo(context, "attribute[IMP_AllowIPVerification]");
				if ("false".equalsIgnoreCase(sAllowIPVerify)) {
					sReturnMsg = "IP Subscription not added to the SoC because it is already in Fabrication state "
							+ "and all IPs detected by verify-ip have been approved for use by the IP owners.";
				}
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in validateSoCToSubscribeIP:   ", exp);
			throw new IMPServiceException(exp);
		}
		return sReturnMsg;
	}
	
	//Added for SWIMP-89:Starts
	  /**
	   * getTechStackInfo .
	   *
	   * @param paramHttpServletRequest the param http servlet request
	   * @return the response
	   * @throws IMPServiceException the IMP generic exception
	   */
	  @SuppressWarnings("unchecked")
	  @POST
	  @Path("/listTechStack")
	  @Produces ("application/json")
	  public Response getAllTechStackInfo(
	      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest) throws IMPServiceException {
	    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){// Modified for 2019x Upgrade
			List<Object> lTechStackValues = JPO.invoke(context, IMP_TECHSTACKUTIL_JPO, null, "getAllTechStack", null,
					 List.class);			
			if (!lTechStackValues.isEmpty()) {
				returnObj.put("tech_stack_info", lTechStackValues);
			} else {
				returnObj.put("error:", "Not able to fetch Tech Stack information");
			}
		} catch (MatrixException | JSONException exp) {
			logger.log(Level.SEVERE, "Exception in getTechStackInfo:   ", exp);
			throw new IMPServiceException(exp);
		}
	    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	//Added for SWIMP-89:Ends

	// Added for SWIMP-56
	@SuppressWarnings("unchecked")
	private String getWhereStringForBuVendorTechStack(
			matrix.db.Context context, Map<String, String> mInputParams,org.codehaus.jettison.json.JSONObject returnObj) throws Exception {
		StringBuilder strWhereExpression = new StringBuilder();
		HashMap<String, String> sVendorMap = new HashMap<>();
		Map<String, Object> mReturnData = new HashMap<>();
		String sVWhere = "";
		String aVWhere = "";
		boolean bVendor = false;
		String sRtnInvalidVendor = "";
		if (mInputParams.get(STR_VENDOR) != null) {
			sVendorMap.put("IMP_Vendor", mInputParams.get(STR_VENDOR));
			mReturnData = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "validateAttributes", JPO.packArgs(sVendorMap),
					Map.class);
		}

		if (!mReturnData.isEmpty()) {
			sVWhere = (String) mReturnData.get("sVWhereExistingVendor");
			bVendor = (boolean) mReturnData.get("bVendorExists");
			aVWhere = (String) mReturnData.get("strVWhereAllVendor");
			sRtnInvalidVendor = (String) mReturnData.get("sRtnInvalidVendor");
		}
		if (mInputParams.get(STR_IMPIPNAME) != null && !mInputParams.get(STR_IMPIPNAME).isEmpty()) {
			strWhereExpression.append("(attribute[IMP_IPName]=='").append(mInputParams.get(STR_IMPIPNAME))
					.append("' || attribute[IMP_IPAliases]=='").append(mInputParams.get(STR_IMPIPNAME)).append("')&&");
		}
		Boolean bFoundry = getBUTechStackWhereClause(context, strWhereExpression, "getFoundryValues", "IMP_Foundry",
				mInputParams.get(STR_IMPFOUNDRY));
		Boolean bTechNode = getBUTechStackWhereClause(context, strWhereExpression, "getProcessNodeValues",
				"IMP_ProcessNode", mInputParams.get(STR_IMPPROCESSNODE));
		Boolean btechSubProcess = getBUTechStackWhereClause(context, strWhereExpression, "getSubProcessValues",
				STR_SUBPROCESS, mInputParams.get(STR_IMPSUBPROCESS));
		Boolean bMetalStack = getBUTechStackWhereClause(context, strWhereExpression, "getMetalStackValues",
				"IMP_MetalStack", mInputParams.get(STR_IMPMETALSTACK));
		Boolean bBu = getBUTechStackWhereClause(context, strWhereExpression, "getProductDivisions", STR_PRODUCTDIVISION,
				mInputParams.get(STR_IMPPRODUCTDIVISION));

		// Added for 979 : Start
		if (!StringUtils.isEmpty(mInputParams.get(STR_IMPIPSOURCE)))
			if ("all".equalsIgnoreCase(mInputParams.get(STR_IMPIPSOURCE)))
				strWhereExpression.append("attribute[IMP_IPSource]=='Internal' || attribute[IMP_IPSource]=='3PIP'&&");
			else
				strWhereExpression.append("attribute[IMP_IPSource]=='").append(mInputParams.get(STR_IMPIPSOURCE))
						.append("'&&");

		if (!StringUtils.isEmpty(mInputParams.get(STR_VENDOR))) {
			if (!"all".equalsIgnoreCase(mInputParams.get(STR_VENDOR)) && bVendor)
				strWhereExpression.append(sVWhere).append("&&");
			else if ("all".equalsIgnoreCase(mInputParams.get(STR_VENDOR)))
				strWhereExpression.append(aVWhere).append("&&");
		}

		String whereExp = strWhereExpression.toString();
		if (whereExp.endsWith("&&")) {
			whereExp = whereExp.substring(0, whereExp.length() - 2);
		} else {
			whereExp = null;
		}
	
		returnObj.put("bBu", bBu);
		returnObj.put("btechSubProcess", btechSubProcess);
		returnObj.put("bTechNode", bTechNode);
		returnObj.put("bFoundry", bFoundry);
		// Added for 957
		returnObj.put("bMetalStack", bMetalStack);
		returnObj.put("sRtnVendor", sRtnInvalidVendor);
		returnObj.put("bVendor", bVendor);
		return whereExp;
	}
	// Added for SWIMP-56

	//Added for SWIMP-222:Starts 
	/**
	 * Gets the WaterMark details for the IP product with corresponding revision
	 * @param paramHttpServletRequest the param http servlet request
	 * @param ArrayList slIPName the IPProducts Name string
	 * @param ArrayList slTag the RevisionTags Name string
	 * @return the response details
	 * @throws IMPServiceException the IMP exception
	 */
	@GET
	@Path("/getWaterMarkValues")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response getWaterMarkValuesForIPProduct(
			@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			@QueryParam(IPNAME) List<String> slIPName, @QueryParam("Tag") List<String> slTag)
					throws IMPServiceException {
		org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){ //Modified for 2019x Upgrade
			Map<String, List<String>> hmPackData = new HashMap<>();
			hmPackData.put("IPList", slIPName);
			hmPackData.put("TAGList", slTag);

			int ipLength = slIPName.size();
			int tagLength = slTag.size();
			if ((ipLength > 0 && tagLength > 0) && ipLength == tagLength) {
				MapList returnMapList = JPO.invoke(context, REL_UTIL_JPO, null, "getAllWaterMarkValues",
						JPO.packArgs(hmPackData), MapList.class);
				returnObj.put("WM_DATA", returnMapList);
			} else {
				returnObj.put("error:", "IPID and IPTAG length are not same or empty.");
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception in getWaterMarkValuesForIPProduct:   ", e);
			throw new IMPServiceException(e);
		}
		return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	}
	//Added for SWIMP-222:Ends
	
	
	//Added for SWIMP-262: Starts
	/**
	 * Check the access for Enovia Objects like IP Product, IMP SoC and DTree Spec
	 * @param HttpServletRequest req the http servlet request
	 * @param sObjectType the object type
	 * @param sObjectName the Object name
	 * @param sSpecVersion the spec version
	 * @param sUserName the user name
	 * @param sCommand the command used
	 * @param sEvent the event
	 * @return the response details
	 * @throws IMPServiceException the IMP exception
	 * @throws FrameworkException 
	 */
	@SuppressWarnings("unchecked")
	@GET
	@Path("/checkAccessForObject")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response hasAccessToEnoviaObject(@Context HttpServletRequest req, @QueryParam(CONST_OBJECTTYPE) String sObjectType,
			@QueryParam(CONST_OBJECTNAME) String sObjectName, @QueryParam(CONST_SPECVERSION) String sSpecVersion,
			@QueryParam(USRNAME) String sUserName, @QueryParam(CONST_COMMAND) String sCommand,
			@QueryParam(CONST_EVENT) String sEvent)
					throws IMPServiceException, FrameworkException {
		org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		int iReturn = 0;
		Map<String, String> hmData = new HashMap<>();
		//Modified for 2019x Upgrade: starts
		try (matrix.db.Context context = getAuthenticatedContext(req, false)){
			ContextUtil.pushContext(context, sUserName, "", SERV_PROD);
			// Modified for 2019x Upgrade: Ends
			hmData.put(CONTEXT, sUserName);
			hmData.put(CONST_OBJECTTYPE, sObjectType);
			hmData.put(CONST_OBJECTNAME, sObjectName);
			hmData.put(CONST_SPECVERSION, sSpecVersion);
			hmData.put(CONST_COMMAND, sCommand);
			hmData.put(CONST_EVENT, sEvent);

			if (TYPE_IMP_DTREESPEC.equals(sObjectType)) {
				InetAddress sHostName = InetAddress.getLocalHost();
				sHostName.getHostName();
				returnObj.put("canonical", sHostName.getCanonicalHostName());
			}

			iReturn = JPO.invoke(context, "IMP_SecurityCheck", null, "checkAccessForIPSoCDTreeSpec",
					JPO.packArgs(hmData));

			if (iReturn == 0) {
				returnObj.put("code", Integer.valueOf(0));

				if (TYPE_IMP_IPPRODUCT.equals(sObjectType)) {

					// Get IMP_ProductDivision, Name , IMP_TechStack
					returnObj.put(strQaValInput, getIPDataforQAValidation(context, sObjectName, sUserName));
					logger.info("Event:" + sCommand);
					logger.info("IPName:" + sObjectName);
					logger.info("UserName:" + sUserName);

					if ("publish".equals(sCommand) || "check-bom".equals(sCommand)) {
						logger.info("Getting All Release Tags...");
						String sIPId = getIpId(context,sObjectName);

						if (UIUtil.isNotNullAndNotEmpty(sIPId)) {
							Map<String, String> hmJSONArgs = new HashMap<>();
							hmJSONArgs.put(OBJ_ID, sIPId);
							Map<String, String> resultsMap = JPO.invoke(context, REL_UTIL_JPO, null,
									"getJSONStringAllIPReleases", JPO.packArgs(hmJSONArgs), Map.class);
							returnObj.put(strAllRevisions, resultsMap);
							
							//Added for SWIMP-425: Starts
							StringList slIPAttributeList = new StringList();
							slIPAttributeList.add(ATTRIBUTE_IMP_IPSOURCE);
							slIPAttributeList.add(ATTRIBUTE_IMP_IPTYPE);
							slIPAttributeList.add(ATTRIBUTE_IMP_PRODUCTTYPE);//Added for SWIMP-31
							slIPAttributeList.add(ATTRIBUTE_IMP_LIBRARY);//Added for SWIMP-720
							returnObj.put("ip_attributeValues_info", getIPProductAttributeValues(context, sObjectName, slIPAttributeList));
							//Added for SWIMP-425: Ends
						} else {
							throw new IMPServiceException("No IP Found with given IP name: "+sObjectName);
						}
					}
					returnObj.put("USER_DATA", getUserDetails(context, sUserName));
				}
			} else {
				returnObj.put("code", Integer.valueOf(iReturn));
			}
		} catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in hasAccessToEnoviaObject:   ", exp);
			throw new IMPServiceException(exp);
		}
		return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	}


	/**
	 * Checks the CLI User/ Switch & Euid users are active in Enovia IMP or not
	 * @param req the http servlet request
	 * @param List alUsers The CLI Context user/Switch user, euid user.
	 * @return the response details
	 * @throws IMPServiceException the IMP exception
	 */
	@SuppressWarnings("unchecked")
	@GET
	@Path("/checkAllUsers")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response isUsersAvailable(@Context HttpServletRequest req,
			@QueryParam("USERS") List<String> alUsers) throws IMPServiceException {
		org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		Map<String, List<String>> hmData = new HashMap<>();
		try (matrix.db.Context context = getAuthenticatedContext(req, false)){ //Modified for 2019x Upgrade
			hmData.put("USERS", alUsers);
			Map<String, Object> returnMap = JPO.invoke(context, "IMP_Utility", null, "isUsersAvailableInIMP", JPO.packArgs(hmData), Map.class);
			returnObj.put("USER_DATA", returnMap);
		}  catch (Exception exp) {
			logger.log(Level.SEVERE, "Exception in isUsersAvailable:   ", exp);
			throw new IMPServiceException(exp);
		}
		return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	}
	//Added for SWIMP-262: Ends
	
	
	/**
	   * Activating User, SWIMP-267
	   *
	   * @param paramHttpServletRequest the param http servlet request
	   * @param form the form
	   * @return the response
	   * @throws IMPServiceException
	   */
	  @SuppressWarnings("unchecked")
	  @POST
	  @Path("/ActivateUser")
	  public Response activateUser(
	      @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
	      jakarta.ws.rs.core.Form form) throws IMPServiceException {
		Map<String, String> hmData = new HashMap<>();
		Map<String, String> hmReturn = new HashMap<>();
	    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
	    try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)){// Modified for 2019x Upgrade    
	      String sOktaID = form.asMap().getFirst("sOktaID");
	      
	      hmData.put(USRNAME, sOktaID);
	      hmReturn = JPO.invoke(context, IMP_UPDATEPERSONDETAILS_JPO, null, "activateUser", JPO.packArgs(hmData),
	    		  Map.class);

	      returnObj.put("Error", hmReturn.get("Error"));
	      returnObj.put("UserActivated", hmReturn.get("UserActivated"));
	      returnObj.put(strMessage, "Successful");
	    } catch (Exception jpoExp) {
	      logger.log(Level.SEVERE, "Exception in ActivateUser:   ", jpoExp);
	      throw new IMPServiceException(jpoExp);
	    }
	    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }


	  // Added for SWIMP-425: Starts
	  /**
	   * This method for getting the IP TechStacks, SWIMP-425
	   *
	   * @param paramHttpServletRequest the param http servlet request
	   * @param form the form
	   * @return the response
	   * @throws IMPServiceException
	   */
	  @GET
	  @Consumes(MediaType.TEXT_PLAIN)
	  @Produces(MediaType.TEXT_PLAIN)
	  @Path("/getIPTechStackValues")
	  public Response getTechStacksForIP(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			  @QueryParam("IPName") String sIPID) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  Map<String, String> hmData = new HashMap<>();
		  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {
			  hmData.put(IPNAME, sIPID);
			  MapList returnMap = JPO.invoke(context, IMP_TECHSTACKUTIL_JPO, null, "getTechStacksForIPBasedOnCLIAction",
					  JPO.packArgs(hmData), MapList.class);
			  returnObj.put(strTechnologyStack, returnMap);
		  } catch (Exception exp) {
			  logger.log(Level.SEVERE, "Exception in getTechStacksForIP:   ", exp);
			  throw new IMPServiceException(exp);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }

	  @GET
	  @Consumes(MediaType.TEXT_PLAIN)
	  @Produces(MediaType.TEXT_PLAIN)
	  @Path("/getSoCTechStackValues")
	  public Response getSoCTechStacks(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			  @QueryParam("SOCNAME") String sSOCID) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  Map<String, String> hmData = new HashMap<>();
		  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {
			  hmData.put(SOCNAME, sSOCID);
			  MapList returnMap = JPO.invoke(context, IMP_TECHSTACKUTIL_JPO, null, "getSoCTechStackValues",
					  JPO.packArgs(hmData), MapList.class);
			  returnObj.put(strTechnologyStack, returnMap);
		  } catch (Exception exp) {
			  logger.log(Level.SEVERE, "Exception in getSoCTechStacks:   ", exp);
			  throw new IMPServiceException(exp);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	  

	  
	  @SuppressWarnings({"unchecked", "rawtypes"})
	  @POST
	  @Path("/setDLCAttributesToVerifyid")
	  public Response setDLCAttributesToVerifyid(@Context HttpServletRequest req, jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  Map<String, String> hmData = new HashMap<>();
		  try (matrix.db.Context context = getAuthenticatedContext(req, false)) {

			  hmData.put("sVerifyid", form.asMap().getFirst("sVerifyid"));
			  hmData.put("iDCLCDLResult", form.asMap().getFirst("iDCLCDLResult"));
			  hmData.put("strDCLCDLOutput", form.asMap().getFirst("strDCLCDLOutput"));
			  hmData.put("iDCLOASResult", form.asMap().getFirst("iDCLOASResult"));
			  hmData.put("strDCLOASOutput", form.asMap().getFirst("strDCLOASOutput"));
			  JPO.invoke(context, IPVERIFICATION_JPO, null, "setDLCAttributesToVerifyid",
					  JPO.packArgs(hmData), MapList.class);
		  } catch (Exception exp) {
			  logger.log(Level.SEVERE, "Exception in setDLCAttributesToVerifyid:   ", exp);
			  throw new IMPServiceException(exp);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	  
	  
	  @SuppressWarnings({"unchecked", "rawtypes"})
	  @POST
	  @Path("/setLLCAttributesToVerifyid")
	  public Response setLLCAttributesToVerifyid(@Context HttpServletRequest req, jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  Map<String, String> hmData = new HashMap<>();
		  try (matrix.db.Context context = getAuthenticatedContext(req, false)) {

			  hmData.put("sVerifyid", form.asMap().getFirst("sVerifyid"));
			  hmData.put("iLLCOASResult", form.asMap().getFirst("iLLCOASResult"));
			  hmData.put("strLLCOASOutput", form.asMap().getFirst("strLLCOASOutput"));
			  JPO.invoke(context, IPVERIFICATION_JPO, null, "setLLCAttributesToVerifyid",
					  JPO.packArgs(hmData), MapList.class);
		  } catch (Exception exp) {
			  logger.log(Level.SEVERE, "Exception in setLLCAttributesToVerifyid:   ", exp);
			  throw new IMPServiceException(exp);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	  
	  
	  @SuppressWarnings({"unchecked", "rawtypes"})
	  @POST
	  @Path("/setIpScoreAttributesToVerifyid")
	  public Response setIpScoreAttributesToVerifyid(@Context HttpServletRequest req, jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  Map<String, String> hmData = new HashMap<>();
		  try (matrix.db.Context context = getAuthenticatedContext(req, false)) {

			  hmData.put("sVerifyid", form.asMap().getFirst("sVerifyid"));
			  hmData.put("mIpScoreOutput", form.asMap().getFirst("mIpScoreOutput"));
			  JPO.invoke(context, IPVERIFICATION_JPO, null, "setIpScoreAttributesToVerifyid",JPO.packArgs(hmData), MapList.class);
		  } catch (Exception exp) {
			  logger.log(Level.SEVERE, "Exception in setIpScoreAttributesToVerifyid:   ", exp);
			  throw new IMPServiceException(exp);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }



	  /**
	   * This method for getting the IP attribute values, SWIMP-425
	   *
	   * @param context
	   * @param sIPName, IPID
	   * @param slIPAttributeList, List contains IP attributes for getting it's values
	   * @return the Map, contains attribute values
	   * @throws IMPServiceException
	   */
	  @SuppressWarnings("unchecked")
	  private Map<String, Object> getIPProductAttributeValues(matrix.db.Context context,
			  String sIPName, StringList slIPAttributeList) throws IMPServiceException {
		  Map<String, Object> mpIpAttrInfo = new HashMap<>();
		  try {
			  BusinessObject boObject = new BusinessObject(TYPE_IMP_IPPRODUCT, //Type
					  sIPName, //Name
					  "A", //Revision
					  PropertyUtil.getSchemaProperty(context, VAULT_SERV_PROD)); //Vault
			  if (boObject.exists(context)) {
				  DomainObject domIPObj = new DomainObject(boObject);
				  mpIpAttrInfo = domIPObj.getInfo(context, slIPAttributeList);
			  }
		  } catch (Exception e) {
			  logger.log(Level.SEVERE, "Exception in getIPProductAttributeValues:   ", e);
			  throw new IMPServiceException(e);
		  }
		  return mpIpAttrInfo;
	  }
	  // Added for SWIMP-425: Ends

	  // Added for SWIMP-31: Starts
	  @POST
	  @Path("/getHIPStructureBasedonWMStrings")
	  @SuppressWarnings({ "rawtypes", "unchecked" })
	  public Response getHIPStructureBasedonWMStrings(
			  @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			  jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
		  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {
			  Map<String, Object> hmArgsData = new HashMap(); //Modified for SWIMP-564
			  String sWMStrings = form.asMap().getFirst(STRING_WMSTRINGS); //Modified for SWIMP-564

			  //Added for SWIMP-568 : Starts
			  String sHIPName = form.asMap().getFirst("IPID");
			  Map<String, Object> mHIPData = getIPProductAttributeValues(context, sHIPName, new StringList(DomainConstants.SELECT_ID));
			  String sHIPID = (String) mHIPData.get(DomainConstants.SELECT_ID);
			  //Added for SWIMP-568 : Ends

			  Map<String, String> mWMStrings = convertWMStringToMap(sWMStrings);
			  hmArgsData.put(STRING_WMSTRINGS, mWMStrings);
			  hmArgsData.put("ID", sHIPID); //Added for SWIMP-568
			  Map<String, Object> returnMap = new HashMap<>();
			  returnMap = JPO.invoke(context, REL_UTIL_JPO, null, "getSoCHIPStructure", JPO.packArgs(hmArgsData), Map.class);
			  returnObj.put("wmReturnData", returnMap);
		  } catch (Exception e) {
			  logger.log(Level.SEVERE, "Exception in getHIPStructureBasedonWMStrings:   ", e);
			  throw new IMPServiceException(e);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	  // Added for SWIMP-31 : Ends

	  // Added for SWIMP-632: Starts
	  @SuppressWarnings("unchecked")
	  @POST
	  @Path("/getIPPublishLock")
	  public Response getIPPublishLock(
			  @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			  jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj;
		  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {
			  Map<String, Object> hmArgsData = convertMupliValueMapToMap(form);
			  logger.info("Getting Lock with data: "+hmArgsData);
			  Map<String, Object> returnMap = JPO.invoke(context, IPPRODUCT_UTIL_JPO, null, "getIPPublishLock", JPO.packArgs(hmArgsData), Map.class);
			  returnObj = new org.codehaus.jettison.json.JSONObject(returnMap);
		  } catch (Exception e) {
			  logger.log(Level.SEVERE, "Exception in getIPPublishLock:   ", e);
			  throw new IMPServiceException(e);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }

	  @SuppressWarnings("unchecked")
	  @POST
	  @Path("/releaseIPPublishLock")
	  public Response releaseIPPublishLock(
			  @jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
			  jakarta.ws.rs.core.Form form) throws IMPServiceException {
		  org.codehaus.jettison.json.JSONObject returnObj;
		  try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {
			  Map<String, Object> hmArgsData = convertMupliValueMapToMap(form);
			  logger.info("Releasing Lock with data: "+hmArgsData);
			  Map<String, Object> returnMap = JPO.invoke(context, IPPRODUCT_UTIL_JPO, null, "releaseIPPublishLock", JPO.packArgs(hmArgsData), Map.class);
			  logger.info("Lock released with data: "+hmArgsData);
			  returnObj = new org.codehaus.jettison.json.JSONObject(returnMap);
		  } catch (Exception e) {
			  logger.log(Level.SEVERE, "Exception in releaseIPPublishLock:   ", e);
			  throw new IMPServiceException(e);
		  }
		  return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
	  }
	  // This method will convert MultiValue Map to HashMap. But it will take only the first value from value list in MultiValue Map
	  //Modified for 2025X Upgrade: START
	  public static Map<String,Object>convertMupliValueMapToMap(Form formData)
	  {
		  Map<String, Object>returnMap = new HashMap<>();
		  for (Map.Entry<String, List<String>> entry : formData.asMap().entrySet()) {
			  List<String> values = entry.getValue();
			  if(!values.isEmpty()) {
			  returnMap.put(entry.getKey(),entry.getValue().get(0));
		   }
		}
		  return returnMap;
	  }
      //Modified for 2025X Upgrade: END


		@SuppressWarnings({ "rawtypes", "unchecked" })
		@GET
		@Path("/getAllIPAndSOCDetailsFromIMP")
		public List<Map> getAllIPAndSOCDetailsFromIMP(@Context HttpServletRequest req, @Context HttpHeaders headers,
				@QueryParam(USRNAME) String strInputUserName, @QueryParam("OBJECTTYPE") String strInputObjectType)
				throws IMPServiceException {
			org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
			matrix.db.Context context = null;
			MapList mlObjects = null;
			try {
				Map<String, String> mpUserDetails = getUserNameAndPassword(headers);// Fetching the user details from restful header
				Map<String, Object> mpReturnContext = getValidUserContext(req, mpUserDetails, strInputUserName); // Added for SWIMP-56 Validates from type and creates the context
				context = (matrix.db.Context) mpReturnContext.get(CONTEXT);// Fetching the context
				if (context != null) {// Modified for SWIMP-56
					HashMap<String, String> hmJPOArgsData = new HashMap<>();
					StringList slObjectSelects = new StringList(DomainConstants.SELECT_NAME);
					slObjectSelects.add(DomainObject.SELECT_TYPE);
					slObjectSelects.add(DomainObject.SELECT_ID);
					slObjectSelects.add(DomainObject.SELECT_MODIFIED);
					slObjectSelects.add("attribute[IMP_ProductDivision]");
					List<Map> lsReturn = new ArrayList<>();
					if (strInputObjectType == null || strInputObjectType.isEmpty()) {// Added for SWIMP-56. Setting the Object Type
						String strSOCType = PropertyUtil.getSchemaProperty(context, SOC_TYPE);
						String strIPProductType = PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE);
						Pattern typePattern = new Pattern(strIPProductType);
						typePattern.addPattern(strSOCType);
						strInputObjectType = typePattern.getPattern();
					}
					mlObjects = DomainObject.findObjects(context, strInputObjectType, // type pattern Modified for SWIMP-56
							"*", // name of object
							"*", // revision of object
							"*", // owner pattern
							SERV_PROD, // vault pattern
							null, // where expression
							null, // query name
							true, // expand type
							slObjectSelects, // object select
							(short) 0// limit
					);

					if (!mlObjects.isEmpty() && mlObjects != null) {
						mlObjects.sort(DomainConstants.SELECT_NAME, "ascending", "string");
						for (Object obj : mlObjects) {
							Map mlObject = (Map) obj;
							mlObject.put("product_division", (String) mlObject.get("attribute[IMP_ProductDivision]"));
							mlObject.remove("attribute[IMP_ProductDivision]");
						}
					}
				}

			} catch (Exception exp) {
				logger.log(Level.SEVERE, "Exception in getAllIPAndSOCDetailsFromIMP:   ", exp);
				throw new IMPServiceException(exp);
			} finally {
				if (context != null) {
					try {
						ContextUtil.popContext(context);
					} catch (Exception e) {
						logger.log(Level.SEVERE,
								"Exception while poping out context in getAllIPAndSOCDetailsFromIMP:   ", e);
					}
				}
			}
			return mlObjects;
		}

		//Added for SWIMP-827 : New imp query for SoCs in Fabrication state : STARTS
		/**
		 * GetAllSoCinFabrication for new IMP Query.
		 *
		 * @param paramHttpServletRequest the param http servlet request
		 * @param form                    the form
		 * @return the response
		 * @throws Exception the exception
		 */
		@SuppressWarnings({ "rawtypes", "unchecked" })
		@POST
		@Path("/GetAllSoCinFabrication")
		public Response GetAllSoCinFabrication(@jakarta.ws.rs.core.Context HttpServletRequest paramHttpServletRequest,
				jakarta.ws.rs.core.Form form) throws IMPServiceException {
			HashMap hmUpdateData = new HashMap();
			// Prepare the response object
			String jsonOutput = "";
			Map<String, String> map = new HashMap<>();
			ObjectMapper mapper = new ObjectMapper();

			try (matrix.db.Context context = getAuthenticatedContext(paramHttpServletRequest, false)) {// Modified for 2019x Upgrade

				String strSoCType = form.asMap().getFirst(STR_SCHEMANAME);
				String strSoCName = form.asMap().getFirst(STR_NAME);
				String strSoCState = form.asMap().getFirst(STR_CURRENTSTATE);
				String strFromDate = form.asMap().getFirst(STR_FROM_DATE);
				String strToDate = form.asMap().getFirst(STR_TO_DATE);
				String strUser = form.asMap().getFirst(STR_USERNAME);

				hmUpdateData.put("sType", strSoCType);
				hmUpdateData.put("sName", strSoCName);
				hmUpdateData.put("sState", strSoCState);
				hmUpdateData.put("sFromDate", strFromDate);
				hmUpdateData.put("sToDate", strToDate);
				hmUpdateData.put("sUser", strUser);

				String retunMap = JPO.invoke(context, CLI_QRY_SERVICE_JPO, null, "getSoCDetailsforStdOut",
						JPO.packArgs(hmUpdateData), String.class);
				map.put(strMessage, retunMap);
				jsonOutput = mapper.writeValueAsString(map);
			} catch (Exception jpoExp) {
				logger.log(Level.SEVERE, "Exception in getSocIPRevisions:   ", jpoExp);
				throw new IMPServiceException(jpoExp);
			}
			return Response.ok(jsonOutput).header(strContentType, strMediaType).build();
		}
		//Added for SWIMP-827 : New imp query for SoCs in Fabrication state : ENDS

		// Added for SWIMP-883 Start
		@POST
		@Path("/checkoutSSGQICfgYaml")
		@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
		@Produces(MediaType.APPLICATION_JSON)
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public Response checkoutSSGQICfgYaml(@Context HttpServletRequest req, Form form) throws IMPServiceException {
			JSONObject returnObj = new JSONObject();

			try (matrix.db.Context context = getAuthenticatedContext(req, false)) {

				String ipName = form.asMap().getFirst(IPNAME); // "IPName"
				String rev = form.asMap().getFirst(STR_TAG); // "Tag"
				String user = form.asMap().getFirst(USRNAME); // optional "UserName"

				if (StringUtils.isEmpty(ipName) || StringUtils.isEmpty(rev)) {
					returnObj.put("code", 2);
					returnObj.put(strMessage, "Missing required params: IPName, Tag");
					returnObj.put(STR_SSGQI_CFG_STATUS, "ERROR");
					return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
				}

				boolean pushed = false;
				try {
					if (!StringUtils.isEmpty(user)) {
						ContextUtil.pushContext(context, user, "", SERV_PROD);
						pushed = true;
					}

					// Resolve IP object id + name from IPName (needed for JPO + filename)
					StringList slObjDetails = new StringList();
					slObjDetails.add(DomainConstants.SELECT_ID);
					slObjDetails.add(DomainConstants.SELECT_NAME);

					MapList mlIPObjectList = DomainObject.findObjects(context,
							PropertyUtil.getSchemaProperty(context, IPPRODUCT_TYPE), ipName, "*", "*", "*", null, false,
							slObjDetails);

					if (mlIPObjectList == null || mlIPObjectList.isEmpty()) {
						returnObj.put("code", 2);
						returnObj.put(strMessage, "IP not found: " + ipName);
						returnObj.put(STR_SSGQI_CFG_STATUS, "NOT_FOUND");
						return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
					}

					Map first = (Map) mlIPObjectList.get(0);
					String ipObjectId = (String) first.get(DomainConstants.SELECT_ID);
					String ipidForFileName = (String) first.get(DomainConstants.SELECT_NAME);

					if (StringUtils.isEmpty(ipObjectId)) {
						returnObj.put("code", 2);
						returnObj.put(strMessage, "IP id not found for: " + ipName);
						returnObj.put(STR_SSGQI_CFG_STATUS, "ERROR");
						return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
					}
					if (StringUtils.isEmpty(ipidForFileName)) {
						// fallback to ipName if SELECT_NAME isn't returned for any reason
						ipidForFileName = ipName;
					}

					String cfgFileName = ipidForFileName + "-" + rev + "-ssgqi-cfg.yaml";

					String baseTmp = System.getProperty("java.io.tmpdir");
					String checkoutDir = baseTmp + File.separator + "imp-ssgqi-cfg-checkout" + File.separator
							+ java.util.UUID.randomUUID().toString() + File.separator;

					try {
						Set<PosixFilePermission> perms = PosixFilePermissions.fromString("rwxrwxr-x");
						FileAttribute<Set<PosixFilePermission>> attr = PosixFilePermissions.asFileAttribute(perms);
						Files.createDirectories(Paths.get(checkoutDir), attr);
					} catch (Exception ignore) {
						Files.createDirectories(Paths.get(checkoutDir));
					}

					HashMap hmArgs = new HashMap();
					hmArgs.put("ipObjectId", ipObjectId);
					hmArgs.put("cfgFileName", cfgFileName);
					hmArgs.put("checkoutDir", checkoutDir);

					Map jpoResult = JPO.invoke(context, IPVERIFICATION_JPO, // "IMP_IPVerification"
							null, "checkoutSSGQICfgYamlFromIMP", // add this JPO method
							JPO.packArgs(hmArgs), Map.class);

					returnObj.put("code", 0);
					returnObj.put(strMessage, EXEC_SUCC);
					returnObj.put("ssgqiCfgStatus", jpoResult.getOrDefault("ssgqiCfgStatus", "ERROR"));
					returnObj.put("ssgqiCfgCheckoutDir", jpoResult.get("ssgqiCfgCheckoutDir"));
					returnObj.put("ssgqiCfgFileName", jpoResult.get("ssgqiCfgFileName"));

				} finally {
					if (pushed) {
						try {
							ContextUtil.popContext(context);
						} catch (Exception ex) {
							logger.log(Level.WARNING, ex.getMessage(), ex);
						}
					}
				}

			} catch (Exception e) {
				logger.log(Level.SEVERE, "Exception in checkoutSSGQICfgYaml:   ", e);
				throw new IMPServiceException(e);
			}

			return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
		}
		

@SuppressWarnings({"unchecked", "rawtypes"})
@POST
@Path("/setSSGQIAttributesToVerifyid")
public Response setSSGQIAttributesToVerifyid(@Context HttpServletRequest req, jakarta.ws.rs.core.Form form)
       throws IMPServiceException {
 
  org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
   Map<String, String> hmData = new HashMap<>();
 
   try (matrix.db.Context context = getAuthenticatedContext(req, false)) {
 
      hmData.put("sVerifyid", form.asMap().getFirst("sVerifyid"));
      hmData.put("iSSGQIResult", form.asMap().getFirst("iSSGQIResult"));           // "pass"/"fail"
      hmData.put("strSSGQIOutput", form.asMap().getFirst("strSSGQIOutput"));       // HTML output
      //hmData.put("strSSGQIReportPath", form.asMap().getFirst("strSSGQIReportPath"));// xlsx path (optional)
 
      JPO.invoke(context, IPVERIFICATION_JPO, null, "setSSGQIAttributesToVerifyid",
              JPO.packArgs(hmData), MapList.class);
 
   } catch (Exception exp) {
      logger.log(Level.SEVERE, "Exception in setSSGQIAttributesToVerifyid:   ", exp);
       throw new IMPServiceException(exp);
   }
 
   return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
}


@SuppressWarnings({"unchecked", "rawtypes"})
@POST
@Path("/executeCSKValidateBOM")
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
@Produces(MediaType.APPLICATION_JSON)
public Response executeCSKValidateBOM(@Context HttpServletRequest req, jakarta.ws.rs.core.Form form)
        throws IMPServiceException {
   
    org.codehaus.jettison.json.JSONObject returnObj = new org.codehaus.jettison.json.JSONObject();
   
    try (matrix.db.Context context = getAuthenticatedContext(req, false)) {
       
        String excelPath = form.asMap().getFirst("excelPath");
        String sheetName = form.asMap().getFirst("sheetName");
        String verifyId = form.asMap().getFirst("verifyId");
       
        // Validate required input
        if (StringUtils.isEmpty(excelPath)) {
            try {
                returnObj.put("status", "Error");
                returnObj.put("message", "Excel path is required");
            } catch (org.codehaus.jettison.json.JSONException je) {
                logger.log(Level.SEVERE, "JSONException in executeCSKValidateBOM: ", je);
            }
            return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
        }
       
        // Prepare arguments for JPO: excelPath, sheetName, verifyId (optional)
        String[] jpoArgs;
        if (verifyId != null && !verifyId.trim().isEmpty()) {
            jpoArgs = new String[]{ excelPath, sheetName, verifyId };
        } else {
            jpoArgs = new String[]{ excelPath, sheetName };
        }
       
        // Invoke the JPO method
        JPO.invoke(context, "IMP_IPVerification", null, "ValidateBOM", jpoArgs);
       
        try {
            returnObj.put("status", "Success");
            returnObj.put("message", "Excel successfully converted to JSON" + 
                          (verifyId != null ? " and stored in attribute" : ""));
            returnObj.put("excelPath", excelPath);
        } catch (org.codehaus.jettison.json.JSONException je) {
            logger.log(Level.SEVERE, "JSONException in executeCSKValidateBOM: ", je);
        }
       
    } catch (Exception e) {
        logger.log(Level.SEVERE, "Exception in executeCSKValidateBOM: ", e);
        try {
            returnObj.put("status", "Error");
            returnObj.put("message", e.getMessage());
        } catch (org.codehaus.jettison.json.JSONException je) {
            logger.log(Level.SEVERE, "JSONException in executeCSKValidateBOM error handling: ", je);
        }
    }
   
    return Response.ok(returnObj.toString()).header(strContentType, strMediaType).build();
}

		
}