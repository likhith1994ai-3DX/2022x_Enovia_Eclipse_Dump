
/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : IMP_IPVerification.java
 * 
 * DESCRIPTION  : This program contains utility IP Verification flow
 *        
 * CREATED      : 10-OCT-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * History
 * Modified By				Modified On			Description
 * Mahammed Irshad K S		19-May-2020			Modified methods getIPVerifications, displayIPReleaseObjects, getVerifyRelID, updateVerifyRunAppInfo, 
 * 												getVerifyRunRevisions, getVerifyRunWMs, getStatusWithIcon and getComments for SWIMP-322
 * Mahammed Irshad K S		25-Aug-2020			Modified the method updateVerifyRunAppInfo for SWIMP-500
 * Mahammed Irshad K S		02-Jul-2021			Modified the method updateAuditRecords and added connectAuditRecordsAndUpdateHistory & mqlHistoryOff for SWIMP-576
 *------------------------------------------------------------------------------------------------------------------------------------------
 */

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.nio.file.*;
import java.util.TreeMap;
import java.util.Vector;
import java.util.List; //Added for SWIMP-31 (Phase-2)
import java.util.Map.Entry;
import java.util.Hashtable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.matrixone.apps.common.MultipleOwner;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException; //Added for SWIMP-322
import matrix.util.Pattern;//Added for SWIMP-31
import matrix.util.StringList;
import matrix.db.RelationshipType; // Added for SWIMP-882

import org.apache.log4j.Logger;// Added for SWIMP-882
import matrix.db.BusinessInterface; // Added for SWIMP-882
import matrix.db.Environment; // Added for SWIMP-882

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;




import java.util.UUID;

import java.util.regex.Matcher;


import org.apache.commons.lang.StringUtils;



import matrix.db.JPO;



import matrix.util.StringList;

import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Objects;

// New imports for ValidateBOM
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;







public class IMP_IPVerification_mxJPO {
	/** A string constant with the value emxSemiTeamCollabStringResource. */
	private static final String RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR = "emxSemiTeamCollabStringResource";
	private static String sMessage = "Message";
	public static final String INPUT_HIDDEN_TAG = "<input type='hidden' name='";
	//SWIMP-231
	protected static final	Map<String , String> ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE = new HashMap<>();
					
			static {
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED, "1");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED, "2");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING, "3");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED, "4");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED, "5");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN, "6");
			}
			//Added For SWIMP-231: End
	//Added for SWIMP-882
	private static Logger logger = Logger.getLogger(IMP_IPVerification_mxJPO.class);
	private static String sSSGQIStatus = "SSGQI Status";
	private static String sSSGQFileName = "SSGQI FileName";
	//Added for SWIMP-882
	/**
	 * This method is executed if a specific method is not specified.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds no arguments
	 * @returns nothing
	 * @throws Exception if the operation fails
	 */

	public int mxMain(Context context, String[] args) throws Exception {
		if (!context.isContextSet())
			throw new Exception("must specify method on IMP_SoC invocation");
		return 0;
	}

	/**Modified for SWIMP-321
	 * Method added for get the connected verify objects from SoC
	 * Modified method for SWIMP-322
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the objectID
	 * @return MapList
	 * @throws Exception if the operations fails
	 */

	@SuppressWarnings("rawtypes")
	public static MapList getIPVerifications(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		String parentOID = (String) programMap.get("parentOID");
		DomainObject masterObject = new DomainObject(parentOID);
		MapList mlVerifyObjList = new MapList();
		//Added for SWIMP-31 Start
		if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(masterObject.getInfo(context, DomainConstants.SELECT_TYPE))) {
			//Added for SWIMP-31 End
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainConstants.SELECT_ORIGINATED);
			// Modified for user story 224
			objectSelects.add(DomainConstants.SELECT_OWNER);
			objectSelects.add("attribute[IMP_Status].value");
			objectSelects.add("attribute[IMP_DryRun].value");
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TSRYAMLFILE);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_Tsr_FileName);
			//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs': Starts
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.attribute[IMP_IPTag]");
			objectSelects.add("from[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS + "].to.to["+ IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.to["
					+ IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH + "].from.name");
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.id");
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.type");

			mlVerifyObjList = masterObject.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_FORSOC, IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, objectSelects, null, true, false,
					(short) 1, null, null, 0);
		}
		else {
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_NAME);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TSRYAMLFILE);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_Tsr_FileName);
			
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUNFORHIP);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN);

			MapList mlVerifyRunList = masterObject.getRelatedObjects(context,
					relPattern.getPattern(), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					null, // relationship selects
					true, // from
					true, // to
					(short) 4, // expand level
					null, // object where
					null, // relationship where
					0); // limit

			if (!mlVerifyRunList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlVerifyRunList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId;
				String strVerifyRunType;
				StringList slIMPVerifyIdsDuplicateCheck = new StringList();
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
					strVerifyRunType = mapVerifyRun.get(DomainConstants.SELECT_TYPE);
					if (IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN.equalsIgnoreCase(strVerifyRunType)  && !slIMPVerifyIdsDuplicateCheck.contains(strVerifyRunId)) {
						slIMPVerifyIdsDuplicateCheck.add(strVerifyRunId);
						mlVerifyObjList.add(mapVerifyRun);
					}
				}
			}
		}
		//Added for SWIMP-31 End

		//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs': Ends
		mlVerifyObjList.sortStructure(DomainConstants.SELECT_NAME, "descending", "string");

		return mlVerifyObjList;

	}

	/**
	 * Method for passing the verify object ID to Release object table
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return Vector
	 * @throws Exception if the operations fails
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getIPReleaseObjects(Context context, String args[]) throws Exception {
		Vector returnVector = new Vector();
		StringBuilder strTableColBuilder = new StringBuilder();
		HashMap programMap = JPO.unpackArgs(args);

		Map mlParamList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sSoCObjId = (String) mlParamList.get("objectId");
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();

		Iterator itrVerifyObjects = verifyMapList.iterator();
		String sTabHeader = EnoviaResourceBundle.getProperty(context, RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR, context.getLocale(), "imp.emxSemiTeamCollab.command.IMP_IPReleaseObjects");

		for (int i = 0; i < iSize; i++) {
			Map map = (Map) itrVerifyObjects.next();
			String strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
			DomainObject db = new DomainObject(strVerifyID);
			String strVerifyName = db.getInfo(context, DomainConstants.SELECT_NAME);
			//Modification for "in chrome clicking on the IP verificaion verify id the page goes up and contents are hidden" Starts
			strTableColBuilder.append("<a onClick=\"highlight(this);\" href=\"javascript:showReleaseObjects('" + strVerifyID + "')\"; title=name>" +strVerifyName + "</a>");
			//Modification for "in chrome clicking on the IP verificaion verify id the page goes up and contents are hidden" Ends
			if (i == iSize - 1) {
				strTableColBuilder.append("<script>");
				strTableColBuilder.append("function showReleaseObjects(VerifyID) { ");
				strTableColBuilder.append("window.parent.parent.frames[1].location.href=");
				strTableColBuilder.append(
						"'../common/emxTable.jsp?table=IMP_IPReleaseSummaryTable&program=IMP_IPVerification:displayIPReleaseObjects&portalMode=true&hideLaunchButton=false&sortColumnName=Status");
				strTableColBuilder.append("&sortDirection=ascending&selection=multiple&toolbar=IMP_SoCIPApprovalToolbar");
				strTableColBuilder.append("&header="+sTabHeader);
				strTableColBuilder.append("&VerifyID='+VerifyID");

				strTableColBuilder.append("+'&objectId=" + sSoCObjId);
				strTableColBuilder.append("';");
				strTableColBuilder.append("}");

				strTableColBuilder.append("function highlight(ctrl) { ");
				strTableColBuilder.append("var table = document.getElementById('IMP_IPVerificationSummaryTable');");
				strTableColBuilder.append("for (var i = 0; i<table.rows.length; i++) {");
				strTableColBuilder.append("var trClassName = table.rows[i].className;");
				strTableColBuilder.append("if(trClassName != '' && trClassName.includes('IMP_highlight')) {");
				strTableColBuilder.append("var newClassName = trClassName.replace(' IMP_highlight', '');");
				strTableColBuilder.append("table.rows[i].className = newClassName;");
				strTableColBuilder.append("}");
				strTableColBuilder.append("}");
				strTableColBuilder.append("ctrl.parentNode.parentNode.className = ctrl.parentNode.parentNode.className+' IMP_highlight';");
				strTableColBuilder.append("}");

				strTableColBuilder.append("</script>");

				strTableColBuilder.append("<style>");
				strTableColBuilder.append("tr.IMP_highlight {");
				strTableColBuilder.append("font-weight: bold;");
				strTableColBuilder.append("}");
				strTableColBuilder.append("</style>");

			}
			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
		return returnVector;
	}

	/**
	 * method to show the IP revisions connected to Verification objects as part of Verify run
	 * Modified for SWIMP-31 (Phase-2)
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return MapList
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList displayIPReleaseObjects(Context context, String[] args) throws FrameworkException {
		//Modified For SWIMP-531 Starts
		MapList objReturnList = new MapList();
		MapList mlFinalLPConnectedObjects = new MapList();
		//Modified For SWIMP-531 Ends
		try {
			HashMap programMap = JPO.unpackArgs(args);
			//Modified key VerifyID with constant, for SWIMP-322
			if (programMap.containsKey(IMP_Constants_mxJPO.KEY_VERIFYID)) {
				String strVerifyID = (String) programMap.get(IMP_Constants_mxJPO.KEY_VERIFYID);
				StringList objectSelects = new StringList();
				objectSelects.add(DomainConstants.SELECT_ID);
				objectSelects.add(DomainConstants.SELECT_NAME);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_WATERMARK);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_VERIFYRUN);   //Added for SWIMP-541
				//Modified For SWIMP-31 Starts
				StringList slRelSelects = new StringList();
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
				slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS); //Added for SWIMP-31 (Phase-2)
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES); //Added for SWIMP-31 (Phase-2)
				
				//Modified For SWIMP-31 Ends

				DomainObject domVerifyObj = new DomainObject(strVerifyID);

				//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs'
				MapList mReturnMap = domVerifyObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
						objectSelects, // Object selects
						slRelSelects, // relationship selects 	//Added For SWIMP-31
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit
				//Modified For SWIMP-531 Starts
				if(!mReturnMap.isEmpty()) {
					Map mapProject;
					mlFinalLPConnectedObjects = getLogicalProducts(context,(String) programMap.get(IMP_Constants_mxJPO.OBJECTID));
					Iterator<Map<String,String>> objectListItr = mReturnMap.iterator();
					while (objectListItr.hasNext()) {
						mapProject = objectListItr.next();
						mapProject.put("allConnectedLogicalProducts",mlFinalLPConnectedObjects);

						objReturnList.add(IMP_Utility_mxJPO.getAccessMap(context, (String) mapProject.get(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_VERIFYRUN),mapProject));  //Added for SWIMP-541
					}
				}
				//Modified For SWIMP-531 Ends
			}
		}
		catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return objReturnList;
	}
	
	/**
	 * method to get the owner of the verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector getVerificationSubBy(Context context, String[] args) throws Exception {
		Vector lSubmittedBy = new Vector();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator objectListItr = relBusObjPageList.iterator();
			Map mVerify;
			String strObjectId;
			DomainObject domVerifyObj;
			String sOwner;
			while (objectListItr.hasNext()) {
				mVerify = (Map) objectListItr.next();
				strObjectId = (String) mVerify.get(DomainConstants.SELECT_ID);
				domVerifyObj = DomainObject.newInstance(context, strObjectId);
				sOwner = domVerifyObj.getInfo(context, DomainConstants.SELECT_OWNER);
				if (sOwner != null && sOwner.length() > 0) {
					lSubmittedBy.add(PersonUtil.getFullName(context, sOwner));
				} else {
					lSubmittedBy.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lSubmittedBy;

	}

	/**
	 * This method gets the name of the IP for the IP Revision table in IP Verification
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getName(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");

		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		HashMap paramMap = (HashMap) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sReportFormat = (String) paramMap.get("reportFormat");
		Vector lName = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		String sURL;
		String sIPObjId;
		StringBuilder sbOutput = new StringBuilder();

        try {
            Map mapProject = null;
            while (objectListItr.hasNext()) {
                mapProject = (Map) objectListItr.next();
                String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
                DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
                String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
                String sDesignFileName = domWMObj.getInfo(context, "attribute[IMP_Design_File]");
                DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
                String strName = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.name");
                sIPObjId = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.id");
                StringList slWMObjs = domRevObj.getInfoList(context, "from[IMP_IP_Watermark].to.name");
                if (slWMObjs.size() > 1)
                    sDesignFileName = "/"+sDesignFileName;
                else
                    sDesignFileName = "";
            //Added for SWIMP-1 ends
				if (UIUtil.isNullOrEmpty(strName)) {
					ContextUtil.pushContext(context);
					strName = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.name");
					if (UIUtil.isNotNullAndNotEmpty(strName)) {
						lName.add(strName);
					} else {
						lName.add("");
					}
					ContextUtil.popContext(context);
				} else {
					if (UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
						lName.add(strName);
					} else {
						sURL = "../common/emxTree.jsp?objectId=" + sIPObjId + "&DefaultCategory=IMP_IPSOCsLink";
                        sbOutput.append("<a href=\"javascript:showNonModalDialog('" + sURL + "',800,600)\">" + strName + sDesignFileName + "</a>");//Modified for SWIMP-1
						lName.add(sbOutput.toString());
						sbOutput.setLength(0);
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("Error getting the IP ID for the detected revision " + e);
		}
		return lName;
	}

	/**
	 * This method gets the approval/rejection comments for IP Verification requests
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getComments(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector lApprovalComments = new Vector();

		String sRevObjId;
		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sVerifyObjId = (String) paramList.get("VerifyID"); 
		Map mapProject;
		String strApprovalComments;
		String sVerifyRelId;

		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			sRevObjId = (String) mapProject.get(DomainConstants.SELECT_ID);
			sVerifyRelId = getVerifyRelID(context, sVerifyObjId, sRevObjId);
			DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
			domVerifyRel.open(context);
			strApprovalComments = domVerifyRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS);//Modified for SWIMP-322 Replaced the old attribute
			domVerifyRel.close(context);

			if (strApprovalComments != null && strApprovalComments.length() > 0) {
				strApprovalComments = strApprovalComments.replaceAll("\\<.*?\\>", " ");
				lApprovalComments.add(strApprovalComments);
			} else {
				lApprovalComments.add("");
			}
		}
		return lApprovalComments;

	}

	/**
	 * This method hides the checkbox in the Verification table for requests having status other than Pending.
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector showCheckbox(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector enableCheckBox = new Vector();

		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sSoCObjId = (String) paramList.get("objectId");
		String strObjectId;
		Map mapProject;
		String strApprovalStatus = "";
		//Modified for SWIMP-31 Starts
		String sVerificationStatusRelId ="";
		DomainObject domIPOrSoC = DomainObject.newInstance(context, sSoCObjId);
		String strTypeIPOrSoC = domIPOrSoC.getInfo(context, DomainConstants.SELECT_TYPE);
		MapList mlWMList = new MapList();
		String strLineage ;
		if(IMP_Constants_mxJPO.TYPE_IMP_IP_RPODUCT.equalsIgnoreCase(strTypeIPOrSoC)) {
			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
			slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK);


			mlWMList = domIPOrSoC.getRelatedObjects(context,
					relPattern.getPattern(), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 4, // expand level
					null, // object where
					null, // relationship where
					0); // limit
		}
		//Modified for SWIMP-31 Ends
		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
			strLineage =(String) mapProject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
			//Modified for SWIMP-31 Starts
			if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(strTypeIPOrSoC)) {
				sVerificationStatusRelId = getRelID(context, sSoCObjId, strObjectId);
			}else {
				strApprovalStatus = getVerificationStatusForHIPApprovalStatus(mlWMList, strObjectId, strLineage);
			}
			//Modified for SWIMP-31 Ends
			if( UIUtil.isNotNullAndNotEmpty(sVerificationStatusRelId)) {
				DomainRelationship domRel = new DomainRelationship(sVerificationStatusRelId);
				domRel.open(context);
				//Modified for SWIMP-322: Replaced attribute IMP_IPSoCApprovalStatus with IMP_ApprovalStatus
				strApprovalStatus = domRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
				domRel.close(context);
			}
			if (strApprovalStatus != null && strApprovalStatus.length() > 0 && strApprovalStatus.equalsIgnoreCase("Pending")) {
				enableCheckBox.add("true");
			} else {
				enableCheckBox.add("false");
			}
		}
		return enableCheckBox;
	}

	/**
	 * This method gets status of the IP Verification objects pertaining to the IP with matching status icon
	 * Modified for SWIMP-31 (Phase-2)
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getStatusWithIcon(Context context, String[] args) throws Exception {
		Vector lStatusICons = new Vector();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			String sReportFormat = (String) paramList.get("reportFormat");
			Iterator objectListItr = lstobjectList.iterator();

			Map mapProject;
			String strApprovalStatus;
			String sVerifyRelId;

			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				sVerifyRelId = (String) mapProject.get(DomainConstants.SELECT_RELATIONSHIP_ID);//Added for SWIMP-31 (Phase-2) : Replace getting verify-rel id mechanism 
				DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
				domVerifyRel.open(context);
				//Modified for SWIMP-322: Replaced attribute IMP_IPSoCApprovalStatus with IMP_ApprovalStatus
				strApprovalStatus = domVerifyRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
				domVerifyRel.close(context);

				if (UIUtil.isNullOrEmpty(sReportFormat)) {
					StringList slReturnList = (StringList) getVerificationStatusList(context, strApprovalStatus);
					lStatusICons.add(slReturnList.get(0));
				} else {
					lStatusICons.add(strApprovalStatus);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lStatusICons;
	}	

	/**
	 * This method gets the relationship id exists between given SoC Object and Revision Object
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param sSoCHIPObjId - SOC ObjectId, sRevObjId - Revision object Id
	 * @return String
	 * @throws FrameworkException if the operations fails
	 */
	@SuppressWarnings("unchecked")
	public static String getRelID(Context context, String sSoCHIPObjId, String sRevObjId, String sType, String sLineage) throws FrameworkException {
		String sReturn = "";
		try {
			DomainObject domSoCHIP = DomainObject.newInstance(context, sSoCHIPObjId);
			//Modified for SWIMP-46
			String sRelIPVerificationForSoCorHIP = "";
			boolean from;
			boolean to;
			if((IMP_Constants_mxJPO.STR_HIP).equalsIgnoreCase(sType)) {
				sRelIPVerificationForSoCorHIP = IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP;
				from = false;
				to = true;
			} else {
				sRelIPVerificationForSoCorHIP = IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORSOC;
				from = true;
				to = false;
			}

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			String sWhere = "";
			if(UIUtil.isNotNullAndNotEmpty(sLineage))
				sWhere = IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE + " == '" + sLineage + "'"; //Added for SIMP-31 (Phase-2)

			MapList mlRevList = domSoCHIP.getRelatedObjects(context,
					sRelIPVerificationForSoCorHIP, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					from, // from
					to, // to
					(short) 1, // expand level
					null, // object where
					sWhere, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Iterator<Map<String, Object>> itrRevList = mlRevList.iterator();
				String sRevId = "";
				while (itrRevList.hasNext()) {
					Map<String, Object> mRev = itrRevList.next();
					sRevId = (String) mRev.get(DomainConstants.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(sRevId) && sRevId.equalsIgnoreCase(sRevObjId)) {
						sReturn = (String) mRev.get(DomainRelationship.SELECT_ID);
						break;
					}
				}
			}
		} catch (FrameworkException e) {
			throw new FrameworkException("Exception in the method IMP_IPVerification_mxJPO::getRelID: " + e);
		}
		return sReturn;
	}
	
	public static String getRelID(Context context, String sSoCHIPObjId, String sRevObjId) throws FrameworkException {
		return getRelID(context,sSoCHIPObjId,sRevObjId,"","");
	}

	/**
	 * This method gets the relationship id exists between given Verification Object and Revision Object
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param SoCObjId - SOC ObjectId, sRevObjId - Revision object Id
	 * @return String
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings("rawtypes")
	public static String getVerifyRelID(Context context, String sVerification, String sRevObjId) throws FrameworkException {
		String sReturn = "";
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerification);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			String sWhere = "";

			//Modified for SWIMP-322: Replaced with new relationship
			MapList mlRevList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Iterator itrRevList = mlRevList.iterator();
				Map mRev;
				String sRevId;
				while (itrRevList.hasNext()) {
					mRev = (Map) itrRevList.next();
					sRevId = (String) mRev.get(DomainConstants.SELECT_ID);
					if (sRevId != null && sRevId.length() > 0 && sRevId.equalsIgnoreCase(sRevObjId)) {
						sReturn = (String) mRev.get(DomainRelationship.SELECT_ID);
						break;
					}
				}
			}

		} catch (FrameworkException e) {
			throw e;
		}
		return sReturn;
	}
	/**
	 * This method gets status of the IP Verification objects pertaining to the IP with matching status icon
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param strApprovalStatus - Approval Status
	 * @return List
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings("unchecked")
	public static List<String> getVerificationStatusList(Context context, String strApprovalStatus) {
		List<String> lStatusICons = new StringList();
		StringBuilder sbHtmlTag = new StringBuilder();
		if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED)+"'></input><img src='../common/images/utilWorkflowGreenArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_APPROVED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN)+"'></input><img src='../common/images/utilWorkflowGrayArrow.gif' border='0'  align='middle'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED)+"'></input><img src='../common/images/utilWorkflowGreenArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_PREAPPROVED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED)+"'></input><img src='../common/images/utilWorkflowRedArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_RETRACTED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING)+"'></input><img src='../common/images/utilWorkflowGrayArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_PENDING_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED)+"'></input><img src='../common/images/utilWorkflowRedArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_REJECTED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED);
		} else {
			sbHtmlTag.append(strApprovalStatus);
		}
		
		lStatusICons.add(sbHtmlTag.toString());
		return lStatusICons;
	}

	

	/**
	 * This method gets the Tag of the revision objects for which IP Verify was run
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getRevision(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lRevTag = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
                //Added for SWIMP-1 starts
                DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
                String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
                DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
                //Added for SWIMP-1 ends
				String sRevTag = domRevObj.getAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag"));

				if (sRevTag != null && sRevTag.length() > 0) {
					lRevTag.add(sRevTag);
				} else {
					lRevTag.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lRevTag;
	}


	//Modified for SWIMP-31 (Phase-2) : Starts
	/**
	 * Method to display No Of Instances of the revision in IP Verification
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return StringList
	 * @throws FrameworkException, if the operations fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StringList getNoOfInstances(Context context, String[] args) throws FrameworkException {
		//Added for SWIMP-31 (Phase-2) : Starts
		StringList slNoOfInstances = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrWMObjs = mlWMObjs.iterator();
			Map<String,String> mapWM;
			String strNoOfInstances;
			while (itrWMObjs.hasNext()) {
				mapWM = itrWMObjs.next();
				strNoOfInstances = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
				slNoOfInstances.add(UIUtil.isNullOrEmpty(strNoOfInstances) ? "" : strNoOfInstances);
			}
		} catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:getNoOfInstances: " + e.getMessage());
		}
		return slNoOfInstances;
		//Added for SWIMP-31 (Phase-2) : Ends
	}
	//Modified for SWIMP-31 (Phase-2) : Ends


	/**
	 * This methods gets the IP Source attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getIPSource(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);

		String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String attrIPSource = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource");
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPSourceList = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			DomainObject domRevObj;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
				
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");

					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					String strIPSource = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.attribute[" + attrIPSource + "]");

					if (strIPSource != null && strIPSource.length() > 0) {
						lIPSourceList.add(strIPSource);
					} else {
						ContextUtil.pushContext(context);
						strIPSource = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.attribute[" + attrIPSource + "]");
						if (UIUtil.isNotNullAndNotEmpty(strIPSource)) {
							lIPSourceList.add(strIPSource);
						} else {
							lIPSourceList.add("");						
						}
						ContextUtil.popContext(context);
					}
				} else {
					lIPSourceList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Error getting IP Source of the IP Product " + e);
		}
		return lIPSourceList;
	}

	/**
	 * This methods gets the IP Source attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getDesignStatus(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);

		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPDesignStatus = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					//Added for SWIMP-1 ends
					DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
					String sBranchLifeCycle = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.attribute[IMP_Branch_Lifecycle]");

					if (sBranchLifeCycle != null && sBranchLifeCycle.length() > 0) {
						lIPDesignStatus.add(sBranchLifeCycle);
					} else {
						lIPDesignStatus.add("");
					}
				} else {
					lIPDesignStatus.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return lIPDesignStatus;
	}

	/**
	 * This methods gets the IP Type attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getIPType(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPTypeList = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			DomainObject domRevObj;
			String strObjectId;
			String strIPType;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					strIPType = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");

					if (strIPType != null && strIPType.length() > 0) {
						lIPTypeList.add(strIPType);
					} else {
						ContextUtil.pushContext(context);
						strIPType = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");
						if (UIUtil.isNotNullAndNotEmpty(strIPType)) {
							lIPTypeList.add(strIPType);
						} else {
							lIPTypeList.add("");
						}
						ContextUtil.popContext(context);
					}
				} else {
					lIPTypeList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Error getting IP Type of the IP Product " + e);
		}
		return lIPTypeList;
	}
	
	/**
	 * This methods gets the IP Deprecated by
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getDeprecatedBy(Context context, String args[]) throws Exception {
		Vector vDeprecatedby = new Vector();
		boolean bContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			bContextPushed = true;
			HashMap programMap = JPO.unpackArgs(args);
			MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			HashMap paramMap = (HashMap) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			String sReportFormat = (String) paramMap.get("reportFormat");
			Iterator objectListItr = relBusObjPageList.iterator();

			String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
			String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");

			Map mapProject;
			DomainObject domRevObj;
			String strObjectId;
			String sIPObjId;
			ArrayList<String> lsDeprecatedBy = new ArrayList<>();
			String sDeprecatedBy;
			StringBuilder sbDeprecatedBy = new StringBuilder();
			String sDeprecatedList;

			while (objectListItr.hasNext()) {
				sDeprecatedBy = "";
				mapProject = (Map) objectListItr.next();
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					sIPObjId = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.id");

					lsDeprecatedBy = (ArrayList<String>) IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, sIPObjId);
					if (!lsDeprecatedBy.isEmpty() && UIUtil.isNullOrEmpty(sReportFormat)) {
						for (int i = 0; i < lsDeprecatedBy.size(); i++) {
							sDeprecatedBy = lsDeprecatedBy.get(i);
							sbDeprecatedBy.append("<font color='red'>");
							sbDeprecatedBy.append(sDeprecatedBy);
							sbDeprecatedBy.append("</font>");
							sbDeprecatedBy.append(", ");
						}

						sDeprecatedList = sbDeprecatedBy.toString();
						if (UIUtil.isNotNullAndNotEmpty(sDeprecatedList) && sDeprecatedList.length() > 2) {
							sDeprecatedList = sDeprecatedList.substring(0, sDeprecatedList.length() - 2);
							vDeprecatedby.add(sDeprecatedList);
						} else {
							vDeprecatedby.add("");
						}

					} else if (!lsDeprecatedBy.isEmpty() && UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
						sDeprecatedBy = (lsDeprecatedBy.toString().substring(1, lsDeprecatedBy.toString().length() - 1)).trim();
						sDeprecatedBy = sDeprecatedBy.replaceAll(", ", "|");
						vDeprecatedby.add(sDeprecatedBy);
					} else {
						vDeprecatedby.add("");
					}

					sbDeprecatedBy.setLength(0);
				} else {
					vDeprecatedby.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification :  getDeprecatedBy " + e);
		} finally {
			if (bContextPushed) {
				ContextUtil.popContext(context);
			}
		}
		return vDeprecatedby;
	}

	/**
	 * This methods gets approvers for the given IP Revision for IP Verification approvals
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return List
	 * @throws Exception if the operations fails
	 */	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getApprover(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector lApprover = new Vector();
		String sRevObjId;

		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sVerifyObjId = (String) paramList.get("VerifyID");
		Map mapProject;
		String sApprover;
		String sVerifyRelId;

		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			sRevObjId = (String) mapProject.get(DomainConstants.SELECT_ID);
			sVerifyRelId = getVerifyRelID(context, sVerifyObjId, sRevObjId);
			DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
			domVerifyRel.open(context);
			sApprover = domVerifyRel.getAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_Approver"));
			domVerifyRel.close(context);

			if (sApprover != null && sApprover.length() > 0) {
				lApprover.add(PersonUtil.getFullName(context, sApprover));
			} else {
				lApprover.add("");
			}
		}
		return lApprover;

	}

  
 
  /**
   * Update audit records.
   *
   * @param context the context
   * @param args the args
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
  public void updateAuditRecords(Context context, String[] args) throws Exception {
    HashMap programMap = JPO.unpackArgs(args);
    String strTag = (String) programMap.get("Tag");
    String strIPID = (String) programMap.get("IPID");
    String strRelID = (String) programMap.get("RELID");
    String strComments = (String) programMap.get("COMMENTS");
    String strProject = (String) programMap.get("PROJECT");
    String strOperation = (String) programMap.get("OPERATION");
    String strConsumedRecord =
        PropertyUtil.getSchemaProperty(context, "relationship_IMP_ConsumedRecords");
    String strAuditRecord =
        PropertyUtil.getSchemaProperty(context, "relationship_IMP_ReleaseAuditRecords");
    String sIPAuditRecordPolicyAlias =
        FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_POLICY,
            PropertyUtil.getSchemaProperty(context, "policy_IMP_IPAuditRecords"), true);
    String sIPAuditRecTypeAdminAlias =
        FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_TYPE,
            PropertyUtil.getSchemaProperty(context, "type_IMP_IPAuditRecords"), true);
    try {
      String sIPAuditRecId =
          FrameworkUtil.autoName(context, sIPAuditRecTypeAdminAlias, "", sIPAuditRecordPolicyAlias,
              PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
      Map mpAttrUpdate = new HashMap<>();
      mpAttrUpdate.put("IMP_Comment", strComments);
      mpAttrUpdate.put("IMP_ProjectName", strProject);
      mpAttrUpdate.put("IMP_IPTag", strTag);
      mpAttrUpdate.put("IMP_IPOperation", strOperation);
      DomainObject domAudit = new DomainObject(sIPAuditRecId);
      domAudit.setAttributeValues(context, mpAttrUpdate);
      DomainObject domIP = new DomainObject(strIPID);
      DomainObject domRelease = new DomainObject(strRelID);

      //Added for SWIMP-576 : Starts
      String sComment = strComments;
      if ("download".equals(strOperation)) {
    	  sComment = "--project: " + strProject + "; --ipid: "
    			  + domIP.getInfo(context, DomainConstants.SELECT_NAME) + "; --tag: " + strTag + "; --comment: "
    			  + strComments;
    	  connectAuditRecordsAndUpdateHistory(context, domRelease, strAuditRecord, domAudit, strRelID, strOperation, sComment);
      }
      connectAuditRecordsAndUpdateHistory(context, domIP, strConsumedRecord, domAudit, strIPID, strOperation, sComment);
      //Added for SWIMP-576 : Ends
    } catch (Exception e) {
      throw new Exception(e);
    }
  }


	/**
	 * Method for getting the co-owners list for the given object Id
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the objectID and New Value
	 * @return MapList
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static MapList getCoOwners(Context context, String sObjectId) throws Exception {
		MapList mlRetrunList = new MapList();
		MapList mlUserList = new MapList();
		try {
			DomainObject domIPObj = DomainObject.newInstance(context, sObjectId);
			MultipleOwner mulOwner = new MultipleOwner(domIPObj);
			String strPersonID;
			mlUserList = mulOwner.getCoOwners(context, null, null, true);

			if (mlUserList != null && !mlUserList.isEmpty()) {
				Map map = (Map) mlUserList.get(0);
				String name = (String) map.get(DomainConstants.SELECT_NAME);
				if (name != null && !"".equals(name)) {
					String[] names = name.split("~");

					for (int i = 0; i < names.length; i++) {
						strPersonID = PersonUtil.getPersonObjectID(context, names[i]);
						HashMap hmObjectMap = new HashMap();
						hmObjectMap.put(DomainConstants.SELECT_ID, strPersonID);
						hmObjectMap.put(DomainConstants.SELECT_NAME, names[i]);
						mlRetrunList.add(hmObjectMap);
					}
				}
			}
		} catch (Exception e) {
			throw new FrameworkException(e);
		}
		return mlRetrunList;
	}

  // Modified for the bug IMPBRCM-985
  /**
   * This method checks in the public documents into given IP
   *
   * @param context the eMatrix <code>Context</code> object
   * @param sIPName - IP ID
   * @param sPath - Path in the Enovia server for the files
   * @param
   * @return nothing
   * @throws Exception if the operations fails
   */
  @SuppressWarnings({"rawtypes", "deprecation", "unchecked"})
  public static Map checkinPublicDocumentsToIP(Context context, String args[]) throws Exception {
    // DO NOT REMOVE ANY SYSOUTS FROM THIS METHOD, THIS IS TO CHECK THE FAILURE -- JIRA 1205
    System.out.println("-- START -- PUBLIC DOCUMENTS CHECKIN --");
    Map mpReturnMap = new HashMap();
    try {
      String strDesignSpecificationID = "";
      HashMap programMap = (HashMap) JPO.unpackArgs(args);
      String strIPIDName = (String) programMap.get("sIPName");
      String sFTPWorkingDirectory = (String) programMap.get("sPath");
      String sDocPublisher = (String) programMap.get("sUser");
      System.out.println("-- PUBLIC DOCUMENTS PUBLISHER --: "+sDocPublisher);
      sFTPWorkingDirectory = sFTPWorkingDirectory + "/";
      System.out.println("-- FTP WORKING DIR --: " + sFTPWorkingDirectory);
      String strRel = PropertyUtil.getSchemaProperty(context, "relationship_ProductSpecification");
      String strDesignSpecificationType =
          PropertyUtil.getSchemaProperty(context, "type_DesignSpecification");
      StringBuilder sbFileList = new StringBuilder();

      // Added for IMPBRCM-695 Starts
      String strVersionPolicy = PropertyUtil.getSchemaProperty(context, "policy_Version");
      String strRelActiveVersion =
          PropertyUtil.getSchemaProperty(context, "relationship_ActiveVersion");
      String strRelLatestVersion =
          PropertyUtil.getSchemaProperty(context, "relationship_LatestVersion");
      String strAttrTitle = PropertyUtil.getSchemaProperty(context, "attribute_Title");
      String attrIsVersionObj =
          PropertyUtil.getSchemaProperty(context, "attribute_IsVersionObject");

      // Added for IMPBRCM-695 Ends
      String strAutoNameType = "type_DesignSpecification";
      String strAutoNamePolicy = "policy_SoftwareDesignSpecification";
      StringList objectSelect = new StringList();
      objectSelect.add(DomainConstants.SELECT_ID);
      objectSelect.add(DomainConstants.SELECT_OWNER);
      String typePattern = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
      // Added for IMPBRCM-695 Starts
      DomainObject designSpecificationObject = new DomainObject();
      DomainObject domDocObj = new DomainObject();
      String sName = null;
      String sRevision = null;
      String sFileName = null;
      // Added for IMPBRCM-695 Ends
      boolean isDocObjPresent = false;

      com.matrixone.apps.common.WorkspaceVault workspaceVault =
          (com.matrixone.apps.common.WorkspaceVault) DomainObject.newInstance(context,
              DomainConstants.TYPE_WORKSPACE_VAULT);

      MapList mMapList = DomainObject.findObjects(context, typePattern, strIPIDName, "A", "*", "*",
          null, false, objectSelect);
      if (!mMapList.isEmpty()) {
        Map mapIPID = (Map) mMapList.get(0);
        String strIPID = (String) mapIPID.get(DomainConstants.SELECT_ID);
        System.out.println("-- IPID --: " + strIPID);
        String sMqlCommand = "";
        StringList objectSelects = new StringList();
        objectSelects.add(DomainConstants.SELECT_ID);
        objectSelects.add(DomainConstants.SELECT_ORIGINATOR);
        DomainObject masterObject = new DomainObject(strIPID);
        System.out.println("-- GETTING PRODUCT SPEC --: ");
        MapList mReturnMap = masterObject.getRelatedObjects(context, strRel,
            strDesignSpecificationType, objectSelects, null, true, true, (short) 1, null, null, 0);

        if (!mReturnMap.isEmpty()) {
          System.out.println("-- PRODUCT SPEC EXISTS--: ");
          Map mapDesignSpecification = (Map) mReturnMap.get(0);
          strDesignSpecificationID = (String) mapDesignSpecification.get(DomainConstants.SELECT_ID);
          designSpecificationObject = new DomainObject(strDesignSpecificationID);
          System.out.println("-- SPEC ID --: " + strDesignSpecificationID);
          StringList slObjSelects = new StringList();
          slObjSelects.add(DomainConstants.SELECT_ID);
          slObjSelects.add(DomainConstants.SELECT_REVISION);
          slObjSelects.add("attribute[Title]");
          String sWhere = "revision==last";

          MapList docObjList = designSpecificationObject.getRelatedObjects(context,
              PropertyUtil.getSchemaProperty(context, "relationship_LatestVersion"), // relationship
                                                                                     // pattern
              strDesignSpecificationType, // type pattern
              slObjSelects, // Object selects
              null, // relationship selects
              false, // from
              true, // to
              (short) 1, // expand level
              sWhere, // object where
              null, // relationship where
              0); // limit
          System.out.println("-- DOC LIST --: " + docObjList);
          docObjList.sortStructure(DomainConstants.SELECT_REVISION, "descending", "string");          
          Map mDocObjMap;
          String sDocObjId;
          String sDocObjTitle;
          int sDocObjRevision;
          int sDocObjNewRevision;
          DomainObject domDocumentObj;
          BusinessObject busNewRevision;
          DomainObject domNewRevision;

          File file = new File(sFTPWorkingDirectory);
          // Added for SWIMP-81: Starts
          System.out.println("-- "+ sFTPWorkingDirectory +" FILE EXISTS--: " + file.exists());
          System.out.println("-- " + sFTPWorkingDirectory +" IS A DIRECTORY --: " + file.isDirectory());
          // Added for SWIMP-81: Ends
          if (file.isDirectory() && file.listFiles() !=null) {
            File[] files = file.listFiles();
            // Added for SWIMP-81
            System.out.println("-- NUMBER OF FILES IN " + sFTPWorkingDirectory+ " --: " +files.length);
            for (int i = 0; i < files.length; i++) {
              String strPath = "";
              if (files[i].isFile()) {
                isDocObjPresent = false;
                strPath = sFTPWorkingDirectory + files[i].getName();
                sFileName = files[i].getName();
                // Added for SWIMP-81: Starts
                System.out.println("-- FILENAME --: " + sFileName);
                sbFileList.append(sFileName);
                sbFileList.append(",");
                try {
                  // Pushing context user to super user
                  ContextUtil.pushContext(context);
                  // Modified for IMPBRCM-695 Starts
                  // Creating a design specification object and connecting with active and current
                  // version to parent design specification object                  
                  sMqlCommand = "checkin businessobject " + strDesignSpecificationID + " append "
                      + strPath + ";";
                  System.out.println("-- COMMAND --: "+sMqlCommand);
                  MqlUtil.mqlCommand(context, sMqlCommand, false, false);
                  System.out.println("-- COMMAND EXECUTED SUCCESSFULLY --: ");
                  Iterator itrDocObjList = docObjList.iterator();
                  while (itrDocObjList.hasNext()) {
                    mDocObjMap = (Map) itrDocObjList.next();
                    sDocObjId = (String) mDocObjMap.get(DomainConstants.SELECT_ID);
                    System.out.println("-- DOC OBJ ID --: " + sDocObjId);
                    sDocObjTitle = (String) mDocObjMap.get("attribute[Title]");
                    System.out.println("-- DOC OBJ TITLE --: " + sDocObjTitle);
                    sDocObjRevision =
                        Integer.valueOf(mDocObjMap.get(DomainConstants.SELECT_REVISION).toString());
                    System.out.println("-- DOC OLD OBJ REVISION --: " + sDocObjRevision);
                    mpReturnMap.put("Old_Revision", sDocObjRevision);
                    if (sDocObjTitle != null && sDocObjTitle.length() > 0
                        && sFileName.equalsIgnoreCase(sDocObjTitle)) {
                      System.out.println("-- START DOC OBJ UPDATE/REVISE --: ");
                      domDocumentObj = DomainObject.newInstance(context, sDocObjId);
                      busNewRevision = domDocumentObj.reviseObject(context, false);
                      domNewRevision = new DomainObject(busNewRevision);
                      domNewRevision.setOwner(context, sDocPublisher);
                      domNewRevision.setAttributeValue(context,
                          PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                          sDocPublisher);
                      domNewRevision.setAttributeValue(context, attrIsVersionObj, "True");
                      isDocObjPresent = true;
                      sDocObjNewRevision = Integer.valueOf(domNewRevision.getRevision());
                      System.out.println("-- DOC OBJ UPDATED/REVISED --: ");
                      System.out.println("-- DOC OBJ NEW REVISION --: " + sDocObjNewRevision);
                      if (sDocObjNewRevision > sDocObjRevision) {
                        mpReturnMap.put(sMessage, "Success");
                        mpReturnMap.put("New Revision", sDocObjNewRevision);
                        mpReturnMap.put("Files_List", sbFileList);
                      } else {
                        mpReturnMap.put(sMessage, "Failed to revise");
                      }
                      System.out.println("-- DOC OBJ UPDATED/REVISED --: ");
                      break;
                    } else {
                      System.out.println("-- DOC OBJ NOT UPDATE/REVISED --: ");
                      System.out.println("-- CREATE NEW DOC OBJECT? --: " + isDocObjPresent);
                    }
                  }
                  if (!isDocObjPresent) {
                    System.out.println("-- START NEW DOC OBJ CREATE --: ");
                    sName = workspaceVault.getUniqueName(DomainConstants.EMPTY_STRING);
                    sRevision = "1";
                    domDocObj.createAndConnect(context, strDesignSpecificationType, sName,
                        sRevision, strVersionPolicy,
                        PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
                        strRelActiveVersion, designSpecificationObject, true);
                    DomainRelationship.connect(context, designSpecificationObject,
                        strRelLatestVersion, domDocObj);
                    domDocObj.setAttributeValue(context, strAttrTitle, sFileName);
                    domDocObj.setOwner(context, sDocPublisher);
                    domDocObj.setAttributeValue(context,
                        PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                        sDocPublisher);
                    domDocObj.setAttributeValue(context, attrIsVersionObj, "True");
                    isDocObjPresent = true;
                    mpReturnMap.put(sMessage, "Success");
                    mpReturnMap.put("New_Object_Created", isDocObjPresent);
                    // Added for SWIMP-81
                    mpReturnMap.put("Files_List", sbFileList);
                    System.out.println("-- NEW DOC OBJ CREATED --: " + isDocObjPresent);
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                  throw new Exception(e);
                } finally {
                  if (context != null) {
                    ContextUtil.popContext(context);
                  }
                } // Modified for IMPBRCM-695 Ends
              }
            }
          // Added for SWIMP-81: Starts
          } else {
              System.out.println("-- " + sFTPWorkingDirectory + " Does not exist---"+ !file.isDirectory());
              mpReturnMap.put(sMessage, "Failure");
          }
          // Added for SWIMP-81: Starts
        } else {
          System.out.println("-- PRODUCT SPEC NOT EXISTS, CREATE NEW--: ");
          try {
            ContextUtil.pushContext(context);
            strDesignSpecificationID =
                FrameworkUtil.autoName(context, strAutoNameType, strAutoNamePolicy);
            designSpecificationObject = new DomainObject(strDesignSpecificationID);
            designSpecificationObject.setOwner(context, sDocPublisher);
            designSpecificationObject.setAttributeValue(context,
                PropertyUtil.getSchemaProperty(context, "attribute_Originator"), sDocPublisher);
            designSpecificationObject.setAttributeValue(context, strAttrTitle, strIPIDName);
            DomainRelationship.connect(context,masterObject, strRel,  designSpecificationObject);
            System.out.println("-- PRODUCT SPEC CREATED--: " + strDesignSpecificationID);
            System.out.println("-- FTP WORKING DIRECTORY--: " + sFTPWorkingDirectory);
            File file = new File(sFTPWorkingDirectory);
            System.out.println("-- "+ sFTPWorkingDirectory +" FILE EXISTS--: " + file.exists());
            System.out.println("-- " + sFTPWorkingDirectory +" IS A DIRECTORY --: " + file.isDirectory());
            if (file.isDirectory()) {
              File[] files = file.listFiles();
              System.out.println("-- NUMBER OF FILES IN " + sFTPWorkingDirectory+ " --: " +files.length);
              for (int i = 0; i < files.length; i++) {
                String strPath = "";
                if (files[i].isFile()) {
                  strPath = sFTPWorkingDirectory + files[i].getName();
                  sFileName = files[i].getName();
                  System.out.println("-- FILENAME --: " +sFileName);
                  sbFileList.append(sFileName);
                  sbFileList.append(",");
                  // Modified for IMPBRCM-695 Starts
                  // Creating a dummy desgin specification object and connecting with active and
                  // current version to parent design specification object
                  sMqlCommand = "checkin businessobject " + strDesignSpecificationID + " append "
                      + strPath + ";";
                  System.out.println("-- COMMAND--: " + sMqlCommand);
                  MqlUtil.mqlCommand(context, sMqlCommand, false, false);
                  System.out.println("-- COMMAND EXECUTED SUCCESSFULLY--: ");
                  sName = workspaceVault.getUniqueName(DomainConstants.EMPTY_STRING);
                  sRevision = "1";
                  System.out.println("-- CREATE DESIGN SPEC OBJ--: ");
                  domDocObj.createAndConnect(context, strDesignSpecificationType, sName, sRevision,
                      strVersionPolicy,
                      PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
                      strRelActiveVersion, designSpecificationObject, true);
                  System.out.println("-- DESIGN SPEC OBJ CREATED--: " + domDocObj.getObjectId());
                  DomainRelationship.connect(context, designSpecificationObject,
                      strRelLatestVersion, domDocObj);
                  domDocObj.setAttributeValue(context, strAttrTitle, sFileName);
                  domDocObj.setOwner(context, sDocPublisher);
                  domDocObj.setAttributeValue(context,
                      PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                      sDocPublisher);
                  domDocObj.setAttributeValue(context, attrIsVersionObj, "True");
                  System.out.println("-- DESIGN SPEC OBJ UPDATED--: ");
                  mpReturnMap.put("New_Spec_Object_Created", true);
                  mpReturnMap.put("Files_List", sbFileList);
				  mpReturnMap.put(sMessage, "Success");
                  // Modified for IMPBRCM-695 Ends
                }
              }
           // Added for SWIMP-81: Starts
            } else {
              System.out.println("-- " + sFTPWorkingDirectory + " Does not exist---"+ !file.isDirectory());
              mpReturnMap.put(sMessage, "Failure");
            }
           // Added for SWIMP-81: Starts
          } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e);
          } finally {
            if (context != null) {
              ContextUtil.popContext(context);
            }
          }
        }
      } else {
        System.out.println("-- IPID NOT FOUND --: ");
        mpReturnMap.put(sMessage, "No IP Found");
      }
    } catch (Exception ex) {
      ex.printStackTrace();
      mpReturnMap.put("Exception", ex.getMessage());
    }
    System.out.println("-- END -- PUBLIC DOCUMENTS CHECKIN --");
    return mpReturnMap;
  }
	
	/**
	 * This method is created for migrating public documents to IP Product
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sIPName - IP ID
	 * @param sPath - Path in the Enovia server for the files
	 * @param sUser - IP Publisher
	 * @return nothing
	 * @throws Exception if the operations fails
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void checkinPublicDoc(Context context, String[] args) throws Exception{			
		HashMap argsMap = new HashMap<>();
		argsMap.put("sIPName", args[0]);
		argsMap.put("sPath", args[1]);
		argsMap.put("sUser", args[2]);	
		try {			
			checkinPublicDocumentsToIP(context, JPO.packArgs(argsMap));
		} catch (Exception e) {
			throw new Exception("JPO : IMP_IPVerification :: checkinPublicDoc"+e);
		}
		
	}
	
  /**
   * This method gets the latest revision of the IP for the IP Revision table in IP Verification
   * 
   * @param context the eMatrix <code>Context</code> object
   * @param args holds objectList
   * @return Vector
   * @throws Exception if the operations fails added for IMPBRCM-1093
   */

  @SuppressWarnings({"rawtypes", "unchecked"})
  public Vector getIPLatestRevision(Context context, String[] args) throws Exception {
	  //Added for SWIMP-90 starts
	  Vector latestRevisionVector = new Vector();
	  try {
		  HashMap programMap = JPO.unpackArgs(args);
		  MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		  ContextUtil.pushContext(context, IMP_Constants_mxJPO.PERSON_USERAGENT, DomainConstants.EMPTY_STRING,IMP_Constants_mxJPO.PROD_VALUT);
		  Iterator objectListItr = relBusObjPageList.iterator();
		  Map mapProject = null;
		  String strIPObjectId ="";
		  String strLatestRevision="";
		  String strType="";
		  DomainObject domObj = new DomainObject();
		  while (objectListItr.hasNext()) {
			  mapProject = (Map) objectListItr.next();
			  
			  if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
				  //Modified for SWIMP-31 Start
				  String strObjectId = (String) mapProject.get("sRevObjID");
				  strObjectId = UIUtil.isNotNullAndNotEmpty(strObjectId) ? strObjectId : (String) mapProject.get(DomainConstants.SELECT_ID);
				  //Modified for SWIMP-31 End
				  domObj.setId(strObjectId);
				  strType=domObj.getInfo(context,DomainConstants.SELECT_TYPE);
				  if(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK.equals(strType))
				  {
					//Added For SWIMP-578 Start
					strIPObjectId = domObj.getInfo(context, "to["+IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK+"].from.to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
					//Added For SWIMP-578 End
					} else if(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(strType)){
					  //Added For SWIMP-578 Start
					 strIPObjectId = domObj.getInfo(context, "to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
					  //Added For SWIMP-578 End
				  }
				  if(UIUtil.isNotNullAndNotEmpty(strIPObjectId)){
					  HashMap mpIPMap = new HashMap();
					  mpIPMap.put("IPID",strIPObjectId);
					  //Added For SWIMP-578 Start
					  mpIPMap.put("isBranch",IMP_Constants_mxJPO.STR_TRUE);
					  //Added For SWIMP-578 End
					  strLatestRevision=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
							  JPO.packArgs(mpIPMap), String.class);
				  }
				  latestRevisionVector.add(strLatestRevision);
			  } else {
				  latestRevisionVector.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
			  }
		  }
	  } finally {
		  ContextUtil.popContext(context);
	  }
	  return latestRevisionVector;
  }
  //Added for SWIMP-90 Ends
  
  /**
   * This method gets the latest revision of the IP for the IP Revision table in IP Verification
   * 
   * @param context the eMatrix <code>Context</code> object
   * @param args holds objectList
   * @return Vector
   * @throws Exception if the operations fails added for IMPBRCM-1093
   */
	//Added for SWIMP-541 --START
  @SuppressWarnings({"rawtypes", "unchecked"})
  public Vector getIPLatestRevisionApprovalPage(Context context, String[] args) throws Exception {
	  //Added for SWIMP-90 starts
	  Vector latestRevisionVector = new Vector();
	  try {
		  HashMap programMap = JPO.unpackArgs(args);
		  MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		  ContextUtil.pushContext(context, IMP_Constants_mxJPO.PERSON_USERAGENT, DomainConstants.EMPTY_STRING,IMP_Constants_mxJPO.PROD_VALUT);
		  Iterator objectListItr = relBusObjPageList.iterator();
		  Map mapProject = null;
		  String strIPObjectId ="";
		  String strLatestRevision="";
		  String strType="";
		  DomainObject domObj = new DomainObject();
		  while (objectListItr.hasNext()) {
			  mapProject = (Map) objectListItr.next();
			  
			  //Modified for SWIMP-31 Start
			  String strObjectId = (String) mapProject.get("sRevObjID");
			  strObjectId = UIUtil.isNotNullAndNotEmpty(strObjectId) ? strObjectId : (String) mapProject.get(DomainConstants.SELECT_ID);
			  //Modified for SWIMP-31 End
			  domObj.setId(strObjectId);
			  strType=domObj.getInfo(context,DomainConstants.SELECT_TYPE);
			  if(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK.equals(strType))
			  {
				  strIPObjectId = domObj.getInfo(context, IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
			  } else if(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(strType)){
				  strIPObjectId = domObj.getInfo(context, IMP_Constants_mxJPO.IPID);
			  }
			  if(UIUtil.isNotNullAndNotEmpty(strIPObjectId)){
				  HashMap mpIPMap = new HashMap();
				  mpIPMap.put("IPID",strIPObjectId);
				  strLatestRevision=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
						  JPO.packArgs(mpIPMap), String.class);
			  }
			  latestRevisionVector.add(strLatestRevision);
		  }
	  } finally {
		  ContextUtil.popContext(context);
	  }
	  return latestRevisionVector;
  }
  //Added for SWIMP-541 --END
	/**
	 * This method updated the approval info in the relationship attributes between verify run and IP Release.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds approval info
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateVerifyRunAppInfo(Context context, String[] args) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strSoCObjID = (String) programMap.get("SocID");
			String sStatus = (String) programMap.get("status");
			String sReason = (String) programMap.get("Reason");
			String sUser = (String) programMap.get("ContextUser");
			String sRevObjId = (String) programMap.get("RevObjId");
			String sApprovedDate = (String) programMap.get("ApprovedDate");
			
			//Modified For SWIMP-31 Start
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUNFORHIP);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_FORSOC);
			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN);
			//Modified For SWIMP-31 End
			sStatus = UIUtil.isNullOrEmpty(sStatus) ? "" : sStatus;
			sReason = UIUtil.isNullOrEmpty(sReason) ? "" : sReason;
			sApprovedDate = UIUtil.isNullOrEmpty(sApprovedDate) ? "" : sApprovedDate;
			sUser = UIUtil.isNullOrEmpty(sUser) ? "" : sUser;

			if (UIUtil.isNotNullAndNotEmpty(sStatus) && ("Retracted").equalsIgnoreCase(sStatus)) {
				sStatus = "Not Approved";
			}

			TreeMap<Date, Object> mpVerifyIdData = new TreeMap<>();
			SimpleDateFormat formatter = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);

			String attrDryRun = PropertyUtil.getSchemaProperty(context, "attribute_IMP_DryRun");

			DomainObject domSoC = DomainObject.newInstance(context, strSoCObjID);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_NAME);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainConstants.SELECT_ORIGINATED);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = "attribute[" + attrDryRun + "]!='Yes'";

			//Modified for SWIMP-322:Replaced relationship 'IMP_VerifyRun' with new 'relationship_IMP_VerifyRunForSoC'
			MapList mlVerification = domSoC.getRelatedObjects(context,
					relPattern.getPattern(), // relationship //Modified for SWIMP-31
					typePattern.getPattern(), // type pattern //Modified for SWIMP-31
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit


			if (!mlVerification.isEmpty()) {
				Iterator objectListItr = mlVerification.iterator();
				Map mVerifyID;
				Date date;
				String sOriginated;
				String sVerifyObjId;

				while (objectListItr.hasNext()) {
					mVerifyID = (Map) objectListItr.next();
					sVerifyObjId = (String) mVerifyID.get(DomainConstants.SELECT_ID);
					sOriginated = (String) mVerifyID.get(DomainConstants.SELECT_ORIGINATED);
					date = formatter.parse(sOriginated);
					mpVerifyIdData.put(date, sVerifyObjId);
				}
				String sLastVerifyObjId = (String) mpVerifyIdData.get(mpVerifyIdData.lastKey());
				List<String> lsLastVerifyRelId = getVerifyRunWMs(context, sLastVerifyObjId, sRevObjId); //Modified for SWIMP-31 (Phase-2)
				for (String sLastVerifyRelId : lsLastVerifyRelId) {
					if (UIUtil.isNotNullAndNotEmpty(sLastVerifyRelId)) {
						Map attrMap = new HashMap();
						//Modified for SWIMP-322: Starts
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS, sStatus);
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS, sReason);
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_APPROVED_DATE, sApprovedDate);
						//Modified for SWIMP-322: Ends

						DomainRelationship domVerifyRel = new DomainRelationship(sLastVerifyRelId);
						domVerifyRel.open(context);
						String sRelAppStatus = (String) (domVerifyRel.getAttributeMap(context)).get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
						//Updating Approver before other attributes to keep the approver for updating the history of the IP on verify Approval/Rejection/Retract
						if (!sRelAppStatus.equalsIgnoreCase(sStatus)) {
							domVerifyRel.setAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_APPROVER, sUser);//Added for SWIMP-500
							domVerifyRel.setAttributeValues(context, attrMap);
						}
						domVerifyRel.close(context);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception in IMP_IPVerification : updateVerifyRunAppInfo " + e);
		}
	}

	/**
	 * Gets the verify run revisions.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sVerifyObjId the verify object id
	 * @param sRevObjId the revision object id
	 * @return String
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public String getVerifyRunRevisions(Context context, String sVerifyObjId, String sRevObjId) throws Exception {
		String sVerifyRunRelId = "";
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerifyObjId);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = DomainConstants.SELECT_ID + "==" + sRevObjId;

			//Modified for SWIMP-322: Replaced old relationship 'IMP_VerifyRun' with new 'IMP_VerifyRunDetectedIPs'
			MapList mlRevList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Map mRev = (Map) mlRevList.get(0);
				sVerifyRunRelId = (String) mRev.get(DomainRelationship.SELECT_ID);
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification : getVerifyRunRevisions " + e);
		}
		return sVerifyRunRelId;
	}
	
	/**
	 * Gets the verify run revisions.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sVerifyObjId the verify object id
	 * @param sRevObjId the revision object id
	 * @return String
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings("unchecked")
	public List<String> getVerifyRunWMs(Context context, String sVerifyObjId, String sWMObjID) throws Exception {
		String sVerifyRunRelId = "";
		List<String> lsVerifyDetectedIPRelIDs = new ArrayList<>(); //Added for SWIMP-31 (Phase-2)
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerifyObjId);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = DomainConstants.SELECT_ID + "==" + sWMObjID;

			//Modified for SWIMP-322: Replaced old relationship 'IMP_VerifyRun' with new 'IMP_VerifyRunDetectedIPs'
			MapList mlWMList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlWMList.isEmpty()) {
				Iterator<Map<String, String>> itrWMList = mlWMList.iterator();
				while (itrWMList.hasNext()) {
					Map<String, String> mpVerifyDetectedIPs = itrWMList.next();
					sVerifyRunRelId = mpVerifyDetectedIPs.get(DomainRelationship.SELECT_ID);
					lsVerifyDetectedIPRelIDs.add(sVerifyRunRelId);
				}
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification : getVerifyRunRevisions " + e);
		}
		return lsVerifyDetectedIPRelIDs;
	}
	//Added for SWIMP-31 Start
	public StringList getIPRevision(Context context, String[] args) throws FrameworkException {
		StringList slIPRevision = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlVerifyRunObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrVerifyRunObjs = mlVerifyRunObjs.iterator();
			Map <String,String> mVerifyRun;
			String strVerifyRunObjectId;
			DomainObject domVerifyObj;
			while (itrVerifyRunObjs.hasNext()) {
				mVerifyRun = itrVerifyRunObjs.next();
				strVerifyRunObjectId = mVerifyRun.get(DomainConstants.SELECT_ID);
				domVerifyObj = DomainObject.newInstance(context, strVerifyRunObjectId);
				slIPRevision.add(domVerifyObj.getInfo(context, IMP_Constants_mxJPO.SELECT_IPRELEASE_FROM_VERIFYOBJECT));
			}
		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return slIPRevision;
	}


	/**
	 * This method gets the relationship id exists between given SoC Object and Revision Object
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param SoCObjId - HIP ObjectId, swatermarkobjectid
	 * @return String
	 * @throws Exception if the operations fails
	 */

	public static String getVerificationStatusForHIPApprovalStatus(MapList mlWMList, String sWMObjId,String strLineage) throws FrameworkException {
		String strVerificationStatusForHIPApprovalStatus = "";
		try {
			if (!mlWMList.isEmpty()) {
				Iterator <Map <String,String>> itrWMList = mlWMList.iterator();
				Map <String,String> mapWM;
				String sWMId;
				String strVerificationStatusForHIPAttrLineage;
				while (itrWMList.hasNext()) {
					mapWM = itrWMList.next();
					sWMId = mapWM.get(DomainConstants.SELECT_ID);
					strVerificationStatusForHIPAttrLineage = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
					if (UIUtil.isNotNullAndNotEmpty(strVerificationStatusForHIPAttrLineage) && sWMId.equalsIgnoreCase(sWMObjId)  && strVerificationStatusForHIPAttrLineage.equalsIgnoreCase(strLineage)) {
						strVerificationStatusForHIPApprovalStatus =  mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS);
						break;
					}
				}
			}

		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return strVerificationStatusForHIPApprovalStatus;
	}

	public StringList getLineage(Context context, String[] args) throws FrameworkException {
		StringList slLineage = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrWMObjs = mlWMObjs.iterator();
			Map <String,String> mapWM;
			String strLineage;
			while (itrWMObjs.hasNext()) {
				mapWM = itrWMObjs.next();
				strLineage = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
				slLineage.add(UIUtil.isNullOrEmpty(strLineage) ? "" : strLineage);
			}
		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return slLineage;
	}
	//Added for SWIMP-31 End



	//Added for SWIMP-531 : Starts
	/**
	 * This method is to get Declared Usage information
	 * Added for SWIMP-531
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args - holds Arguments passed
	 * @return StringList
	 * @throws FrameworkException, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public static StringList isDeclaredInIPRevision(Context context, String[] args) throws FrameworkException {
		StringList slIsDeclared = new StringList();
		try {
			Map<String, Object> programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Map<String, Object> paramMap = (Map<String, Object>) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			String sReportFormat = (String) paramMap.get(IMP_Constants_mxJPO.KEY_REPORTFORMAT);
			Iterator<Map <String, Object>> itrWMObjs = mlWMObjs.iterator();
			Map<String, Object> mapWM = new HashMap<>();
			Map <String,String> mapLP = new HashMap<>();
			String strReleaseId = "";
			String strBranchId = "";
			MapList mlLogicalProducts;
			Iterator<Map <String,String>> itrLogicalProducts;
			while (itrWMObjs.hasNext()) {
				boolean isDeclared = false;
				mapWM = itrWMObjs.next();
				//get the IP Revision, revision loading in the table and its branch compare against allConnectedLogicalProducts ids if matches send green else send red
				strReleaseId = (String)mapWM.get(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK) ;
				strBranchId = (String)mapWM.get(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_WATERMARK);
				mlLogicalProducts = (MapList)mapWM.get("allConnectedLogicalProducts");
				itrLogicalProducts = mlLogicalProducts.iterator();
				while (itrLogicalProducts.hasNext()) {
					mapLP = itrLogicalProducts.next();
					if(strReleaseId.equalsIgnoreCase(mapLP.get(DomainConstants.SELECT_ID)) || strBranchId.equalsIgnoreCase(mapLP.get(DomainConstants.SELECT_ID))) {
						isDeclared = true;
						break;
					}
				}

				if (UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
					slIsDeclared.add(isDeclared ? IMP_Constants_mxJPO.STR_YES : IMP_Constants_mxJPO.STR_NO);
				} else {
					slIsDeclared.add(isDeclared
							? "<img src='../common/images/iconBigDiamondGreenApprove.png' border='0'  align='middle'></img>"
									: "<img src='../common/images/iconActionDelete.png' border='0'  align='middle'></img>");
				}
			}
		} catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:isDeclaredInIPRevision: " + e.getMessage());
		}
		return slIsDeclared;
	}


	/**
	 * This method is to get Logical Products relationship / Subscriptions
	 * Added for SWIMP-531
	 *
	 * @param context, the Context
	 * @param strProjectID - holds Product Object ID
	 * @return MapList
	 * @throws FrameworkException, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public MapList getLogicalProducts(Context context, String strProjectID) throws FrameworkException {
		MapList mlFinalLPConnectedObjects = new MapList();
		try {
			Map<String, Object> mapProject = new HashMap<>();
			MapList mlBranchObjList;
			MapList mlRevList;
			MapList mlLPConnectedObjects;

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainConstants.SELECT_NAME);
			StringList slRelationshipSelects = new StringList();
			slRelationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			IMP_BlockIP_mxJPO classBlockIPObject = new IMP_BlockIP_mxJPO();

			if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(new DomainObject(strProjectID).getInfo(context, DomainConstants.SELECT_TYPE))){
				mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context, strProjectID);
				mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
			}else {
				mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context, strProjectID);
				mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
				//get LP of branch and Its revision
				DomainObject domIPObj = DomainObject.newInstance(context, strProjectID);
				mlBranchObjList = (MapList) domIPObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_BRANCH, // type pattern
						slObjectSelects, // Object selects
						slRelationshipSelects, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit

				Iterator<Map <String, Object>> objectBranchListItr = mlBranchObjList.iterator();
				Iterator<Map <String, Object>> objectRevisionListItr ;
				while (objectBranchListItr.hasNext()) {
					mapProject = objectBranchListItr.next();
					mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context,(String) mapProject.get(DomainConstants.SELECT_ID));
					mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);

					DomainObject domBranch = DomainObject.newInstance(context, (String) mapProject.get(DomainConstants.SELECT_ID));
					mlRevList = domBranch.getRelatedObjects(context,
							IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // relationship pattern
							IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
							slObjectSelects, // Object selects
							slRelationshipSelects, // relationship selects
							false, // from
							true, // to
							(short) 1, // expand level
							null, // object where//SWIMP-1
							null, // relationship where
							0); // limit

					objectRevisionListItr = mlRevList.iterator();
					while (objectRevisionListItr.hasNext()) {
						mapProject = objectRevisionListItr.next();
						mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context,(String) mapProject.get(DomainConstants.SELECT_ID));
						mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
					}

				}

			}
		}
		catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:getLogicalProducts: " + e.getMessage());
		}
		return mlFinalLPConnectedObjects;
	}
	//Added for SWIMP-531 : Ends



	//Added for SWIMP-576 : Starts
	/**
	 * This method is to connect AuditRecords and Update History of IP
	 * Added for SWIMP-576
	 *
	 * @param context, the Context
	 * @param domObj - DomainObject of IP/IPRelease
	 * @param strAuditRelationship - ConsumedRecord relationship name
	 * @param domAudit - DomainObject of Audit Records object
	 * @param strIPID - IP ID
	 * @param strOperation - CLI Operation
	 * @param sComment - History update comment
	 * @return Nothing
	 * @throws MatrixException, if operation fails
	 */
	private void connectAuditRecordsAndUpdateHistory(Context context, DomainObject domObj, String strAuditRelationship,
			DomainObject domAudit, String strIPorReleaseID, String strOperation, String sComment) throws MatrixException {
		String sContextUser = PersonUtil.getFullName(context);
		boolean isContextPushed = false;
		try {
			mqlHistoryOff(context, true);
			DomainRelationship.connect(context, domObj, strAuditRelationship, domAudit);
			mqlHistoryOff(context, false);
			sComment = sComment + "; by user: " + sContextUser;
			ContextUtil.pushContext(context, IMP_Constants_mxJPO.ADMINUSER_BCADMIN, "", IMP_Constants_mxJPO.PROD_VAULT);
			isContextPushed = true;
			MqlUtil.mqlCommand(context, IMP_Constants_mxJPO.MQLCOMMAND_ADDHISTORY, false, strIPorReleaseID, "CLI "+strOperation, sComment);
		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPVerification:connectAuditRecordsAndUpdateHistory: connect & update audit records and update history: \n\t"+me);
		} finally {
			if (isContextPushed) {
				ContextUtil.popContext(context);
			}
		}
	}



	/**
	 * This method is do mql history off/on
	 * Added for SWIMP-576
	 *
	 * @param context, the Context
	 * @param bHistoryOff - history to off/on as true or false
	 * @return Nothing
	 * @throws MatrixException, if operation fails
	 */
	private void mqlHistoryOff(Context context, boolean bHistoryOff) throws MatrixException {
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context, IMP_Constants_mxJPO.ADMINUSER_BCADMIN, "", IMP_Constants_mxJPO.PROD_VAULT);
			isContextPushed = true;
			if (bHistoryOff) {
				MqlUtil.mqlCommand(context, false, IMP_Constants_mxJPO.MQLCOMMAND_HISTORYOFF, false);
			} else {
				MqlUtil.mqlCommand(context, false, IMP_Constants_mxJPO.MQLCOMMAND_HISTORYON, false);
			}
		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPVerification:mqlHistoryOff: failed to history off/on:  \n\t"+me);
		} finally {
			if (isContextPushed) {
				ContextUtil.popContext(context);
			}
		}
	}
	//Added for SWIMP-576 : Ends
	
		@SuppressWarnings("unchecked")
	public void setDLCAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
		    StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);
			 String sVerifyid =  hmData.get("sVerifyid");
			 String iDCLCDLResult =  hmData.get("iDCLCDLResult");
			 String strDCLCDLOutput =  hmData.get("strDCLCDLOutput");
			 String iDCLOASResult =  hmData.get("iDCLOASResult");
			 String strDCLOASOutput =  hmData.get("strDCLOASOutput");
			 MapList mlIPObjectList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
				  null, false, slObjDetails);
				  if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				  Map mpAttrUpdate = new HashMap<>();
				  mpAttrUpdate.put("IMP_DLC_CDLReturnValue", iDCLCDLResult);
				  mpAttrUpdate.put("IMP_DLC_CDLOutput", strDCLCDLOutput);
				  mpAttrUpdate.put("IMP_DLC_OASISReturnValue", iDCLOASResult);
				  mpAttrUpdate.put("IMP_DLC_OASISOutput", strDCLOASOutput);
				  DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				  domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setDLCAttributesToVerifyid: " + e);
		}
	}




	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getDLCResultsOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_DLCCDLRETURN = "";
		String ATTRIBUTE_IMP_DLCCDLOUTPUT = "";
		String ATTRIBUTE_IMP_DLCOASISRETURN = "";
		String ATTRIBUTE_IMP_DLCOASISOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyID = "";
		
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
		while (itrVerifyObjects.hasNext()){
			StringBuilder strTableColBuilder = new StringBuilder();
			Map map = (Map) itrVerifyObjects.next();
			ATTRIBUTE_IMP_DLCCDLRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			ATTRIBUTE_IMP_DLCCDLOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			ATTRIBUTE_IMP_DLCOASISRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			ATTRIBUTE_IMP_DLCOASISOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			strVerifyID = (String) map.get(DomainConstants.SELECT_ID);


					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_DLCOASISRETURN)) {
						if(ATTRIBUTE_IMP_DLCOASISRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showDLCOutputForOasis('" + strVerifyID + "')\" href=\"\"; title=name>" + "Oasis" + "</a>");
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showDLCOutputForOasis('" + strVerifyID + "')\" href=\"\"; title=name>" + "Oasis" + "</a>");
						}
						strTableColBuilder.append("<input type=\"hidden\" name=\"Outputvalue\" id="+strVerifyID+" value='<div> "+ATTRIBUTE_IMP_DLCOASISOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showDLCOutputForOasis(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementById(VerifyID).value");
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("");
					}

					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_DLCCDLRETURN)) {
						strTableColBuilder.append(" | ");
						if(ATTRIBUTE_IMP_DLCCDLRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showDLCOutputForCDL('" + strVerifyID + "')\" href=\"\"; title=name>" + "CDL" + "</a>");
					
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showDLCOutputForCDL('" + strVerifyID + "')\" href=\"\"; title=name>" + "CDL" + "</a>");
						

						}
						strTableColBuilder.append("<input type=\"hidden\" name="+strVerifyID+" value='<div> "+ATTRIBUTE_IMP_DLCCDLOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showDLCOutputForCDL(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementsByName(VerifyID)[0].value");
						
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
				
						
					}else{
						strTableColBuilder.append("");
					}



			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getDLCResultsOutput " + e);
		}
		return returnVector;
	}
	
	
	@SuppressWarnings("unchecked")
	public void setLLCAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
		    StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);
			 String sVerifyid =  hmData.get("sVerifyid");
			 String iLLCOASResult =  hmData.get("iLLCOASResult");
			 String strLLCOASOutput =  hmData.get("strLLCOASOutput");;
			 MapList mlIPObjectList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
				  null, false, slObjDetails);
				  if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				  Map mpAttrUpdate = new HashMap<>();
				  mpAttrUpdate.put("IMP_LLC_OASISReturnValue", iLLCOASResult);
				  mpAttrUpdate.put("IMP_LLC_OASISOutput", strLLCOASOutput);
				  DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				  domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setLLCAttributesToVerifyid: " + e);
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getLLCResultsOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_LLCOASISRETURN = "";
		String ATTRIBUTE_IMP_LLCOASISOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyID = "";
		
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
		while (itrVerifyObjects.hasNext()){
			StringBuilder strTableColBuilder = new StringBuilder();
			Map map = (Map) itrVerifyObjects.next();
			ATTRIBUTE_IMP_LLCOASISRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			ATTRIBUTE_IMP_LLCOASISOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_LLCOASISRETURN)) {
						if(ATTRIBUTE_IMP_LLCOASISRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showLLCOutputForOasis('" + strVerifyID +"_strLlcResults" + "')\" href=\"\"; title=name>" + "Passed" + "</a>");
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showLLCOutputForOasis('" + strVerifyID +"_strLlcResults"+ "')\" href=\"\"; title=name>" + "Failed" + "</a>");
						}
						strTableColBuilder.append("<input type=\"hidden\" name=\"Outputvalue\" id="+strVerifyID+"_strLlcResults"+" value='<div> "+ATTRIBUTE_IMP_LLCOASISOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showLLCOutputForOasis(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementById(VerifyID).value");
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("");
					}
			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getLLCResultsOutput " + e);
		}
		return returnVector;
	}
	

	@SuppressWarnings("unchecked")
	public void setIpScoreAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
			StringList slObjDetails = new StringList();
			StringBuilder ipBuild = new StringBuilder();
			slObjDetails.add(DomainConstants.SELECT_ID);
			String sVerifyid =  hmData.get("sVerifyid");
			String sIpScoreOutput =  hmData.get("mIpScoreOutput");

			MapList mlIPObjectList = DomainObject.findObjects(context,
			IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
			null, false, slObjDetails);
			if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				Map mpAttrUpdate = new HashMap<>();
				mpAttrUpdate.put("IMP_IpScoreOutput", sIpScoreOutput);
				DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setIpScoreAttributesToVerifyid: " + e);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getIpScoreOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_IPSCOREOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyName = "";
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
			while (itrVerifyObjects.hasNext()){
				StringBuilder strTableColBuilder = new StringBuilder();
				StringBuilder strTableRowBuilder = new StringBuilder();
				Map map = (Map) itrVerifyObjects.next();
				ATTRIBUTE_IMP_IPSCOREOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
				strVerifyName = (String) map.get(DomainConstants.SELECT_NAME);
				if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_IPSCOREOUTPUT)) {
					if (ATTRIBUTE_IMP_IPSCOREOUTPUT.contains("<br>")) {
						String lines[] = ATTRIBUTE_IMP_IPSCOREOUTPUT.split("<br>");
						for (String line: lines) {
							String sVendor = "";
							String ipProductName = "";
							if (line.contains(":")) {
								ipProductName = line.substring(0,line.indexOf(":"));
								sVendor = line.substring(line.indexOf(":")+1);
								strTableRowBuilder.append(ipProductName+"<span>&emsp; &emsp; &emsp; &emsp; &emsp; </span>"+sVendor+"<br>");
							}else{
								strTableRowBuilder.append(line+"<br>");
							}
						}
						ATTRIBUTE_IMP_IPSCOREOUTPUT = strTableRowBuilder.toString();
					}
					
					strTableColBuilder.append("<a style=color:red; onClick=showIPScoreOutput('" + strVerifyName+"_strKeyUnknow3PIPs" + "') title=IPS> Yes </a>");
					strTableColBuilder.append("<input type=hidden name=strOutputvalue id="+strVerifyName+"_strKeyUnknow3PIPs"+" value='<div> "+ATTRIBUTE_IMP_IPSCOREOUTPUT+" </div>'>");
					strTableColBuilder.append("<script>");
					strTableColBuilder.append("function showIPScoreOutput(VerifyobjID) { ");
					strTableColBuilder.append("var y = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
					strTableColBuilder.append("y.document.write('<div id=Unknow3PIPs> </div>');");
					strTableColBuilder.append("y.document.getElementById(\"Unknow3PIPs\").innerHTML = \"IP Name <span> &emsp; &emsp; &emsp; &emsp;&emsp; &emsp;&emsp; &emsp;&emsp; &emsp;&emsp; &emsp; </span>Vendor Name <br>\" + document.getElementById(VerifyobjID).value");
					strTableColBuilder.append("}");
					strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("<h4 style=color:green; title=name> No </h4>");
						}
				returnVector.add(strTableColBuilder.toString());
				strTableColBuilder.setLength(0);
				strTableRowBuilder.setLength(0);
			}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getIpScoreOutput " + e);
		}
		return returnVector;
	}
	
	@SuppressWarnings("unchecked")
	public static String getVerifyIPLogsForEPSWithVerifyid(Context context, String args[]) throws Exception {
		System.out.println("**** services has invoked getVerifyIPLogsForEPSWithVerifyid **** ");
		MapList mlIPVerifications = new MapList();
		String verifyIPLogs = "";
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
			String sVerifyid =  hmData.get("sVerifyid");
			System.out.println("*** sVerifyid  - "+sVerifyid);
			StringList slObjDetails = new StringList();
		    slObjDetails.add("attribute[IMP_VerifyIP_LogsForEPS]");

		    mlIPVerifications = DomainObject.findObjects(context,
					  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
					  null, false, slObjDetails);
				     
		    for (Object obj : mlIPVerifications) {
				HashMap mapIPVerifyObj = (HashMap) obj;
				verifyIPLogs = (String) mapIPVerifyObj.get("attribute[IMP_VerifyIP_LogsForEPS]");
		    }
		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:getVerifyIPLogsForEPSWithVerifyid: " + e);
		}
		
		return verifyIPLogs;
	}
	
	@SuppressWarnings("unchecked")
	public static void setVerifyIPLogsToVerifyid(Context context, String sVerifyid, String sVerifyIPLogs) throws Exception {
		MapList mlIPVerifications = new MapList();
		try {
			System.out.println("===== setVerifyIPLogsToVerifyid =====");
			StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);

		    mlIPVerifications = DomainObject.findObjects(context,
					  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
					  null, false, slObjDetails);
		    if (mlIPVerifications != null && !mlIPVerifications.isEmpty()) {
		    	System.out.println("==MapList is not empty====");
		    }
			for (Object obj : mlIPVerifications) {
				HashMap mapIPVerifyObj = (HashMap) obj;
				String objectId = (String) mapIPVerifyObj.get(DomainObject.SELECT_ID);
				System.out.println("==== found object id - "+objectId);
				Map mpAttrUpdate = new HashMap<>();
				mpAttrUpdate.put("IMP_VerifyIP_LogsForEPS", sVerifyIPLogs);
				DomainObject domVerifyRun = new DomainObject(objectId);
				domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}
			System.out.println("==== after updating verifyLogs in DB === ");
		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setVerifyIPLogsToVerifyid: " + e);
		}
	}
	
	public static void test(Context context, String []arg) {
		try {
			//25664.47740.61850.7650
			
		}catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	
	//Added for SWIMP-882:START
	public static Map checkinSSGQICfgYamlToIMP(Context context, String args[]) throws Exception {
	// DO NOT REMOVE ANY SYSOUTS FROM THIS METHOD, THIS IS TO CHECK THE FAILURE -- SWIMP-882
	boolean error = false;
	System.out.println("-- START -- SSGQI YAML CONFIGURATION FILE CHECKIN --");
	Map mpReturnMap = new HashMap();
	StringList objectSelects = new StringList();
    objectSelects.add(DomainConstants.SELECT_ID);
    objectSelects.add(DomainConstants.SELECT_ORIGINATOR);
    
    String sIPType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
    
    //String sTypePattern = PropertyUtil.getSchemaProperty(context, "type_IMP_IP_SSGQI_CONFIG");
    //String sRelPattern = PropertyUtil.getSchemaProperty(context, "relationship_IMP_SSGQIConfigforIP");
    String sPolicy = PropertyUtil.getSchemaProperty(context, "policy_IMP_IP_SSGQI_CONFIG");
    String sVault = PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction");
    
    String sStatus = "";
    String sSSGQIObjId = "";
    
    String sNewSSGQIName = "";
    String sMqlCmd = "print bus $1 $2 $3 select $4 dump";
    
	try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
		    String sIPName = (String) programMap.get("sIPName");
		    System.out.println("-- sIPName --: " + sIPName);
		    String sUser = (String) programMap.get("sUser");
		    System.out.println("-- sUser --: " + sUser);
		    String sTag = (String) programMap.get("sTag");
		    System.out.println("-- sTag --: " + sTag);
		    String sSSGQICfgFile = (String) programMap.get("sSSGQICfgFile");
		    System.out.println("-- sSSGQICfgFile --: " + sSSGQICfgFile);
		    String sSSGQICfgPath = (String) programMap.get("sSSGQICfgPath");
		    System.out.println("-- sSSGQICfgPath --: " + sSSGQICfgPath);
		    MapList mpIPIDList = DomainObject.findObjects(context, sIPType, sIPName, "A", "*", "*", null, false, objectSelects);
		    System.out.println("-- mpIPIDList --: \n" + mpIPIDList);
		    if (!mpIPIDList.isEmpty() && mpIPIDList.size() != 0) {
		    Map mapIPID = (Map) mpIPIDList.get(0);
		    System.out.println("-- mapIPID --: \n" + mapIPID);
		    String strIPID = (String) mapIPID.get(DomainConstants.SELECT_ID);
		    System.out.println("-- strIPID --: \n" + strIPID);  
		    try {
		    //sSSGQIObjId = FrameworkUtil.autoName(context, sTypePattern, "", sPolicy, sVault);
		    sNewSSGQIName = DomainObject.getAutoGeneratedName(context, "type_IMP_IP_SSGQI_CONFIG", "");
		    DomainObject domObject = DomainObject.newInstance(context);
		    domObject.createObject(context, "IMP_IP_SSGQI_CONFIG", sNewSSGQIName, "-", sPolicy, sVault);
		    
		    System.out.println("-- sSSGQIObjId---AUTONAME--GENERATED --: \n" + sNewSSGQIName);
		    
		    DomainObject domIPObj = DomainObject.newInstance(context, strIPID);
		    DomainRelationship.connect(context, domIPObj, "IMP_SSGQIConfigforIP", domObject);
		    System.out.println("-- strIPID --:"+strIPID+" -- CONNECTED TO -- sSSGQIObjId --:"+sNewSSGQIName+"  -- WITH REL -- :IMP_SSGQIConfigforIP");
		    ContextUtil.commitTransaction(context);
		    } catch (Exception e) {
				ContextUtil.abortTransaction(context);
				logger.error("Exception while saving "+sSSGQICfgFile+"  in IMP");
				e.getMessage();
			}
		    
		    System.out.println("-- FTP WORKING DIR --: " + sSSGQICfgPath);
		    File file = new File(sSSGQICfgPath);
		    if (file.isDirectory() && file.listFiles() != null) {
	            File[] files = file.listFiles();
	            sStatus = "Failure";
	            for (int i = 0; i < files.length; i++) {
	              String strPath = "";
	              if (files[i].isFile()) {
	                strPath = sSSGQICfgPath + files[i].getName();
	                System.out.println("-- strPath --: " + strPath);
	                String sFileName = files[i].getName();
	                System.out.println("-- sFileName --: " + sFileName);
	                if(sFileName.equals(sSSGQICfgFile)) {
	                	System.out.println("-- "+ sSSGQICfgPath +" FILE EXISTS AND MATCHES: " + file.exists());
	                	
	                	try {
	                	String sSSGQIID = MqlUtil.mqlCommand(context, sMqlCmd, "IMP_IP_SSGQI_CONFIG", sNewSSGQIName, "-", "id");
	                	System.out.println("-- sSSGQIID --: " + sSSGQIID);
	                	if (UIUtil.isNotNullAndNotEmpty(sSSGQIID)) {
	                    String sMqlCommand = "checkin bus $1 $2 format $3 append $4";
	                	MqlUtil.mqlCommand(context, sMqlCommand, sSSGQIID, "unlock", "yaml", sSSGQICfgPath+java.io.File.separatorChar+sSSGQICfgFile);
	                    System.out.println("-- SSGQI CHECKIN COMMAND EXECUTED SUCCESSFULLY FOR OBJ --: "+sSSGQIID);
	                    ContextUtil.commitTransaction(context);
	                    sStatus = "Success";
	                	}} catch (Exception e) {
	        				ContextUtil.abortTransaction(context);
	        				logger.error("Exception while checkin "+sSSGQICfgFile+" from  :"+strPath+"  in IMP");
	        				e.getMessage();
	                	}
	                  break;	
	                }
	            }
	         }
		  }
	   } 
	   mpReturnMap.put(sSSGQIStatus, sStatus);
	   mpReturnMap.put(sSSGQFileName, sSSGQICfgFile);
	} catch (Exception ex) {
		ex.printStackTrace();
    }
	return mpReturnMap;
	//Added for SWIMP-882:ENDED
  }
@SuppressWarnings("unchecked")
	public void setTsrToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
		    StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);
			 String sVerifyid =  hmData.get("sVerifyid");
			 String TsrYamlResult =  hmData.get("sStrYamlfile");
			 String TsrFileName =  hmData.get("sTsrFileName");
			 MapList mlIPObjectList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
				  null, false, slObjDetails);
				  if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				  Map mpAttrUpdate = new HashMap<>();
				  mpAttrUpdate.put("IMP_Tsr_YamlValue", TsrYamlResult);
				  mpAttrUpdate.put("IMP_Tsr_FileName", TsrFileName);
				  DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				  domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setTsrToVerifyid: " + e);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
    public static Vector getTsrToVerifyid(Context context, String args[]) throws Exception {
    String ATTRIBUTE_IMP_TSRYAMLFILE = "";
    String ATTRIBUTE_IMP_TSRFileName = "";
    Vector returnVector = new Vector();
    String strVerifyID = "";

    HashMap programMap = JPO.unpackArgs(args);
    MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);

    Iterator itrVerifyObjects = verifyMapList.iterator();

    boolean scriptAdded = false;

    try {
        while (itrVerifyObjects.hasNext()) {
            StringBuilder strTableColBuilder = new StringBuilder();
            Map map = (Map) itrVerifyObjects.next();

            ATTRIBUTE_IMP_TSRYAMLFILE = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TSRYAMLFILE);
            ATTRIBUTE_IMP_TSRFileName = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_Tsr_FileName);
            strVerifyID = (String) map.get(DomainConstants.SELECT_ID);

            // --- NEW: show only the filename (not full path) ---
            String displayFileName = ATTRIBUTE_IMP_TSRFileName;
            if (displayFileName != null) {
                int cut = Math.max(displayFileName.lastIndexOf('/'), displayFileName.lastIndexOf('\\'));
                if (cut >= 0 && cut + 1 < displayFileName.length()) {
                    displayFileName = displayFileName.substring(cut + 1);
                }
            } else {
                displayFileName = "";
            }
            // ---------------------------------------------------

            if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_TSRYAMLFILE)
                    && !ATTRIBUTE_IMP_TSRYAMLFILE.equalsIgnoreCase("No_YamlFile")) {

                String elemId = strVerifyID + "_strYamlFile";

                // Safety: avoid closing the textarea accidentally
                String yamlSafe = ATTRIBUTE_IMP_TSRYAMLFILE;
                if (yamlSafe != null) {
                    yamlSafe = yamlSafe.replace("</textarea>", "<\\/textarea>");
                } else {
                    yamlSafe = "";
                }

                strTableColBuilder
                    .append("<a href=\"javascript:void(0)\" style=\"color:green\" ")
                    .append("onclick=\"showStrYamlFile('").append(elemId).append("');return false;\" ")
                    .append(">")
                    .append(displayFileName)          // <-- use just the filename as link text
                    .append("</a>");

                strTableColBuilder
                    .append("<textarea style=\"display:none\" id=\"").append(elemId).append("\">")
                    .append(yamlSafe)
                    .append("</textarea>");

                if (!scriptAdded) {
                    strTableColBuilder.append("<script>")
                        .append("function showStrYamlFile(id){")
                        .append("var w=window.open('','popUpWindow','height=500,width=700,left=100,top=100,scrollbars=yes,resizable=yes');")
                        .append("if(!w){return;}")
                        .append("var el=document.getElementById(id);")
                        .append("var txt=(el && el.value) ? el.value : '';")
                        .append("w.document.open();")
                        .append("w.document.write('<!doctype html><html><head><title>YAML</title></head><body><pre id=\"out\" style=\"white-space:pre-wrap;\"></pre></body></html>');")
                        .append("w.document.close();")
                        .append("w.document.getElementById('out').textContent=txt;")
                        .append("}")
                        .append("</script>");
                    scriptAdded = true;
                }

            } else {
                strTableColBuilder.append("-");
            }

            returnVector.add(strTableColBuilder.toString());
            strTableColBuilder.setLength(0);
        }
    } catch (Exception e) {
        throw e;
    }

    return returnVector;
}
	
//Added for SWIMP-883: Start


@SuppressWarnings({ "rawtypes", "unchecked" })
public static Map checkoutSSGQICfgYamlFromIMP(Context context, String[] args) throws Exception {

    final String K_STATUS = "ssgqiCfgStatus";
    final String K_MSG = "message";
    final String K_DIR = "ssgqiCfgCheckoutDir";
    final String K_FILE = "ssgqiCfgFileName";
    final String K_FALLBACK = "ssgqiCfgFallbackUsed";

    final String ST_SUCCESS = "Success";
    final String ST_NOT_FOUND = "NOT_FOUND";
    final String ST_AMBIGUOUS = "AMBIGUOUS";
    final String ST_ERROR = "ERROR";

    Map mpReturnMap = new HashMap();

    try {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);

        String ipObjectId = (String) programMap.get("ipObjectId");
        String cfgFileName = (String) programMap.get("cfgFileName");

        if (StringUtils.isBlank(ipObjectId)) throw new Exception("ipObjectId is null/empty");
        if (StringUtils.isBlank(cfgFileName)) throw new Exception("cfgFileName is null/empty");

        DomainObject ipObj = new DomainObject(ipObjectId);
        String ipName = ipObj.getInfo(context, DomainConstants.SELECT_NAME);

        // Normalize if caller passed "null-..."
        String targetFileName = cfgFileName.trim();
        if (targetFileName.startsWith("null-")) {
            targetFileName = ipName + "-" + targetFileName.substring("null-".length());
        }

        // allow .yaml vs .yml (compute once)
        final String targetYml = targetFileName.endsWith(".yaml")
                ? targetFileName.substring(0, targetFileName.length() - 5) + ".yml"
                : targetFileName;

        String relSSGQIForIP = PropertyUtil.getSchemaProperty(context, "relationship_IMP_PrivateDocuments");
        String typeSSGQI = PropertyUtil.getSchemaProperty(context, "type_IMP_IP_SSGQI_CFG");

        StringList objectSelects = new StringList();
        objectSelects.add(DomainConstants.SELECT_ID);
        objectSelects.add(DomainConstants.SELECT_NAME);
        objectSelects.add(DomainConstants.SELECT_TYPE);

        StringList relSelects = new StringList();
        relSelects.add(DomainRelationship.SELECT_ID);

        // Single direction only (removed second call per your observation/logs)
        MapList connectedObjects = ipObj.getRelatedObjects(
                context,
                relSSGQIForIP,
                typeSSGQI,
                objectSelects,
                relSelects,
                false,  // getTo
                true,   // getFrom
                (short) 1,
                null,
                null,
                0
        );


        int count = (connectedObjects == null) ? 0 : connectedObjects.size();
        System.out.println("SWIMP-883: connectedObjects(getTo=false,getFrom=true,level=1) count=" + count
                + " ip=" + ipName + " ipObjectId=" + ipObjectId);

        if (connectedObjects == null || connectedObjects.isEmpty()) {
            mpReturnMap.put(K_STATUS, ST_NOT_FOUND);
            mpReturnMap.put(K_MSG, "No related SSGQI config object for IP " + ipName);
            return mpReturnMap;
        }

        DomainObject exactObj = null;
        String exactFile = null;
        String exactFormat = null;

        DomainObject soleObj = null;
        String soleFile = null;
        String soleFormat = null;
        int attachmentCount = 0;

        // Search attachments across all connected objects
        for (int i = 0; i < connectedObjects.size() && exactObj == null; i++) {
            Map objMap = (Map) connectedObjects.get(i);
            String objId = (String) objMap.get(DomainConstants.SELECT_ID);
            DomainObject tmpObj = new DomainObject(objId);

            StringList yamlFiles = tmpObj.getInfoList(context, "format[yaml].file.name");
            if (yamlFiles == null) yamlFiles = new StringList();

            StringList ymlFiles = tmpObj.getInfoList(context, "format[yml].file.name");
            if (ymlFiles == null) ymlFiles = new StringList();

            // Scan YAML files
            for (int j = 0; j < yamlFiles.size(); j++) {
                String f = String.valueOf(yamlFiles.get(j)).trim();
                if (f.isEmpty()) continue;

                if (f.equals(targetFileName)) {
                    exactObj = tmpObj; exactFile = f; exactFormat = "yaml";
                    break;
                }

                attachmentCount++;
                if (attachmentCount == 1) { soleObj = tmpObj; soleFile = f; soleFormat = "yaml"; }
                else { soleObj = null; soleFile = null; soleFormat = null; }
            }

            // Scan YML files
            for (int j = 0; j < ymlFiles.size() && exactObj == null; j++) {
                String f = String.valueOf(ymlFiles.get(j)).trim();
                if (f.isEmpty()) continue;

                if (f.equals(targetFileName) || f.equals(targetYml)) {
                    exactObj = tmpObj; exactFile = f; exactFormat = "yml";
                    break;
                }

                attachmentCount++;
                if (attachmentCount == 1) { soleObj = tmpObj; soleFile = f; soleFormat = "yml"; }
                else { soleObj = null; soleFile = null; soleFormat = null; }
            }
        }

        DomainObject ssgqiObj;
        String foundFileName;
        String foundFormat;
        boolean fallbackUsed = false;

        if (exactObj != null) {
            ssgqiObj = exactObj;
            foundFileName = exactFile;
            foundFormat = exactFormat;
        } else if (attachmentCount == 1 && soleObj != null && StringUtils.isNotBlank(soleFile)) {
            ssgqiObj = soleObj;
            foundFileName = soleFile;
            foundFormat = soleFormat;
            fallbackUsed = true;
        } else if (attachmentCount > 1) {
            mpReturnMap.put(K_STATUS, ST_AMBIGUOUS);
            mpReturnMap.put(K_MSG, "Multiple YAML/YML attachments; cannot choose safely. Requested=" + targetFileName);
            return mpReturnMap;
        } else {
            mpReturnMap.put(K_STATUS, ST_NOT_FOUND);
            mpReturnMap.put(K_MSG, "No YAML/YML attachment found. Requested=" + targetFileName);
            return mpReturnMap;
        }

        // Checkout into IMP server working dir (SFTP-visible) like SWIMP-882
        String workingDir = System.getProperty("imp.cli.server.working.dir", "/projects/imp/tmp");
        String ssgqiFolder = System.getProperty("imp.cli.ssgqi.temp.cfg.folder", "ssgqi");

        String checkoutDir =
                workingDir + File.separator
                        + ssgqiFolder + File.separator
                        + "imp-ssgqi-cfg-checkout" + File.separator
                        + UUID.randomUUID().toString() + File.separator;

        File dir = new File(checkoutDir);
        if (!dir.exists() && !dir.mkdirs()) {
            mpReturnMap.put(K_STATUS, ST_ERROR);
            mpReturnMap.put(K_MSG, "Failed to create checkout dir: " + checkoutDir);
            return mpReturnMap;
        }

        try {
            ContextUtil.startTransaction(context, true);

            MqlUtil.mqlCommand(
                    context,
                    "checkout bus $1 server format $2 file $3 $4",
                    ssgqiObj.getObjectId(),
                    foundFormat,
                    foundFileName,
                    checkoutDir
            );

            ContextUtil.commitTransaction(context);

            mpReturnMap.put(K_STATUS, ST_SUCCESS);
            mpReturnMap.put(K_DIR, checkoutDir);
            mpReturnMap.put(K_FILE, foundFileName);
            mpReturnMap.put(K_FALLBACK, String.valueOf(fallbackUsed));
            mpReturnMap.put(K_MSG, fallbackUsed
                    ? ("Exact filename not found; checked out single available file: " + foundFileName)
                    : ("Checked out file: " + foundFileName));

            return mpReturnMap;

        } catch (Exception e) {
            ContextUtil.abortTransaction(context);
            mpReturnMap.put(K_STATUS, ST_ERROR);
            mpReturnMap.put(K_MSG, "Checkout failed: " + e.getMessage());
            throw e;
        }

    } catch (Exception e) {
        mpReturnMap.put(K_STATUS, ST_ERROR);
        mpReturnMap.put(K_MSG, String.valueOf(e.getMessage()));
        return mpReturnMap;
    }
}

@SuppressWarnings("unchecked")
public void setSSGQIAttributesToVerifyid(Context context, String[] args) throws Exception {
    Map<String, String> hmData = JPO.unpackArgs(args);
    
    StringList slObjDetails = new StringList();
    slObjDetails.add(DomainConstants.SELECT_ID);
    
    String sVerifyid = hmData.get("sVerifyid");
    String iSSGQIResult = hmData.get("iSSGQIResult");
    String strSSGQIOutput = hmData.get("strSSGQIOutput");
    String strSSGQIReportPath = hmData.get("strSSGQIReportPath");
    String strSSGQIReportServerPath = hmData.get("strSSGQIReportServerPath");
    
    MapList mlIPObjectList = DomainObject.findObjects(context,
            IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
            null, false, slObjDetails);
    
    if (!mlIPObjectList.isEmpty()) {
        Iterator<Map<String, String>> itrVerifyRunList = mlIPObjectList.iterator();
        Map<String, String> mapVerifyRun;
        String strVerifyRunId = "";
        while (itrVerifyRunList.hasNext()) {
            mapVerifyRun = itrVerifyRunList.next();
            strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
        }
        
        Map mpAttrUpdate = new HashMap<>();
        mpAttrUpdate.put("IMP_SSGQI_ReturnValue", iSSGQIResult);
        mpAttrUpdate.put("IMP_SSGQI_Output", strSSGQIOutput);
        mpAttrUpdate.put("IMP_SSGQI_ReportPath", strSSGQIReportPath);
        mpAttrUpdate.put("IMP_SSGQI_ServerReportPath", strSSGQIReportServerPath);
        
        DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
        domVerifyRun.setAttributeValues(context, mpAttrUpdate);
        
        // NEW: Copy file to permanent location on server if path is provided
        if (StringUtils.isNotBlank(strSSGQIReportServerPath)) {
            try {
                String serverDestDir = "/tmp/SSGQI_results/";
                File destDir = new File(serverDestDir);
                if (!destDir.exists()) {
                    destDir.mkdirs();
                }
                
                String fileName = new File(strSSGQIReportServerPath).getName();
                String destPath = serverDestDir + fileName;
                
                // Use MQL or Java file operations to copy
                // This depends on your server environment
                java.nio.file.Files.copy(
                    java.nio.file.Paths.get(strSSGQIReportServerPath),
                    java.nio.file.Paths.get(destPath),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING
                );
                
                System.out.println("SSGQI report copied to server: " + destPath);
            } catch (Exception e) {
                System.out.println("Failed to copy SSGQI report to server: " + e.getMessage());
            }
        }
    }
}

@SuppressWarnings({ "unchecked", "rawtypes" })
public static Vector getSSGQIResultsOutput(Context context, String args[]) throws Exception {

    Vector returnVector = new Vector();

    HashMap programMap = JPO.unpackArgs(args);
    MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
    Iterator itrVerifyObjects = (verifyMapList == null) ? null : verifyMapList.iterator();

    boolean scriptAdded = false; // add popup JS only once

    try {
        while (itrVerifyObjects != null && itrVerifyObjects.hasNext()) {

            StringBuilder cell = new StringBuilder(768);
            Map map = (Map) itrVerifyObjects.next();

            String strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
            if (UIUtil.isNullOrEmpty(strVerifyID)) strVerifyID = (String) map.get("id");

            String ssgqiReturn = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);
            String ssgqiOutput = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);

            // Fallback DB read (trigger on NULL OR EMPTY) - ONLY 2 attributes
            if (UIUtil.isNotNullAndNotEmpty(strVerifyID)
                    && (UIUtil.isNullOrEmpty(ssgqiReturn) || UIUtil.isNullOrEmpty(ssgqiOutput))) {

                DomainObject dObj = new DomainObject(strVerifyID);

                StringList sels = new StringList(2);
                sels.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);
                sels.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);

                Map info = dObj.getInfo(context, sels);

                if (UIUtil.isNullOrEmpty(ssgqiReturn)) {
                    ssgqiReturn = (String) info.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);
                }
                if (UIUtil.isNullOrEmpty(ssgqiOutput)) {
                    ssgqiOutput = (String) info.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);
                }
            }

            if (UIUtil.isNullOrEmpty(ssgqiReturn)) {
                returnVector.add("");
                continue;
            }

            boolean isPass = "pass".equalsIgnoreCase(ssgqiReturn);
            String popupId = strVerifyID + "_strSsgqiResults";

            String out = (ssgqiOutput == null) ? "" : ssgqiOutput;
            if (UIUtil.isNullOrEmpty(out)) {
                out = isPass ? "SSGQI passed." : "SSGQI failed. No output available.";
            }

            // Show report base name if present; else Passed/Failed
            String reportBaseName = extractSsgqiReportBaseName(out);
            String linkText = UIUtil.isNotNullAndNotEmpty(reportBaseName)
                    ? reportBaseName
                    : (isPass ? "Passed" : "Failed");

            // Correct HTML escaping for link text
            linkText = linkText.replace("&", "&amp;")
                               .replace("<", "&lt;")
                               .replace(">", "&gt;")
                               .replace("\"", "&quot;")
                               .replace("'", "&#39;");

            // Add popup function once per table render
            if (!scriptAdded) {
                cell.append("<script>");
                cell.append("window.showSSGQIOutput=window.showSSGQIOutput||function(VerifyID){");
                cell.append("var x=window.open('','popUpWindow','height=500,width=600,left=100,top=100');");
                cell.append("x.document.open();");
                cell.append("x.document.write('<div id=\"div\"></div>');");
                cell.append("x.document.close();");
                cell.append("x.document.getElementById('div').innerHTML=document.getElementById(VerifyID).value;");
                cell.append("};");
                cell.append("</script>");
                scriptAdded = true;
            }

            cell.append("<a style=\"color:")
                .append(isPass ? "green" : "red")
                .append(";\" onClick=\"showSSGQIOutput('")
                .append(popupId)
                .append("'); return false;\" href=\"#\" title=\"SSGQI Output\">")
                .append(linkText)
                .append("</a>");

            // Only escape what breaks value='...'
            String outForAttr = out.replace("'", "&#39;");

            cell.append("<input type=\"hidden\" name=\"Outputvalue\" id=\"")
                .append(popupId)
                .append("\" value='<div>")
                .append(outForAttr)
                .append("</div>'>");

            returnVector.add(cell.toString());
        }

    } catch (Exception e) {
        throw new Exception("Exception occured in IMP_IPVerification:getSSGQIResultsOutput", e);
    }

    return returnVector;
}

/**
 * Returns report filename WITHOUT .xls/.xlsx, or null if not found.
 * Handles cases like:
 *  - "Report generated: /tmp/name.xlsx"
 *  - "Report copied to server:\n/projects/.../name.xlsx"
 * Works even if output contains <br> and simple HTML tags.
 */
private static String extractSsgqiReportBaseName(String out) {
    if (out == null) return null;

    // 1) Normalize breaks/entities for parsing
    String s = out;
    s = s.replace("<br />", "\n").replace("<br/>", "\n").replace("<br>", "\n");
    s = s.replace("&nbsp;", " ");
    if (s.indexOf("&amp;") >= 0) s = s.replace("&amp;", "&");

    // 2) Strip simple HTML tags only if needed
    if (s.indexOf('<') >= 0) {
        StringBuilder plain = new StringBuilder(s.length());
        boolean inTag = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '<') { inTag = true; continue; }
            if (c == '>') { inTag = false; continue; }
            if (!inTag) plain.append(c);
        }
        s = plain.toString();
    }

    String lower = s.toLowerCase();

    // Prefer "Report generated" over "Report copied" (matches what users expect)
    String[] keys = new String[] { "Report generated:", "Report copied to server:" };

    for (int k = 0; k < keys.length; k++) {
        String key = keys[k];
        String keyLower = key.toLowerCase();

        int idx = lower.indexOf(keyLower);
        while (idx >= 0) {

            int start = idx + key.length();

            // Skip spaces/tabs
            while (start < s.length()) {
                char c = s.charAt(start);
                if (c == ' ' || c == '\t') start++;
                else break;
            }

            // If immediate newline, take next non-empty line
            if (start < s.length() && (s.charAt(start) == '\n' || s.charAt(start) == '\r')) {
                // consume newline(s)
                while (start < s.length() && (s.charAt(start) == '\n' || s.charAt(start) == '\r')) start++;
                // skip empty lines
                int scan = start;
                while (scan < s.length()) {
                    // end of line
                    int eol = s.indexOf('\n', scan);
                    int cr = s.indexOf('\r', scan);
                    if (eol < 0 || (cr >= 0 && cr < eol)) eol = cr;
                    if (eol < 0) eol = s.length();

                    String line = s.substring(scan, eol).trim();
                    if (line.length() != 0) { start = scan; break; }

                    // advance to next line
                    scan = eol;
                    while (scan < s.length() && (s.charAt(scan) == '\n' || s.charAt(scan) == '\r')) scan++;
                    start = scan;
                }
            }

            // End at line break
            int endN = s.indexOf('\n', start);
            int endR = s.indexOf('\r', start);
            int end;
            if (endN < 0) end = (endR < 0) ? s.length() : endR;
            else end = (endR < 0) ? endN : Math.min(endN, endR);

            String path = (start <= end) ? s.substring(start, end).trim() : "";
            if (path.length() != 0) {
                // Extract filename from path
                int slash = path.lastIndexOf('/');
                int bslash = path.lastIndexOf('\\');
                int cut = (slash > bslash) ? slash : bslash;

                String file = (cut >= 0) ? path.substring(cut + 1).trim() : path.trim();
                if (file.length() != 0) {
                    // Strip extension
                    String fLower = file.toLowerCase();
                    if (fLower.endsWith(".xlsx")) file = file.substring(0, file.length() - 5);
                    else if (fLower.endsWith(".xls")) file = file.substring(0, file.length() - 4);

                    file = file.trim();
                    if (file.length() != 0) return file;
                }
            }

            // find next occurrence (rare, but safe)
            idx = lower.indexOf(keyLower, idx + 1);
        }
    }

    // Fallback: last *.xlsx/*.xls anywhere in text
    int pos = lower.lastIndexOf(".xlsx");
    int extLen = 5;
    if (pos < 0) { pos = lower.lastIndexOf(".xls"); extLen = 4; }
    if (pos < 0) return null;

    int extEnd = pos + extLen;

    int cut1 = s.lastIndexOf('/', pos);
    int cut2 = s.lastIndexOf('\\', pos);
    int cut3 = s.lastIndexOf('\n', pos);
    int cut4 = s.lastIndexOf('\r', pos);
    int start = Math.max(Math.max(cut1, cut2), Math.max(cut3, cut4));

    String file = s.substring(start + 1, extEnd).trim();
    if (file.length() == 0) return null;

    String fLower = file.toLowerCase();
    if (fLower.endsWith(".xlsx")) file = file.substring(0, file.length() - 5);
    else if (fLower.endsWith(".xls")) file = file.substring(0, file.length() - 4);

    file = file.trim();
    return (file.length() == 0) ? null : file;
}
//Added for SWIMP-883: End


    // ==================== New ValidateBOM method integrated from CSK_PLM_emxValidateBOM_mxJPO ====================
// ==================== New method to store SSGQI logs into verify object ====================
/**
 * Stores the SSGQI JSON log content into the attribute IMP_VerifyIP_SSGQI_LogsForEPS
 * of the specified verify object.
 *
 * @param context the eMatrix Context
 * @param sVerifyid ID of the verify object
 * @param sSSGQILogs JSON string to store
 * @throws Exception if the operation fails
 */
public static void setSSGQILogsToVerifyid(Context context, String sVerifyid, String sSSGQILogs) throws Exception {
    MapList mlIPVerifications = new MapList();
    try {
        StringList slObjDetails = new StringList();
        slObjDetails.add(DomainConstants.SELECT_ID);
        mlIPVerifications = DomainObject.findObjects(context,
                IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
                null, false, slObjDetails);
        if (mlIPVerifications != null && !mlIPVerifications.isEmpty()) {
            for (Object obj : mlIPVerifications) {
                @SuppressWarnings("rawtypes")
                HashMap mapIPVerifyObj = (HashMap) obj;
                String objectId = (String) mapIPVerifyObj.get(DomainObject.SELECT_ID);
				System.out.println(":::::::::::::::::::::::::::::::::::objectId:::::::::::::::::"+objectId);
                Map<String, String> mpAttrUpdate = new HashMap<>();
                mpAttrUpdate.put("IMP_VerifyIP_SSGQI_LogsForEPS", sSSGQILogs);
				System.out.println(":::::::::::::::::::::::::::::::::::mpAttrUpdate:::::::::::::::::"+mpAttrUpdate);
                DomainObject domVerifyRun = new DomainObject(objectId);
                domVerifyRun.setAttributeValues(context, mpAttrUpdate);
            }
        }
    } catch (MatrixException e) {
        throw new MatrixException("Exception occurred in IMP_IPVerification:setSSGQILogsToVerifyid: " + e);
    }
}

// ==================== Modified ValidateBOM method ====================
/**
 * Args:
 * args[0] = Excel Path
 * args[1] = Output JSON Path
 * args[2] = (optional) Sheet Name
 * args[3] = (optional) Verify object ID – if provided, the JSON content is stored
 * in the attribute IMP_VerifyIP_SSGQI_LogsForEPS of that verify object.
 *
 * Behavior:
 * - If sheet name is missing/blank/"ALL"/"Sheet1": converts ALL sheets
 * - If sheet name is provided but not found: converts ALL sheets (and logs available names)
 * - Always writes the JSON to the specified output file.
 * - If verify ID is supplied, also stores the JSON string into the verify object's attribute.
 */
// ==================== Modified ValidateBOM method (no file write) ====================
public static void ValidateBOM(Context context, String[] args) throws Exception {
    try {
        if (args.length < 1 || args.length > 3) {
            throw new Exception("Please pass {Excel Path} {Sheet Name(optional)} {Verify ID(optional)} as parameters");
        }
        System.out.println("Args count: " + (args == null ? 0 : args.length));
        if (args != null) {
            for (int i = 0; i < args.length; i++) {
                System.out.println("args[" + i + "] = '" + args[i] + "'");
            }
        }

        Path excelPath = Paths.get(args[0]).toAbsolutePath().normalize();
        String requestedSheetName = (args.length >= 2) ? safeTrim(args[1]) : null;
        String verifyId = (args.length >= 3) ? safeTrim(args[2]) : null;

        if (!Files.exists(excelPath)) throw new IOException("Excel file not found: " + excelPath);
        if (!Files.isRegularFile(excelPath)) throw new IOException("Not a file: " + excelPath);

        Instant start = Instant.now();
        System.out.println("Reading Excel: " + excelPath);

        Map<String, Object> root = new LinkedHashMap<>();

        try (InputStream in = Files.newInputStream(excelPath);
             Workbook workbook = WorkbookFactory.create(in)) {

            DataFormatter formatter = new DataFormatter();
            FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();

            boolean treatAsAll = (requestedSheetName == null || requestedSheetName.length() == 0
                    || "ALL".equalsIgnoreCase(requestedSheetName)
                    || "Sheet1".equalsIgnoreCase(requestedSheetName));

            if (!treatAsAll) {
                Sheet s = workbook.getSheet(requestedSheetName);
                if (s != null) {
                    putParsedSheet(root, s, formatter, evaluator);
                } else {
                    System.out.println("WARN: Sheet not found: " + requestedSheetName);
                    System.out.println("WARN: Available sheets: " + listSheetNames(workbook));
                    processAllSheets(root, workbook, formatter, evaluator);
                }
            } else {
                processAllSheets(root, workbook, formatter, evaluator);
            }
        }

        System.out.println("Converting to JSON; topKeys=" + root.size());
        String json = toJsonAny(root);

        // If a verify object ID was provided, store the JSON in its attribute
        if (verifyId != null && !verifyId.trim().isEmpty()) {
            setSSGQILogsToVerifyid(context, verifyId, json);
            System.out.println("Stored JSON in attribute IMP_VerifyIP_SSGQI_LogsForEPS of verify object " + verifyId);
        } else {
            System.out.println("No verify ID provided; JSON not stored in attribute.");
        }

        // File writing removed as requested

        Duration timeElapsed = Duration.between(start, Instant.now());
        System.out.println("Done.");
        System.out.println("Time Taken : " + timeElapsed.toMillis() + " Milli Seconds");

    } catch (Exception ex) {
        ex.printStackTrace();
        throw ex;
    }
}







    /* ===================== Workbook / sheet processing ===================== */

    private static void processAllSheets(Map<String, Object> root, Workbook workbook, DataFormatter formatter, FormulaEvaluator evaluator) {
        int n = workbook.getNumberOfSheets();
        for (int i = 0; i < n; i++) {
            Sheet sheet = workbook.getSheetAt(i);
            if (sheet == null) continue;
            putParsedSheet(root, sheet, formatter, evaluator);
        }
    }

    private static void putParsedSheet(Map<String, Object> root, Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator) {
        Object parsed = parseSheetAuto(sheet, formatter, evaluator);

        if (parsed == null) return;
        if (parsed instanceof Map && ((Map<?, ?>) parsed).isEmpty()) return;
        if (parsed instanceof List && ((List<?>) parsed).isEmpty()) return;

        // Key/value sheet => top key = PROJECT NAME if present, else sheet name
        if (parsed instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> m = (Map<String, Object>) parsed;

            String projectName = "";
            Object pn = m.get("PROJECT NAME");
            if (pn != null) projectName = String.valueOf(pn).trim();

            String topKey = (projectName.length() > 0) ? projectName : sheet.getSheetName();
            topKey = makeUniqueTopKey(root, topKey);
            root.put(topKey, m);
            return;
        }

        // Tabular sheet => top key = sheet name
        String topKey = makeUniqueTopKey(root, sheet.getSheetName());
        root.put(topKey, parsed);
    }

    private static String makeUniqueTopKey(Map<String, Object> root, String key) {
        if (!root.containsKey(key)) return key;
        int i = 2;
        while (root.containsKey(key + "_" + i)) i++;
        return key + "_" + i;
    }

    private static String listSheetNames(Workbook workbook) {
        int n = workbook.getNumberOfSheets();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append(", ");
            sb.append(workbook.getSheetName(i));
        }
        return sb.toString();
    }

    private static String safeTrim(String s) {
        return (s == null) ? null : s.trim();
    }

    /* ===================== Auto-detect sheet structure ===================== */

    private static class KvLayout {
        final int keyCol;
        final int valCol;
        KvLayout(int keyCol, int valCol) { this.keyCol = keyCol; this.valCol = valCol; }
    }

    /**
     * No hard-coded headers/section names.
     * - If a "wide" header row (>=3 non-empty cells) exists with data under it -> tabular.
     * - Otherwise -> key/value.
     */
    public static Object parseSheetAuto(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator) {
        Objects.requireNonNull(sheet, "sheet");
        Objects.requireNonNull(formatter, "formatter");
        Objects.requireNonNull(evaluator, "evaluator");

        int first = sheet.getFirstRowNum();
        int last  = sheet.getLastRowNum();
        if (last < first) return null;

        int headerRowIdx = findLikelyTableHeaderRow(sheet, formatter, evaluator, first, Math.min(last, first + 80));
        if (headerRowIdx >= 0) {
            List<Map<String, String>> table = readTabularSheet(sheet, formatter, evaluator, headerRowIdx);
            if (!table.isEmpty()) return table;
        }

        KvLayout kv = detectKvLayout(sheet, formatter, evaluator, first, Math.min(last, first + 120));
        return readKeyValueSheetGeneric(sheet, formatter, evaluator, kv);
    }

    /** Picks widest row as candidate header; validates it has data rows beneath. */
    private static int findLikelyTableHeaderRow(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator, int start, int end) {
        int bestIdx = -1;
        int bestNonEmpty = 0;

        for (int r = start; r <= end; r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            int nonEmpty = countNonEmptyCells(row, 0, 60, formatter, evaluator);
            if (nonEmpty > bestNonEmpty) {
                bestNonEmpty = nonEmpty;
                bestIdx = r;
            }
        }

        if (bestIdx < 0 || bestNonEmpty < 3) return -1;

        int last = sheet.getLastRowNum();
        int dataWideRows = 0;
        for (int r = bestIdx + 1; r <= Math.min(last, bestIdx + 25); r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;
            int nonEmpty = countNonEmptyCells(row, 0, 60, formatter, evaluator);
            if (nonEmpty >= 2) dataWideRows++;
            if (dataWideRows >= 1) return bestIdx;
        }
        return -1;
    }

    /** Detect key/value columns even if they shift (mode of first-two-non-empty columns). */
    private static KvLayout detectKvLayout(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator, int start, int end) {
        Map<Integer, Integer> keyColCounts = new HashMap<Integer, Integer>();
        Map<Integer, Integer> valColCounts = new HashMap<Integer, Integer>();

        for (int r = start; r <= end; r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;

            int[] firstTwo = firstTwoNonEmptyCols(row, 0, 60, formatter, evaluator);
            int keyCol = firstTwo[0];
            int valCol = firstTwo[1];

            if (keyCol >= 0) {
                keyColCounts.put(keyCol, Integer.valueOf(keyColCounts.containsKey(keyCol) ? keyColCounts.get(keyCol).intValue() + 1 : 1));
            }
            if (keyCol >= 0 && valCol >= 0) {
                valColCounts.put(valCol, Integer.valueOf(valColCounts.containsKey(valCol) ? valColCounts.get(valCol).intValue() + 1 : 1));
            }
        }

        int keyCol = modeColumn(keyColCounts, 0);
        int valCol = modeColumn(valColCounts, keyCol + 1);
        return new KvLayout(keyCol, valCol);
    }

    private static int modeColumn(Map<Integer, Integer> counts, int defaultCol) {
        int bestCol = defaultCol;
        int best = -1;
        for (Map.Entry<Integer, Integer> e : counts.entrySet()) {
            int col = e.getKey().intValue();
            int cnt = e.getValue().intValue();
            if (cnt > best) { best = cnt; bestCol = col; }
        }
        return bestCol;
    }

    /* ===================== Key/value parser (generic + list sections) ===================== */

    /**
     * Generic key/value:
     * - key = cell at kv.keyCol
     * - value = cell at kv.valCol
     * - If a key row has empty value AND next rows have blank key but have values => treat as LIST
     *   (works for "IP SUBSCRIPTIONS" but also for any other section name).
     */
    public static Map<String, Object> readKeyValueSheetGeneric(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator, KvLayout kv) {
        int firstRowNum = sheet.getFirstRowNum();
        int lastRowNum  = sheet.getLastRowNum();

        Map<String, Object> out = new LinkedHashMap<String, Object>();

        String pendingListKey = null;
        List<String> pendingList = null;
        boolean pendingListInserted = false;

        for (int r = firstRowNum; r <= lastRowNum; r++) {
            Row row = sheet.getRow(r);
            if (row == null) continue;

            String key = cellString(row, kv.keyCol, formatter, evaluator).trim();
            String val = cellString(row, kv.valCol, formatter, evaluator).trim();

            boolean keyEmpty = (key.length() == 0);
            boolean valEmpty = (val.length() == 0);

            if (keyEmpty && valEmpty) continue;

            // Value-only row -> possible list item
            if (keyEmpty) {
                if (pendingListKey != null) {
                    if (!pendingListInserted) {
                        out.put(pendingListKey, pendingList);
                        pendingListInserted = true;
                    }

                    String item = val;
                    if (item.length() == 0) item = firstNonEmptyCellString(row, 0, 60, formatter, evaluator).trim();
                    if (item.length() > 0) pendingList.add(item);
                }
                continue;
            }

            // New key row closes any pending list-without-items
            if (pendingListKey != null && !pendingListInserted) {
                out.put(pendingListKey, "");
            }
            pendingListKey = null;
            pendingList = null;
            pendingListInserted = false;

            // Normal kv
            if (!valEmpty) {
                out.put(key, val);
                continue;
            }

            // Key with blank value -> maybe list section header (confirm when we see items)
            pendingListKey = key;
            pendingList = new ArrayList<String>();
            pendingListInserted = false;
        }

        if (pendingListKey != null && !pendingListInserted) {
            out.put(pendingListKey, "");
        }

        return out;
    }

    /* ===================== Tabular parser ===================== */

    public static List<Map<String, String>> readTabularSheet(Sheet sheet, DataFormatter formatter, FormulaEvaluator evaluator, int headerRowIdx) {
        int lastRow  = sheet.getLastRowNum();

        Row headerRow = sheet.getRow(headerRowIdx);
        int lastCell = (headerRow == null) ? -1 : headerRow.getLastCellNum();
        if (lastCell <= 0) return new ArrayList<Map<String, String>>();

        List<String> headers = buildHeaders(headerRow, lastCell, formatter, evaluator);
        List<Map<String, String>> out = new ArrayList<Map<String, String>>();

        int blankStreak = 0;
        for (int r = headerRowIdx + 1; r <= lastRow; r++) {
            Row row = sheet.getRow(r);

            Map<String, String> rowMap = new LinkedHashMap<String, String>(headers.size());
            boolean anyValue = false;

            for (int c = 0; c < headers.size(); c++) {
                String v = (row == null) ? "" : cellString(row, c, formatter, evaluator);
                v = (v == null) ? "" : v.trim();
                if (v.length() > 0) anyValue = true;
                rowMap.put(headers.get(c), v);
            }

            if (!anyValue) {
                blankStreak++;
                if (blankStreak >= 20) break;
                continue;
            }

            blankStreak = 0;
            out.add(rowMap);
        }

        return out;
    }

    private static List<String> buildHeaders(Row headerRow, int lastHeaderCell, DataFormatter formatter, FormulaEvaluator evaluator) {
        List<String> headers = new ArrayList<String>(lastHeaderCell);
        Map<String, Integer> seen = new HashMap<String, Integer>();

        for (int c = 0; c < lastHeaderCell; c++) {
            String raw = cellString(headerRow, c, formatter, evaluator);
            raw = (raw == null) ? "" : raw;

            String h = raw.trim();
            if (h.length() == 0) h = "Column" + (c + 1);

            Integer count = seen.get(h);
            if (count == null) {
                seen.put(h, 1);
                headers.add(h);
            } else {
                int next = count.intValue() + 1;
                seen.put(h, next);
                headers.add(h + "_" + next);
            }
        }
        return headers;
    }

    /* ===================== Cell helpers ===================== */

    private static int countNonEmptyCells(Row row, int fromCol, int toCol, DataFormatter formatter, FormulaEvaluator evaluator) {
        int n = 0;
        for (int c = fromCol; c <= toCol; c++) {
            String s = cellString(row, c, formatter, evaluator);
            if (s != null && s.trim().length() > 0) n++;
        }
        return n;
    }

    private static int[] firstTwoNonEmptyCols(Row row, int fromCol, int toCol, DataFormatter formatter, FormulaEvaluator evaluator) {
        int first = -1, second = -1;
        for (int c = fromCol; c <= toCol; c++) {
            String s = cellString(row, c, formatter, evaluator);
            if (s == null || s.trim().length() == 0) continue;
            if (first < 0) first = c;
            else { second = c; break; }
        }
        return new int[] { first, second };
    }

    private static String firstNonEmptyCellString(Row row, int fromCol, int toCol, DataFormatter formatter, FormulaEvaluator evaluator) {
        for (int c = fromCol; c <= toCol; c++) {
            String s = cellString(row, c, formatter, evaluator);
            if (s != null && s.trim().length() > 0) return s;
        }
        return "";
    }

    private static String cellString(Row row, int col, DataFormatter formatter, FormulaEvaluator evaluator) {
        if (row == null || col < 0) return "";
        Cell cell = row.getCell(col, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
        if (cell == null) return "";
        String s = formatter.formatCellValue(cell, evaluator);
        return (s == null) ? "" : s;
    }

    /* ===================== JSON writer ===================== */

    public static String toJsonAny(Object v) {
        StringBuilder sb = new StringBuilder(4096);
        writeJsonAny(sb, v, 0);
        sb.append("\n");
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void writeJsonAny(StringBuilder sb, Object v, int indent) {
        if (v == null) { sb.append("null"); return; }

        if (v instanceof Map) {
            Map<Object, Object> map = (Map<Object, Object>) v;
            sb.append("{");
            if (!map.isEmpty()) sb.append("\n");

            int i = 0;
            for (Map.Entry<Object, Object> e : map.entrySet()) {
                if (i++ > 0) sb.append(",\n");
                indent(sb, indent + 2);
                sb.append("\"").append(escapeJson(String.valueOf(e.getKey()))).append("\": ");
                writeJsonAny(sb, e.getValue(), indent + 2);
            }

            if (!map.isEmpty()) { sb.append("\n"); indent(sb, indent); }
            sb.append("}");
            return;
        }

        if (v instanceof List) {
            List<Object> list = (List<Object>) v;
            sb.append("[");
            if (!list.isEmpty()) sb.append("\n");

            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",\n");
                indent(sb, indent + 2);
                writeJsonAny(sb, list.get(i), indent + 2);
            }

            if (!list.isEmpty()) { sb.append("\n"); indent(sb, indent); }
            sb.append("]");
            return;
        }

        sb.append("\"").append(escapeJson(String.valueOf(v))).append("\"");
    }

    private static void indent(StringBuilder sb, int n) {
        for (int i = 0; i < n; i++) sb.append(' ');
    }

    public static void writeJsonFile(Path jsonPath, String json) throws IOException {
        Objects.requireNonNull(jsonPath, "jsonPath");
        Objects.requireNonNull(json, "json");

        Path parent = jsonPath.getParent();
        if (parent != null) Files.createDirectories(parent);

		try (BufferedWriter w = Files.newBufferedWriter(jsonPath, Charset.forName("UTF-8"))) {
			w.write(json);
		}
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder(s.length() + 16);

        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            i += Character.charCount(cp);

            if (cp == '\"') out.append("\\\"");
            else if (cp == '\\') out.append("\\\\");
            else if (cp == '\b') out.append("\\b");
            else if (cp == '\f') out.append("\\f");
            else if (cp == '\n') out.append("\\n");
            else if (cp == '\r') out.append("\\r");
            else if (cp == '\t') out.append("\\t");
            else {
                if (cp >= 0x0000 && cp <= 0x001F) out.append(String.format("\\u%04X", cp));
                else if (cp == 0x2028) out.append("\\u2028");
                else if (cp == 0x2029) out.append("\\u2029");
                else out.appendCodePoint(cp);
            }
        }
        return out.toString();
    }





}