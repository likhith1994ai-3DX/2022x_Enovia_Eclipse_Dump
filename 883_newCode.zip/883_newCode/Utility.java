/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : Utility.java
 * DESCRIPTION  : Utitlity java holds the common utility methods which can be used in CLI.
 *                
 * USAGE        : java -jar ${PATH}/CLI.jar 
 * 
 * CREATED      : 27-October-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * HISTORY:
 * 
 * Name                     Modified Date                 Description
 * 
 * Sai Prasad               27-Oct-2016                   Initial version.
 * Sujatha Ramakrishnan		27-Feb-2018					  SWIMP-133 - Validating the branch.
 * Mahammed Irshad K S		14-Nov-2018					  Added the method getIPProductID for SWIMP-262, gets IP ID from IP DIR
 * Mahammed Irshad K S		22-Nov-2018					  Added the methods checkAccess and getRetCode for SWIMP-262
 * Mahammed Irshad K S		01-Jan-2019					  Removed getIPProductID for SWIMP-262
 * Mahammed Irshad K S		22-Feb-2019					  Modified getRetCode and checkAccess methods for SWIMP-262
 * Mahammed Irshad K S		19-Oct-2019					  Added method createDirectory for SWIMP-383, for creating imp directory while downloading migrated IPs
 * Mahammed Irshad K S		11-Apr-2020					  Added method getTechStackMappingsForExternalTools, readTechStackExceptionFile, getTechStacksForIPProduct,
 *                                                        getTechStackMappingFromTechStackExceptionFile, getToolBasedMapping, convertTechStackMappingIntoToolSpecific, techStackMappingCaseConversion,
 *                                                        getBalancedPairsOfBracesAndRegEx, getReplacementString, getCheckLayerProcessCommand, writeOutputOrErrorFile
 *                                                        & getCheckLayerErrorFile for SWIMP-425
 * Mahammed Irshad K S      09-Jun-2020                   Added methods getDesignFiles, writeCheckLayersFile, deleteFiles, unTarAndGetDesignFiles, extractTarFiles and deleteFolders for SWIMP-471
 * Mahammed Irshad K S      13-Jul-2020                   Added method getIPBaseDirectoryPath and modified methods getDesignFiles, unTarAndGetDesignFiles, deleteFolders and extractTarFiles for SWIMP-492
 * Mahammed Irshad K S      07-Sep-2020                   Modified methods getDesignFiles, extractTarFiles, writeCheckLayersFile and writeOutputOrErrorFile for SWIMP-501
 * Mahammed Irshad K S      07-Jul-2021                   Modified buildHIPStructure4EachDesignFile and added getIPHierarchyParentStructure, getIPHierarchyChildInformation, getDetectedIPsFromMap methods for SWIMP-568
 * Mahammed Irshad K S      24-Jul-2021                   Added methods getYamlOutputForVerifiedIPs, getYamlOutputFromVerifyRun for SWIMP-570
 *------------------------------------------------------------------------------------------------------------------------------------------
 */

package com.broadcom.utility;

import java.io.BufferedInputStream;//Added for SWIMP-471
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;//Added for SWIMP-471
import java.io.FileReader; //Added for SWIMP-425
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap; //Added for SWIMP-568
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher; //Added for SWIMP-425
import java.util.regex.Pattern; //Added for SWIMP-425
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;//Added for SWIMP-471
import java.util.TreeMap;

import javax.ws.rs.core.MediaType;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets; ///Added for SWIMP-883


//Added for SWIMP-471: Starts
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.compress.utils.IOUtils;
//Added for SWIMP-471: Ends
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import com.broadcom.impcli.client.IMP; //Added for SWIMP-425
import com.broadcom.impcli.client.IMPCommon;
import com.broadcom.impcli.client.IMPConstants;
import com.broadcom.impcli.client.IMPException;
import com.broadcom.impcli.client.IMPLog;
import com.broadcom.impcli.enovia.IMPEnoviaClientWrapper;
import com.broadcom.impcli.stclc.IMPStclcWrapper;
import com.broadcom.impcli.subcommands.PrepareSA; //Added for SWIMP-859
import com.broadcom.impcli.subcommands.Version;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.JSchException;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.fasterxml.jackson.databind.ObjectMapper; //Added for SWIMP-425


/**
 * The Class Utility.
 */
public class Utility {

  /** The log. */
  private static Logger log = LoggerFactory.getLogger(Utility.class);

  private static String strSpecName;
  private static String strSpecVersion; //SWIMP-666

  private static boolean isDtree;

  private static String strSFTPHost;

  private static String strHostKeyChecking = "StrictHostKeyChecking";
  private static String strPrefferedAuth = "PreferredAuthentications";
  private static String strKeys = "publickey,keyboard-interactive,password";
  private static boolean hasDirCreated = false;
  private static String createdDirName;

  //Added for SWIMP-425: Starts
  private static String sTechnologyStacks = "technology_stacks";
  static List<Map<String, Object>> lExceptionMap = new ArrayList<>();
  static String strReturnExceptionTechStackMapping = "";
  //Added for SWIMP-425: Ends
  
  //Added for SWIMP-31: Starts
  private static String strIPXWM = "IPXWM-";
  private static String strInvalidWM = "__INVD__";
  private static String sRefGetBlockIP = "to[IMP_IP_Watermark].from.to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_ProductType]";
  private static String sBlockIP="Block IP";
  //Added for SWIMP-31: Ends
  
  //Added for SWIMP-354: Starts
  //Modified for SWIMP-859: Starts
  private static String strMessageForDesignSyncConnectionForExistingModule = "Check existing staging area for modifications";
  private static String strCommandNameForExistingStagingAreaCheck = "checkForDifferencesInExistingStagingArea";
  private static String strMessageForReturnCodeOnExistingModuleCheck = "Check existing staging area for modifications is returning with the exit code: ";
  //Added for SWIMP-354: Ends
  //Modified for SWIMP-859: Ends

  protected static final List<Map<String, Object>> lsFinalDetectedIPsMapList = new ArrayList<>(); //Added for SWIMP-568
  /**
   * Instantiates a new utility.
   */
  private Utility() {
    // Instatiates variables
  }

  /**
   * Upload file.
   *
   * @param strSpecFile the str spec file
   * @param sTempDir the s temp dir
   * @return the int
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static int uploadFile(String strSpecFile, String sTempDir) throws IOException {
    int iReturn = 0;
    String sFTPHost = getHost();
    int sFTPPort = 22;
    String sFTPUser = IMPConstants.IMP_CLI_SERVER_USER;
    String sFTPPass = getDecodePass();
    String sFTPWorkingDirectory = Paths.get(IMPConstants.IMP_CLI_WORKING_DIR).toString();
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try (FileInputStream fileStream = new FileInputStream(new File(strSpecFile))){
      JSch jsch = new JSch();
      session = jsch.getSession(sFTPUser, sFTPHost, sFTPPort);
      session.setPassword(sFTPPass);
      java.util.Properties config = new java.util.Properties();
      config.put(strHostKeyChecking, "no");
      session.setConfig(config);
      session.setConfig(strPrefferedAuth, strKeys);
      session.connect();
      boolean bConnected = session.isConnected();
      if (!bConnected) {
        iReturn = 1;
      } else {
        channel = session.openChannel("sftp");
        channel.connect();
        channelSftp = (ChannelSftp) channel;
        checkCreateDir(channelSftp,Paths.get(IMPConstants.IMP_CLI_SERVER_WORKING_DIR).toString() ); //Added for SWIMP-78
        checkCreateDir(channelSftp,sFTPWorkingDirectory); //Added for SWIMP-78
        channelSftp.cd(sFTPWorkingDirectory);
        checkCreateDir(channelSftp,sTempDir);
        channelSftp.cd(sTempDir);
        channelSftp.put(fileStream, Paths.get(strSpecFile).toFile().getName());
      }
    } catch (Exception ex) {
      log.error("Exception", ex);
    } finally {
      if (session != null) {
        session.disconnect();
      }
    }
    return iReturn;
  }

  
  private static void checkCreateDir(ChannelSftp channelSftp, String strTempDir) throws SftpException {
	  		try {
	  			channelSftp.lstat(strTempDir);
	  		} catch (SftpException e) {
	  			channelSftp.mkdir(strTempDir);
	  		}
	  
	  	}
  /**
   * Download.
   *
   * @param strFileName the str file name
   * @param strFilePath the str file path
   * @param strPath the str path
   * @return the path
   * @throws IMPException the IMP exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static Path download(String strFileName, String strFilePath, String strPath)
      throws IMPException, IOException {
    String sFTPHost = getHost();
    int sFTPPort = 22;
    String sFTPUser = IMPConstants.IMP_CLI_SERVER_USER;
    String sFTPPass = getDecodePass();
    String sFTPWorkingDirectory = Paths.get(IMPConstants.IMP_CLI_WORKING_DIR).resolve(strPath).toString(); //Added for SWIMP-78
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    Path ipPath = null;
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(sFTPUser, sFTPHost, sFTPPort);
      session.setPassword(sFTPPass);
      java.util.Properties config = new java.util.Properties();
      config.put(strHostKeyChecking, "no");
      session.setConfig(config);
      session.setConfig(strPrefferedAuth, strKeys);
      session.connect();
      channel = session.openChannel("sftp");
      channel.connect();
      channelSftp = (ChannelSftp) channel;
      channelSftp.cd(sFTPWorkingDirectory);
      if (isDtree) {
        File fName = new File(strFilePath);
        File newFile = null;
        if (fName.isDirectory()) {
          newFile = new File(Paths.get(strFilePath).resolve(strFileName).toAbsolutePath().toString());
        } else {
          newFile = new File(strFilePath);
        }
        ipPath = Paths.get(newFile.getAbsolutePath());
      } else {
        ipPath = Paths.get(Paths.get(strFilePath).resolve(strFileName).toAbsolutePath().toString());
      }
      channelSftp.get(strFileName, ipPath.toString()); 	   
    } catch (JSchException e) {
		 IMPLog.error("Exception in SFTP Connection :::::  " + e.getMessage()); //Added for SWIMP-695
		 
    } catch (Exception ex) {		
		 throw new IMPException("Requested file for specified dtree-spec '" + getStrSpecName()
			  + "' does not exist in IMP.");
		  	   
    } finally {
      IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
      enoClient.deleteOnExit(sFTPWorkingDirectory); // Added for bug 821
      if (channelSftp != null) {
        channelSftp.exit();
      }
      if (session != null) {
        session.disconnect();
      }
    }
    return ipPath;
  }

  /**
   * Gets the IP dir.
   *
   * @param sIPDir the s IP dir
   * @return the IP dir
   */
  public static String getIPDir(String sIPDir) {
    String currentDir = System.getProperty("user.dir");
    String sModRoot;
    if (sIPDir == null) {
      sModRoot = currentDir;
    } else {
      sModRoot = sIPDir;
    }
    return sModRoot;
  }

  /**
   * Gets the file from tree.
   *
   * @param dir the dir
   * @param fileName the file name
   * @param maxDepth the max depth
   * @return the file from tree
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static String getFileFromTree(Path dir, String fileName, int maxDepth) throws IOException {
    if (dir.toFile().exists()) {
      try (Stream<Path> stream =
          Files.find(dir, maxDepth, (path, attr) -> String.valueOf(path).endsWith(fileName))) {
        return stream.sorted().map(String::valueOf).collect(Collectors.joining("; "));
      }
    } else {
      return "";
    }
  }

  public static String getStrSpecName() {
    return strSpecName;
  }

  public static void setStrSpecName(String strSpecName) {
    Utility.strSpecName = strSpecName;
  }
//SWIMP-666 -start
  public static String getStrSpecVersion() {
    return strSpecVersion;
  }

  public static void setStrSpecVersion(String strSpecVersion) {
    Utility.strSpecVersion = strSpecVersion;
  }
//SWIMP-666 -end
  /**
   * Gets the process status.
   *
   * @param pBuilder the builder
   * @param stclWrapper the stcl wrapper
   * @return the process status
   * @throws IOException Signals that an I/O exception has occurred.
   * @throws InterruptedException the interrupted exception
   * @throws IMPException the IMP exception
   */
  public static int getProcessStatus(ProcessBuilder pBuilder, IMPStclcWrapper stclWrapper)
      throws IMPException {
    int iReturn = 1;
    try {
      Process process = pBuilder.start();
      
      pBuilder.redirectErrorStream(true);
      IMPLog.trace("Get process status");
      String sOut = stclWrapper.processOutput(process);
      int pValue = process.waitFor();
      IMPLog.trace("Process builder value:  " + pValue);
      if (pValue == 0) {
        IMPLog.trace("Design Sync: " + System.lineSeparator() + sOut);
        sOut = stclWrapper.getSoutValue(sOut).trim();
        if (!sOut.trim().startsWith("Error:")) {
          iReturn = 0;
        } else {
          iReturn = 2;
          sOut = sOut.replace("Error: ", "");
          int iIndex = sOut.indexOf("IMP Stcl designsync output");
          if (iIndex > -1) { // Modified for bug 531
            sOut = sOut.substring(0, iIndex);
          }
          IMPLog.error(sOut);
        }
      } else {
        iReturn = 2;
        sOut = sOut.replace("Error: ", "");
        IMPLog.error(sOut);
      }
    } catch (Exception e) {
      throw new IMPException(e);
    }
    return iReturn;
  }

  /**
   * Copy spec from platform.
   *
   * @param specName the spec name
   * @param specVersion the spec version
   * @param copyLoc the copy loc
   * @return the int
   * @throws IMPException the IMP exception
   */
  public static int copySpecFromPlatform(String specName, String specVersion, String copyLoc)
      throws IMPException {
    int iReturn = 1;
    IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
    setStrSpecName(specName);
    try { // Modified for bug 821
      // In case, specific version needs to be downloaded from IMP.
      // Pass the spec version to the method getLatestSpecVersion to get the specific spec file from
      // IMP.
      org.codehaus.jettison.json.JSONObject jsOwnerData =
          enoClient.getLatestSpecVersion(specName, "*");
      String sMsg = (String) jsOwnerData.get(IMPConstants.IMP_MESSAGE);
      if ("does not exist".equals(sMsg) || "Inactive".equalsIgnoreCase(sMsg)) {
        throw new IMPException(
            "Directory tree spec '" + specName + " " + sMsg + " in IMP"); //Modified for SWIMP-219
      } else {
        // Modified for 491---Start
        String sPath = enoClient.checkOutAndCheckInSpec(IMPConstants.IMP_FILE,
            IMPConstants.IMP_CLI_WORKING_DIR, specName, "checkout", "*", "");
        // Modified for 491---End
        Utility.download((String) jsOwnerData.get("filename"), copyLoc, sPath);
        iReturn = 0;
      }
    } catch (IMPException | JSONException | IOException e) {
      throw new IMPException(e.getMessage());
    }
    return iReturn;
  }

  public static boolean isDtree() {
    return isDtree;
  }

  public static void setDtree(boolean isDtree) {
    Utility.isDtree = isDtree;
  }

  private static String getHost() {
    String sReturnHost;
    if (null != strSFTPHost) {
      sReturnHost = strSFTPHost;
    } else {
      sReturnHost = IMPConstants.IMP_CLI_SERVER_HOST;
    }
    return sReturnHost;
  }

  public static String getStrSFTPHost() {
    return strSFTPHost;
  }

  public static void setStrSFTPHost(String strSFTPHost) {
    Utility.strSFTPHost = strSFTPHost;
  }


  /**
   * Gets the decode pass.
   *
   * @return the decode pass
   * @throws UnsupportedEncodingException the unsupported encoding exception
   */
  public static String getDecodePass() throws UnsupportedEncodingException {
    byte[] bUName = Base64.getDecoder().decode(IMPConstants.IMP_CLI_SERVER_PASS);
    return new String(bUName, "utf-8");
  }

  public static String getFullQualHostName() throws UnknownHostException {
    return InetAddress.getLocalHost().getCanonicalHostName();
  }

  // Added for bug IMPBRCM-985 - START
  /**
   * Creates the temp dir.
   *
   * @param strIpId the str ip id
   * @param strHost the str host
   * @param strTempDir the str temp dir
   * @return the path
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static Path createTempDir(String strHost, String strTempDir)
      throws IOException {
    int sFTPPort = 22;
    Path pReturnPath = null;
    String sFTPUser = IMPConstants.IMP_CLI_SERVER_USER;
    String sFTPPass = Utility.getDecodePass();
    String sFTPWorkingDirectory = Paths.get(IMPConstants.IMP_CLI_SERVER_WORKING_DIR).resolve("fileChckin").resolve("Public").toString(); //Added for SWIMP-78
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(sFTPUser, strHost, sFTPPort);
      session.setPassword(sFTPPass);
      java.util.Properties config = new java.util.Properties();
      config.put(strHostKeyChecking, "no");
      session.setConfig(config);
      session.setConfig(strPrefferedAuth, strKeys);
      session.connect();
      boolean bConnected = session.isConnected();
      if (bConnected) {
        channel = session.openChannel("sftp");
        channel.connect();
        channelSftp = (ChannelSftp) channel;
        //Added for SWIMP-78: Starts
        checkCreateDir(channelSftp,Paths.get(IMPConstants.IMP_CLI_SERVER_WORKING_DIR).toString());
        checkCreateDir(channelSftp,Paths.get(IMPConstants.IMP_CLI_SERVER_WORKING_DIR).resolve("fileChckin").toString());
        checkCreateDir(channelSftp,sFTPWorkingDirectory);
        channelSftp.cd(sFTPWorkingDirectory);
        checkCreateDir(channelSftp, strTempDir);
        pReturnPath = Paths.get(sFTPWorkingDirectory).resolve(strTempDir);
      }
    } catch (Exception ex) {
      IMPLog.trace("Exception in creating temp directory: " + ex);
    } finally {
      if (session != null) {
        session.disconnect();
      }
    }
    return pReturnPath;
  }

// Added for bug 1006
  /**
   * Check valid tag.
   *
   * @param sTag the s tag
   * @return true, if successful
   */
  public static boolean checkValidTag(String sTag) {
    boolean bReturn = false;
    if ("Trunk".equalsIgnoreCase(sTag)) {
      bReturn = true;
    }
    return bReturn;
  }

  /**
   * Write in file.
   *
   * @param fileName the file name
   * @param fileData the file data
   * @throws IOException Signals that an I/O exception has occurred.
   */
  public static void writeInFile(String fileName, String fileData) throws IOException {
    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)));
    out.println(fileData);
    out.close();
  }

  // Added for 321
  /**
   * Check file permission.
   *
   * @param strPath the str path
   * @param bDryRun the b dry run
   * @return the string
   */
  public static boolean checkFilePermission(String strPath, boolean bDryRun) {
    boolean bReturn = false;
    Path path = Paths.get(strPath);
    if (!"/".equals(path.toString()) && !"/home".equals(path.toString())) {
      try {
        if (!bDryRun && !path.toFile().exists()) {
          findDirtoDelete(path);
          Files.createDirectories(Paths.get(path.toAbsolutePath().toString()));
          setDirCreated(true);
        }
        bReturn = true;
      } catch (IOException e) {
        bReturn = false;
      }
    }
    return bReturn;
  }

	// Added for SWIMP-220
	/**
	 * To get the directory to be deleted
	 * 
	 * @param path
	 */
	private static void findDirtoDelete(Path path) {
		Path pAbsPath = path.toAbsolutePath();
		Path parentPath = pAbsPath.getParent();
		if (parentPath.toFile().exists()) {
			setCreatedDirName(pAbsPath.toString());
		} else {
			while (!parentPath.toFile().exists()) {
				setCreatedDirName(parentPath.toString());
				parentPath = parentPath.getParent();
			}
		}
	}

/**
   * Gets the water mark string.
   *
   * @param strIPID the str IPID
   * @param strTag the str tag
   * @return the water mark string
   * @throws IMPException the IMP exception
   */
  // Modified to public for 712
  public static String checkExistingWaterMarkString(String strIPID, String strTag)
      throws IMPException {
    String strReturn = "";
    IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
    try {
      WebResource webResource = enoClient.getIMPServiceWebResource("watermarkstring");
      // Pass multiple Query Params
      MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
      queryParams.add("IPID", strIPID);
      queryParams.add("TAG", strTag);

      ClientResponse response = webResource.queryParams(queryParams).accept(MediaType.TEXT_PLAIN)
          .header(IMPConstants.IMP_AUTHORIZATION, "Basic " + IMPConstants.IMP_AUTH_USER)
          .get(ClientResponse.class);
      org.codehaus.jettison.json.JSONObject retJson =
          new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
      if (response.getStatus() != 200) {
        throw new IMPException(
            "Failed : getWaterMarkString HTTP error code : " + response.getStatus());
      }
      strReturn = (String) retJson.get("Value");
    } catch (ClientHandlerException | UniformInterfaceException | JSONException e) {
      IMPLog.error("Exception in get watermark string : " + e);
      throw new IMPException(e.getMessage());
    }
    return strReturn;
  }

  /**
   * Gets the userDefined ipInfo Path and Options
   * If user has not defined then takes ipInfo from properties file
   * @return the ipInfoPath & ipInfoOptions
   */
  // Added for SWIMP-108
  public static List<String> getIPinfoPathAndOptions() {
	  List<String> slRet = new ArrayList<>();
	  //modified for SWIMP-256
	  String userDefinedIpInfoPath = System.getenv("IMP_IPINFO")==null?"":System.getenv("IMP_IPINFO").trim();
	  String userDefinedIpinfoOption = System.getenv("IMP_IPINFO_OPTS")==null?"":System.getenv("IMP_IPINFO_OPTS").replaceAll("\\s+", " ").trim();
	  //Added For SWIMP-255
	  if(StringUtils.isEmpty(userDefinedIpInfoPath)) {
		 // modified for SWIMP-646 Starts
		  slRet.add(IMPConstants.IMP_IPINFO);
		  // modified for SWIMP-646 Ends
	  } else {
		  IMPLog.trace("Using user specified value of IMP_IPINFO ("+userDefinedIpInfoPath+")");
		  slRet.add(userDefinedIpInfoPath);
	  }
	  if(StringUtils.isNotEmpty(userDefinedIpinfoOption)) {
		  IMPLog.trace("Using user specified value of IMP_IPINFO_OPTS ("+userDefinedIpinfoOption+")");
		  List<String> ipInfoOpts = Arrays.asList(userDefinedIpinfoOption.split(" "));
		  slRet.addAll(ipInfoOpts);
	  }
	  // modified for SWIMP-646 Starts
	  else {
              slRet.addAll(Arrays.asList(IMPConstants.IMP_IPINFO_OPTS.split(" ")));
      }
	 // modified for SWIMP-646 Ends
	  return slRet;
  }

  /** Added for SWIMP-87
   * @param uniquificationFileName, ipPath, yamlData
   * @return int
   * @throws IMPException, IOException
   */
  public static int createManifestYaml(String uniquificationFileName, Path ipPath, Map<String, Object> yamlData) throws IMPException, IOException {
	  int iReturn = 0; //Added for SWIMP-636
	  String existUniquificationFile = ipPath.resolve("imp/uniquification_input_manifest.yaml").toString();
	  try { 
		  File f = new File(existUniquificationFile);
		  if (f.exists()) {
			  Files.move(ipPath.resolve("imp/uniquification_input_manifest.yaml"), ipPath.resolve("imp/uniquification_input_manifest.yaml.do_not_use"),StandardCopyOption.REPLACE_EXISTING);
		  }
		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		  String curDate = sdf.format(System.currentTimeMillis());
		  String impVersion = Version.getIMPVersion();
		  String userInfo = IMPCommon.getImpUser()+"@"+IMPCommon.getImpDomain();
		  String sBegin = "# Begin uniquification input manifest" + "\n"
				  + "# For manually created manifest files, delete the following Created by comment line." + "\n"
				  + "# Created by " + userInfo + " on " + curDate + " using imp version " + impVersion + "\n"; // Modified SWIMP-457
		  String sEnd = "# End uniquification input manifest";
		  Files.write(Paths.get(uniquificationFileName), sBegin.getBytes());
		  final DumperOptions options = new DumperOptions();
		  options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
		  options.setPrettyFlow(true);
		  Yaml exportYamFile = new Yaml(options);
		  exportYamFile.dump(yamlData, new FileWriter(uniquificationFileName,true));
		  Files.write(Paths.get(uniquificationFileName), sEnd.getBytes(), StandardOpenOption.APPEND);
	  } catch (Exception e) {
		  IMPLog.error("Exception while writing into manifest file " + e.getMessage());
		  iReturn = 111;//Added for SWIMP-636
	  }
	  return iReturn;//Added for SWIMP-636
  }
    
  
  /**
   * Gets the water mark string.
   *
   * @param strIPID the str IPID
   * @param strTag the str tag
   * @return the water mark string
   * @throws IMPException the IMP exception
   * @throws JSONException
   */
   //SWIMP-1 Starts
  public static String getWaterMarkString(String strIPIDWMSeed) throws IMPException {
    LocalDateTime dateTime = LocalDateTime.now();
    String sTimeStamp = dateTime.format(DateTimeFormatter.ofPattern(IMPConstants.TIME_STAMP));
    String sRevisionWatermarkID;
    sRevisionWatermarkID = strIPIDWMSeed + sTimeStamp;
    try {
        sRevisionWatermarkID = checkUniqueness(sRevisionWatermarkID);
      } catch (IMPException | JSONException e) {
        throw new IMPException(e);
      }
    IMPLog.info("Watermark string generated: "+sRevisionWatermarkID);
	return sRevisionWatermarkID;
  }
//SWIMP-1 Ends
  /**
   * Check uniqueness.
   *
   * @param sWaterMarkId the s water mark id
   * @return the string
   * @throws IMPException the IMP exception
   * @throws JSONException the JSON exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  private static String checkUniqueness(String sWaterMarkId) throws IMPException, JSONException {
    String sReturn = "";
    org.codehaus.jettison.json.JSONObject retJson = null;
    try {
      Set<String> sWaterMarks = new HashSet();
      IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
      String sUniqueWaterMarkID = getRandomString(sWaterMarkId);
      WebResource webResource = enoviaWrapper.getIMPServiceWebResource("getListofwatermarks");
      // Pass multiple Query Params
      MultivaluedMapImpl queryParams = new MultivaluedMapImpl();

      ClientResponse response = webResource.queryParams(queryParams).accept("application/json")
          .header("authorization", "Basic " + IMPConstants.IMP_AUTH_USER)
          .post(ClientResponse.class);
      retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));

      if (response.getStatus() != 200) {
        throw new IMPException(retJson.getString(IMPConstants.IMP_MESSAGE));
      }

      org.codehaus.jettison.json.JSONArray jsonObject =
          (JSONArray) retJson.get(IMPConstants.IMP_MESSAGE);
      for (int i = 0; i < jsonObject.length(); i++) {
        sWaterMarks.add(jsonObject.get(i).toString());
      }

      // Check the watermark string already available, else regenerate and check.
      while (true) {
        if (sWaterMarks.contains(sUniqueWaterMarkID)) {
          sUniqueWaterMarkID = getRandomString(sWaterMarkId);
        } else {
          sReturn = sUniqueWaterMarkID;
          break;
        }
      }
    } catch (IMPException e) {
      throw new IMPException(e);
    }
    return sReturn;
  }
  
  /**
   * Gets the random string.
   *
   * @param sWaterMarkId the s water mark id
   * @return the random string
   */
  private static String getRandomString(String sWaterMarkId) {
    String sUniqueWaterMarkID = RandomStringUtils.random(20, sWaterMarkId.toCharArray());
    sUniqueWaterMarkID = sUniqueWaterMarkID.replaceAll("[^a-zA-Z0-9]", "0");
    return sUniqueWaterMarkID;
  }

  /**
   * Delete dir.
   *
   * @param dir the dir
   * @return true, if successful
   */
  public static boolean deleteDir(File dir) {
    if (dir.exists()) {
      if (dir.isDirectory()) {
        String[] children = dir.list();
        for (int i = 0; i < children.length; i++) {
          boolean success = deleteDir(new File(dir, children[i]));
          if (!success) {
            return false;
          }
        }
      }
      return dir.delete();
    }
    return true;
  }
  
  /**
   * Gets the module info.
   *
   * @param sMethod the s method
   * @param sModRoot the s IP name
   * @param strOption the str option
   * @return the module info
   * @throws IMPException the IMP exception
   */
  public static String getModuleInfo(String sModRoot) throws IMPException {
    String sValue = "";
    List<String> sCommands = new ArrayList<>();
    String strBranchValue = "";
    String strIPIDValue = "";
    String strIPDIRValue = "";
    String strIPTagValue = "";
    String strIPModSelector = "";
    try {
      IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
      sCommands.add("getModuleInfo");
      sCommands.add(IMPConstants.IMPCLI_IPDIR);
      sCommands.add(sModRoot);
      ProcessBuilder pbStcl = stclWrapper.getStclProcessBuilder(sCommands);
      pbStcl.redirectErrorStream(true);
      Process process = pbStcl.start();
      if (process.waitFor() == 0) {
        sValue = stclWrapper.output(process, false);
      }
      String[] lines = sValue.split("\r\n|\r|\n");
      
      String moduleInfoFromDesignSync="";
      List<String> stclWrapperOutput = new ArrayList(Arrays.asList(lines));
      for(int i = 0; i < stclWrapperOutput.size(); i++)
      {
          if((stclWrapperOutput.get(i)).contains("Successfully authenticated"))
        	  stclWrapperOutput.remove(i+1);
      }
      moduleInfoFromDesignSync = String.join("\n", stclWrapperOutput);
      IMPLog.debug("Get Design Sync Out: \n" + moduleInfoFromDesignSync);
      int i = lines.length - 1;
      sValue = lines[i];
      if (sValue.contains("Directory")) {
        sValue = "";
      } else if (!sValue.startsWith("__") && !sValue.startsWith(IMPConstants.IMP_ERROR)) {
        sValue = IMPConstants.IMP_ERROR;
      } else {
        String[] sArray = sValue.split("\\s+");
        strBranchValue = sArray[0];
        strBranchValue = strBranchValue.replaceAll("__BRANCH__=", "");
        IMPStclcWrapper.setStrBranch(strBranchValue);
        strIPIDValue = sArray[1];
        strIPIDValue = strIPIDValue.replaceAll("__IPID__=", "");
        IMPStclcWrapper.setStrIPID(strIPIDValue);
        strIPDIRValue = sArray[2];
        strIPDIRValue = strIPDIRValue.replaceAll("__IPDIR__=", "");
        IMPStclcWrapper.setStrDIR(strIPDIRValue);
        strIPModSelector = sArray[4];
        strIPModSelector = strIPModSelector.replaceAll("__MODSEL__=|:", "");
        IMPStclcWrapper.setStrModSelector(strIPModSelector);
        strIPTagValue = sArray[6];
        strIPTagValue = strIPTagValue.replaceAll("__MODTAG__=", "");
        IMPStclcWrapper.setStrTag(strIPTagValue);
      }
    } catch (IOException | InterruptedException exp) {
      throw new IMPException("Exception in getModuleInfo :", exp);
    }
    return sValue;
  }
  

  /**
   * Parses the JSON arrayto list.
   *
   * @param jsonArr the json arr
   * @return the list
   * @throws JSONException the JSON exception
   */
  public static List<String> parseJSONArraytoList(JSONArray jsonArr) throws JSONException {
    List<String> list = new ArrayList<>();
    for (int i = 0; i < jsonArr.length(); i++) {
      list.add(jsonArr.getString(i));
    }
    return list;
  }
  //Added for SWIMP-1 s
  
	public static Map<String, String> convertWMStringToMap(String strToConvertIntoMap) {
		Map<String, String> mpReturn = new HashMap<>();
		if (null != strToConvertIntoMap && !strToConvertIntoMap.isEmpty()) {
			for (String sWM : strToConvertIntoMap.split("\\|")) {
				if (null != sWM && !sWM.isEmpty()) {
					String[] saWMs = sWM.split("\\^");
					if (saWMs.length == 2 && null != saWMs[0] && null != saWMs[1]) {
						mpReturn.put(saWMs[0], saWMs[1]);
					}
				}
			}
		}
		return mpReturn;
	}
  
	public static String convertWMMapToString(Map<String, String> wmMap) {
		StringBuilder sRevisionWaterMarkID = new StringBuilder();
		if (null != wmMap && !wmMap.isEmpty()) {
			Iterator<Entry<String, String>> it = wmMap.entrySet().iterator();
			while (it.hasNext()) {
				Entry<String, String> pair = it.next();
				sRevisionWaterMarkID.append(pair.getKey());
				sRevisionWaterMarkID.append("^");
				sRevisionWaterMarkID.append(pair.getValue());
				sRevisionWaterMarkID.append("|");
			}
		}
		return sRevisionWaterMarkID.toString();
	}
  
  /**
   * @param mWMFile
   * @return
   * @throws Exception
   */
  public static String formatWMString(Map<String, String> mWMFile) {
  	String sFormattWM;
  	sFormattWM = Utility.convertWMMapToString(mWMFile).replace('|', ';').replace('^', ':').replace("singleDesignFile", "");
  	sFormattWM = sFormattWM.startsWith(":") ? sFormattWM.substring(1) : sFormattWM;
  	sFormattWM = sFormattWM.endsWith(";") ? sFormattWM.substring(0,sFormattWM.length()-1) : sFormattWM;
  	return sFormattWM;
  }
  //Added for SWIMP-1 e
  
	public static String[] getIpInfoCommand(String sFWM, Path strFile) {

		List<String> slipInfo = Utility.getIPinfoPathAndOptions();
		

		List<String> stclArgsLists = new ArrayList<>();
		stclArgsLists.addAll(slipInfo);
		
		stclArgsLists.add("-insert");
		stclArgsLists.add("-wm");
		stclArgsLists.add("TYP=IMP");
		stclArgsLists.add("-wm");
		stclArgsLists.add("BLMK=" + sFWM);
		stclArgsLists.add(strFile.toAbsolutePath().toString());

		String sCommands = StringUtils.join(stclArgsLists, ' ');
		IMPLog.trace(sCommands);
		String[] argsArray = new String[stclArgsLists.size()];
		stclArgsLists.toArray(argsArray);
		return argsArray;
	}
	//DLC:Device Legality Checker
	public static List<String> getDLCCommand(String tech, Path strFileForDLC, boolean isCDL) {
		List<String> stclArgsListsForCDL = new ArrayList<>();
		stclArgsListsForCDL.add(IMPConstants.IMP_DLC_CMD);
		stclArgsListsForCDL.add("-tech " + tech);
		stclArgsListsForCDL.add("-vdi");
		if(isCDL){
			stclArgsListsForCDL.add("-cdl");
		}
		stclArgsListsForCDL.add(strFileForDLC.toString());

		String sCommands = StringUtils.join(stclArgsListsForCDL, ' ');
		IMPLog.trace(sCommands);
		
		return stclArgsListsForCDL;
	}
	//LLC:Support
	public static List<String> getLLCCommand(String tech, Path strFileForLLC) {
		List<String> stclArgsListsForLLC = new ArrayList<>();
		stclArgsListsForLLC.add(IMPConstants.IMP_LLC_CMD);
		stclArgsListsForLLC.add("-tech " + tech);
		stclArgsListsForLLC.add("-vdi");
		stclArgsListsForLLC.add("-nocolor");
		stclArgsListsForLLC.add(strFileForLLC.toString());
		String sCommands = StringUtils.join(stclArgsListsForLLC, ' ');
		IMPLog.trace(sCommands);
		
		return stclArgsListsForLLC;
	}
	
		public static List<String> getSoCIPscore(String sProjectName, Path strInfoWMFile) {
		List<String> stclArgsListsForSoCIPscore = new ArrayList<>();
		stclArgsListsForSoCIPscore.add(IMPConstants.IMP_SOC_IPSCORE);
		stclArgsListsForSoCIPscore.add("-s");
		stclArgsListsForSoCIPscore.add(sProjectName);
		stclArgsListsForSoCIPscore.add("-w");
		stclArgsListsForSoCIPscore.add(strInfoWMFile.toAbsolutePath().toString());
		stclArgsListsForSoCIPscore.add("-q");
		String sCommands = StringUtils.join(stclArgsListsForSoCIPscore, ' ');
		IMPLog.trace(sCommands);
		return stclArgsListsForSoCIPscore;

	}
	
	
	public static String[] getGenWMCellCommand(String ipID, String ipRev, String strWaterMarkString, String wmkDir,
			String techStackVal, String derView, String imp3pipWatermarkRunPath) {
		List<String> comParams = new ArrayList<>();
		String reqID = "3PIP_WM_REQID" + System.currentTimeMillis();
		comParams.add(imp3pipWatermarkRunPath);
		comParams.add("-id");
		comParams.add(ipID);
		comParams.add("-rev");
		comParams.add(ipRev);
		comParams.add("-uid");
		comParams.add(strWaterMarkString);
		comParams.add("-wmkdir");
		comParams.add(wmkDir);
		comParams.add("-r");
		comParams.add(reqID);
		comParams.add("-techstack");
		comParams.add(techStackVal);
		if (!derView.isEmpty())
			comParams.add(derView);

		String[] commands = new String[comParams.size()];
		commands = comParams.toArray(commands);
		IMPLog.trace(imp3pipWatermarkRunPath + " -id " + ipID + " -rev " + ipRev + " -uid " + strWaterMarkString
				+ " -wmkdir " + wmkDir + " -r " + reqID + " -techstack " + techStackVal + " " + derView);
		return commands;
	}

	  /**
	   * Added for SWIMP-133
	   * Validates if the branch exist or if any revision has been published for that branch
	   * @param jsBranchInfo the JSON object
	   * @return the int
	   */
	public static int validateBranchandRevisionfromTag(org.codehaus.jettison.json.JSONObject jsBranchInfo, String strTag) throws JSONException {
		int iReturn = 0;
		try{
			boolean bBranchExists = (boolean) jsBranchInfo.get("BRANCHEXISTS");
			boolean bAnyRevisionPublishedforBranch = (boolean) jsBranchInfo.get("ANYREVISIONPUBLISHEDFORBRANCH");
		    String sBranchName = (String) jsBranchInfo.get("BRANCHNAME");
		    IMPCommon.setsBranch(sBranchName);
	        if (!bBranchExists) {
	        	iReturn= 70;
			} else  if (!bAnyRevisionPublishedforBranch){
				iReturn= 71;
			}
           if(iReturn==0){
				boolean bRevExists = (boolean) jsBranchInfo.get("REVISIONEXISTS");
				if (!bRevExists) {
					IMPCommon.setsTag(strTag);
					iReturn= 58;
				}
           }
		} catch (JSONException e) {
			log.error("Exception", e);
			throw e;
		}
        return iReturn;
	  }
	
	//Added for SWIMP-56:Starts
	public static String convertMapToYamlString(Map<String, Object> objMap){
		final DumperOptions options = new DumperOptions();
		options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
		options.setPrettyFlow(true);
		Yaml exportYamFile = new Yaml(options);
		return exportYamFile.dump(objMap);
	}
	//Added for SWIMP-56:Ends

	public static boolean isDirCreated() {
		return hasDirCreated;
	}

	public static void setDirCreated(boolean hasDirCreated) {
		Utility.hasDirCreated = hasDirCreated;
	}

	public static String getCreatedDirName() {
		return createdDirName;
	}

	public static void setCreatedDirName(String createdDirName) {
		Utility.createdDirName = createdDirName;
	}
	
	//Added for SWIMP-262 --Starts
	/**
	 * This method is to check the access of the Enovia Objects like IP, SoC and Dtree spec
	 * 
	 * @param sUserName the user name
	 * @param sObjectType the Object type
	 * @param sObjectName the Object name
	 * @param sCommand the Command name
	 * @param sEvent the Event
	 * @return integer
	 * @throws IMPException, JSONException, IOException 
	 */
	public static int checkAccess(String sUserName, String sObjectType, String sObjectName, String sCommand,
			String sEvent) throws IMPException, JSONException {
		int iAccess = 0;
		IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
		org.codehaus.jettison.json.JSONObject jsnInfo = enoviaWrapper.checkAccessForObject(sUserName, sObjectType,
				sObjectName, sCommand, sEvent);
		if (jsnInfo.length() > 0) {
			//Updated for SWIMP-318 - s
			org.codehaus.jettison.json.JSONObject jsQaValInput = null;
			if(jsnInfo.has("QA_VAL_INPUT")) {
				jsQaValInput = (JSONObject) jsnInfo.get("QA_VAL_INPUT");
			}
			//Updated for SWIMP-318 - e
			if (IMPConstants.getRestrictedCommands().contains(sCommand) && jsQaValInput != null
					&& ("Public Restricted").equalsIgnoreCase(jsQaValInput.getString("IP_ACCESS_CONTROL_PROTECTION"))) {
				String sPQDN = IMPCommon.getImpDomain().substring(IMPCommon.getImpDomain().indexOf('.') + 1);
				List<String> lRestrictedCountries = Arrays.asList(IMPConstants.IMP_RESTRIICTED_COUNTRIES.split(";"));
				if (lRestrictedCountries.contains(IMPStclcWrapper.getUserSite(sUserName))) {
					iAccess = 26;
				} else if (lRestrictedCountries.contains(IMPConstants.getPQDNSiteMapping().get(sPQDN))) {
					iAccess = 84;
				}
			}
			if (iAccess == 0) { // If it is not restricted User or Site then check access
				iAccess = getRetCode(sObjectType, jsnInfo.getInt("code"), sCommand);
			}
		} else {
			IMPLog.error("Exception in checkAccess: " + jsnInfo);
		}
		return iAccess;
	}

	/**
	 * This method is to return the integer code based on the type of the Enovia objects and its access return code
	 * 
	 * @param sObjectType the Object type
	 * @param iReturn access return code from Enovia JPO for Enovia Object
	 * @param sCommand the command name
	 * @return integer
	 */
	private static int getRetCode(String sObjectType, int iReturn, String sCommand) {
		int iAccess = 0;
		if (IMPConstants.IMP_CONST_TYPE_IMPSOC.equals(sObjectType)) {
			if (iReturn == 1) {
				iAccess = 76;
			} else if (iReturn == 2){
				iAccess = 78;
			}
		} else if (IMPConstants.IMP_CONST_TYPE_IPPRODUCT.equals(sObjectType)) {
			if (iReturn == 1) {
				//Return 83 for Prepare-sa, Make-branch and Switch-branch commands, else return 75
				iAccess = (IMPConstants.IMP_CLI_PROCEDURE_PREPARE_SA.equals(sCommand) || IMPConstants.IMP_CLI_PROCEDURE_MAKE_BRANCH.equals(sCommand)
						|| IMPConstants.IMP_CLI_PROCEDURE_SWITCH_BRANCH.equals(sCommand)) ? 83 : 75;
			} else if (iReturn == 2) {
				iAccess = 10;
			} else if (iReturn == 6) {
				iAccess = 17;
			} else if (iReturn == 9) {
				iAccess = 26;
			}
		} else if (IMPConstants.IMP_CONST_TYPE_IMPDTREESPEC.equals(sObjectType)) {
			return iReturn;
		}
		return iAccess;
	}
	//Added for SWIMP-262 --Ends

	/**
	 * The method gets the system environment variable based on the value passed. If
	 * the system value is not found it returns the default value
	 *
	 * Added for SWIMP-328
	 *
	 * @param sEnvVariableName the Env Variable name
	 * @param sEnvVariableDefaultValue the Environment variable default value
	 * @return String
	 */
	public static String getEnvironmentVariable(String sEnvVariableName, String sEnvVariableDefaultValue) {
		String sEnvVariableValue = System.getenv(sEnvVariableName) == null ? ""
				: System.getenv(sEnvVariableName).trim();
		if (StringUtils.isEmpty(sEnvVariableValue)) {
			sEnvVariableValue = sEnvVariableDefaultValue;
		} else {
			IMPLog.trace("Using user specified value of " + sEnvVariableName + " (" + sEnvVariableValue + ")");
		}
		return sEnvVariableValue;
	}


	//Added for SWIMP-383: Starts
	/**
	 * Checks if the given directory existing or not in the parent IP directory. If not, it creates the directory
	 *
	 * @param sPath, directory should need to be created
	 * @return integer, return code 0 or 1, 0 - success, 1 - failure
	 * @throws RuntimeException if there is directory creation failure
	 */
	public static int createDirectory (String sPath) {
		int iReturn = 0;
		File dDirectory = new File(sPath);
		String sDirectoryName = dDirectory.getName();
		if(!dDirectory.exists()) {
			IMPLog.info("Creating missing '"+sDirectoryName+"' directory in the design data...");
			try {
				dDirectory.mkdir();
			} catch (RuntimeException re) {
				iReturn = 1;
				IMPLog.error("'"+sDirectoryName+"' directory creation failed. \nError: " + re);
			}
		}
		return iReturn;
	}
	//Added for SWIMP-383: Ends


	//Added for SWIMP-425: Starts
	/**
	 * This method is to process Technology Stacks for external tools
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param sIPID, IPID
	 * @param sToolName, the external tool name
	 * @return integer, return code 0 or 1, 0 - success, 1 - failure
	 * @throws IOException / JSONException / IMPException, if there is any failures
	 */
	public static List<String> getTechStackMappingsForExternalTools(String sIPID, String sToolName) throws IOException, JSONException, IMPException {
		List<String> lsFinalTechStackMapList = new ArrayList<>();
		//Get TechStacks for IP
		List<Map<String, Object>> lTechStackInfo = getTechStacksForIPProduct(sIPID);
		String strExceptionFileTechStackMapping = "";

		//Check if the Exception file has any entry of IP TechStacks - process
		IMPLog.trace("Checking for IP tech stack matches in "+ IMPConstants.IMP_TECHSTACK_EXCEPTION_FILE);
		//Get the Exception file map
		Map<String, Object> mpExceptionTechStackMap = readTechStackExceptionFile();
		if (!lTechStackInfo.isEmpty()) {
			for (int i = 0 ; lTechStackInfo.size() > i ; i++) {
				Map<String, Object> mpTechStackMap = lTechStackInfo.get(i);
				//Check the IP technology stack matches with the Exception file map
				strExceptionFileTechStackMapping = getTechStackMappingFromTechStackExceptionFile(mpTechStackMap, mpExceptionTechStackMap, sToolName);
				if (strExceptionFileTechStackMapping.isEmpty()) {
					IMPLog.trace("No exception mapping found for the tech stack: "+mpTechStackMap);
					//Get tool based mapping
					String strToolBasedMapping = getToolBasedMapping(sToolName);

					if (!strToolBasedMapping.isEmpty()) {
						IMPLog.trace("Using the default mapping of '"+strToolBasedMapping+"' for '"+sToolName+"'.");
						//Convert Technology Stack map into tool specific map
						strExceptionFileTechStackMapping = convertTechStackMappingIntoToolSpecific(mpTechStackMap, strToolBasedMapping);
						lsFinalTechStackMapList.add(strExceptionFileTechStackMapping);
					} else {
						IMPLog.error("No mapping available for the tool '"+sToolName+"';");
					}
				} else {
					lsFinalTechStackMapList.add(strExceptionFileTechStackMapping);
				}
			}
		} else {
			IMPLog.error("No techstack(s) found for IP '"+sIPID+"'.");
		}
		return lsFinalTechStackMapList;
	}
	


	/**
	 * This method is to Check Exception file exists in the given path or not and if exists, get the Exception TechStack Map
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @return Map mpExceptionFileMap, Exception TechStack Map
	 * @throws IOException, if there is any failures
	 */
	@SuppressWarnings("unchecked")
	private static Map<String, Object> readTechStackExceptionFile() {
		Map<String, Object> mpExceptionFileMap = new HashMap<>();
		Yaml exceptionYamlFile = new Yaml();
		try {
			File fIMPToolPath = new File(IMP.class.getProtectionDomain().getCodeSource().getLocation().getPath());
			Path pthExceptionFile = Paths.get(fIMPToolPath.getParent()).getParent()
					.resolve(IMPConstants.IMP_CLI_ETC_FOLDER).resolve(IMPConstants.IMP_TECHSTACK_EXCEPTION_FILE);
			if (pthExceptionFile.toFile().exists()) {
				IMPLog.trace("Using the mapping exceptions file  "+pthExceptionFile.toString());
				mpExceptionFileMap = (Map<String, Object>) exceptionYamlFile.load(new FileReader(pthExceptionFile.toString()));
			} else {
				IMPLog.error("ERROR: Internal Error: '"+pthExceptionFile.toString()+"' not found.");
			}
		} catch (IOException e) {
			IMPLog.error("Exception in the method readTechStackExceptionFile: " + e);
		}
		return mpExceptionFileMap;
	}


	/**
	 * Method for getting IP TechStack values
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param sIPID, IPID
	 * @return lIPTechStackInfo, List of IP Technology Stack values
	 * @throws IMPException, JSONException, IOException, if fails
	 */
	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> getTechStacksForIPProduct(String sIPID) throws IMPException, IOException, JSONException {

		List <Map<String, Object>> lIPTechStackInfo = IMPCommon.getTechStackList();
		if (lIPTechStackInfo.isEmpty()) {
			IMPLog.trace("Processing for getting the tech stack(s) from IMP.");
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			org.codehaus.jettison.json.JSONObject retJsonObject = enoviaWrapper.getTechStacks(sIPID);
			if (retJsonObject.getJSONArray(sTechnologyStacks)!=null) {
				lIPTechStackInfo =  new ObjectMapper()
						.readValue(retJsonObject.getJSONArray(sTechnologyStacks).toString(), ArrayList.class);
			}
			IMPCommon.setTechStackList(lIPTechStackInfo); //Set the TechStack global
		}
		return lIPTechStackInfo;
	}
	
	@SuppressWarnings("unchecked")
	public static List<Map<String, Object>> getSoCTechStacks(String sSOCID) throws IMPException, IOException, JSONException {
	
	
		List <Map<String, Object>> lIPTechStackInfo = new ArrayList<>();
		IMPLog.trace("Processing for getting the tech stack(s) from IMP.");
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			org.codehaus.jettison.json.JSONObject retJsonObject = enoviaWrapper.getSoCTechStacks(sSOCID);
			if (retJsonObject.getJSONArray(sTechnologyStacks)!=null) {
				lIPTechStackInfo =  new ObjectMapper()
						.readValue(retJsonObject.getJSONArray(sTechnologyStacks).toString(), ArrayList.class);
			}
		return lIPTechStackInfo;
	}
	
	
		@SuppressWarnings("unchecked")
	public static void setDLCAttributesToVerifyid(String sVerifyid, String iDCLCDLResult, String strDCLCDLOutput, String iDCLOASResult, String strDCLOASOutput) throws IMPException, IOException, JSONException {
	
		IMPLog.trace("setting DLC return and output to IMP");
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			 enoviaWrapper.setDLCAttributesToVerifyid(sVerifyid, iDCLCDLResult, strDCLCDLOutput, iDCLOASResult, strDCLOASOutput);
	}
	
	
	@SuppressWarnings("unchecked")
	public static void setLLCAttributesToVerifyid(String sVerifyid, String iLLCOASResult, String strLLCOASOutput) throws IMPException, IOException, JSONException {
	
		IMPLog.trace("setting LLC return and output to IMP");
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			 enoviaWrapper.setLLCAttributesToVerifyid(sVerifyid, iLLCOASResult, strLLCOASOutput);
	}
	
	@SuppressWarnings("unchecked")
	public static void setIpScoreAttributesToVerifyid(String sVerifyid,String sIpScoreResults) throws IMPException, IOException, JSONException {
	
		IMPLog.trace("setting IpScore output to IMP");
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			 enoviaWrapper.setIpScoreAttributesToVerifyid(sVerifyid, sIpScoreResults);
	}
	


	/**
	 * This method is to get the TechStack mapping for processed IPTechStack if the exception file has the same entry
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param sToolName
	 * @param Map mpIPTechStacks, IPTechStacks
	 * @param Map mpExceptionTechStackMap, TechStacks which are marked as Exception list from the Exception file
	 * @param String sToolName, tool name
	 * @return String strReturnExceptionMap, exception TechStack map
	 * @throws RuntimeException, if there is any failures
	 */
	@SuppressWarnings("unchecked")
	private static String getTechStackMappingFromTechStackExceptionFile(Map<String, Object> mpIPTechStacks, Map<String, Object> mpExceptionTechStackMap, String sToolName)  {
		String sFoundry = (String) mpIPTechStacks.get(IMPConstants.IMP_TECHSTACK_ATTR_FOUNDRY);
		String sProcessNode = (String) mpIPTechStacks.get(IMPConstants.IMP_TECHSTACK_ATTR_PROCESSNODE);
		String sSubProcess = (String) mpIPTechStacks.get(IMPConstants.IMP_TECHSTACK_ATTR_SUBPROCESS);
		String sMetalStack = (String) mpIPTechStacks.get(IMPConstants.IMP_TECHSTACK_ATTR_METALSTACK);
		List<String> lsIPTechStacks = new ArrayList<>();
		lsIPTechStacks.add(sFoundry);
		lsIPTechStacks.add(sProcessNode);
		lsIPTechStacks.add(sSubProcess);
		lsIPTechStacks.add(sMetalStack);
		lsIPTechStacks.add(sToolName);
		strReturnExceptionTechStackMapping = "";
		try {
			if (!mpExceptionTechStackMap.isEmpty()) {
				lExceptionMap = (List<Map<String, Object>>) mpExceptionTechStackMap.get(IMPConstants.IMP_TECHSTACK_ATTR_FOUNDRY);
				lsIPTechStacks.stream().forEach(lTechStack -> lExceptionMap.stream().filter(exceptionTechStack -> exceptionTechStack.containsValue(lTechStack))
						.forEach(listValue -> listValue.entrySet().stream().filter(list -> !list.getKey().contains(IMPConstants.MAPKEY_NAME))
								.forEach(techStackData -> {
									if (techStackData.getValue() instanceof List) {
										lExceptionMap = (List<Map<String, Object>>) techStackData.getValue();
									} else {
										strReturnExceptionTechStackMapping = (String) techStackData.getValue();
									}
								})
								)
						);
			} else {
				IMPLog.error("No exceptions found.");
			}
		} catch (RuntimeException re) {
			IMPLog.error("Exception in getTechStackMappingFromTechStackExceptionFile: "+re);
		}
		return strReturnExceptionTechStackMapping;
	}
	


	/**
	 * This method is to get tool based mapping from Property file
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param sToolName, the external tool name
	 * @return String strToolMapper, Map for given tool name
	 */
	public static String getToolBasedMapping(String sToolName){
		String strToolMapper = "";
		//Get all mappings with tool name from property file
		Map<String, String> mpAllMaps = IMPConstants.getAllToolMappings();
		if (!mpAllMaps.isEmpty()) {
			strToolMapper = mpAllMaps.get(sToolName);
		}
		return strToolMapper;
	}


	/**
	 * This method is to process TechStack Map for case conversion by replacing the map var with actual TechStack values
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param Map mpTechnologyStack, Map contains 3PIP TechStack values
	 * @param strToolBasedMapping, Tool Based Map from property file
	 * @return String strTSMapper, Final converted tool based map
	 */
	private static String convertTechStackMappingIntoToolSpecific(Map<String, Object> mpTechnologyStack, String strToolBasedMapping) {
		String strTSMapper = "";
		if (!mpTechnologyStack.isEmpty() && StringUtils.isNotBlank(strToolBasedMapping)) {
			strTSMapper = strToolBasedMapping;
			String sFoundry = (String) mpTechnologyStack.get(IMPConstants.IMP_TECHSTACK_ATTR_FOUNDRY);
			String sProcessNode = (String) mpTechnologyStack.get(IMPConstants.IMP_TECHSTACK_ATTR_PROCESSNODE);
			String sSubProcess = (String) mpTechnologyStack.get(IMPConstants.IMP_TECHSTACK_ATTR_SUBPROCESS);
			String sMetalStack = (String) mpTechnologyStack.get(IMPConstants.IMP_TECHSTACK_ATTR_METALSTACK);
			List<String> lsIPTechStacksAttrVal = new ArrayList<>();
			lsIPTechStacksAttrVal.add(sFoundry);
			lsIPTechStacksAttrVal.add(sProcessNode);
			lsIPTechStacksAttrVal.add(sSubProcess);
			lsIPTechStacksAttrVal.add(sMetalStack);
			int iKey = 0;

			for (int i = 0; lsIPTechStacksAttrVal.size() > i ; i++) {
				iKey = i + 1;
				if (StringUtils.isNotBlank(lsIPTechStacksAttrVal.get(i))) {
					strTSMapper =  strTSMapper.replace("$"+iKey, lsIPTechStacksAttrVal.get(i));
				} else {
					strTSMapper =  strTSMapper.replace("$"+iKey, "");
				}
			}
			strTSMapper = techStackMappingCaseConversion(strTSMapper);
		}
		return strTSMapper;
	}


	/**
	 * This method is to convert the TechStack map based on string contains lowerCase or upperCase
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param strToolBasedMapping, Tool Based Map
	 * @return String strToolBasedMapping, case converted map
	 */
	public static String techStackMappingCaseConversion(String strToolBasedMapping) {
		String regEx = "";
		if (StringUtils.contains(strToolBasedMapping, IMPConstants.REGX_LOWERCASE)) {
			regEx = IMPConstants.REGX_LOWERCASE;
		} else if (StringUtils.contains(strToolBasedMapping, IMPConstants.REGX_UPPERCASE)) {
			regEx = IMPConstants.REGX_UPPERCASE;
		}
		if (StringUtils.isNotBlank(regEx)) {
			char cNextChar = StringUtils.substringAfter(strToolBasedMapping, regEx).charAt(0);
			if (!Character.isLetter(cNextChar) && !Character.isDigit(cNextChar)) {
				List<String> arList = getBalancedPairsOfBracesAndRegEx(cNextChar);
				String strBalancedNextChar = arList.get(0);
				String strRegExpression = arList.get(1);
				int iFirstIndex = strToolBasedMapping.indexOf(regEx);
				int iSecondIndex = strToolBasedMapping.indexOf(strBalancedNextChar) + 1;
				if (iFirstIndex >= iSecondIndex) {
					regEx = IMPConstants.REGX_UPPERCASE;
					iFirstIndex = strToolBasedMapping.indexOf(regEx);
				}
				String strTarget = strToolBasedMapping.substring(iFirstIndex, iSecondIndex );
				String strReplacement = getReplacementString(strToolBasedMapping, strRegExpression, strTarget, regEx, iSecondIndex);
				if (!strTarget.isEmpty() && !strReplacement.isEmpty()) {
					strToolBasedMapping = techStackMappingCaseConversion(strToolBasedMapping.replace(strTarget, strReplacement));
				}
			}
		}
		return strToolBasedMapping;
	}


	/**
	 * This method is to get the balances pair of Braces or Brackets for RegEx conversion method
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param cNextChar, Open Brace or open Parenthesis or Brackets
	 * @return List<String>, List contains, the closed Brace or parenthesis or brackets and matching RegEx Pattern
	 */
	public static List<String> getBalancedPairsOfBracesAndRegEx(char cNextChar) {
		List<String> returnList = new ArrayList<>();
		Character cBalancedChar = 0;
		String strRegEx = "";
		if (cNextChar == '(') {
			cBalancedChar = ')';
			strRegEx = "\\((.*?)\\)";
		} else if (cNextChar == '{') {
			cBalancedChar = '}';
			strRegEx = "\\{(.*?)\\}";
		} else if (cNextChar == '[') {
			cBalancedChar = ']';
			strRegEx = "\\[(.*?)\\]";
		}
		returnList.add(Character.toString(cBalancedChar));
		returnList.add(strRegEx);
		return returnList;
	}


	/**
	 * This method is to get replacement string for target string
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param String strToolBasedMapping, Tool Based Map
	 * @param String strRegExpression, Regular Expression Pattern based on the open parenthesis/brace/bracket
	 * @param String strTarget, Replaceable / Target string
	 * @param String regEx, Matcher regular expression
	 * @param Integer iSecondIndex, closing parenthesis/brace/bracket index
	 * @return String strReplacement, Replacement string for Target string
	 */
	private static String getReplacementString(String strToolBasedMapping, String strRegExpression, String strTarget, String regEx,
			int iSecondIndex) {
		String strReplacement = "";
		Matcher matcher = Pattern.compile(strRegExpression).matcher(strToolBasedMapping.substring(strToolBasedMapping.indexOf(strTarget), iSecondIndex));
		while (matcher.find()) {
			if (!(StringUtils.isAllLowerCase(matcher.group(1)) && regEx.equalsIgnoreCase(IMPConstants.REGX_UPPERCASE))
					|| !(StringUtils.isAllUpperCase(matcher.group(1)) && regEx.equalsIgnoreCase(IMPConstants.REGX_LOWERCASE))) {
				strReplacement = (regEx.equalsIgnoreCase(IMPConstants.REGX_LOWERCASE)) ? matcher.group(1).toLowerCase() :  matcher.group(1).toUpperCase();
			}
		}
		return strReplacement;
	}


	/**
	 * This method is to prepare the process builder command for CHECKLAYERS tool call
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param checkLayerPath, CheckLayer script path
	 * @param strFile, the GDS/OAS file with its path
	 * @param strMetalStackMap, Tool based TechStack map
	 * @return String Array, Process Builder command
	 */
	public static String[] getCheckLayerProcessCommand(String checkLayerPath, Path strFile, String strMetalStackMap) {
		List<String> stclArgsLists = new ArrayList<>();

		stclArgsLists.add(checkLayerPath);
		stclArgsLists.add(strFile.toAbsolutePath().toString());
		stclArgsLists.add(strMetalStackMap);

		String sCommands = StringUtils.join(stclArgsLists, ' ');
		IMPLog.trace(sCommands);
		String[] argsArray = new String[stclArgsLists.size()];
		stclArgsLists.toArray(argsArray);
		return argsArray;
	}

	/**
	 * This method is to write output file
	 * Added for SWIMP-425 JIRA ticket, Modified for SWIMP-501
	 *
	 * @param ipPath, Path '../<IPDir>/imp', the path where output/error file should be written
	 * @param strOutputfile, the output/error file name to written
	 * @param sOutMessage, output/Error message to be written
	 * @param bAppend, append or not (true/false)
	 * @return Nothing
	 * @throws IOException, if there is any failures
	 */
	public static void writeOutputOrErrorFile(Path ipPath, String strOutputfile, String sOutMessage, boolean bAppend) throws IOException {
		String strFile = ipPath.resolve(strOutputfile).toString();
		File fOutputOrErrorFile = new File(strFile);
		FileWriter fw = new FileWriter(fOutputOrErrorFile, bAppend); //Modified for SWIMP-501
		try {
			if (fOutputOrErrorFile.createNewFile() || fOutputOrErrorFile.exists()) {
				fw.write(sOutMessage); //Modified for SWIMP-501
				fw.flush();
			}
		} catch (Exception e) {
			IMPLog.error("Exception in the method writeOutputOrErrorFile(): "+e);
		} finally {
			fw.close();
		}
	}

	/**
	 * This method is to get the checklayers.err file path
	 * Added for SWIMP-425 JIRA ticket
	 *
	 * @param sIpPath, IP Download directory
	 * @param sIPID, IPID
	 * @return Path, .err file path
	 */
	public static Path getCheckLayerErrorFile(String sIpPath, String sIPId) {
		Path clTempPath = Paths.get(sIpPath);
		Path clErrPath = clTempPath.resolve(IMPConstants.IMP_CLI_IMP_FOLDER).resolve(IMPConstants.IMP_CHECKLAYER_ERRORFILE);
		if (!clErrPath.toFile().exists()) {
			clErrPath = clTempPath.resolve(sIPId).resolve(IMPConstants.IMP_CLI_IMP_FOLDER).resolve(IMPConstants.IMP_CHECKLAYER_ERRORFILE);
			if (!clTempPath.resolve(sIPId).resolve(IMPConstants.IMP_CLI_IMP_FOLDER).resolve(IMPConstants.IMP_CHECKLAYER_ERRORFILE).toFile().exists()) {
				return null;
			}
		}
		//Check file is Empty or not
		File fErrorFile = new File (clErrPath.toString());
		if (fErrorFile.length() == 0) {
			return null;
		}
		return clErrPath;
	}
	//Added for SWIMP-425: Ends


	//Added for SWIMP-471: Addition to SWIMP-425: Starts
	/**
	 * This method is to get all design files.
	 * Added for SWIMP-425 JIRA ticket, Modified for SWIMP-471
	 *
	 * @param directory, the directory
	 * @return Nothing
	 * @throws IOException
	 */
	public static void getDesignFiles(Path dirPath) throws IOException {
		Set<Path> setFiles = new HashSet<>();

		try (Stream<Path> walk = Files.walk(dirPath)) {
			setFiles = walk.filter(path -> path.toFile().isFile()).filter(path -> (path.getFileName().toString().endsWith(".gds")
					|| path.getFileName().toString().endsWith(".gds2")
					|| path.getFileName().toString().endsWith(".oasis")
					|| path.getFileName().toString().endsWith(".oas")
					|| path.getFileName().toString().contains(".gds.gz")
					|| path.getFileName().toString().contains(".gds2.gz")
					|| path.getFileName().toString().contains(".oasis.gz")
					|| path.getFileName().toString().contains(".oas.gz")
					|| path.getFileName().toString().endsWith(".tar")
					|| path.getFileName().toString().contains(".tar.gz")
					|| path.getFileName().toString().endsWith(".tgz"))  && !path.getFileName().toString().endsWith(".swp")).collect(Collectors.toSet());//Modified for SWIMP-501

			if (!setFiles.isEmpty()) {//Added for SWIMP-492
				unTarAndGetDesignFiles(setFiles);//Added for SWIMP-471
			}
		} catch (IOException io) {
			IMPLog.error("Exception in getDesignFiles method: "+io);
		}
	}


	/**
	 * This method is to pass the output/error file information to create the respective file in the specified directory
	 * Added for SWIMP-425 JIRA ticket, Modified for SWIMP-471, 501
	 *
	 * @param Path ipPath, the IP path
	 * @param Map mpCLFile, Map contains file name and file contents which needs to written in the file
	 * @return nothing
	 */
	public static void writeCheckLayersFile(Path ipPath, Map<String, StringBuilder> mpCLFile) {
		mpCLFile.forEach((fileName, fileContent)-> {
			try {
				writeOutputOrErrorFile(ipPath.resolve(IMPConstants.IMP_CLI_IMP_FOLDER), fileName, fileContent.toString(), false);//Modified for SWIMP-501
			} catch (IOException ie) {
				IMPLog.error("Exception in method writeCheckLayersFile(): "+ie);
			}
		});
	}


	/**
	 * This method is to delete the files from given path
	 * Added for SWIMP-425 JIRA ticket, Modified for SWIMP-471
	 *
	 * @param Path path, the path from where the files needs to be deleted.
	 * @param List lsFiles, List of deleting files
	 * @return nothing
	 */
	public static void deleteFiles(Path path, List<String> lsFiles) throws IOException {
		for (String strFile : lsFiles) {
			if (path.resolve(strFile).toFile().exists()) {
				Files.delete(path.resolve(strFile));
			}
		}
	}


	/**
	 * This method for getting all the Design files including the files which is compressed/Tar
	 * Added for SWIMP-471, Modified for SWIMP-492
	 *
	 * @param setFiles, all design files
	 * @return nothing
	 * @throws IOException, if fails
	 */
	public static void unTarAndGetDesignFiles(Set<Path> setFiles) throws IOException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss.SSS"); //Modified for SWIMP-492
		String strTimeSTamp = sdf.format(System.currentTimeMillis());
		Path pTemporaryFolder = Paths.get(IMPConstants.IMP_CLI_TMP_FOLDER).resolve(IMPCommon.getImpUser().toUpperCase() + "_" + IMPCommon.getIpID() + "_" + strTimeSTamp);
		File fTempFile = new File(pTemporaryFolder.toString());

		for (Path pFilePath : setFiles) {
			if (pFilePath.toString().endsWith(".tar") || pFilePath.toString().contains(".tar.gz") || 
					pFilePath.toString().contains(".gds.gz") || pFilePath.toString().contains(".gds2.gz") || 
					pFilePath.toString().contains(".oasis.gz") || pFilePath.toString().contains(".oas.gz") || pFilePath.toString().endsWith(".tgz")) {
				//Added for SWIMP-492: Starts
				if (!fTempFile.exists()) {
					fTempFile.mkdirs();
					IMPCommon.setTemporaryFolder(pTemporaryFolder);
					IMPCommon.addDirPathToList(fTempFile);//Add all created temporary directories to a List
				}
				//Added for SWIMP-492: Ends
				extractTarFiles(pFilePath, pTemporaryFolder);
			} else {
				IMPCommon.addToSet(pFilePath);//Set files path to a Set(HashSet) variable
			}
		}

		//Added for SWIMP-492: Starts
		if (pTemporaryFolder.toFile().exists()) {
			getDesignFiles(pTemporaryFolder);
		}
		//Added for SWIMP-492: Ends
	}


	/**
	 * This method is to extract compressed/tar/GZ files
	 * Added for SWIMP-471, Modified for SWIMP-492, Modified for SWIMP-501
	 *
	 * @param Path pSourceFilePath, Source file path.
	 * @param Path pDestinationFilePath, Destination file path.
	 * @return nothing
	 * @throws IOException, if fails
	 */
	private static void extractTarFiles(Path pSourceFilePath, Path pDestinationFilePath) throws IOException {
		TarArchiveInputStream tis = null;
		GZIPInputStream gzipInputStream = null;
		File outputFile = null;
		String strIPBaseDirectoryPath = getIPBaseDirectoryPath(pSourceFilePath);//Added for SWIMP-492

		try (FileInputStream fis = new FileInputStream(pSourceFilePath.toString())) {//GZ
			if (pSourceFilePath.toString().contains(".tar.gz")  || pSourceFilePath.toString().contains(".tgz") || pSourceFilePath.toString().endsWith(".tar")) {
				//Modified for SWIMP-501: Starts
				try {
					if (pSourceFilePath.toString().endsWith(".tar")) {
						tis = new TarArchiveInputStream(fis);
					} else {
						gzipInputStream = new GZIPInputStream(new BufferedInputStream(fis));//.tar.gz
						tis = new TarArchiveInputStream(gzipInputStream);
					}
					TarArchiveEntry tarEntry = null;
					while ((tarEntry = tis.getNextTarEntry()) != null) {
						if(!tarEntry.isDirectory()){
							outputFile = new File(
									pDestinationFilePath + File.separator + IMPCommon.getIpID() + File.separator
									+ strIPBaseDirectoryPath + File.separator + new File(tarEntry.getName()).getName());
							IMPCommon.addToFileMap(outputFile.toString(), strIPBaseDirectoryPath + File.separator + Paths.get(tarEntry.getName()).getFileName());//Add files info to map
							outputFile.getParentFile().mkdirs();
							IOUtils.copy(tis, new FileOutputStream(outputFile));
						}
					}
				} catch (IOException io) {
					IMPCommon.setInvalidTarZIPFile(Paths.get(strIPBaseDirectoryPath).getParent() + File.separator + pSourceFilePath.getFileName()); //Added for SWIMP-501
				}
				//Modified for SWIMP-501: Ends
			} else {
				//Modified for SWIMP-501: Starts
				try {
					try (GZIPInputStream in = new GZIPInputStream(new FileInputStream(pSourceFilePath.toString()))) {
						String fileName = FilenameUtils.getBaseName(pSourceFilePath.toString());
						outputFile = new File(pDestinationFilePath + File.separator + IMPCommon.getIpID() + File.separator
								+ strIPBaseDirectoryPath);
						outputFile.mkdirs();
						IMPCommon.addToFileMap(outputFile + File.separator + fileName, strIPBaseDirectoryPath  + File.separator + fileName);
						IOUtils.copy(in, new FileOutputStream(outputFile + File.separator +fileName));
					}
				} catch (IOException io) {
					IMPCommon.setInvalidTarZIPFile(Paths.get(strIPBaseDirectoryPath).getParent() + File.separator + pSourceFilePath.getFileName());
				}
				//Modified for SWIMP-501: Ends
			}
		} finally {
			if (tis != null) {
				tis.close();
			}
			if (gzipInputStream != null ) {
				gzipInputStream.close();
			}
		}
	}


	/**
	 * This method is to Delete folders
	 * Added for SWIMP-471, Modified for SWIMP-492
	 *
	 * @param List<Strinig> lsDirPaths, List of file paths to be deleted.
	 * @return nothing
	 */
	public static void deleteFolders(List<String> lsDirPaths) {
		//Modified for SWIMP-492: Starts
		try {
			for (String strFilePath : lsDirPaths) {
				File fDir = new File(strFilePath);
				if (fDir.exists() && fDir.isDirectory()) {
					FileUtils.forceDelete(fDir);
				}
			}
		} catch (IOException io) {
			IMPLog.error("Exception in method deleteFolders : "+io);
		}
		//Modified for SWIMP-492: Ends
	}
	//Added for SWIMP-471: Addition to SWIMP-425: Ends


	//Added for SWIMP-492: Starts
	/**
	 * This method is to get IPBase path from the Source Path
	 * Added for SWIMP-492
	 *
	 * @param Path pSourceFilePath, Source file path.
	 * @return String, IP Base Path
	 * @throws IOException, if fails
	 */
	public static String getIPBaseDirectoryPath(Path pSourceFilePath) {
		Path ipPath = null;
		String strIpBaseFile = "";
		String strIPBaseFolderName = Paths.get(IMPCommon.getIpDIR()).getFileName().toString();
		String strIPBaseParameter = pSourceFilePath.toString().substring(0, pSourceFilePath.toString().indexOf(strIPBaseFolderName+File.separator));

		if (StringUtils.isNotBlank(strIPBaseParameter)) {
			ipPath = Paths.get(strIPBaseParameter +File.separator+IMPCommon.getIpID());
			strIpBaseFile = FilenameUtils.removeExtension(ipPath.relativize(pSourceFilePath).toString());
		} else {
			strIpBaseFile = FilenameUtils.removeExtension(pSourceFilePath.toString());
		}
		if (strIpBaseFile.contains(".oas") || strIpBaseFile.contains(".gds") || strIpBaseFile.contains(".gds2") || strIpBaseFile.contains(".oasis") || strIpBaseFile.contains(".tar")) {
			strIpBaseFile = FilenameUtils.removeExtension(strIpBaseFile);
		}
		if (strIpBaseFile.contains("../")) {
			strIpBaseFile = strIpBaseFile.replace("../", "");
		}
		return strIpBaseFile;
	}
	//Added for SWIMP-492: Ends
	
	// Added for SWIMP-31: Starts
	public static int warnUnDetectedWMandGetCount(String strUnavailableWM, StringBuilder sbOutWM,
			List<String> undetectedList) {

		String[] undeteWM = strUnavailableWM.split(",");
		int undetectedWaterMarks = undeteWM.length;
		StringTokenizer st = new StringTokenizer(strUnavailableWM, ",");
		sbOutWM.append("The Following watermarks (IP name/revision) were detected BUT NOT FOUND IN IMP:"
				+ System.lineSeparator());
		while (st.hasMoreTokens()) {
			String sWaterMark = st.nextToken();
			if (sWaterMark.startsWith(strIPXWM)) {
				String[] stringArray = sWaterMark.split("___");
				String strWMValue = stringArray[0].replaceAll(strIPXWM, "");
				sbOutWM.append(strWMValue + "/" + stringArray[2] + System.lineSeparator());
				undetectedList.add(strWMValue + "/" + stringArray[2]);
			} else {
				if (sWaterMark.contains(strInvalidWM)) { // Doing this replacement if the user wantedly added WM with , separated.
					sWaterMark = sWaterMark.replaceAll(strInvalidWM, ",");
				}
				sbOutWM.append(sWaterMark + System.lineSeparator());
				undetectedList.add(sWaterMark);
			}
		}
		if (!IMPCommon.getCommand().equalsIgnoreCase("Query")) //Added for SWIMP-570
			IMPLog.warn(sbOutWM.toString());
		return undetectedWaterMarks;
	}

	//SWIMP-31: Phase 2 - starts
	@SuppressWarnings("unchecked")
	public static void buildHIPStructure4EachDesignFile(Map<String, String> mWMCountInfo,
			Map<String, Map<String, Map<String, String>>> mDesignFileNameNwmObjInfo,
			Map<String, Map<String, Object>> mDesignFileNHIPChildInfo,
			Map<String, Map<String, String>> mDSFileNWMOrigInstanceCount, String sDesignFileName,
			StringBuilder sbMissingProgenyCount, Map<String, String> gdsSpecificChildInfoMap,
			Map<String, Map<String, String>> gdsSpecificLineageMap, Map<String, Map<String, Object>> mpLatestRevAndDeclaredUsageInfo ) { //Modified for SWIMP-568
		String strWMId = null;
		String strInstanceCount = null;
		String strIPIDrev = null;
		String strPrefixSpacer = "...";
		String strIPID = ""; //Added for SWIMP-31 (Phase-2)
		String strIPTag = ""; //Added for SWIMP-31 (Phase-2)
		//Added for SWIMP-568 : Starts
		String sLatestRevision = "";
		String sDeclaredForUse = "";
		String sIPSource = "";
		String sDesignFile = "";
		String sVendor = "";

		//Added for SWIMP-568 : Ends
		StringBuilder sbChildIPsToConnect = new StringBuilder();
		StringBuilder sbStructureDisplay = new StringBuilder();

		//Added for SWIMP-568 : Starts
		Map<String, Map<String, Object>> mpIPHierarchyFinalMap = new LinkedHashMap<>();
		Map<String, Object> mpWMIPReleaseInfo = mpLatestRevAndDeclaredUsageInfo.get(sDesignFileName);
		Map<String, Object> mpDetectedIPsListForYamlMap = new HashMap<>();
		//Added for SWIMP-568 : Ends

		List<String> lstWarningMessageForWMInstance = new ArrayList<>();//Added for SWIMP-31 (Phase-2)
		HashMap<String, String> lineageMap = new HashMap<>();
		Map<String, String> mWMObjInfo;
		Map<String, Map<String, String>> mIPIDnWMObjInfo = mDesignFileNameNwmObjInfo.get(sDesignFileName);
		Map<String, Object> mHIPnHIPChildInfo = mDesignFileNHIPChildInfo.get(sDesignFileName);
		Map<String, String> mIPIDNOrigWMCount = mDSFileNWMOrigInstanceCount.get(sDesignFileName);
		for (Map.Entry<String, String> mWmobjIdnCountInfo : mWMCountInfo.entrySet()) {
			strWMId = mWmobjIdnCountInfo.getKey();
			int iOriginalInstanceCount = Integer.parseInt(mIPIDNOrigWMCount.get(strWMId) == null ? "0" : mIPIDNOrigWMCount.get(strWMId)); //Added for SWIMP-31 (Phase-2)
			strInstanceCount = mWmobjIdnCountInfo.getValue();
			mWMObjInfo = mIPIDnWMObjInfo.get(strWMId);
			strIPID = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID); //Added for SWIMP-31 (Phase-2)
			strIPTag = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG); //Added for SWIMP-31 (Phase-2)
			strIPIDrev = getStrIPIDrev(strIPID, strIPTag, mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE));//Modified for SWIMP-31 (Phase-2)
			int iInstanceCount = Integer.parseInt(strInstanceCount);

			//Added for SWIMP-568 : Starts
			Map<String, Object> mpIpStructureData = new LinkedHashMap<>();
			Map<String, Object> mpWMLatestRevDeclaredUsageMap = (Map<String, Object>) mpWMIPReleaseInfo.get(strWMId);
			//Added for SWIMP-568 : Ends

			if (iInstanceCount > 0) {
				sbStructureDisplay.append(strIPIDrev);
				sbStructureDisplay.append(", Watermark=");
				sbStructureDisplay.append(getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)));
				sbStructureDisplay.append(", Count=");
				sbStructureDisplay.append(strInstanceCount + System.lineSeparator());
				sbChildIPsToConnect.append(strWMId).append("^").append(strInstanceCount).append("^").append(mWMObjInfo.get(sRefGetBlockIP)).append("|");
				if (lineageMap.containsKey(strWMId)) {
					lineageMap.put(strWMId, new StringBuilder(lineageMap.get(strWMId)).append(";").append(strIPIDrev + "#" + strInstanceCount).toString());
				} else {
					lineageMap.put(strWMId, strIPIDrev + "#" + strInstanceCount);
				}

				//Added for SWIMP-568 : Starts
				String sOwner = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPOWNER_FROM_IPWATERMARK);
				String sBU = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPBU_FROM_IPWATERMARK);
				String sAlert = mWMObjInfo.get(IMPConstants.ATTRIBUTE_ALERT_FROM_IPWATERMARK);
				sIPSource = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPSOURCE_FROM_IPWATERMARK);
				sDesignFile = mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE);
				sVendor = mWMObjInfo.get(IMPConstants.ATTRIBUTE_3PIPVENDOR_FROM_IPWATERMARK);
				sLatestRevision = (String) mpWMLatestRevDeclaredUsageMap.get(IMPConstants.CONST_LATESTREVISION);
				sDeclaredForUse = (String) mpWMLatestRevDeclaredUsageMap.get(IMPConstants.CONST_DECLATEDFORUSE);
				List<String> lsDeprecatedBy = (List<String>) mpWMLatestRevDeclaredUsageMap.get(IMPConstants.CONST_DEPRECATED_BY);
				String sDeprecatedBy = "";
				if (!lsDeprecatedBy.isEmpty()) {
					for (String sList : lsDeprecatedBy) {
						sDeprecatedBy = (StringUtils.isBlank(sDeprecatedBy)) ? sList : sDeprecatedBy.concat(", ").concat(sList);
					}
				}

				String sVRLineage = StringUtils.isNotBlank(IMPCommon.getIpID())
						? IMPCommon.getIpID() + ":" + IMPCommon.getsTag() + "|" + strIPIDrev
								: IMPCommon.getProjectName() + "|" + strIPIDrev;

				mpIpStructureData.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpIpStructureData.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpIpStructureData.containsKey(IMPConstants.CONST_BU))
						mpIpStructureData.remove(IMPConstants.CONST_BU);
				} else {
					mpIpStructureData.put(IMPConstants.CONST_BU, sBU);
					if (mpIpStructureData.containsKey(IMPConstants.CONST_VENDOR))
						mpIpStructureData.remove(IMPConstants.CONST_VENDOR);
				}
				mpIpStructureData.put(IMPConstants.CONST_REVISION, strIPTag);
				mpIpStructureData.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpIpStructureData.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpIpStructureData.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpIpStructureData.put(IMPConstants.CONST_ALERT, sAlert);
				mpIpStructureData.put(IMPConstants.CONST_LINEAGE, sVRLineage);
				mpIpStructureData.put(IMPConstants.CONST_WATERMARK, getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)));
				mpIpStructureData.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strInstanceCount));

				Map<String, Object> mpDetectedIPsMap = new LinkedHashMap<>();
				mpDetectedIPsMap.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpDetectedIPsMap.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_BU))
						mpDetectedIPsMap.remove(IMPConstants.CONST_BU);
				} else {
					mpDetectedIPsMap.put(IMPConstants.CONST_BU, sBU);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_VENDOR))
						mpDetectedIPsMap.remove(IMPConstants.CONST_VENDOR);
				}
				mpDetectedIPsMap.put(IMPConstants.CONST_REVISION, strIPTag);
				mpDetectedIPsMap.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpDetectedIPsMap.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpDetectedIPsMap.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpDetectedIPsMap.put(IMPConstants.CONST_ALERT, sAlert);
				mpDetectedIPsMap.put(IMPConstants.CONST_LINEAGE, sVRLineage);
				mpDetectedIPsMap.put(IMPConstants.CONST_WATERMARK, getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)));
				mpDetectedIPsMap.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strInstanceCount));
				mpDetectedIPsMap.put(IMPConstants.CONST_IPSOURCE, sIPSource);
				mpDetectedIPsMap.put(IMPConstants.CONST_DESIGNFILE, sDesignFile);
				mpDetectedIPsListForYamlMap.put(strIPID, mpDetectedIPsMap);
				//Added for SWIMP-568 : Ends

				if (sBlockIP.equals(mWMObjInfo.get(sRefGetBlockIP))) {
					List<Map<String, String>> lIPChildInfo = (List<Map<String, String>>) mHIPnHIPChildInfo.get(strWMId);
					gdsIPInfo(strPrefixSpacer, strIPIDrev, strInstanceCount, lIPChildInfo, mHIPnHIPChildInfo, mIPIDnWMObjInfo,lineageMap, sbStructureDisplay);
					mpIpStructureData.put(IMPConstants.CONST_CHILDREN, getIPHierarchyParentStructure(sVRLineage, strInstanceCount,
							lIPChildInfo, mHIPnHIPChildInfo, mIPIDnWMObjInfo, mpWMIPReleaseInfo)); //Added for SWIMP-568
				}
				mpIPHierarchyFinalMap.put(strIPID, mpIpStructureData); //Added for SWIMP-568
			} else if (iInstanceCount < 0) {
				int iOrigInstanceCount = Integer
						.parseInt(mIPIDNOrigWMCount.get(strWMId) == null ? "0" : mIPIDNOrigWMCount.get(strWMId));
				sbMissingProgenyCount.append(sDesignFileName).append(": ").append(iOrigInstanceCount - iInstanceCount)
				.append(" instances of ").append(strIPIDrev).append(" expected but only ")
				.append(iOrigInstanceCount).append(" found").append("\r\n");
				//Added for SWIMP-568 : Starts
				int iInstCount = iOrigInstanceCount - iInstanceCount;
				String sMsg = sDesignFileName + ": " + iInstCount + " instances of " + strIPIDrev + " expected but only " + iOrigInstanceCount + " found";
				IMPCommon.setWarnMessage(new StringBuilder(sMsg));
				//Added for SWIMP-568 : Ends
			} else {
				//Added for SWIMP-31 (Phase-2): Starts
				if (iOriginalInstanceCount == 0) {
					IMPCommon.setZeroInstanceIPCount(1);
					lstWarningMessageForWMInstance
					.add(sDesignFileName + ": instance count of 0 found for " + strIPID + "/" + strIPTag
							+ "; ignoring this revision and this may cause inconsistencies in IP hierarchy.");
					IMPCommon.setWarnMessage(new StringBuilder(sDesignFileName + ": instance count of 0 found for " + strIPID + "/" + strIPTag
							+ "; ignoring this revision and this may cause inconsistencies in IP hierarchy.")); //Added for SWIMP-568
				}
				//Added for SWIMP-31 (Phase-2): Ends
			}
		}
		IMPLog.info(System.lineSeparator() + sbStructureDisplay.toString());
		
		//Display Warning message on instance count is 0 for any IPID/TAG
		if (!lstWarningMessageForWMInstance.isEmpty()) {
			for (String sWarningMessage : lstWarningMessageForWMInstance) {
				IMPLog.warn(sWarningMessage);
			}
		}

		if(StringUtils.isNotBlank(sbChildIPsToConnect.toString())) {
			gdsSpecificChildInfoMap.put(sDesignFileName, sbChildIPsToConnect.toString());
		}
		if(!lineageMap.isEmpty()) {
			gdsSpecificLineageMap.put(sDesignFileName, lineageMap);
		}
		lsFinalDetectedIPsMapList.add(mpDetectedIPsListForYamlMap);
		IMPCommon.addStructureToIPHierarchyMap(sDesignFileName, mpIPHierarchyFinalMap);
	}


	public static String getWatermark(String sIPRevisionWatermark,String sIPXWaterMark) {
		return StringUtils.isNotBlank(sIPRevisionWatermark)?sIPRevisionWatermark:sIPXWaterMark;
	}
	
	@SuppressWarnings("unchecked")
	private static void gdsIPInfo(String strPrefixSpacer, String strLineage, String strInstanceCount,
			List<Map<String, String>> lmChildInfo, Map<String, Object> ipChildInfoObject,
			Map<String, Map<String, String>> wmObjInfoMapObject, HashMap<String, String> lineageMap, StringBuilder sbStructureDisplay) {
		String strChildWMId = null;
		Map<String, String> mWMObjInfo = null;
		String strWMInstanceCnt = null;
		String strMultipliedCnt = null;
		String strCurrentLineage = null;
		String strIPIDrev = null;
		if (lmChildInfo != null) { //Added for SWIMP-564
			for (Map<String, String> mipInfo : lmChildInfo) {
				strChildWMId = mipInfo.get(IMPConstants.KEY_ID);
				strWMInstanceCnt = mipInfo.get(IMPConstants.ATTRIBUTE_NOOFINSTANCES);
				mWMObjInfo = wmObjInfoMapObject.get(strChildWMId);
				strMultipliedCnt = Integer
						.toString(Integer.parseInt(strInstanceCount) * Integer.parseInt(strWMInstanceCnt));
				strIPIDrev = getStrIPIDrev(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID), mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG),
						mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE));
				strCurrentLineage = strLineage + "|" + strIPIDrev;
				String sWatermarkValue = getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)); //Added for SWIMP-568
				sbStructureDisplay.append(strPrefixSpacer).append(" [").append(strCurrentLineage).append(", Watermark=");
				sbStructureDisplay.append(sWatermarkValue); //Modified for SWIMP-568
				sbStructureDisplay.append(", Count=").append(strMultipliedCnt).append("]").append(System.lineSeparator());

				if (lineageMap.containsKey(strChildWMId)) {
					lineageMap.put(strChildWMId, new StringBuilder(lineageMap.get(strChildWMId)).append(";")
							.append(strCurrentLineage).append("#").append(strMultipliedCnt).toString());
				} else {
					lineageMap.put(strChildWMId, strCurrentLineage + "#" + strMultipliedCnt);
				}

				if (sBlockIP.equals(mWMObjInfo.get(sRefGetBlockIP))) {
					gdsIPInfo(strPrefixSpacer.concat(" ").concat(strPrefixSpacer), strCurrentLineage, strMultipliedCnt,
							(List<Map<String, String>>) ipChildInfoObject.get(strChildWMId), ipChildInfoObject,
							wmObjInfoMapObject, lineageMap, sbStructureDisplay);
				}
			}
		}
	}

	private static String getStrIPIDrev(String sIPID, String sIPTag, String sDesignFile) {
		String strIPIDrev = "";
		if (StringUtils.isNotBlank(sDesignFile)) {
			strIPIDrev = sIPID + ":" + sIPTag + "(" + sDesignFile + ")";
		} else {
			strIPIDrev = sIPID + ":" + sIPTag;
		}
		return strIPIDrev;
	}
	// Added for SWIMP-31 (Phase 2): Ends
	// Added for SWIMP-31: Ends


	//Added for SWIMP-554 : Starts
	/**
	 * This method is to get the Latest Tag of the IP using Branch and Module URL from Design Sync
	 * Added for SWIMP-554
	 *
	 * @param String sIPId, the IPID.
	 * @param String sBranch, the IP Branch.
	 * @param String sModuleUrl, the IP Module URL.
	 * @return Integer, Return value with success (0) or failure(Non-Zero) code
	 * @throws IOException/InterruptedException, if the operation fails
	 */
	public static int getLatestTagFromDS(String sIPId, String sBranch, String sModuleUrl) throws IOException, InterruptedException {
		int iReturn = 0;
		IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
		List<String> sCommands = new ArrayList<>();
		IMPStclcWrapper stclWrapper1 = new IMPStclcWrapper();
		sCommands.add("getLatestTag");
		sCommands.add("-I");
		sCommands.add(sModuleUrl);
		sCommands.add("-b");
		sCommands.add(sBranch);
		sCommands.add(IMPConstants.IMPCLI_IPID);
		sCommands.add(sIPId);
		sCommands.add("-latestRevision");
		sCommands.add(IMPConstants.DSKEY_LATEST);

		ProcessBuilder pbStcl = stclWrapper1.getStclProcessBuilder(sCommands);
		Process process = pbStcl.start();
		String sValue = stclWrapper.processOutput(process);

		try {
			int pValue = process.waitFor();
			IMPLog.trace("GetLatestTagFromDesignSync process status: " + pValue);
			if (pValue == 0) {
				sValue = stclWrapper.getSoutValue(sValue);
				IMPLog.debug("Getting latest tag of branch '" + sBranch + "': " + System.lineSeparator() + sValue);
				if (!sValue.trim().startsWith("Error:")) {
					IMPCommon.setLatestTag(stclWrapper.getSvalue(sValue));
				} else {
					sValue = sValue.replace("Error: ", "");
					iReturn = 2;
					IMPLog.error(sValue.trim());
				}
			}
		} catch (IOException ie) {
			iReturn = 1;
			IMPLog.error("Exception while getting the latest tag " + ie.getMessage());
		}
		return iReturn;
	}
	//Added for SWIMP-554 : Ends



	//Added for SWIMP-568 : Starts
	/**
	 * This method is to get IPHierarchy Structure Map
	 * Added for SWIMP-568
	 *
	 * @param strLineage, the Lineage
	 * @param strInstanceCount, the Instance count
	 * @param lmChildInfo, the detected IP info
	 * @param ipChildInfoObject, the Child IP Watermark information
	 * @param wmObjInfoMapObject, the Watermark information
	 * @param mpWMIPReleaseInfo, the Latest Revision and Declared Usage Info
	 * @return Map, holds map of Block IP connection or ip hierarchy details
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getIPHierarchyParentStructure(String strLineage, String strInstanceCount,
			List<Map<String, String>> lmChildInfo, Map<String, Object> ipChildInfoObject,
			Map<String, Map<String, String>> wmObjInfoMapObject, Map<String, Object> mpWMIPReleaseInfo) {
		Map<String, Object> mpChildrenStructureMap = new LinkedHashMap<>();
		String strChildWMId = "";
		String strWMInstanceCnt = "";
		String strMultipliedCnt = "";
		String strCurrentLineage = "";
		String strIPIDrev = "";
		String sIPID = "";
		String sOwner = "";
		String sBU = "";
		String sLatestRevision = "";
		String sDeclaredForUse = "";
		String sAlert = "";
		String sWatermarkValue = "";
		String sIPSource = "";
		String sDesignFile = "";
		String sVendor = "";

		Map<String, Object> mpDetectedIPsListForYamlMap = new HashMap<>();
		if (lmChildInfo != null) {
			for (Map<String, String> mipInfo : lmChildInfo) {
				Map<String, Object> mpChildHierarchyMap = new LinkedHashMap<>();
				Map<String, Object> mpDetectedIPsMap = new HashMap<>();
				strChildWMId = mipInfo.get(IMPConstants.KEY_ID);
				strWMInstanceCnt = mipInfo.get(IMPConstants.ATTRIBUTE_NOOFINSTANCES);
				Map<String, String> mWMObjInfo = wmObjInfoMapObject.get(strChildWMId);
				strMultipliedCnt = Integer.toString(Integer.parseInt(strInstanceCount) * Integer.parseInt(strWMInstanceCnt));
				strIPIDrev = getStrIPIDrev(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID), mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG), mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE));
				strCurrentLineage = strLineage + "|" + strIPIDrev;
				sWatermarkValue = getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK));
				Map<String, Object> mpIPRevisionInfo = (Map<String, Object>) mpWMIPReleaseInfo.get(strChildWMId);

				sOwner = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPOWNER_FROM_IPWATERMARK);
				sBU = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPBU_FROM_IPWATERMARK);
				sAlert = mWMObjInfo.get(IMPConstants.ATTRIBUTE_ALERT_FROM_IPWATERMARK);
				sIPSource = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPSOURCE_FROM_IPWATERMARK);
				sDesignFile = mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE);
				sVendor = mWMObjInfo.get(IMPConstants.ATTRIBUTE_3PIPVENDOR_FROM_IPWATERMARK);
				sLatestRevision = (String) mpIPRevisionInfo.get(IMPConstants.CONST_LATESTREVISION);
				sDeclaredForUse = (String) mpIPRevisionInfo.get(IMPConstants.CONST_DECLATEDFORUSE);
				List<String> lsDeprecatedBy = (List<String>) mpIPRevisionInfo.get(IMPConstants.CONST_DEPRECATED_BY);
				String sDeprecatedBy = "";
				if (!lsDeprecatedBy.isEmpty()) {
					for (String sList : lsDeprecatedBy) {
						sDeprecatedBy = (StringUtils.isBlank(sDeprecatedBy)) ? sList : sDeprecatedBy.concat(", ").concat(sList);
					}
				}
				sIPID = mWMObjInfo.containsKey(IMPConstants.ATTRIBUTE_IMP_IPID) ? mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID) : "";

				mpChildHierarchyMap.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpChildHierarchyMap.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpChildHierarchyMap.containsKey(IMPConstants.CONST_BU))
						mpChildHierarchyMap.remove(IMPConstants.CONST_BU);
				} else {
					mpChildHierarchyMap.put(IMPConstants.CONST_BU, sBU);
					if (mpChildHierarchyMap.containsKey(IMPConstants.CONST_VENDOR))
						mpChildHierarchyMap.remove(IMPConstants.CONST_VENDOR);
				}
				mpChildHierarchyMap.put(IMPConstants.CONST_REVISION, mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG));
				mpChildHierarchyMap.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpChildHierarchyMap.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpChildHierarchyMap.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpChildHierarchyMap.put(IMPConstants.CONST_ALERT, sAlert);
				mpChildHierarchyMap.put(IMPConstants.CONST_LINEAGE, strCurrentLineage);
				mpChildHierarchyMap.put(IMPConstants.CONST_WATERMARK, sWatermarkValue);
				mpChildHierarchyMap.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strMultipliedCnt));

				mpDetectedIPsMap.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpDetectedIPsMap.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_BU))
						mpDetectedIPsMap.remove(IMPConstants.CONST_BU);
				} else {
					mpDetectedIPsMap.put(IMPConstants.CONST_BU, sBU);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_VENDOR))
						mpDetectedIPsMap.remove(IMPConstants.CONST_VENDOR);
				}
				mpDetectedIPsMap.put(IMPConstants.CONST_REVISION, mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG));
				mpDetectedIPsMap.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpDetectedIPsMap.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpDetectedIPsMap.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpDetectedIPsMap.put(IMPConstants.CONST_ALERT, sAlert);
				mpDetectedIPsMap.put(IMPConstants.CONST_LINEAGE, strCurrentLineage);
				mpDetectedIPsMap.put(IMPConstants.CONST_WATERMARK, getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)));
				mpDetectedIPsMap.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strInstanceCount));
				mpDetectedIPsMap.put(IMPConstants.CONST_IPSOURCE, sIPSource);
				mpDetectedIPsMap.put(IMPConstants.CONST_DESIGNFILE, sDesignFile);
				mpDetectedIPsListForYamlMap.put(sIPID, mpDetectedIPsMap);

				if (sBlockIP.equals(mWMObjInfo.get(sRefGetBlockIP))) {
					mpChildHierarchyMap.put(IMPConstants.CONST_CHILDREN, getIPHierarchyChildInformation(strCurrentLineage, strMultipliedCnt,
							(List<Map<String, String>>) ipChildInfoObject.get(strChildWMId), wmObjInfoMapObject, mpWMIPReleaseInfo));
					mpChildrenStructureMap.put(sIPID, mpChildHierarchyMap);
				} else {
					mpChildrenStructureMap.put(sIPID, mpChildHierarchyMap);
				}
			}
		}
		lsFinalDetectedIPsMapList.add(mpDetectedIPsListForYamlMap);
		return mpChildrenStructureMap;
	}


	/**
	 * This method is to get IP Hierarchy for the child block IPs
	 * Added for SWIMP-568
	 *
	 * @param strLineage, the Lineage
	 * @param strInstanceCount, the Instance count
	 * @param lIPChildInfo, the detected IP info
	 * @param mIPIDnWMObjInfo, the IP and Child IP Watermark information
	 * @param mpWMIPReleaseInfo, the Latest Revision and Declared Usage Info
	 * @return Object, holds map of ip hierarchy details
	 */
	@SuppressWarnings("unchecked")
	private static Object getIPHierarchyChildInformation(String strLineage, String strInstanceCount,
			List<Map<String, String>> lIPChildInfo, Map<String, Map<String, String>> mIPIDnWMObjInfo, Map<String, Object> mpWMIPReleaseInfo) {
		Map<String, Object> mpProcessStructureMap = new LinkedHashMap<>();
		Map<String, Object> mReturnMap = new LinkedHashMap<>();
		String strWMInstanceCnt = "";
		String strMultipliedCnt = "";
		String strCurrentLineage = "";
		String strIPIDrev = "";
		String sOwner = "";
		String sBU = "";
		String sLatestRevision = "";
		String sDeclaredForUse = "";
		String sAlert = "";
		String sWatermarkValue = "";
		String sIPSource = "";
		String sDesignFile = "";
		String sVendor = "";

		Map<String, Object> mpDetectedIPsListForYamlMap = new HashMap<>();
		if (lIPChildInfo != null) {
			for (Map<String, String> mipInfo : lIPChildInfo) {
				Map<String, Object> mpDetectedIPsMap = new HashMap<>();
				String strChildWMId = mipInfo.get(IMPConstants.KEY_ID);
				Map<String, Object> mpIPRevisionInfo = (Map<String, Object>) mpWMIPReleaseInfo.get(strChildWMId);
				strWMInstanceCnt = mipInfo.get(IMPConstants.ATTRIBUTE_NOOFINSTANCES);
				Map<String, String> mWMObjInfo = mIPIDnWMObjInfo.get(strChildWMId);
				strMultipliedCnt = Integer.toString(Integer.parseInt(strInstanceCount) * Integer.parseInt(strWMInstanceCnt));
				strIPIDrev = getStrIPIDrev(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID), mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG), mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE));
				strCurrentLineage = strLineage + "|" + strIPIDrev;
				sWatermarkValue = getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK));

				sOwner = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPOWNER_FROM_IPWATERMARK);
				sBU = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPBU_FROM_IPWATERMARK);
				sAlert = mWMObjInfo.get(IMPConstants.ATTRIBUTE_ALERT_FROM_IPWATERMARK);
				sIPSource = mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPSOURCE_FROM_IPWATERMARK);
				sDesignFile = mWMObjInfo.get(IMPConstants.ATTRIBUTE_DESIGN_FILE);
				sVendor = mWMObjInfo.get(IMPConstants.ATTRIBUTE_3PIPVENDOR_FROM_IPWATERMARK);
				sLatestRevision = (String) mpIPRevisionInfo.get(IMPConstants.CONST_LATESTREVISION);
				sDeclaredForUse = (String) mpIPRevisionInfo.get(IMPConstants.CONST_DECLATEDFORUSE);
				List<String> lsDeprecatedBy = (List<String>) mpIPRevisionInfo.get(IMPConstants.CONST_DEPRECATED_BY);
				String sDeprecatedBy = "";
				if (!lsDeprecatedBy.isEmpty()) {
					for (String sList : lsDeprecatedBy) {
						sDeprecatedBy = (StringUtils.isBlank(sDeprecatedBy)) ? sList : sDeprecatedBy.concat(", ").concat(sList);
					}
				}

				mpProcessStructureMap.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpProcessStructureMap.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpProcessStructureMap.containsKey(IMPConstants.CONST_BU))
						mpProcessStructureMap.remove(IMPConstants.CONST_BU);
				} else {
					mpProcessStructureMap.put(IMPConstants.CONST_BU, sBU);
					if (mpProcessStructureMap.containsKey(IMPConstants.CONST_VENDOR))
						mpProcessStructureMap.remove(IMPConstants.CONST_VENDOR);
				}
				mpProcessStructureMap.put(IMPConstants.CONST_REVISION, mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG));
				mpProcessStructureMap.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpProcessStructureMap.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpProcessStructureMap.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpProcessStructureMap.put(IMPConstants.CONST_ALERT, sAlert);
				mpProcessStructureMap.put(IMPConstants.CONST_LINEAGE, strCurrentLineage);
				mpProcessStructureMap.put(IMPConstants.CONST_WATERMARK, sWatermarkValue);
				mpProcessStructureMap.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strMultipliedCnt));
				mReturnMap.put(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID), mpProcessStructureMap);

				mpDetectedIPsMap.put(IMPConstants.CONST_OWNER, sOwner);
				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpDetectedIPsMap.put(IMPConstants.CONST_VENDOR, sVendor);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_BU))
						mpDetectedIPsMap.remove(IMPConstants.CONST_BU);
				} else {
					mpDetectedIPsMap.put(IMPConstants.CONST_BU, sBU);
					if (mpDetectedIPsMap.containsKey(IMPConstants.CONST_VENDOR))
						mpDetectedIPsMap.remove(IMPConstants.CONST_VENDOR);
				}
				mpDetectedIPsMap.put(IMPConstants.CONST_REVISION, mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPTAG));
				mpDetectedIPsMap.put(IMPConstants.CONST_LATESTREVISION, sLatestRevision);
				mpDetectedIPsMap.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
				mpDetectedIPsMap.put(IMPConstants.CONST_DEPRECATED_BY, sDeprecatedBy);
				mpDetectedIPsMap.put(IMPConstants.CONST_ALERT, sAlert);
				mpDetectedIPsMap.put(IMPConstants.CONST_LINEAGE, strCurrentLineage);
				mpDetectedIPsMap.put(IMPConstants.CONST_WATERMARK, getWatermark(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPREVISIONWATERMARK),mWMObjInfo.get(IMPConstants.ATTRIBUTE_IPXWATERMARK)));
				mpDetectedIPsMap.put(IMPConstants.CONST_INSTANCECOUNT, Integer.parseInt(strInstanceCount));
				mpDetectedIPsMap.put(IMPConstants.CONST_IPSOURCE, sIPSource);
				mpDetectedIPsMap.put(IMPConstants.CONST_DESIGNFILE, sDesignFile);
				mpDetectedIPsMap.put(IMPConstants.CONST_IPSOURCE, sIPSource);
				mpDetectedIPsMap.put(IMPConstants.CONST_DESIGNFILE, sDesignFile);
				mpDetectedIPsListForYamlMap.put(mWMObjInfo.get(IMPConstants.ATTRIBUTE_IMP_IPID), mpDetectedIPsMap);
			}
		}
		lsFinalDetectedIPsMapList.add(mpDetectedIPsListForYamlMap);
		return mReturnMap;
	}


	/**
	 * This method is to get the detected IPs MapList for yaml
	 * Added for SWIMP-568
	 *
	 * @return Map, holds detected IPs list for the project/HIP
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getDetectedIPsFromMap() {
		Map<String, Object> mpDetectedIPsMap = new LinkedHashMap<>();
		String sExistingLineage = "";
		String sNewLineage = "";
		int iExistingInstanceCount = 0;
		int iNewInstanceCount = 0;

		if (!lsFinalDetectedIPsMapList.isEmpty()) {
			for (Map<String, Object> mpDetectedIPs : lsFinalDetectedIPsMapList) {
				for (Entry<String, Object> mpTempDetectedIPsData : mpDetectedIPs.entrySet()) {
					String sKey = mpTempDetectedIPsData.getKey();
					Map<String, Object> mpDetectedIPMap = (Map<String, Object>) mpTempDetectedIPsData.getValue();
					if (mpDetectedIPsMap.containsKey(sKey)) {
						StringBuilder sbLineageValue = new StringBuilder();
						Map<String, Object> mpTempMap = (Map<String, Object>) mpDetectedIPsMap.get(sKey);
						sExistingLineage = (String) mpTempMap.get(IMPConstants.CONST_LINEAGE);
						sNewLineage = (String) mpDetectedIPMap.get(IMPConstants.CONST_LINEAGE);
						iExistingInstanceCount = (int) mpTempMap.get(IMPConstants.CONST_INSTANCECOUNT);
						iNewInstanceCount = (int) mpDetectedIPMap.get(IMPConstants.CONST_INSTANCECOUNT);
						List<String> lsExistLineageArray = new ArrayList<>(Arrays.asList(sExistingLineage.split("\\,")));
						iNewInstanceCount += iExistingInstanceCount;

						if (!lsExistLineageArray.contains(sNewLineage)) {
							sbLineageValue.append(sExistingLineage).append(",").append(sNewLineage);
							mpDetectedIPMap.put(IMPConstants.CONST_LINEAGE, sbLineageValue.toString());
							mpDetectedIPMap.put(IMPConstants.CONST_INSTANCECOUNT, iNewInstanceCount);
							mpDetectedIPsMap.put(sKey, mpDetectedIPMap);
						}
					} else {
						mpDetectedIPsMap.put(sKey, mpDetectedIPMap);
					}
				}
			}
		}

		return mpDetectedIPsMap;
	}
	//Added for SWIMP-568 : Ends


	//Added for SWIMP-570 : Starts
	/**
	 * This method is to get the yaml output and ip detected structure for verifyruns on query consumed-ips execution
	 * Added for SWIMP-570
	 *
	 * @param JSONObject sYamlOutIPStructure, the ip_structure/hierarchy information.
	 * @param JSONObject sYamlVerifyRunDetails, the VerifyRun object information.
	 * @return Map, Returns yaml output which contains verified-ip hierarchy
	 * @throws JSONException/IOException, if the operation fails
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> getYamlOutputForVerifiedIPs(JSONObject sYamlOutIPStructure,
			JSONObject sYamlVerifyRunDetails) throws JSONException, IOException {
		StringBuilder sbIMPUnknownComponentWatermark = new StringBuilder();
		String sVerifyRunObjectName = (String) sYamlVerifyRunDetails.get(IMPConstants.KEY_VERIFY_OBJECTNAME);
		int iUndetectedWaterMarks = 0;

		Map<String, String> gdsSpecificChildInfoMap = new HashMap<>();
		Map<String, Map<String, String>> gdsSpecificLineageMap = new HashMap<>();
		IMPCommon.setVerifyRunName(sVerifyRunObjectName);

		Map<String, List<String>> mpList = new HashMap<>();
		Map<String, Map<String, String>> mDesignFileNCalculatedIPInstanceCountRef = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_REF_COUNT_MAP).toString(), Map.class);
		Map<String, Map<String, Map<String, String>>> mDesignFileNameNwmObjInfoRef = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_WM_OBJECTINFO_MAP).toString(), Map.class);
		Map<String, Map<String, Object>> mDesignFileNHIPChildInfoRef = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_WM_CHILDINFO_MAP).toString(), Map.class);
		Map<String, Map<String, String>> mDSFileNWMOrigInstanceCountRef = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_ORIGINAL_COUNT).toString(), Map.class);
		Map<String, String> mDSFilenNotAvailableWMRef = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_NOT_AVAILABLE_WM).toString(), Map.class);
		Map<String, Map<String, Object>> mpLatestRevAndDeclaredUsageInfo = new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_DETECTED_IP_INFO).toString(), Map.class);
		Map<String, String> mpMissingProgeny = sYamlOutIPStructure.has(IMPConstants.MAPKEY_MISSING_PROGENY)?new ObjectMapper().readValue(sYamlOutIPStructure.getJSONObject(IMPConstants.MAPKEY_MISSING_PROGENY).toString(), Map.class):null;
		
		for (Map.Entry<String, Map<String, String>> mDSFilenCountInfo : mDesignFileNCalculatedIPInstanceCountRef.entrySet()) {
			StringBuilder sbMissingProgenyCount = new StringBuilder();
			StringBuilder sbUnknownWaterMark = new StringBuilder();
			String sDesignFileName = mDSFilenCountInfo.getKey();
			List<String> lsUnDetectedWMs = new ArrayList<>();

			IMPLog.info("The following structure has been extracted from '" + sDesignFileName + "' for the verify-run id '" + sVerifyRunObjectName + "' with the expected instance count of the detected IPs:");
			Utility.buildHIPStructure4EachDesignFile(mDSFilenCountInfo.getValue(), mDesignFileNameNwmObjInfoRef,
					mDesignFileNHIPChildInfoRef, mDSFileNWMOrigInstanceCountRef, sDesignFileName,
					sbMissingProgenyCount, gdsSpecificChildInfoMap, gdsSpecificLineageMap,
					mpLatestRevAndDeclaredUsageInfo);

			if (!StringUtils.isBlank(sbMissingProgenyCount.toString())) {
				IMPLog.warn(sbMissingProgenyCount.toString());
			} else if (mpMissingProgeny != null) {
				String sMissingProgenyforDesignFile = mpMissingProgeny.get(sDesignFileName);
				if (StringUtils.isNotBlank(sMissingProgenyforDesignFile))
				{
					IMPLog.warn(mpMissingProgeny.get(sDesignFileName).trim());
					for(String sWarnMessage:sMissingProgenyforDesignFile.split(System.lineSeparator())) {
						IMPCommon.setWarnMessage(new StringBuilder(sWarnMessage));
					}
				}
			}
			String sIMPUnknownComponentWatermark = mDSFilenNotAvailableWMRef.get(mDSFilenCountInfo.getKey());
			if (!StringUtils.isBlank(sIMPUnknownComponentWatermark)) {
				Utility.warnUnDetectedWMandGetCount(sIMPUnknownComponentWatermark, sbUnknownWaterMark,
						lsUnDetectedWMs);
				sbIMPUnknownComponentWatermark.append(sbUnknownWaterMark).append("\r\n");

				if (!lsUnDetectedWMs.isEmpty()) {
					List<String> lsUnknownWMs = new ArrayList<>();
					for (String sUnWM : lsUnDetectedWMs) {
						String sGDSFileName = "";
						String[] saDesignFileKey = sDesignFileName.split("\\|");
						IMPLog.warn(saDesignFileKey[0] + "|" + saDesignFileKey[1] + "|" + sUnWM);
						String[] saArrayWMs = sUnWM.split("\\n");
						for (String sWMs : saArrayWMs) {
							if (sWMs.contains(IMPConstants.KEYSTRING_DETECTEDWM_BUTNOTFOUNDINIMP)) {
								sGDSFileName = sWMs.replace(IMPConstants.KEYSTRING_DETECTEDWM_BUTNOTFOUNDINIMP, "").replace(":", "").trim();
							} else {
								lsUnknownWMs.add(sWMs);
								iUndetectedWaterMarks = iUndetectedWaterMarks + 1;
							}
						}
						mpList.put(sGDSFileName, lsUnknownWMs);
					}
				}
			}
		}
		return getYamlOutputFromVerifyRun(sVerifyRunObjectName, mpList, iUndetectedWaterMarks);
	}



	/**
	 * This method is to get the yaml output for verifyRun
	 * Added for SWIMP-570
	 *
	 * @param String sVerifyRunObjectName, the verifyrun id
	 * @param Map mpUnDetectedWMsList, the undetected WM list Map
	 * @param int iUndetectedWaterMarks, the count of undetected WMs.
	 * @return Map, Returns yaml output which contains verified-ip hierarchy
	 */
	@SuppressWarnings("unchecked")
	private static Map<String, Object> getYamlOutputFromVerifyRun(String sVerifyRunObjectName,
			Map<String, List<String>> mpUnDetectedWMsList, int iUndetectedWaterMarks) {
		Map<String, Object> yamlOut = new LinkedHashMap<>();
		yamlOut.put(IMPConstants.KEY_VERIFY_IPID, StringUtils.isNotBlank(sVerifyRunObjectName) ? sVerifyRunObjectName : "");
		Map<String, Object> mpYamlDetectedIPsList = Utility.getDetectedIPsFromMap();
		Map<String, Object> yamlDetectedIPs = new LinkedHashMap<>();
		Map<String, Object> yamlInternalIPs = new LinkedHashMap<>();
		Map<String, Object> yaml3PIPs = new LinkedHashMap<>();

		if (!mpYamlDetectedIPsList.isEmpty()) {
			for (Entry<String, Object> mpTempDetectedIPsData : mpYamlDetectedIPsList.entrySet()) {
				String sKeyIPID = mpTempDetectedIPsData.getKey();
				Map<String, Object> mpTempData = (Map<String, Object>) mpTempDetectedIPsData.getValue();
				String sIPSource = (String) mpTempData.get(IMPConstants.CONST_IPSOURCE);
				Map<String, Object> mpFillerMap = new LinkedHashMap<>();
				Map<String, Object> mpInstanceDataMap = new LinkedHashMap<>();
				Map<String, Object> mpWatermarkMap = new LinkedHashMap<>();
				String sLineage = (String) mpTempData.get(IMPConstants.CONST_LINEAGE);
				sLineage = sLineage.replaceAll("\\,", ", ");

				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpFillerMap.put(IMPConstants.CONST_OWNER, mpTempData.get(IMPConstants.CONST_OWNER));
					mpFillerMap.put(IMPConstants.CONST_VENDOR, mpTempData.get(IMPConstants.CONST_VENDOR));
					mpFillerMap.put(IMPConstants.CONST_REVISION, mpTempData.get(IMPConstants.CONST_REVISION));
					mpFillerMap.put(IMPConstants.CONST_LATESTREVISION, mpTempData.get(IMPConstants.CONST_LATESTREVISION));
					mpFillerMap.put(IMPConstants.CONST_DECLATEDFORUSE, mpTempData.get(IMPConstants.CONST_DECLATEDFORUSE));
					mpFillerMap.put(IMPConstants.CONST_DEPRECATEDBY, mpTempData.get(IMPConstants.CONST_DEPRECATEDBY));
					mpFillerMap.put(IMPConstants.CONST_ALERT, mpTempData.get(IMPConstants.CONST_ALERT));
					mpWatermarkMap.put(IMPConstants.CONST_LINEAGE, sLineage);
					mpWatermarkMap.put(IMPConstants.CONST_INSTANCECOUNT, mpTempData.get(IMPConstants.CONST_INSTANCECOUNT));
					mpWatermarkMap.put(IMPConstants.CONST_DESIGNFILE, mpTempData.get(IMPConstants.CONST_DESIGNFILE));
					mpInstanceDataMap.put((String) mpTempData.get(IMPConstants.CONST_WATERMARK), mpWatermarkMap);
					mpFillerMap.put(IMPConstants.CONST_INSTANCES, mpInstanceDataMap);
					yaml3PIPs.put(sKeyIPID, mpFillerMap);
				} else {
					mpFillerMap.put(IMPConstants.CONST_OWNER, mpTempData.get(IMPConstants.CONST_OWNER));
					mpFillerMap.put(IMPConstants.CONST_BU, mpTempData.get(IMPConstants.CONST_BU));
					mpFillerMap.put(IMPConstants.CONST_REVISION, mpTempData.get(IMPConstants.CONST_REVISION));
					mpFillerMap.put(IMPConstants.CONST_LATESTREVISION, mpTempData.get(IMPConstants.CONST_LATESTREVISION));
					mpFillerMap.put(IMPConstants.CONST_DECLATEDFORUSE, mpTempData.get(IMPConstants.CONST_DECLATEDFORUSE));
					mpFillerMap.put(IMPConstants.CONST_DEPRECATEDBY, mpTempData.get(IMPConstants.CONST_DEPRECATEDBY));
					mpFillerMap.put(IMPConstants.CONST_ALERT, mpTempData.get(IMPConstants.CONST_ALERT));
					mpWatermarkMap.put(IMPConstants.CONST_LINEAGE, sLineage);
					mpWatermarkMap.put(IMPConstants.CONST_INSTANCECOUNT, mpTempData.get(IMPConstants.CONST_INSTANCECOUNT));
					mpWatermarkMap.put(IMPConstants.CONST_DESIGNFILE, mpTempData.get(IMPConstants.CONST_DESIGNFILE));
					mpInstanceDataMap.put((String) mpTempData.get(IMPConstants.CONST_WATERMARK), mpWatermarkMap);
					mpFillerMap.put(IMPConstants.CONST_INSTANCES, mpInstanceDataMap);
					yamlInternalIPs.put(sKeyIPID, mpFillerMap);
				}
			}

			Map<String, Object> mpYamlCount = new LinkedHashMap<>();
			mpYamlCount.put(IMPConstants.KEY_TOTAL_DETECTED_IPS, yamlInternalIPs.size() + yaml3PIPs.size());
			mpYamlCount.put(IMPConstants.KEY_TOTAL_DETECTED_3PIPS, yaml3PIPs.size());
			mpYamlCount.put(IMPConstants.KEY_TOTAL_DETECTED_INTERNALIPS, yamlInternalIPs.size());
			mpYamlCount.put(IMPConstants.KEY_TOTAL_DETECTEDIPS_WITH_ZEROINSTANCECOUNT, IMPCommon.getZeroInstanceIPCount());
			mpYamlCount.put(IMPConstants.KEY_UNDETECTED_WATERMARKS, iUndetectedWaterMarks);
			yamlOut.put(IMPConstants.KEY_COUNT, mpYamlCount);

			Map<String, Object> yamlIpHierarchy = new LinkedHashMap<>();
			Map<String, Object> mpIpHierarchyDataMap = (Map<String, Object>) IMPCommon.getStructureFromIPHierarchyMap();
			if(!mpIpHierarchyDataMap.isEmpty()) {
				for (Map.Entry<String, Object> mpTempStructureData : mpIpHierarchyDataMap.entrySet()) {
					Map<String, Object> mpTempData = (Map<String, Object>) mpTempStructureData.getValue();
					yamlIpHierarchy.put(mpTempStructureData.getKey(), mpTempData);
				}
				yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, yamlIpHierarchy);
			} else {
				yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, "");
			}

			yamlDetectedIPs.put(IMPConstants.CONST_INTERNAL, !yamlInternalIPs.isEmpty() ? yamlInternalIPs : "");
			yamlDetectedIPs.put(IMPConstants.CONST_3PIP, !yaml3PIPs.isEmpty() ? yaml3PIPs : "");
			yamlOut.put(IMPConstants.KEY_DETECTEDIPS, !yamlDetectedIPs.isEmpty() ? yamlDetectedIPs : "");
			yamlOut.put(IMPConstants.KEY_UNDETECTED_WATERMARKS, mpUnDetectedWMsList.isEmpty() ? "" : mpUnDetectedWMsList);
			yamlOut.put(IMPConstants.KEY_WARNING, !(IMPCommon.getWarnMessage().isEmpty()) ? IMPCommon.getWarnMessage() : "");
		}
		return yamlOut;
	}
	//Added for SWIMP-570 : Ends
	//Added for SWIMP-XXX:- Use LSF to invoke ipinfo for large .oas/.gds files
	public static List<String> verifyFileSizeandQueueName(List<String> stclArgsList,String sQueueName,List<String> sFilelist) {
		boolean appendedBsub = false;
		List<String> stclNewArgsList;
		boolean shouldUseQueue = false;
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < sFilelist.size(); i++) {
			stclNewArgsList = new ArrayList<>();
			Path gdsFilePath = Paths.get(sFilelist.get(i));
			long gdsFileSize = gdsFilePath.toFile().length(); // fetching .OAS or .GDS file size in bytes
			long ramSize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean())
						.getTotalPhysicalMemorySize(); // fetching the RAM size of the VDI in bytes
			IMPLog.trace("The RAM size of VDI in bytes is: "+ramSize);
			if (gdsFileSize > (ramSize / IMPConstants.IMP_VERIFY_IP_WATERMARK_DEDUCT_FILE_SIZE_MULTIPLIER)) { // if file size is grater than 1/8th of RAM size displaying a warning
				shouldUseQueue = true;
				sb.append(gdsFilePath.getFileName());
				if (sb.length() > 0){
					sb.append(",");//check empty
				}
			} else if (StringUtils.isNotBlank(sQueueName)) {
				stclNewArgsList.add(IMPConstants.IMP_LSF_RUN_PATH);
				stclNewArgsList.add("-q");
				stclNewArgsList.add(sQueueName);
				stclNewArgsList.add("-I");
				stclNewArgsList.add("-R");
				stclNewArgsList.add("rusage[mem=" + Math.round(
						(gdsFileSize / (1048576d)) * IMPConstants.IMP_VERIFY_IP_WATERMARK_DEDUCT_FILE_SIZE_MULTIPLIER) // (1024*1024= 1048576)
				+ "]"); // Memory requested is always in MB. so converting file size from byte to MB
				stclNewArgsList.addAll(stclArgsList);
				appendedBsub = true;
				
				return stclNewArgsList;
			} //else {
				//return stclArgsList;
			//}
		}
		if(shouldUseQueue) {
		IMPLog.warn("The SoC Oasis/GDS file(s) " + sb.toString()
				+ " may be too large for the available memory. It is recommended that you use the --queue-name option to specify a queue that can support a large memory footprint as needed by the underlying ipinfo/calibredrv command.");
		}
		return stclArgsList;
		
	}
	
	// Added for SWIMP-354: Starts
	// Modified for SWIMP-859: Starts
	/**
	 * Check if there is any existing module for the IP. If yes, if
     * there is any modification of existing module revision with Design Sync Data
     * for the same revision which is in the existing module before proceeding with
	 * the new downloading tag/revision or prepare sa tag/revision.
     *
	 * @param currentDir
	 * @return integer, return code
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public static int checkExistingModuleModified(String sCmd, String currentDir, String sIPId, String sIPDir, boolean bDryRun, List<String> stclArgsList) throws IMPException, InterruptedException, IOException {
		int iReturn = 0;
		IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
		IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		List<String> sCommands = new ArrayList<>();
		IMPStclcWrapper stclWrapper2 = null;
		ProcessBuilder pbStcl2  = null;
		
		try {
			IMPLog.trace(strMessageForDesignSyncConnectionForExistingModule);
			String sModuleUrl = enoClient.getModuleUrlvalue(sIPId);
			if (StringUtils.isEmpty(sModuleUrl)) {
				iReturn = 27;
				return iReturn;
			}
			sCommands.add(strCommandNameForExistingStagingAreaCheck);
			sCommands.add(IMPConstants.CONST_IPDIR_OPTION);
			sCommands.add(StringUtils.isNotBlank(sIPDir) ? sIPDir : sIPId);
			sCommands.add(IMPConstants.CONST_IP_OPTION);
			sCommands.add(sIPId);
			sCommands.add(IMPConstants.IMP_MODULE_URL);
			sCommands.add(sModuleUrl);
			sCommands.add(IMPConstants.CONST_CURRDIR_OPTION);
			sCommands.add(currentDir);
			sCommands.add(IMPConstants.CONST_COMMAND_OPTION);
			sCommands.add(sCmd);
			ProcessBuilder pbStcl = stclWrapper.getStclProcessBuilder(sCommands);
			pbStcl.redirectErrorStream(true);
			IMPLog.trace(IMPConstants.CONST_STR_SETREDIRECT_ERROR);
			Process process = pbStcl.start();
			String sOutput = stclWrapper.processOutput(process);
			sOutput = stclWrapper.getSoutValue(sOutput).trim();
			iReturn = process.waitFor();
			
			if (iReturn == 0 && sOutput.trim().startsWith(IMPConstants.CONST_STR_ERROR) && !bDryRun) {
				iReturn = 2;
				sOutput = sOutput.replace(IMPConstants.CONST_STR_ERROR + IMPConstants.CONST_STR_SPACE, "");
				if (sCmd.equalsIgnoreCase(IMPConstants.IMP_CLI_PROCEDURE_PREPARE_SA) && sOutput.contains(IMPConstants.CONST_STR_DESIGNSYNC_OUTPUT_COMPARISION_OF
				        + IMPConstants.CONST_STR_SPACE + "("
				        + IMPConstants.CONST_STR_DESIGNSYNC_OUTPUT_IDENTICAL_OBJECTS_NOT_REPORTED + ")" + ":")) {
					stclWrapper2 = new IMPStclcWrapper();
					pbStcl2 = new ProcessBuilder();
					pbStcl2 = stclWrapper2.getStclProcessBuilder(stclArgsList);
					iReturn = getProcessStatus(pbStcl2, stclWrapper2);
				} else {
					IMPLog.trace(IMPConstants.CONST_STR_DESIGNSYNC_ERROR + System.lineSeparator() + sOutput);
					int iIndex = sOutput.indexOf(IMPConstants.CONST_STR_DESIGNSYNC_OUTPUT);
					if (iIndex > -1) {
						sOutput = sOutput.substring(0, iIndex);
					}
					IMPLog.error(sOutput.trim());
				}
			}
			IMPLog.trace(strMessageForReturnCodeOnExistingModuleCheck + iReturn);
		} catch (IOException e) {
			IMPLog.error("Execption while moving intermediate/log files created by bcm_uniquify: " + e.getMessage());
		}
		return iReturn;
	}
	//Added for SWIMP-354: Ends
	//Modified for SWIMP-859: Ends
	
	//Added for SWIMP-883: Start
	
	public static void setSSGQIAttributesToVerifyid(String sVerifyid,
                                               String iSSGQIResult,
                                               String strSSGQIOutput) throws IMPException {
    IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
    enoviaWrapper.setSSGQIAttributesToVerifyid(sVerifyid, iSSGQIResult, strSSGQIOutput);
}
	
	
public static List<String> getSsgqiCommand(String socName, Path specFile, Path extraDir, Path reportPrefix) {
    List<String> cmd = new ArrayList<>();

    cmd.add("/projects/analog/bin/ssgqi");
    cmd.add("--project-name"); cmd.add(socName);
    cmd.add("--spec-file");    cmd.add(specFile.toString());
    cmd.add("--ip-extra-files-dir"); cmd.add(extraDir.toString());
    cmd.add("--report"); cmd.add(reportPrefix.toString());
	IMPLog.info("command invoked for SSGQI:"+cmd);

    return cmd;
}
public static java.nio.file.Path writeSsgqiSpecYamlToImpCfg(
        String socName,
        java.util.Map<String, Object> ssgqiSpec
) throws java.io.IOException {

    // Optional: make socName safe for filenames
    String safeSocName = (socName == null || socName.trim().isEmpty())
            ? "unknown_soc"
            : socName.trim().replaceAll("[^A-Za-z0-9._-]", "_");
    String fileName = safeSocName + "-ssgqi-spec.yaml";

    java.nio.file.Path cfgDir = java.nio.file.Paths.get(
            System.getProperty("user.home"),
            ".imp",
            "cfg"
    );
    java.nio.file.Files.createDirectories(cfgDir);

    class Normalizer {
        Object norm(Object v) {
            if (v instanceof java.util.Map) {
                java.util.Map<?, ?> m = (java.util.Map<?, ?>) v;
                java.util.Map<String, Object> out = new java.util.LinkedHashMap<>();
                for (java.util.Map.Entry<?, ?> e : m.entrySet()) {
                    String k = String.valueOf(e.getKey());
                    k = k.trim().replace(' ', '_');
                    out.put(k, norm(e.getValue()));
                }
                return out;
            }
            if (v instanceof java.util.List) {
                java.util.List<?> list = (java.util.List<?>) v;
                java.util.List<Object> out = new java.util.ArrayList<>(list.size());
                for (Object item : list) out.add(norm(item));
                return out;
            }
            return v;
        }
    }

    @SuppressWarnings("unchecked")
    java.util.Map<String, Object> normalized =
            (java.util.Map<String, Object>) new Normalizer().norm(ssgqiSpec);

    // Ensure ssgqi_info is a map we can write into
    @SuppressWarnings("unchecked")
    java.util.Map<String, Object> ssgqiInfo =
            (java.util.Map<String, Object>) normalized.get("ssgqi_info");

    if (ssgqiInfo == null) {
        ssgqiInfo = new java.util.LinkedHashMap<>();
    } else {
        // copy to preserve insertion order and ensure mutability
        ssgqiInfo = new java.util.LinkedHashMap<>(ssgqiInfo);
    }

    // Keys you want to appear (in order) under ssgqi_info
    final java.util.List<String> infoOrder = java.util.Arrays.asList(
            "impversion",
            "starttime",
            "userlogin@hostname",
            "CWD",
            "soc_name",
            "owner",
            "bu",
            "foundry",
            "process",
            "subprocess",
            "metalstack",
            "detected_ips"
    );

    // Move these keys from the root into ssgqi_info (except ssgqi_info itself)
    for (String k : infoOrder) {
        if (!"ssgqi_info".equals(k) && normalized.containsKey(k)) {
            ssgqiInfo.put(k, normalized.remove(k));
        }
    }

    // Put back updated ssgqi_info at root
    normalized.put("ssgqi_info", ssgqiInfo);

    // Build final map with ONLY ssgqi_info at the root (matches your right-side output)
    java.util.Map<String, Object> finalMap = new java.util.LinkedHashMap<>();
    finalMap.put("ssgqi_info", ssgqiInfo);

    org.yaml.snakeyaml.DumperOptions opts = new org.yaml.snakeyaml.DumperOptions();
    opts.setDefaultFlowStyle(org.yaml.snakeyaml.DumperOptions.FlowStyle.BLOCK);
    opts.setPrettyFlow(true);
    opts.setIndent(2);
    opts.setIndicatorIndent(2);
    opts.setWidth(1000);
    opts.setSplitLines(false);
    opts.setDefaultScalarStyle(org.yaml.snakeyaml.DumperOptions.ScalarStyle.PLAIN);

    String yamlText = new org.yaml.snakeyaml.Yaml(opts).dump(finalMap);

    java.nio.file.Path out = cfgDir.resolve(fileName);

    // Write atomically (tmp -> move)
    java.nio.file.Path tmp = java.nio.file.Files.createTempFile(cfgDir, fileName, ".tmp");
    java.nio.file.Files.writeString(
            tmp,
            yamlText,
            java.nio.charset.StandardCharsets.UTF_8,
            java.nio.file.StandardOpenOption.TRUNCATE_EXISTING,
            java.nio.file.StandardOpenOption.WRITE
    );

    java.nio.file.Files.move(
            tmp,
            out,
            java.nio.file.StandardCopyOption.REPLACE_EXISTING,
            java.nio.file.StandardCopyOption.ATOMIC_MOVE
    );

    IMPLog.info("Created SSGQI spec file: " + out);
    return out;
}
	
	
	
	public static int uploadFileToServer(String localFilePath, String remoteDir) throws IOException {
    int iReturn = 0;
    // Use the same approach as your working download/upload methods
    String sFTPHost = getHost();
    int sFTPPort = 22;
    String sFTPUser = IMPConstants.IMP_CLI_SERVER_USER;
    String sFTPPass = getDecodePass();

    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;

    try (FileInputStream fileStream = new FileInputStream(new File(localFilePath))) {
        JSch jsch = new JSch();
        session = jsch.getSession(sFTPUser, sFTPHost, sFTPPort);
        session.setPassword(sFTPPass);

        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        session.setConfig(config);
        session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");

        session.connect();
        if (!session.isConnected()) return 1;

        channel = session.openChannel("sftp");
        channel.connect();
        channelSftp = (ChannelSftp) channel;

        String fileName = new File(localFilePath).getName();

        // Try to upload to /tmp/ssgqi_finalreport/
        try {
            // First try to go to /tmp directory
            channelSftp.cd("/projects/imp/tmp");

            // Now try to create/access ssgqi_finalreport directory in /tmp
            try {
                channelSftp.cd("ssgqi_finalreport");
            } catch (SftpException e) {
                // Directory doesn't exist, try to create it
                try {
                    channelSftp.mkdir("ssgqi_finalreport");
                    channelSftp.cd("ssgqi_finalreport");
                } catch (SftpException ex) {
                    // If can't create in /tmp, log error and return failure
                    return 1;
                }
            }

            // Upload the file
            channelSftp.put(fileStream, fileName);

            // Confirm upload location
            String currentPath = channelSftp.pwd();
            iReturn = 0;
        } catch (SftpException e) {
            iReturn = 1;
        }
    } catch (JSchException e) {
        iReturn = 1;
    } catch (Exception ex) {
        iReturn = 1;
    } finally {
        if (channelSftp != null) { try { channelSftp.exit(); } catch (Exception e) {} }
        if (channel != null) { try { channel.disconnect(); } catch (Exception e) {} }
        if (session != null) { try { session.disconnect(); } catch (Exception e) {} }
    }
    return iReturn;
}
	
	
	
	
	//Added for SWIMP-883: Ends
	
	
	
}
