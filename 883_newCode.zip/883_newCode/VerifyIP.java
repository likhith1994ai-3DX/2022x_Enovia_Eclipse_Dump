	/*------------------------------------------------------------------------------------------------------------------------------------------
	 *
	 * NAME         : VerifyIP.java
	 * DESCRIPTION  : Verify the IP used in the specified gds file for the specified project
	 *
	 * USAGE        : java -jar ${PATH}/imp.jar
	 *
	 *                Sample input as below format
	 *                imp verify-ip -h
	 *                imp verify-ip --help
	 *                imp verify-ip --gds-file </path/gdsfile> -P <project name>
	 *              
	 * CREATED      : 17-August-2016
	 *
	 * AUTHOR       : TECHMAHINDRA
	 *
	 * HISTORY:
	 *
	 * Name                     Modified Date                 Description
	 *
	 * Sai Prasad               17-Aug-2016                   Initial version.
	 * Sai Prasad               16-Sep-2016                   Help text updated
	 * Sai Prasad               27-Sep-2016                   Added a method verfiyIP for the user story IMPBRCM-175
	 * Sai Prasad               07-Nov-2016                   Added executeDetectWaterMark and executeDetectGDS to detect watermark strings. IMPBRCM-175
	 * Sai Prasad               15-Nov-2016                   Minor bug fixes for getting watermarks not available in IMP
	 * Sai Prasad               16-Nov-2016                   Modified algorithm to get the watermark string for IMP and AVAGO
	 * Sai Prasad               16-Dec-2016                   Bug fix for 804 and 807
	 * Sai Prasad               22-May-2017                   Fix for 1170 and reformatted code
	 * Krishna Durgasi          08-Aug-2017                   SWIMP-1 Watermarking Multiple GDS Files
	 * Udaya                    11-Aug-2017  Added for SWIMP-39
	 * Madhusmita M             11-Nov-2017                   Added for SWIMP-108
	 * Sujatha 18-Apr-2018  Modified for SWIMP-181
	 * Manish 25-JAN-2019  Modified/Added code for SWIMP-321
	 * Mahammed Irshad K S 20-Nov-2018  Modified the methods execute, verifyIP and executePreProcessCheck for SWIMP-262
	 * Mahammed Irshad K S 15-May-2021  Modified the methods verifyIP and displayIPInfoTable for SWIMP-531 (Change Request)
	 *------------------------------------------------------------------------------------------------------------------------------------------
	 */
	package com.broadcom.impcli.subcommands;

	import java.io.File;
	import java.io.IOException;
	import java.nio.file.Path;
	import java.nio.file.Paths;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.LinkedHashMap;
	import java.util.List;
	import java.util.Map;
	import java.util.Map.Entry;
	import java.util.Set; //Added for SWIMP-31 (Phase-2)
	import java.util.TreeMap;


	import java.nio.charset.StandardCharsets;


	import org.apache.commons.lang.StringUtils;
	import org.codehaus.jettison.json.JSONArray;
	import org.codehaus.jettison.json.JSONException;
	import org.kohsuke.args4j.Argument;
	import org.kohsuke.args4j.Option;
	import org.kohsuke.args4j.spi.StopOptionHandler;


	//Added for SWIMP-883: Start
	import org.codehaus.jettison.json.JSONObject;
	import java.text.SimpleDateFormat;
	import java.nio.file.Files;
	//Added for SWIMP-883: End


	import com.broadcom.impcli.client.IMPCommon;
	import com.broadcom.impcli.client.IMPConstants; //Added for SWIMP-568
	import com.broadcom.impcli.client.IMPException;
	import com.broadcom.impcli.client.IMPLog;
	import com.broadcom.impcli.enovia.IMPEnoviaClientWrapper;
	import com.broadcom.utility.GDSFileUtility;
	import com.broadcom.impcli.stclc.IMPStclcWrapper;
	import com.broadcom.utility.OutputFile;
	import com.broadcom.utility.Utility;

	/**
	 * The Class VerifyIP.
	 */
	public class VerifyIP extends AbstractSubcommand {

	/** The s help. */
	@Option(name = "--help", required = false, help = true, aliases = { "-h", "--help" }, usage = "Print this message.")
	private boolean bHelp;

	@Option(name = "-ofile", required = false, aliases = { "-o",
	"--ofile" }, usage = "output-file. unix path name to a file where structured results data will be placed.Default to stdout")
	private String sOutputFile = "";

	/** The s verbose. */
	@Option(name = "--verbose", usage = "Turns on additional messaging.", aliases = "-v", required = false)
	private int iVerbose = 4;

	/** The s dry run. */
	@Option(name = "--dry-run", usage = "Do everything but don't send the emails to IP owners for approvals.", aliases = {
	"-D", "--dry-run" }, required = false)
	private boolean bDryRun;

	/** The s GDS. */
	@Option(name = "--gds-file", usage = "The project's GDS file that should be scanned for all the IPs used in the project.", required = false) // Modified for SWIMP-31
	private String sGDS;

	/** The s CDL. */
	@Option(name = "--cdl-file", usage = "The project's CDL file that should be scanned for all the IPs used in the project.", required = false) // Modified for SWIMP-746
	private String sCDL;

	/** The s project name. */
	@Option(name = "-P", usage = "The project's GDS file that should be scanned for all the IPs used in the project.", aliases = {
	"-P", "--project-name" }, required = false, depends = { "--gds-file" }, forbids = { "--ip-id", "--tag" }) // Modified for SWIMP-31
	private String sProjectName;

	/** The s Queue Name. */
	@Option(name = "--queue-name", usage = "The queue name to invoke ipinfo for large .oas/.gds files", required = false)
	private String sQueueName;

	// Added foe SWIMP-31: Starts
	@Option(name = "--ip-id", usage = "IP's ID in IMP - generated at IP create time. Required with --create.", aliases = "-i", required = false, depends = {
	"--tag" }, forbids = { "--queue-name", "-P" })
	private String sIPId;

	/** The s tag. */
	@Option(name = "--tag", usage = "The tag name to check in the files under", aliases = { "--tag",
	"-t" }, required = false, depends = { "--ip-id" }, forbids = { "--queue-name", "-P"})
	private String sTag;
	// Added foe SWIMP-31: Ends

	@Argument
	@Option(name = "--", handler = StopOptionHandler.class)
	List<String> lCmdArgs;
	// Modified for SWIMP-12
	private String sProcName = "verify-ip";
	private OutputFile oFileObj;
	private static Object sOutput;
	private static String sINTERNAL = "internal";
	private static String sCOUNT = "count";
	private static String sALERT = "Alert";
	private static String sOWNER = "Owner";
	private static String sDEPRECATEDBY = "Deprecated by";
	private static final String STR_FAILED = "Failed";
	private static String sLINEAGE = "Lineage"; // Added for SWIMP-31 (Phase-2)
	private static String sNONDETECTEDWMMsg = "The Following watermarks (IP name/revision) were detected BUT NOT FOUND IN IMP:"; // Added for SWIMP-31 (Phase-2)
	private static String sPROJECTTYPE = "ProjectType"; // Added for SWIMP-31 (Phase-2)
	private static String sHIP = "HIP"; // Added for SWIMP-31 (Phase-2)
	GDSFileUtility gdsFileUtility; // SWIMP-480
	GDSFileUtility cdlFileUtility;

	private static String sISDECLAREDFORUSE = "Declared For Use?"; // Added for SWIMP-531
	// Added for SWIMP-568 : Starts
	private static String sInstances_YamlKey = "instances";
	private static String sDeclaredForUse_YamlKey = "declared_for_use";
	private static String sLineage_YamlKey = "lineage";
	private static String sDesignFile_YamlKey = "design_file";



	//Added for SWIMP-883: Start

	private static final String SSGQI_CFG_DIR_PREFIX = "ip-ssgqi-cfg-files.d_";
	//Added for SWIMP-883: End


	// Added for SWIMP-568 : Ends

	  /**
	   * Instantiates a new verify IP.
	   */
	  public VerifyIP() {
		this(new String[1]);
	  }

	  /**
	   * Instantiates a new verify IP.
	   *
	   * @param args the args
	   */
	  public VerifyIP(String[] args) {
		super(args);
	  }

	  /**
	   * Gets the s Output.
	   *
	   * @return the s Output
	   */
	  public static Object getsOutput() {
		return sOutput;
	  }
	   
	  /**
	   * Sets the s Output.
	   *
	   * @param sOutput the new s output
	   */
	  public static void setsOutput(Object sOutput) {
		VerifyIP.sOutput = sOutput;
	  }
	 

	  /*
	   * (non-Javadoc)
	   *
	   * @see com.broadcom.impcli.subcommands.Subcommand#execute()
	   */
	  @Override
	  public void execute() {
	 int iExit = 0;
	 IMPCommon commonObj = new IMPCommon();
	 try {
	 if (this.bHelp) {
	 printUsage();
	 } else {
	 IMPLog.start(sProcName, iVerbose, lCmdArgs);
	 iExit = verifyIP();
	 IMPLog.writeMessage(oFileObj, getsOutput(), iExit);
	 }
	 } catch (IMPException | IOException | JSONException e) {
	 IMPLog.error("Exception in verifyip execute: " + e);
	 } finally {
	 commonObj.exitSystem(iExit); //SWIMP-262
	 }
	  }

	//Added for SWIMP-883: Start
	private Path createUniqueSsgqiCfgDir() throws IOException {
		Path tmpDir = Paths.get(System.getProperty("java.io.tmpdir")); // /tmp
		return Files.createTempDirectory(tmpDir, SSGQI_CFG_DIR_PREFIX); // /tmp/ip-ssgqi-cfg-files.d_<unique>
	}
	//Added for SWIMP-883: End

	/**
	* Verify IP.
	*
	* @return the map
	* @throws IMPException  the IMP exception
	* @throws JSONException the JSON exception
	* @throws IOException   Signals that an I/O exception has occurred.
	*/
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private int verifyIP() throws IMPException, JSONException, IOException {
	int iReturn = 0;
	IMPCommon.setStrFileName(this.sGDS);
	IMPCommon.setStrFileNameForCDL(this.sCDL);
	Map<String, Object> ssgqiSpecLocal = null;

	Path ssgqiCfgDir = null;  // added for SWIMP-883



	String sENV = IMP_CLI_ENV;
	IMPCommon.setSoCName(this.sProjectName);
	IMPCommon.setsTag(this.sTag); // Added for SWIMP-31
	IMPCommon.setIpID(this.sIPId); // Added for SWIMP-31
	iReturn = executePreProcessCheck();
	String strDCLOASOutput = "";
	String strLLCOASOutput = "";
	String strDCLCDLOutput = "";
	String iDCLOASResult = "";
	String iLLCOASResult = "";
	String iDCLCDLResult = "";
	String str3pipNameAndVendorName = "";
	Map<String, Object> mpCDLYaml = new LinkedHashMap<>();
	Map<String, Object> mpOASYaml = new LinkedHashMap<>();
	Map<String, Object> mpLLCOASYaml = new LinkedHashMap<>();
	if (iReturn != 0) {
	return iReturn;
	}
	try {
	if (this.sProjectName != null|| (StringUtils.isNotBlank(this.sIPId) && StringUtils.isNotBlank(this.sTag))) { // Modified for SWIMP-31 (Phase-2)
	if (StringUtils.isNotBlank(this.sOutputFile)) {// Modified for SWIMP-262
	oFileObj = new OutputFile();
	try {
	oFileObj.init(sProcName, sOutputFile, System.getProperty("user.dir"));
	} catch (IMPException e) {
	iReturn = 2;
	IMPLog.error(e.getMessage());
	return iReturn;
	}
	}

	if (StringUtils.isNotBlank(this.sGDS)) { // Added for SWIMP-31 (Phase-2)
	// Modified for SWIMP-262: Starts
	this.gdsFileUtility = new GDSFileUtility();// SWIMP-480
	iReturn = this.gdsFileUtility.createTempFile(this.sGDS);// SWIMP-480
	if (iReturn != 0) {
	return iReturn;
	}
	}
	if (StringUtils.isNotBlank(this.sCDL)) {
	this.cdlFileUtility = new GDSFileUtility();
	iReturn = this.cdlFileUtility.createTempFileForCDL(this.sCDL);
	if (iReturn != 0) {
	return iReturn;
	}
	}

	}
	IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
	// Modified for SWIMP-262: Ends

	 //Added for SWIMP-85 start
	 String strDryRun = "";
	 if (bDryRun) {
	 IMPLog.info("Executing in Dry-Run mode");
	 strDryRun = "Dry-Run";
	 }
	 String sFilePath = "";
	 String sWatermarks = "";
	 Map<String, Object> strReturnMap = null;
	 String sGDSFileName = "";
	 String strSoCID = this.sProjectName;
	 
	 //If -P specified means user is using SoC as Project
	 if (this.sProjectName != null) {
	 IMPCommon.setProjectName(this.sProjectName); //Added for SWIMP-568
	 // Added for SWIMP-321 - Starts
	 StringBuilder sbWaterMarks = new StringBuilder();
	 iReturn = detectWatermark(sbWaterMarks);
	 if(iReturn != 0)
	 return iReturn;
	 sWatermarks = sbWaterMarks.toString();
	 File fCheckGDS = new File(this.sGDS);

	 //Added for SWIMP-31(Phase-2): Starts
	 sGDSFileName = fCheckGDS.getName();
	 sWatermarks = sGDSFileName + "^" + sWatermarks;
	 //Added for SWIMP-31(Phase-2): Ends

	 //Modified for SWIMP-534
	 String strFilePath = fCheckGDS.getCanonicalPath();
	 sFilePath = IMPCommon.getImpDomain() + ":" + strFilePath;
	 // Added for SWIMP-321 - Ends
	 }
	 //check for verify-ip run execution and get structure of Hierarchy structure
	 strReturnMap = enoviaWrapper.checkForVerifyIPRun(StringUtils.isNotBlank(this.sProjectName) ? this.sProjectName : this.sIPId, this.sTag, sWatermarks);
	 //Validate the data for further execution
	 iReturn = continueVerifyRunExecution(strReturnMap.get("SoCHIPVerifyStatus").toString());
	 if(iReturn != 0) {
	 return iReturn;
	 }
	 // Parse the water marks to the wrapper to send mail.
	 IMPLog.trace("Starting IP approvals process for detected watermarks");
	 //Changed the method name for SWIMP-75
	 //Modified Method Signature for SWIMP-321

	 //Code to display structure
	 Map<String, String> gdsSpecificChildInfoMap = new HashMap<>();
	 Map<String, Map<String, String>> gdsSpecificLineageMap = new HashMap<>();
	 Map<String, Object> returnMap = (Map<String, Object>) strReturnMap.get("wmReturnData");
	 if(StringUtils.isNotBlank(sTag) && returnMap.get("refCountMap") == null) {
	 return 58; //Modified for SWIMP-31 (Phase-2)
	 }


	 int iUndetectedWaterMarks = 0; //Added for SWIMP-570
	 String sHIPIDInfo = "";
	 StringBuilder sbmpObjId = new StringBuilder();
	 Map<String, Object> mpHasWMStructure = new HashMap<>(); //Added for SWIMP-31 (Phase-2)
	 Map<String, String> mpLineageInfoMap = new HashMap<>(); //Added for SWIMP-31 (Phase-2)
	 Map<String, List<String>> mpList = new HashMap<>(); //Added for SWIMP-570
	 if(!returnMap.isEmpty()) {
	 Map<String, Map<String, String>> mDesignFileNCalculatedIPInstanceCountRef = (Map<String, Map<String, String>>) returnMap.get("refCountMap");
	 Map<String, Map<String, Map<String, String>>> mDesignFileNameNwmObjInfoRef = (Map<String, Map<String, Map<String, String>>>) returnMap.get("wmObjInfoMap");
	 Map<String, Map<String, Object>> mDesignFileNHIPChildInfoRef = (Map<String, Map<String, Object>>) returnMap.get("wmChildInfoMap");
	 Map<String, Map<String, String>> mDSFileNWMOrigInstanceCountRef = (Map<String, Map<String, String>>) returnMap.get("OriginalCount");
	 Map<String, String> mDSFilenNotAvailableWMRef = (Map<String, String>) returnMap.get("NotAvaiableWM");
	 Map<String, String> mDSFileMissingProgeny = returnMap.containsKey("MissingProgeny") ? (Map<String, String>) returnMap.get("MissingProgeny") : null; //Added for SWIMP-31 (Phase-2)
	 mpHasWMStructure = returnMap.containsKey("WM_BASIC_INFO") ? (Map<String, Object>) returnMap.get("WM_BASIC_INFO") : null;
	 mpLineageInfoMap = returnMap.containsKey("LINEAGEINFO") ? (Map<String, String>) returnMap.get("LINEAGEINFO") : null;
	 Map<String, Map<String, Object>> mpLatestRevAndDeclaredUsageInfo = (Map<String, Map<String, Object>>) returnMap.get("detected_ip_info"); //Added for SWIMP-568

	 //Added for SWIMP-31 (Phase-2): Starts
	 if (returnMap.containsKey("MetadataInput")) {
	 Map<String, String> mHIPIDINfo = (Map<String, String>) returnMap.get("MetadataInput");
	 sHIPIDInfo = mHIPIDINfo.toString();
	 }
	 //Added for SWIMP-31 (Phase-2): Ends

	 //Modified for SWIMP-31 (Phase - 2) : Starts
	 if (!mDesignFileNCalculatedIPInstanceCountRef.isEmpty()) {
	 for (Map.Entry<String, Map<String, String>> mDSFilenCountInfo : mDesignFileNCalculatedIPInstanceCountRef.entrySet()) {

	 StringBuilder sbMissingProgenyCount = new StringBuilder();
	 StringBuilder sbUnknownWaterMark = new StringBuilder();
	 String sDesignFileName = mDSFilenCountInfo.getKey();
	 IMPLog.info("The following structure has been extracted from '" + sDesignFileName + "' with the expected instance count of the detected IPs:");
	 List<String> lsUnDetectedWMs = new ArrayList<>(); //Added for SWIMP-570

	 Utility.buildHIPStructure4EachDesignFile(mDSFilenCountInfo.getValue(),
	 mDesignFileNameNwmObjInfoRef, mDesignFileNHIPChildInfoRef,
	 mDSFileNWMOrigInstanceCountRef, sDesignFileName, sbMissingProgenyCount,
	 gdsSpecificChildInfoMap, gdsSpecificLineageMap, mpLatestRevAndDeclaredUsageInfo); //Modified for SWIMP-568
	 if (StringUtils.isNotBlank(sbMissingProgenyCount.toString())) {
	 IMPLog.warn(sbMissingProgenyCount.toString());
	 } else if (mDSFileMissingProgeny != null) {
	 String sMissingProgenyforDesignFile = mDSFileMissingProgeny.get(sDesignFileName);
	 if (StringUtils.isNotBlank(sMissingProgenyforDesignFile))
	 {
	 IMPLog.warn(mDSFileMissingProgeny.get(sDesignFileName).trim());
	 for(String sWarnMessage:sMissingProgenyforDesignFile.split(System.lineSeparator())) {
	 IMPCommon.setWarnMessage(new StringBuilder(sWarnMessage));
	 }
	 }
	 }
	 String sIMPUnknownComponentWatermark = mDSFilenNotAvailableWMRef.containsKey(sDesignFileName) ? mDSFilenNotAvailableWMRef.get(sDesignFileName) : ""; //Modified for SWIMP-31 (Phase-2)
	 if (!StringUtils.isBlank(sIMPUnknownComponentWatermark)) {
	 //Modified for SWIMP-31 (Phase-2) : Starts
	 sIMPUnknownComponentWatermark = sIMPUnknownComponentWatermark.replace(sNONDETECTEDWMMsg, "").trim();
	 Utility.warnUnDetectedWMandGetCount(sIMPUnknownComponentWatermark, sbUnknownWaterMark,
	 lsUnDetectedWMs); //Modified for SWIMP-570
	 //Modified for SWIMP-31 (Phase-2) : Ends
	 //Added for SWIMP-570 : Starts
	 if (!lsUnDetectedWMs.isEmpty()) {
	 List<String> lsUnknownWMs = new ArrayList<>();
	 for (String sUnWM : lsUnDetectedWMs) {
	 String sGDSOASFileName = "";
	 String[] saArrayWMs = sUnWM.split("\\n");
	 for (String sWMs : saArrayWMs) {
	 if (sWMs.contains(":")) {
	 sGDSOASFileName = sWMs.replace(":", "").trim();
	 lsUnknownWMs = new ArrayList<>();
	 } else {
	 lsUnknownWMs.add(sWMs);
	 iUndetectedWaterMarks = iUndetectedWaterMarks + 1;
	 }
	 if(StringUtils.isNotBlank(sGDSOASFileName))
	 {
	 mpList.put(sGDSOASFileName, lsUnknownWMs);
	 } else {
	 mpList.put(sGDSFileName, lsUnknownWMs);
	 }
	 }
	 }
	 }
	 //Added for SWIMP-570 : Ends
	 }
	 }
	 }
	 //Modified for SWIMP-31 (Phase - 2) : Ends

	 //
	 for (Entry<String, Map<String, String>> entry : mDSFileNWMOrigInstanceCountRef.entrySet()) {
	 sbmpObjId.append(Utility.convertWMMapToString(entry.getValue()));
	 }
	 //
	 }
	 Map<String, String> mGDSSpecificLineageInfo = new HashMap<>();
	 Map<String, String> mpCLILineageDisplay = new HashMap<>(); //Added for SWIMP-31 (Phase-2)

	 //Added for SWIMP-31 (Phase-2) : Starts
	 if(strReturnMap.get(sPROJECTTYPE).toString().equalsIgnoreCase(sHIP)) {
	 if (!mpLineageInfoMap.isEmpty() && mpLineageInfoMap != null) {
	 Set<String> strSetKey = mpLineageInfoMap.keySet();
	 for (String sKey : strSetKey) {
	 String[] saEachLinMap = mpLineageInfoMap.get(sKey).split("\\$");
	 for(String sEachLinMap : saEachLinMap) {
	 String[] sEachLin = sEachLinMap.split("\\^");
	 getLineageCLIDisplayMap(mpCLILineageDisplay, sEachLin[1]);
	 }
	 }
	 mGDSSpecificLineageInfo = mpLineageInfoMap;
	 }

	 //Check if WM has any lineage or any structure created while publishing (Applicable only for HIPs)
	 if (!mpHasWMStructure.isEmpty() && mpHasWMStructure != null) {
	 Set<String> stKeySet = mpHasWMStructure.keySet();
	 for (String sWMBKey : stKeySet) {
	 Map<String, Object> mpWMBasicInfo = (Map<String, Object>) mpHasWMStructure.get(sWMBKey);
	 String sDFile = (String) mpWMBasicInfo.get("IMP_Design_File");
	 boolean bHasStructure = (boolean) mpWMBasicInfo.get("Has_Structure");
	 String sWMIPID = (String) mpWMBasicInfo.get("IPID");
	 String sWMIPTag = (String) mpWMBasicInfo.get("IPTAG");
	 String sDisplayWM = "single_design_file".equals(sWMBKey) ? sWMIPID + "/" + sWMIPTag
	 : sWMIPID + "/" + sWMIPTag + "/" + sDFile;
	 if (!bHasStructure) {
	 IMPLog.warn("No watermarks detected for " + sDisplayWM + ".");
	 }
	 }
	 }

	 } else {
	 if (!gdsSpecificLineageMap.isEmpty()) {
	 for (Entry<String, Map<String, String>> entry : gdsSpecificLineageMap.entrySet()) {
	 StringBuilder sbLineage = new StringBuilder();
	 Map<String, String> lineageMap = entry.getValue();
	 if (lineageMap!=null && !lineageMap.isEmpty()) {
	 for(Map.Entry<String,String> mLineageInfo : lineageMap.entrySet()) {
	 for(String s:mLineageInfo.getValue().split(";") ) {
	 String[] saLineageInfo = s.split("#");
	 getLineageCLIDisplayMap(mpCLILineageDisplay, getLineageString(entry.getKey(), saLineageInfo[0], gdsSpecificLineageMap.size())); //Added for SWIMP-31 (Phase-2)
	 sbLineage.append(mLineageInfo.getKey()).append("^").append(getLineageString(entry.getKey(), saLineageInfo[0], gdsSpecificLineageMap.size())).append("^").append(saLineageInfo[1]).append("$");
	 }
	 }
	 mGDSSpecificLineageInfo.put(entry.getKey(), sbLineage.substring(0, sbLineage.length()-1));
	 }
	 }
	 }
	 //Added for SWIMP-31 (Phase-2) : Ends
	 }
	 //Added for SWIMP-31 (Phase-2) : Starts
	 if (mGDSSpecificLineageInfo.isEmpty()) {
	 if (strReturnMap.get(sPROJECTTYPE).toString().equalsIgnoreCase(sHIP)) {
	 IMPLog.error("No component IPs found in " + this.sIPId + "/" + this.sTag + " - aborting Verify-IP");
	 } else {
	 IMPLog.error("No IPs found in " + this.sGDS  + " - aborting Verify-IP");
	 }
	 return 2;
	 }
	 //Added for SWIMP-31 (Phase-2) : Ends

	 //End code to display structure
	 org.codehaus.jettison.json.JSONObject jsOwnerData =
	enoviaWrapper.createVerificationMetaData(this.sProjectName, strDryRun, sENV, sFilePath, this.sIPId,
	this.sTag, mGDSSpecificLineageInfo.toString(), sbmpObjId.toString(), sHIPIDInfo);
	 org.codehaus.jettison.json.JSONArray jaDetectedWaterMarks =
	 (org.codehaus.jettison.json.JSONArray) jsOwnerData.get("MapList");
	 //Added for SWIMP-883: Start
	 List<Map<String, Object>> detectedIpsForSsgqi = new ArrayList<>();
	 Map<String, java.util.Set<String>> ipidToRevsForSsgqiCfg = new LinkedHashMap<>();
	//Added for SWIMP-883: Start

	 
	 org.codehaus.jettison.json.JSONObject joDeclaredUsageData = (org.codehaus.jettison.json.JSONObject) jsOwnerData.get(KEY_DECLARED_USAGE); //Added for SWIMP-531

	 String sIPID;
	 StringBuilder sIPName;
	 String sIPRevision;
	 String sIPType;
	 String sOwner;
	 String sVendor;
	 String sBU;
	 String sLatestRev;
	 String sRefCount;
	 String sNoOfGDSFiles;//Added for SWIMP-1
	 String sDesignFile;//Added for SWIMP-1
	 String sAlert;
	 String sIPAlert = null;

	 int intTemp = 0;
	 int pipTemp = 0;

	 Object oNull = null;

	 TreeMap<String, Object> interNamMap = new TreeMap<>();
	 TreeMap<String, Object> pipNameSort = new TreeMap<>();

	// Added for 1062: Starts
	Map<String, Object> yamlOut = new LinkedHashMap<>();
	Map<String, Object> yamlIntFinalData = new LinkedHashMap<>();
	Map<String, Object> yamlPIPFinalData = new LinkedHashMap<>();
	Map<String, Object> yamlData = new LinkedHashMap<>();
	Map<String, Object> yamlDLCData = new LinkedHashMap<>();
	Map<String, Object> yamlLLCData = new LinkedHashMap<>();
	Map<String, Object> countData = new LinkedHashMap<>();
	Map<String, Object> yamlIpHierarchy = new LinkedHashMap<>(); // Added for SWIMP-568
	Map<String, Map<String, String>> mpLatestRevisionAndDeclaredUsageMap = new HashMap<>(); // Added for SWIMP-568
	Map<String, Object> mpInstanceData;

	 List<Map> dummyList = new ArrayList<>();

	 int internalIPCount = 0;
	 int pipIPCount = 0;
	 int zeroInstanceIPCount = IMPCommon.getZeroInstanceIPCount(); //Added for SWIMP-31 (Phase-2)
	 int iTotalDetectedIP = jaDetectedWaterMarks.length();

	 Map<String, Object> yamlIntData;
	 Map<String, Object> yaml3PIPData;
	 // Added for 1062: Ends


	 // Detected watermark id's
	 if (jaDetectedWaterMarks.length() > 0) {
	 for (int j = 0; j < jaDetectedWaterMarks.length(); j++) {
	 
	 //Added for SWIMP-883: Start
	 Map<String, Object> ssgqiSpec = new LinkedHashMap<>();
	 //Added for SWIMP-883: End
	 TreeMap<String, Object> interTMap = new TreeMap<>();
	 TreeMap<String, Object> pipTMap = new TreeMap<>();
	 // Added for 1062: Starts
	 yamlIntData = new LinkedHashMap<>();
	 yaml3PIPData = new LinkedHashMap<>();
	 mpInstanceData = new LinkedHashMap<>();
	 Map<String, Object> mpExistWatermarkData = new LinkedHashMap<>(); //Added for SWIMP-568, Modified for SWIMP-570
	 Map<String, Object> existingMap;
	 ArrayList<Map> instanceList = new ArrayList<Map>();
	 List<Map> lsInstances = new ArrayList<>();
	 // Added for 1062: Ends
	 org.codehaus.jettison.json.JSONObject detectedArrayObject =
	 (org.codehaus.jettison.json.JSONObject) jaDetectedWaterMarks.get(j);
	 String sourceOfDetectedIP = detectedArrayObject.getString(
	 "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPSource]");
	 sIPID = detectedArrayObject
	 .getString("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.name");
	 sIPName = new StringBuilder(detectedArrayObject.getString(
	 "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPName]"));
	 sIPRevision = detectedArrayObject.getString("attribute[IMP_IPTag]");
	 final String sIPRevisionRaw = detectedArrayObject.getString("attribute[IMP_IPTag]");
	 //Added for SWIMP-883 Start
	ipidToRevsForSsgqiCfg
	.computeIfAbsent(sIPID, k -> new java.util.LinkedHashSet<>())
	.add(sIPRevisionRaw);
	 //Added for SWIMP-883 End
	 
	 sIPType = detectedArrayObject.getString(
	 "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");
	 sOwner = detectedArrayObject
	 .getString("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.owner");
	 sBU = detectedArrayObject.getString(
	 "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_ProductDivision]");
	 sVendor = detectedArrayObject.getString(
	 "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_Vendor]");
	 // Added for IMPBRCM-1093 Starts
	 sLatestRev = detectedArrayObject.getString("LATREV");
	 // Added for IMPBRCM-1093 Ends
	 sRefCount = detectedArrayObject.getString("REFCOUNT");
	 sDesignFile = detectedArrayObject.getString("DesignFile");//Added for SWIMP-1
	 sAlert = detectedArrayObject.getString("attribute[IMP_Alert]");// Added for IMPBRCM-1166
	 sNoOfGDSFiles = detectedArrayObject.getString("noOfGDsFiles");//Added for SWIMP-1


	 //Added for SWIMP-531 : Starts
	 String sDeclaredForUse = STR_NO;
	 if (joDeclaredUsageData.has(sIPID+"|"+sIPRevision)) {
	 sDeclaredForUse = joDeclaredUsageData.getString(sIPID+"|"+sIPRevision);
	 }
	 //Added for SWIMP-531 : Ends

	 sIPAlert = sAlert;

	 List<String> deprecatedByList =
	 Utility.parseJSONArraytoList((JSONArray) detectedArrayObject.get("DeprecatedBy"));
	 String sDeprecatedBy = "";
	 if(!deprecatedByList.isEmpty()){
	 sDeprecatedBy = deprecatedByList.toString().substring(1, deprecatedByList.toString().length() - 1);
	 }

	 //Added for SWIMP-31 (Phase-2): Starts
	 sIPRevision = StringUtils.isNotBlank(sDesignFile) ? sIPRevision+"("+sDesignFile+")" : sIPRevision;
	 String sDisplayLineage = mpCLILineageDisplay.containsKey(sIPID + ":" + sIPRevision) ? mpCLILineageDisplay.get(sIPID + ":" + sIPRevision) : "";
	 sDisplayLineage = sDisplayLineage.contains(";") ? sDisplayLineage.replaceAll("\\;", ", ") : sDisplayLineage;
	 //Added for SWIMP-31 (Phase-2): Ends

	 //Added for SWIMP-568 : Starts
	 String sIPXWatermark = detectedArrayObject.getString("IPXWaterMark");
	 String sIPRevisionWatermark = detectedArrayObject.getString("IPRevisionWatermark");
	 String sWatermarkString = StringUtils.isNotBlank(sIPRevisionWatermark) ? sIPRevisionWatermark : sIPXWatermark;
	 Map<String, Object> mpWatermarkDataMap = new HashMap<>();
	 Map<String, String> mpEachIPData = new HashMap<>();
	 mpEachIPData.put(IMPConstants.CONST_LATESTREVISION, sLatestRev);
	 mpEachIPData.put(IMPConstants.CONST_DECLATEDFORUSE, sDeclaredForUse);
	 mpLatestRevisionAndDeclaredUsageMap.put(sIPID, mpEachIPData);
	 //Added for SWIMP-568 : Ends

	 //Added for SWIMP-1
	 if (Integer.valueOf(sNoOfGDSFiles) > 1)
	 sIPName.append("/").append(sDesignFile);
	 // Added for CR-1063 : Start
	 // Detected IP's are clustered to internal/3pip
	 if (sINTERNAL.equalsIgnoreCase(sourceOfDetectedIP) && Integer.valueOf(sRefCount) > 0 && StringUtils.isNotBlank(sDisplayLineage)) {//Modified for SWIMP-31 (Phase-2)
	 interTMap.put("ID", sIPID);
	 interTMap.put("Name", sIPName.toString());
	 interTMap.put("Rev", sIPRevision);
	 // Added for IMPBRCM-1093 Starts
	 interTMap.put("LRev", sLatestRev);
	 // Added for IMPBRCM-1093 Ends
	 interTMap.put(sISDECLAREDFORUSE, sDeclaredForUse); //Added for SWIMP-531
	 interTMap.put("Type", sIPType);
	 interTMap.put(sOWNER, sOwner);
	 interTMap.put("Sbu", sBU);
	 interTMap.put(sLINEAGE, sDisplayLineage); //Added for SWIMP-31 (Phase-2)
	 interTMap.put(sDEPRECATEDBY, sDeprecatedBy);
	 interTMap.put(sALERT, sIPAlert);
	 interNamMap.put(sIPID + sIPRevision + sDesignFile, interTMap);//Modified for SWIMP-1
	 intTemp = intTemp + 1;
	 internalIPCount = internalIPCount + 1;

	 // Added for 1062: Starts
	 yamlIntData.put("owner", sOwner);
	 yamlIntData.put("bu", sBU);
	 yamlIntData.put("revision", sIPRevision); //Added for SWIMP-568
	 yamlIntData.put("latest_revision", sLatestRev);
	 yamlIntData.put(sDeclaredForUse_YamlKey, sDeclaredForUse); //Added for SWIMP-531
	 yamlIntData.put("deprecated_by", sDeprecatedBy);
	 yamlIntData.put("alert", sIPAlert); //Added for SWIMP-568
	 //Modified for SWIMP-568 : Starts
	 mpInstanceData.put(sLineage_YamlKey, sDisplayLineage);
	 mpInstanceData.put(sCOUNT, Integer.valueOf(sRefCount));
	 mpInstanceData.put(sDesignFile_YamlKey, sDesignFile);
	 //Modified for SWIMP-568 : Ends
	 lsInstances.add(mpInstanceData);
	 if (!yamlIntFinalData.isEmpty() && yamlIntFinalData.containsKey(sIPID)) {
	 existingMap = (Map<String, Object>) yamlIntFinalData.get(sIPID);

	 //Added for SWIMP-568 : Starts
	 mpExistWatermarkData = (Map<String, Object>) existingMap.get(sInstances_YamlKey);
	 if (!mpExistWatermarkData.isEmpty() && mpExistWatermarkData.containsKey(sWatermarkString)) {
	 instanceList.add((Map<String,Object>)mpExistWatermarkData.get(sWatermarkString));
	 instanceList.add(mpInstanceData);
	 mpExistWatermarkData.put(sWatermarkString, instanceList);
	 existingMap.put(sInstances_YamlKey, mpExistWatermarkData);
	 yamlIntFinalData.put(sIPID, existingMap);
	 } else {
	 mpExistWatermarkData.put(sWatermarkString, mpInstanceData);
	 existingMap.put(sInstances_YamlKey, mpExistWatermarkData);
	 yamlIntFinalData.put(sIPID, existingMap);
	 }
	 //Added for SWIMP-568 : Ends
	 } else {
	 mpWatermarkDataMap.put(sWatermarkString, mpInstanceData); //Added for SWIMP-568
	 yamlIntData.put(sInstances_YamlKey, mpWatermarkDataMap); //Modified for SWIMP-568
	 yamlIntFinalData.put(sIPID, yamlIntData);
	 }
	 // Added for 1062: Ends
	 }
	 yamlData.put(sINTERNAL, yamlIntFinalData == null || yamlIntFinalData.isEmpty()
	 ? dummyList : yamlIntFinalData);
	 if ("3pip".equalsIgnoreCase(sourceOfDetectedIP) && Integer.valueOf(sRefCount) > 0 && StringUtils.isNotBlank(sDisplayLineage)) { //Modified for SWIMP-31 (Phase-2)
	 pipTMap.put("ID", sIPID);
	 pipTMap.put("Name", sIPName.toString());
	 pipTMap.put("Rev", sIPRevision);
	 // Added for IMPBRCM-1093 Starts
	 pipTMap.put("LRev", sLatestRev);
	 // Added for IMPBRCM-1093 Ends
	 pipTMap.put(sISDECLAREDFORUSE, sDeclaredForUse); //Added for SWIMP-531
	 pipTMap.put("Type", sIPType);
	 pipTMap.put(sOWNER, sOwner);
	 pipTMap.put("Svendor", sVendor);
	 pipTMap.put(sLINEAGE, sDisplayLineage); //Added for SWIMP-31 (Phase-2)
	 pipTMap.put(sDEPRECATEDBY, sDeprecatedBy);
	 pipTMap.put(sALERT, sIPAlert);
	 pipNameSort.put(sIPID + sIPRevision + sDesignFile, pipTMap);//Modified for SWIMP-1
	 pipTemp = pipTemp + 1;
	 pipIPCount = pipIPCount + 1;

	 // Added for 1062: Starts
	 yaml3PIPData.put("owner", sOwner);
	 yaml3PIPData.put("vendor", sVendor);
	 yaml3PIPData.put("revision", sIPRevision); //Added for SWIMP-568
	 yaml3PIPData.put("latest_revision", sLatestRev);
	 yaml3PIPData.put(sDeclaredForUse_YamlKey, sDeclaredForUse); //Added for SWIMP-531, Modified for SWIMP-568
	 yaml3PIPData.put("deprecated_by", sDeprecatedBy);
	 yaml3PIPData.put("alert", sIPAlert); //Added for SWIMP-568
	 //Modified for SWIMP-568 : Starts
	 mpInstanceData.put(sLineage_YamlKey, sDisplayLineage);
	 mpInstanceData.put(sCOUNT, Integer.valueOf(sRefCount));
	 mpInstanceData.put(sDesignFile_YamlKey, sDesignFile);
	 //Modified for SWIMP-568 : Ends
	 lsInstances.add(mpInstanceData);

	 if (!yamlPIPFinalData.isEmpty() && yamlPIPFinalData.containsKey(sIPID)) {
	 existingMap = (Map<String, Object>) yamlPIPFinalData.get(sIPID);
	//Added for SWIMP-568 : Starts
	 mpExistWatermarkData = (Map<String, Object>) existingMap.get(sInstances_YamlKey);
	 if (!mpExistWatermarkData.isEmpty() && mpExistWatermarkData.containsKey(sWatermarkString)) {
	 instanceList.add((Map<String,Object>)mpExistWatermarkData.get(sWatermarkString));
	 instanceList.add(mpInstanceData);
	 mpExistWatermarkData.put(sWatermarkString, instanceList);
	 existingMap.put(sInstances_YamlKey, mpExistWatermarkData);
	 yamlIntFinalData.put(sIPID, existingMap);
	 } else {
	 mpExistWatermarkData.put(sWatermarkString, mpInstanceData);
	 existingMap.put(sInstances_YamlKey, mpExistWatermarkData);
	 yamlPIPFinalData.put(sIPID, existingMap);
	 }
	 //Added for SWIMP-568 : Ends
	 } else {
	 mpWatermarkDataMap.put(sWatermarkString, mpInstanceData); //Added for SWIMP-568
	 yaml3PIPData.put(sInstances_YamlKey, mpWatermarkDataMap); //Modified for SWIMP-568
	 yamlPIPFinalData.put(sIPID, yaml3PIPData);
	 }
	 }
	 yamlData.put("3pip", yamlPIPFinalData == null || yamlPIPFinalData.isEmpty() ? "" : yamlPIPFinalData);
	 }
	 // Added for 1062: Ends
	 }
	 



	 




	 // Cluster IP's sorted on IPID for internal/3pip respectively
	String sVerifyID = (String) jsOwnerData.get("VerifyID");
	String tempFilePath = gdsFileUtility.getsOutFile();
	TreeMap<String, Object> ipScoreResultsOutput = new TreeMap<>();
	ipScoreResultsOutput = ipScoreResults(this.sProjectName,tempFilePath);
	if("false".equalsIgnoreCase((String)(ipScoreResultsOutput.get("isSucessfull")))){
	return 2;
	}
	Utility.setIpScoreAttributesToVerifyid(sVerifyID, (String)(ipScoreResultsOutput.get("isEmailorUI_True")));
	str3pipNameAndVendorName = (String)(ipScoreResultsOutput.get("isEmailorUI_True"));
	pipNameSort.putAll((TreeMap<String, Object>)(ipScoreResultsOutput.get("isConsole_True")));
	 if (intTemp >= 1) {
	 displayIPInfoTable(interNamMap, "BU", "internal IPs");
	 }
	 if (pipTemp >= 1 || (pipNameSort.size() > 0 && !pipNameSort.isEmpty())) {
	 displayIPInfoTable(pipNameSort, "Vendor", "3PIPs");
	 }
	 // Added for CR -1063 : End

	 String sMsg = (String) jsOwnerData.get("message");
	//dlc execution start

	String sfoundary = "";
	String sSubProcess = "";
	String sMetalStack = "";
	String sProcessNode = "";


	try {

		if (this.sProjectName != null) {

			File fileGDS = new File(this.sGDS);
			String strFilePath = fileGDS.getCanonicalPath(); // keeping since you had it (even if unused)

			List<Map<String, Object>> lTechStackInfo = Utility.getSoCTechStacks(strSoCID);

			Map<String, Object> mpDLCReturn = new LinkedHashMap<>();
			Map<String, Object> mpLLCReturn = new LinkedHashMap<>();

			// Pull SoC tech stack (keeps last entry if multiple)
			for (int i = 0; i < lTechStackInfo.size(); i++) {
				Map<String, Object> mpTechStackMap = lTechStackInfo.get(i);

				sfoundary   = (String) mpTechStackMap.get(IMP_TECHSTACK_ATTR_SEL_FOUNDRY);
				sSubProcess = (String) mpTechStackMap.get(IMP_TECHSTACK_ATTR_SEL_SUBPROCESS);
				sMetalStack = (String) mpTechStackMap.get(IMP_TECHSTACK_ATTR_SEL_METALSTACK);
				sProcessNode= (String) mpTechStackMap.get(IMP_TECHSTACK_ATTR_SEL_PROCESSNODE);
			}

			// Preprocess check makes sure metalstack is not null, but guard anyway
			if (sMetalStack != null && sMetalStack.contains(" ")) {
				sMetalStack = sMetalStack.substring(0, sMetalStack.indexOf(" "));
			}

			// -------------------------
			// DLC/LLC execution
			// -------------------------
			String strSoCTechstack = sfoundary.toLowerCase() + sSubProcess.toLowerCase() + "_" + sMetalStack;

			List<Map> mpAllFoundaryMapping = IMPConstants.getFoundaryMapping();
			String strSingleFoundaryMapping = "";
			for (Map singleFoundaryMapping : mpAllFoundaryMapping) {
				strSingleFoundaryMapping = (String) singleFoundaryMapping.get(sfoundary.toLowerCase());
				if (StringUtils.isNotBlank(strSingleFoundaryMapping)) {
					strSoCTechstack = strSingleFoundaryMapping + sSubProcess.toLowerCase() + "_" + sMetalStack;
				}
			}

			if (StringUtils.isNotBlank(this.sCDL) && sCDL != null) {
				mpDLCReturn = runDLC(sCDL, strSoCTechstack, sQueueName, true);
				mpCDLYaml.putAll((Map) mpDLCReturn.get("yamlfile"));
				strDCLCDLOutput = (String) mpDLCReturn.get("emailandconsoleoutput");
				iDCLCDLResult = (String) mpDLCReturn.get("dlcpassorfail");
			}

			mpDLCReturn = runDLC(sGDS, strSoCTechstack, sQueueName, false);
			mpOASYaml.putAll((Map) mpDLCReturn.get("yamlfile"));
			strDCLOASOutput = (String) mpDLCReturn.get("emailandconsoleoutput");
			iDCLOASResult = (String) mpDLCReturn.get("dlcpassorfail");
			Utility.setDLCAttributesToVerifyid(sVerifyID, iDCLCDLResult, strDCLCDLOutput, iDCLOASResult, strDCLOASOutput);

			mpLLCReturn = runLLC(sGDS, strSoCTechstack, sQueueName);
			mpLLCOASYaml.putAll((Map) mpLLCReturn.get("yamlfile"));
			strLLCOASOutput = (String) mpLLCReturn.get("emailandconsoleoutput");
			iLLCOASResult = (String) mpLLCReturn.get("llcpassorfail");
			Utility.setLLCAttributesToVerifyid(sVerifyID, iLLCOASResult, strLLCOASOutput);
			

			// ==================== SWIMP-883: SSGQI execution moved after DLC/LLC ====================
			
			
			IMPLog.info("SWIMP-883: about to call download (post DLC/LLC), ipCount=" + ipidToRevsForSsgqiCfg.size());
	ssgqiCfgDir = createUniqueSsgqiCfgDir();
	downloadSsgqiCfgs(enoviaWrapper, ipidToRevsForSsgqiCfg, yamlOut, ssgqiCfgDir);
			
			
			//Added for SWIMP-883: Start
			// -------------------------
			// Create <SoC-name>-ssgqi-spec.yaml in tmp directory
			ssgqiSpecLocal = new LinkedHashMap<>();

			// 1) ssgqi_info
			String impVersion = Version.getIMPVersion();
			String userInfo = IMPCommon.getImpUser() + "@" + Utility.getFullQualHostName();
			String cwd = System.getProperty("user.dir");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
			String startTime = sdf.format(System.currentTimeMillis());

			Map<String, Object> ssgqiInfo = new LinkedHashMap<>();
			ssgqiInfo.put("impversion", impVersion);
			ssgqiInfo.put("starttime", startTime);
			ssgqiInfo.put("userlogin@hostname", userInfo);
			ssgqiInfo.put("CWD", cwd);
			ssgqiSpecLocal.put("ssgqi_info", ssgqiInfo);

			// 2) Flattened SoC fields (match screenshot keys)
			String socOwner = "Unknown";
			String socBU = "Unknown";

			try {
				JSONObject jsSoCDetails = enoviaWrapper.getSoCDetails(this.sProjectName);

				if (jsSoCDetails != null && jsSoCDetails.has("JSONStringForSoC") && !jsSoCDetails.isNull("JSONStringForSoC")) {
					Object raw = jsSoCDetails.get("JSONStringForSoC");

					JSONObject socDetails = (raw instanceof JSONObject)
							? (JSONObject) raw
							: new JSONObject(String.valueOf(raw));

					if (socDetails.has("owner") && !socDetails.isNull("owner")) {
						String v = socDetails.getString("owner").trim();
						if (!v.isEmpty()) socOwner = v;
					}
					if (socDetails.has("product_division") && !socDetails.isNull("product_division")) {
						String v = socDetails.getString("product_division").trim();
						if (!v.isEmpty()) socBU = v;
					}
				} else {
					IMPLog.warn("getSoCDetails: missing JSONStringForSoC for " + this.sProjectName);
				}
			} catch (Exception e) {
				IMPLog.warn("getSoCDetails failed for " + this.sProjectName + ": " + e.getMessage());
			}

			ssgqiSpecLocal.put("soc name", this.sProjectName);
			ssgqiSpecLocal.put("owner", socOwner);
			ssgqiSpecLocal.put("bu", socBU);
			ssgqiSpecLocal.put("foundry", sfoundary);
			ssgqiSpecLocal.put("process", sProcessNode);
			ssgqiSpecLocal.put("subprocess", sSubProcess);
			ssgqiSpecLocal.put("metalstack", sMetalStack);

			// 3) detected_ips (same as you already do)
			Map<String, Object> detectedIpsMap = new LinkedHashMap<>();

			for (int j = 0; j < jaDetectedWaterMarks.length(); j++) {
				JSONObject detectedArrayObject = jaDetectedWaterMarks.getJSONObject(j);

				String ipId = detectedArrayObject.getString("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.name");
				String ipOwner = detectedArrayObject.getString("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.owner");

				String ipRevision = detectedArrayObject.getString("attribute[IMP_IPTag]");
				String latestRev = detectedArrayObject.getString("LATREV");
				String bu = detectedArrayObject.getString("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_ProductDivision]");

				Map<String, Object> ipInfo = new LinkedHashMap<>();
				ipInfo.put("owner", ipOwner);
				ipInfo.put("bu", bu);
				ipInfo.put("revision", ipRevision);
				ipInfo.put("latest_revision", latestRev);

				detectedIpsMap.put(ipId, ipInfo);
			}

			ssgqiSpecLocal.put("detected_ips", detectedIpsMap);

			// Write YAML
			Path specFile = Utility.writeSsgqiSpecYamlToImpCfg(this.sProjectName, ssgqiSpecLocal);

			String safeSocName = this.sProjectName.replaceAll("[^A-Za-z0-9._-]", "_");
			Path reportPath = Paths.get(System.getProperty("java.io.tmpdir"), safeSocName + "-SSGQI_report");

			try {
				Map<String, Object> ssgqiResult = runSSGQI(this.sProjectName, specFile, ssgqiCfgDir, reportPath, this.sQueueName, this.sGDS, enoviaWrapper, sVerifyID);

				yamlOut.put("ssgqi_results", ssgqiResult);

				// Persist to VerifyRun like DLC/LLC
				String ssgqiPassFail = (String) ssgqiResult.get("ssgqipassorfail");
				String outHtml = (String) ssgqiResult.get("ssgqi_output_html");
				if (outHtml == null || outHtml.trim().isEmpty()) {
					outHtml = (String) ssgqiResult.get("emailandconsoleoutput");
				}
				Utility.setSSGQIAttributesToVerifyid(sVerifyID, ssgqiPassFail, outHtml);
			} catch (IOException e) {
				IMPLog.error("SSGQI failed: " + e.getMessage());

				Map<String, Object> ssgqiResult = new LinkedHashMap<>();
				ssgqiResult.put("exit_code", -1);
				ssgqiResult.put("error", "Exception while running SSGQI: " + e.getMessage());
				yamlOut.put("ssgqi_results", ssgqiResult);

				Utility.setSSGQIAttributesToVerifyid(sVerifyID, "fail",
						"Exception while running SSGQI:<br>" + e.getMessage());
			}

			//Added for SWIMP-883: End
			// ==================== End of moved SSGQI block ====================
		}

	} catch (IOException e) {
		IMPLog.error("Exception while performing dlc" + e);
		throw new IOException("Exception while performing dlc" + e);
	}


	//dlc execution end



	if ("Success".equals(sMsg)) {
	iReturn = 0;
	} else {
	iReturn = 2;
	IMPLog.error(sMsg);
	}

	 // Added for 1062: Starts
	 
	 countData.put("total_detected_ips", iTotalDetectedIP);
	 countData.put("total_detected_3pips", pipIPCount);
	 countData.put("total_detected_internal_ips", internalIPCount);
	 countData.put("total_detected_ips_with_zero_instance_count", zeroInstanceIPCount); //Added SWIMP-31 (Phase-2)
	 countData.put("undetected_watermarks", iUndetectedWaterMarks); //Modified for SWIMP-570
	 yamlOut.put("verify_ip_id",
	 sVerifyID == null || "null".equals(sVerifyID) ? oNull : sVerifyID);
	 yamlOut.put(sCOUNT, countData);

	 //Added for SWIMP-568 : Starts
	 Map<String, Object> mpIpHierarchyDataMap = (Map<String, Object>) IMPCommon.getStructureFromIPHierarchyMap();
	 if(!mpIpHierarchyDataMap.isEmpty()) {
	 for (Map.Entry<String, Object> mpTempStructureData : mpIpHierarchyDataMap.entrySet()) {
	 Map<String, Object> mpTempData = (Map<String, Object>) mpTempStructureData.getValue();
	 yamlIpHierarchy.put(mpTempStructureData.getKey(), mpTempData);
	 }
	 yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, yamlIpHierarchy);
	 } else {
	 yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, "");
	 }
	 //Added for SWIMP-568 : Ends
	if (yamlData.size() > 0 && !yamlData.isEmpty()) {
	yamlOut.put("detected_ips", yamlData);
	} else {
	yamlData.put(sINTERNAL, ""); // Modified for SWIMP-568
	yamlData.put("3pip", ""); // Modified for SWIMP-568
	yamlOut.put("detected_ips", yamlData);
	}
	Map<String, Object> ipScoreYamlOutput = new LinkedHashMap<>();
	ipScoreYamlOutput = (Map<String, Object>)(ipScoreResultsOutput.get("isYaml_True"));
	if (ipScoreYamlOutput.size() > 0 && !ipScoreYamlOutput.isEmpty()) {
	yamlData.put("3pip_unknown", ipScoreYamlOutput);
	}
	yamlOut.put("undetected_watermarks", mpList.isEmpty() ? "" : mpList); // Modified for SWIMP-570
	yamlOut.put("warning", !(IMPCommon.getWarnMessage().isEmpty()) ? IMPCommon.getWarnMessage() : ""); // Modified for SWIMP-568, Modified for SWIMP-570
	if (StringUtils.isNotBlank(this.sCDL) && sCDL != null) {
	yamlDLCData.put("cdl_file", mpCDLYaml);
	}
	yamlDLCData.put("oasis_file", mpOASYaml);
	yamlOut.put("dlc_results", yamlDLCData);
	yamlLLCData.put("oasis_file", mpLLCOASYaml);
	yamlOut.put("llc_results", yamlLLCData);
	setsOutput(yamlOut);
	// Added for 1062: Ends

	// Added for SWIMP-39: verify-ip should be logged in the CLI history start
	IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
	if (iReturn == 0 && !this.bDryRun) {
	IMPLog.trace("Start post VerifyIp process");
	String sIPIDs = jsOwnerData.get("IPIds").toString().trim();

	iReturn = enoClient.executePostVerifyIP(sVerifyID, sGDS,
	StringUtils.isNotBlank(this.sProjectName) ? this.sProjectName : this.sIPId + "/" + this.sTag,
	sIPIDs, sENV, (String) strReturnMap.get(sPROJECTTYPE), strDCLCDLOutput, strDCLOASOutput, str3pipNameAndVendorName,strLLCOASOutput); // Modified for SWIMP-31(Phase-2)
	}
	if("fail".equals(iDCLCDLResult) || "fail".equals(iDCLOASResult) || "fail".equals(iLLCOASResult))
	{
	return 2;
	}
	else{
	return iReturn;
	}

	 } catch (IMPException e) {
	 iReturn = 1;
	 IMPLog.error("Unable to perform verification process for the detected IP Revisions");
	 IMPLog.error(e.getMessage());
	 IMPLog.trace("Exception in verifyIP run: " + e);
	 } finally {
	 if(this.gdsFileUtility != null){
	 this.gdsFileUtility.deleteTempFile();
	 }
	 if(this.cdlFileUtility != null){
	 this.cdlFileUtility.deleteCDLTempFile();
	 }
	 }
	 return iReturn;
	  }


	/*
	   * (non-Javadoc)
	   *
	   * @see com.broadcom.impcli.subcommands.Subcommand#printUsage()
	   */
	  @Override
	  public void printUsage() {
	 String sHelp = IMPCommon.getHelpContent(HELP_VERIFYIP);
	 IMPCommon.displayMessage(sHelp, false);
	  }

	private int executePreProcessCheck() throws IMPException {
	int iReturn = 0;
	try {
	if ((StringUtils.isNotBlank(this.sProjectName) && this.sProjectName != null) && !bDryRun
	&& (StringUtils.isBlank(sCDL) || sCDL == null)) {
	return 113;
	}
	if (((StringUtils.isNotBlank(this.sIPId) && this.sIPId != null) || (StringUtils.isNotBlank(this.sTag) && this.sTag != null))) {
	if((StringUtils.isNotBlank(sCDL) || sCDL != null)){
	return 116;
	}
	if((StringUtils.isNotBlank(sGDS) || sGDS != null)){
	return 117;
	}
	}
	if ((StringUtils.isNotBlank(this.sProjectName) && this.sProjectName != null)) {
	String sSoCMetalStack = "";
	String sSoCID = this.sProjectName;
	List<Map<String, Object>> lSoCTechStackInfo = Utility.getSoCTechStacks(sSoCID);
	for (int i = 0; lSoCTechStackInfo.size() > i; i++) {
	Map<String, Object> mpSoCTechStackMap = lSoCTechStackInfo.get(i);
	sSoCMetalStack = (String) mpSoCTechStackMap.get(IMP_TECHSTACK_ATTR_SEL_METALSTACK);
	}
	if (StringUtils.isBlank(sSoCMetalStack) || sSoCMetalStack == null) {
	IMPCommon.setSoCNameForDLC(sSoCID);
	return 115;
	}
	}
	// Added for the SWIMP-262: Starts
	// Check for User access to the SoC
	// Modified for SWIMP-31
	int iAccess;
	if (StringUtils.isNotBlank(this.sProjectName)) {
	iAccess = Utility.checkAccess(IMPCommon.getImpUser(),
	IMP_CONST_TYPE_IMPSOC, this.sProjectName,sProcName, null);
	} else if (StringUtils.isNotBlank(this.sIPId)) {
	iAccess = Utility.checkAccess(IMPCommon.getImpUser(),
	IMP_CONST_TYPE_IPPRODUCT, this.sIPId, sProcName,null);
	} else {
	iAccess = 74;
	}
	// Modified for SWIMP-31
	if (iAccess > 0) {
	return iAccess;
	}
	// Added for the SWIMP-262: Ends
	} catch (IMPException | JSONException | IOException e) {
	IMPLog.error("ERROR in validating Verify command", e);
	}
	return iReturn;
	}

	  private int continueVerifyRunExecution(String sInput) {
	 int iReturn = 0;
	 if (StringUtils.isNotBlank(this.sProjectName)) {
	 if ((!"false".equalsIgnoreCase(sInput)) || ("false".equalsIgnoreCase(sInput) && this.bDryRun)) {
	 return iReturn;
	 } else {
	 return 67;
	 }
	 } else if (StringUtils.isNotBlank(this.sIPId) && ("false".equalsIgnoreCase(sInput))){
	 return 108;
	 }

	 return iReturn;
	  }

	@SuppressWarnings("unchecked")
	private void displayIPInfoTable(TreeMap<String, Object> ipNameSort, String vendorOrBu, String internalOr3PIP) {
	String sLineSep = "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------";
	String sSpace = "%-20s";

	StringBuilder ipIPDetected = new StringBuilder();

	TreeMap<String, String> pipSort;
	StringBuilder ipBuild = new StringBuilder();
	//Modified for SWIMP-31 (Phase-2) : Starts
	//Re-structured Internal and 3P IPs column for SWIMP-31 (Phase-2)
	for (Entry<String, Object> entry : ipNameSort.entrySet()) {
	pipSort = (TreeMap<String, String>) entry.getValue();
	// Modified for IMPBRCM-1093 Starts
	ipBuild.append(String.format(sSpace, "| " + pipSort.get("ID")));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get("Name")));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get("Rev")));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get("LRev")));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get(sISDECLAREDFORUSE)));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get("Type")));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get(sOWNER)));
	ipBuild.append(String.format(sSpace, "| " + pipSort.get(("Vendor").equalsIgnoreCase(vendorOrBu)?"Svendor":"Sbu")));
	ipBuild.append(String.format(sSpace, "| [" + pipSort.get("Lineage") + "] ")); //Added for SWIMP-31 (Phase-2)
	ipBuild.append(String.format(sSpace, "| " + pipSort.get(sDEPRECATEDBY)));  
	// Modified for IMPBRCM-1093 Ends
	// Added for IMPBRCM-1166 Starts
	if (pipSort.get(sALERT) != null && !pipSort.get(sALERT).isEmpty()) {
	ipBuild.append(String.format(sSpace, "| " + pipSort.get(sALERT)));
	} else {
	ipBuild.append(String.format(sSpace, "|"));
	}
	ipBuild.append(System.lineSeparator());
	// Added for IMPBRCM-1166 Ends
	}
	ipIPDetected.append("Detected " + internalOr3PIP + ":" + System.lineSeparator());
	ipIPDetected.append(sLineSep);
	ipIPDetected.append(System.lineSeparator());
	// Modified for IMPBRCM-1093 Starts
	ipIPDetected.append(String.format(sSpace, "| IPID"));
	ipIPDetected.append(String.format(sSpace, "| Name"));
	ipIPDetected.append(String.format(sSpace, "| Revision"));
	ipIPDetected.append(String.format(sSpace, "| Latest_Revision"));
	ipIPDetected.append(String.format(sSpace, "| "+sISDECLAREDFORUSE));
	ipIPDetected.append(String.format(sSpace, "| Type"));
	ipIPDetected.append(String.format(sSpace, "| Owner"));
	ipIPDetected.append(String.format(sSpace, "| " + vendorOrBu));
	ipIPDetected.append(String.format(sSpace, "| Lineage")); //Added for SWIMP-31 (Phase-2)
	ipIPDetected.append(String.format(sSpace, "| Deprecated by"));
	ipIPDetected.append(String.format(sSpace, "| Alert"));
	// Modified for IMPBRCM-1093 Ends
	ipIPDetected.append(System.lineSeparator());
	ipIPDetected.append(sLineSep);
	ipIPDetected.append(System.lineSeparator());
	ipIPDetected.append(ipBuild);
	IMPLog.info(ipIPDetected.toString());
	// Modified for SWIMP-31 (Phase-2) : Ends
	}

	private int detectWatermark(StringBuilder sbWaterMarks) throws IMPException, IOException {
	int iReturn = 0;
	// To check whether SoC is pushed to oracle or not
	String sWaterMarks = "";
	// Added for SWIMP-85 end
	// Get the water marks from the GDS file
	Path iPath = Paths.get(this.sGDS);
	sWaterMarks = gdsFileUtility.executeDetectWaterMark(iPath, this.sQueueName, this.sGDS);// SWIMP-480
	if (!STR_FAILED.equalsIgnoreCase(sWaterMarks) && !sWaterMarks.isEmpty()) {
	sbWaterMarks.append(sWaterMarks);
	return iReturn;
	} else if (STR_FAILED.equalsIgnoreCase(sWaterMarks)) {
	iReturn = 2;
	} else if (sWaterMarks.isEmpty()) {
	iReturn = 42;
	} else {
	iReturn = 43;
	}
	return iReturn;
	}

	private String getLineageString (String sDesignFileName, String strChildLineage, int nOfWMs) {
	StringBuilder sbFinalChildLineage = new StringBuilder();
	sbFinalChildLineage.append(this.sProjectName!=null?this.sProjectName:this.sIPId);
	if(StringUtils.isNotBlank(this.sTag)) {
	sbFinalChildLineage.append(":").append(this.sTag);
	}
	if (nOfWMs > 1) {
	String strFileName = "(" + sDesignFileName + ")";
	sbFinalChildLineage.append(strFileName).append("|").append(strChildLineage);
	} else {
	sbFinalChildLineage.append("|").append(strChildLineage);
	}
	return sbFinalChildLineage.toString();
	}











	 










	//Added for SWIMP-31 (Phase-2) : Starts
	/**
	* This method get Lineage Map to display on the CLI Console
	*
	* @param mpCLILineageDisplay, return Map with added Lineage Map
	* @param sLineage, Lineage from GDS
	* @return mpCLILineageDisplay, Structured Lineage Map
	*/
	private void getLineageCLIDisplayMap(Map<String, String> mpCLILineageDisplay, String sLineage) {
	if (StringUtils.isNotBlank(sLineage)) {
	String[] saLng = sLineage.split("\\|");
	String sTmpLng = saLng[saLng.length - 1];
	if (mpCLILineageDisplay.containsKey(sTmpLng)) {
	String sTmp = mpCLILineageDisplay.get(sTmpLng);
	mpCLILineageDisplay.remove(sTmpLng);
	mpCLILineageDisplay.put(sTmpLng, sTmp + ";" + sLineage);
	} else {
	mpCLILineageDisplay.put(sTmpLng, sLineage);
	}
	}
	}
	// Added for SWIMP-31 (Phase-2) : Ends
	//for console Display false and false
	//for File Output true and false
	//for mail Output false and true
	private Map getYamlOutputForDLCorOASIS(String DCLYamlOutput, boolean isEmail) {
	String lines[] = DCLYamlOutput.split(System.lineSeparator());
	List<String> lsCDLorOASISYaml = new ArrayList<>();
	Map<String, Object> mpReturn = new LinkedHashMap<>();
	StringBuilder sbDLCOASOutputYaml = new StringBuilder();
	for (String line: lines) {
	if ((line.startsWith("Job <") || line.startsWith("<<Waiting")|| line.startsWith("<<Starting"))) {
	continue;
	}
	sbDLCOASOutputYaml.append(line);
	lsCDLorOASISYaml.add(line);

	if(isEmail){
	sbDLCOASOutputYaml.append("<br>");
	}else{
	sbDLCOASOutputYaml.append(System.lineSeparator());
	}
	}

	mpReturn.put("displayAndEmail", sbDLCOASOutputYaml.toString());
	mpReturn.put("yamlfileOutput", lsCDLorOASISYaml);
	return mpReturn;

	}

	private Map runDLC(String strFilepath, String strSoCTechstack, String sQueueName, boolean isCDL) throws IOException {
	List<String> argsListForCDLorOASIS = new ArrayList<>();
	List<String> stclArgsList = new ArrayList<>();
	String sOutCDLorOASIS = "";
	int iProcessCDLorOASIS;
	String strDLCforCDLorOASISOutput = "";
	Map<String, Object> mpCDLorOASISYaml = new LinkedHashMap<>();
	Map<String, Object> mpReturn = new LinkedHashMap<>();
	IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
	try{
	boolean appendedBsub = gdsFileUtility.verifyQueueNameAndUseBsub(stclArgsList,sQueueName,strFilepath);
	argsListForCDLorOASIS = Utility.getDLCCommand(strSoCTechstack, Paths.get(strFilepath), isCDL);
	stclArgsList.addAll(argsListForCDLorOASIS);
	IMPLog.info("Running dlc for file "+strFilepath);
	String[] argsArrayForCDLorOASIS = new String[stclArgsList.size()];
	stclArgsList.toArray(argsArrayForCDLorOASIS);
	ProcessBuilder pb = stclWrapper.getStclProcessBuilder(argsArrayForCDLorOASIS);
	pb.redirectErrorStream(true);
	Process process = pb.start();
	sOutCDLorOASIS = stclWrapper.outputForYaml(process).trim();
	int length = 10000000;
	if(sOutCDLorOASIS.length() > length) {
	sOutCDLorOASIS = sOutCDLorOASIS.substring(0, length);
	IMPLog.warn("1000k-character limit reached, ignoring remaining output from dlc");
	}
	iProcessCDLorOASIS = process.waitFor();
	mpCDLorOASISYaml.put("filepath", strFilepath);
	mpCDLorOASISYaml.put("result", iProcessCDLorOASIS);
	if (iProcessCDLorOASIS != 0 && !sOutCDLorOASIS.isEmpty()) {
	IMPLog.error("Return value from dlc for file "+strFilepath+": "+iProcessCDLorOASIS);
	if (iProcessCDLorOASIS == 99) {
	IMPLog.error("design in "+strFilepath+" failed dlc check");

	}else{
	IMPLog.error("dlc command for file "+strFilepath+" failed");
	}
	IMPLog.error("Output from dlc:");
	mpCDLorOASISYaml.put("output",(getYamlOutputForDLCorOASIS(sOutCDLorOASIS, false)).get("yamlfileOutput"));
	IMPLog.error((String)(getYamlOutputForDLCorOASIS(sOutCDLorOASIS, false)).get("displayAndEmail"));
	strDLCforCDLorOASISOutput = "dlc command for file  "+strFilepath+" failed"+"<br>Output from dlc:<br>"+(String)(getYamlOutputForDLCorOASIS(sOutCDLorOASIS, true)).get("displayAndEmail");
	mpReturn.put("dlcpassorfail", "fail");
	}
	if(iProcessCDLorOASIS == 0 ){
	IMPLog.info("Return value from dlc for file "+strFilepath+": "+iProcessCDLorOASIS);
	strDLCforCDLorOASISOutput = "dlc command passed for file "+strFilepath;
	mpCDLorOASISYaml.put("output",(getYamlOutputForDLCorOASIS(strDLCforCDLorOASISOutput, false)).get("yamlfileOutput"));
	IMPLog.info(strDLCforCDLorOASISOutput);
	mpReturn.put("dlcpassorfail", "pass");
	}

	mpReturn.put("yamlfile", mpCDLorOASISYaml);
	mpReturn.put("emailandconsoleoutput", strDLCforCDLorOASISOutput);

	}
	catch (IOException | InterruptedException e) {
	IMPLog.error("Exception while performing dlc" + e);
	throw new IOException("Exception while performing dlc" + e);
	}
	return mpReturn;
	}

	private TreeMap<String, Object> ipScoreResults(String strProjectName, String strFilepath) throws IOException {
	List<String> argsListsForIpScoreResults = new ArrayList<>();
	String sOutIpScore = "";
	int iProcessIpScore;
	TreeMap<String, Object> pipNameSort = new TreeMap<>();
	TreeMap<String, Object> pipNameSortOutput = new TreeMap<>();
	try{
	IMPStclcWrapper stclWrapperIpScore = new IMPStclcWrapper();
	StringBuilder ipBuild = new StringBuilder();
	Map<String, Object> mpIpScoreYaml = new LinkedHashMap<>();
	File fCheck = new File(strFilepath);
	String strIpinfoFilePath = fCheck.getCanonicalPath();
	Path strFilePathForIpScoreResults = Paths.get(strIpinfoFilePath);
	argsListsForIpScoreResults = Utility.getSoCIPscore(strProjectName, strFilePathForIpScoreResults);
	IMPLog.info("Running ipscore for file "+strIpinfoFilePath);
	String[] argsArrayForIpScore = new String[argsListsForIpScoreResults.size()];
	ProcessBuilder pb = new ProcessBuilder(argsListsForIpScoreResults);
	pb.redirectErrorStream(true);
	Process process = pb.start();
	sOutIpScore = stclWrapperIpScore.outputForYaml(process).trim();
	iProcessIpScore = process.waitFor();
	if(iProcessIpScore == 0)
	{
	if(!sOutIpScore.isEmpty() && sOutIpScore != null)
	{
	IMPLog.info(sOutIpScore);
	String lines[] = sOutIpScore.split(System.lineSeparator());
	for (String line: lines) {
	TreeMap<String, Object> pipTMap = new TreeMap<>();

	Map<String, Object> mpIpScoreVendor = new LinkedHashMap<>();
	String sVendor = "";
	String ipProductName = "";
	sVendor = line.substring(line.indexOf("\"", 0)+1,line.indexOf("\"", 1));
	ipProductName = line.substring(line.indexOf("\"", 1)+1);

	pipTMap.put("ID", "IPID From IpScore");
	pipTMap.put("Name", ipProductName);
	pipTMap.put("Rev", "");
	pipTMap.put("LRev", "");
	pipTMap.put(sISDECLAREDFORUSE, "");
	pipTMap.put("Type", "");
	pipTMap.put(sOWNER, "");
	pipTMap.put("Svendor", sVendor);
	pipTMap.put(sLINEAGE, "");
	pipTMap.put(sDEPRECATEDBY, "");
	pipTMap.put(sALERT, "");
	pipNameSortOutput.put(ipProductName + sVendor , pipTMap);

	ipBuild.append(ipProductName);
	ipBuild.append(":");
	ipBuild.append(sVendor);
	ipBuild.append("<br>");

	mpIpScoreVendor.put("vendor",sVendor);
	mpIpScoreYaml.put(ipProductName.trim() ,mpIpScoreVendor);

	}
	pipNameSort.put("isConsole_True", pipNameSortOutput);
	pipNameSort.put("isEmailorUI_True", ipBuild.toString());
	pipNameSort.put("isYaml_True", mpIpScoreYaml);
	pipNameSort.put("isSucessfull", "true");
	}
	else{
	pipNameSort.put("isConsole_True", pipNameSortOutput);
	pipNameSort.put("isEmailorUI_True", ipBuild.toString());
	pipNameSort.put("isYaml_True", mpIpScoreYaml);
	pipNameSort.put("isSucessfull", "true");
	}
	}else{
	IMPLog.error(sOutIpScore);
	pipNameSort.put("isSucessfull", "false");
	}
	}
	catch (IOException | InterruptedException e) {
	IMPLog.error("Exception while performing ipscore" + e);
	throw new IOException("Exception while performing ipscore" + e);
	}
	return pipNameSort;
	}


	private Map runLLC(String strFilepath, String strSoCTechstack, String sQueueName) throws IOException {
	List<String> argsListForOASIS = new ArrayList<>();
	List<String> stclArgsList = new ArrayList<>();
	String sOutOASIS = "";
	int iProcessOASIS;
	String strLLCforOASISOutput = "";
	Map<String, Object> mpOASISYaml = new LinkedHashMap<>();
	Map<String, Object> mpReturn = new LinkedHashMap<>();
	IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
	try{
	boolean appendedBsub = gdsFileUtility.verifyQueueNameAndUseBsub(stclArgsList,sQueueName,strFilepath);
	argsListForOASIS = Utility.getLLCCommand(strSoCTechstack, Paths.get(strFilepath));
	stclArgsList.addAll(argsListForOASIS);
	IMPLog.info("Running llc for file "+strFilepath);
	String[] argsArrayForOASIS = new String[stclArgsList.size()];
	stclArgsList.toArray(argsArrayForOASIS);
	ProcessBuilder pb = stclWrapper.getStclProcessBuilder(argsArrayForOASIS);
	pb.redirectErrorStream(true);
	Process process = pb.start();
	sOutOASIS = stclWrapper.outputForYaml(process).trim();
	int length = 10000000;
	if(sOutOASIS.length() > length) {
	sOutOASIS = sOutOASIS.substring(0, length);
	IMPLog.warn("1000k-character limit reached, ignoring remaining output from llc");
	}
	iProcessOASIS = process.waitFor();
	mpOASISYaml.put("filepath", strFilepath);
	mpOASISYaml.put("result", iProcessOASIS);
	if (iProcessOASIS != 0 && !sOutOASIS.isEmpty()) {
	IMPLog.error("Return value from llc for file "+strFilepath+": "+iProcessOASIS);
	if (iProcessOASIS == 99) {
	IMPLog.error("design in "+strFilepath+" failed llc check");

	}else{
	IMPLog.error("llc command for file "+strFilepath+" failed");
	}
	IMPLog.error("Output from llc:");
	mpOASISYaml.put("output",(getYamlOutputForDLCorOASIS(sOutOASIS, false)).get("yamlfileOutput"));
	IMPLog.error((String)(getYamlOutputForDLCorOASIS(sOutOASIS, false)).get("displayAndEmail"));
	strLLCforOASISOutput = "llc command for file  "+strFilepath+" failed"+"<br>Output from llc:<br>"+(String)(getYamlOutputForDLCorOASIS(sOutOASIS, true)).get("displayAndEmail");
	mpReturn.put("llcpassorfail", "fail");
	}
	if(iProcessOASIS == 0 ){
	IMPLog.info("Return value from llc for file "+strFilepath+": "+iProcessOASIS);
	strLLCforOASISOutput = "llc command passed for file "+strFilepath;
	mpOASISYaml.put("output",(getYamlOutputForDLCorOASIS(strLLCforOASISOutput, false)).get("yamlfileOutput"));
	IMPLog.info(strLLCforOASISOutput);
	mpReturn.put("llcpassorfail", "pass");
	}

	mpReturn.put("yamlfile", mpOASISYaml);
	mpReturn.put("emailandconsoleoutput", strLLCforOASISOutput);

	}
	catch (IOException | InterruptedException e) {
	IMPLog.error("Exception while performing llc" + e);
	throw new IOException("Exception while performing llc" + e);
	}
	return mpReturn;
	}





	//Added for SWIMP-883: Start

	 
	private void downloadSsgqiCfgs(
			IMPEnoviaClientWrapper enoviaWrapper,
			Map<String, Set<String>> ipidToRevsForSsgqiCfg,
			Map yamlOut,
			Path ssgqiCfgDirPath) throws IMPException, IOException {

		IMPLog.info("SWIMP-883 [S00] ENTER runSwimp883DownloadSsgqiCfgs");

		if (ipidToRevsForSsgqiCfg == null || yamlOut == null || enoviaWrapper == null || ssgqiCfgDirPath == null) return;



		// Ensure directory exists
		Files.createDirectories(ssgqiCfgDirPath);

		final String ssgqiCfgLocalDir = ssgqiCfgDirPath.toString();

		Map ssgqiDownloadResults = new LinkedHashMap<>();
		int totalFilesDownloaded = 0;
		int totalFilesAttempted = 0;

		for (Map.Entry<String, Set<String>> entry : ipidToRevsForSsgqiCfg.entrySet()) {
			String ipid = entry.getKey();
			Set<String> revisions = entry.getValue();
			if (StringUtils.isBlank(ipid) || revisions == null || revisions.isEmpty()) continue;

			for (String revision : revisions) {
				totalFilesAttempted++;

				String expectedFileName = ipid + "-" + revision + "-ssgqi-cfg.yaml";
				String expectedLocalPath = ssgqiCfgLocalDir + File.separator + expectedFileName;

				Map fileResult = new LinkedHashMap<>();
				fileResult.put("ipid", ipid);
				fileResult.put("revision", revision);
				fileResult.put("expected_filename", expectedFileName);
				fileResult.put("expected_local_path", expectedLocalPath);

				try {
					Map downloadResult = enoviaWrapper.downloadSsgqiCfgFile(ipid, revision, ssgqiCfgLocalDir);

					String statusStr = (downloadResult == null) ? null : String.valueOf(downloadResult.get("ssgqiCfgStatus"));
					boolean ok = "Success".equals(statusStr) || "FALLBACK_USED".equals(statusStr);

					if (ok) {
						String downloadedFileName = (String) downloadResult.get("ssgqiCfgFileName");
						String actualLocalPath = ssgqiCfgLocalDir + File.separator + downloadedFileName;

						File actualLocalFile = new File(actualLocalPath);

						if (actualLocalFile.exists() && actualLocalFile.length() > 0) {
							File expectedLocalFile = new File(expectedLocalPath);
							if (!expectedLocalFile.getName().equals(downloadedFileName)) {
								try {
									Files.copy(actualLocalFile.toPath(), expectedLocalFile.toPath(),
											java.nio.file.StandardCopyOption.REPLACE_EXISTING);
								} catch (Exception ex) {
									IMPLog.warn("SWIMP-883: normalization copy failed: " + ex);
								}
							}

							fileResult.put("status", "downloaded");
							fileResult.put("message", "SSGQI config file downloaded successfully");
							fileResult.put("downloaded_filename", downloadedFileName);
							fileResult.put("actual_local_path", actualLocalPath);
							fileResult.put("file_size_bytes", actualLocalFile.length());
							totalFilesDownloaded++;
						} else {
							fileResult.put("status", "partial_download");
							fileResult.put("message", "Server reported success but file missing locally");
							fileResult.put("downloaded_filename", downloadedFileName);
							fileResult.put("actual_local_path", actualLocalPath);
						}
					} else {
						String msg = (downloadResult == null) ? "Download failed" : String.valueOf(downloadResult.get("message"));
						fileResult.put("status", (statusStr == null) ? "error" : statusStr.toLowerCase());
						fileResult.put("message", msg);
					}

				} catch (Exception e) {
					fileResult.put("status", "error");
					fileResult.put("message", "Error downloading SSGQI config file: " + e.getMessage());
				}

				ssgqiDownloadResults.put(ipid + "_" + revision, fileResult);
			}
		}

		Map ssgqiSummary = new LinkedHashMap<>();
		ssgqiSummary.put("download_directory", ssgqiCfgLocalDir);
		ssgqiSummary.put("total_files_attempted", totalFilesAttempted);
		ssgqiSummary.put("total_files_downloaded", totalFilesDownloaded);
		ssgqiSummary.put("total_files_not_found", totalFilesAttempted - totalFilesDownloaded);
		ssgqiSummary.put("file_results", ssgqiDownloadResults);

		yamlOut.put("ssgqi_config_download", ssgqiSummary);

		IMPLog.info("SWIMP-883 [S64] EXIT runSwimp883DownloadSsgqiCfgs");
	}

private Map<String, Object> runSSGQI(
        String socName,
        Path specFile,
        Path ipExtraFilesDir,
        Path reportPath,
        String sQueueName,
        String sGdsOrOasPath,
        IMPEnoviaClientWrapper enoviaWrapper,
        String verifyId) throws IOException {

    final long t0 = System.currentTimeMillis();
    final String logPfx = "[SSGQI] ";

    IMPLog.info(logPfx + "ENTER runSSGQI");

    IMPLog.info(logPfx + "inputs socName=" + socName
            + ", specFile=" + (specFile == null ? "" : specFile)
            + ", ipExtraFilesDir=" + (ipExtraFilesDir == null ? "" : ipExtraFilesDir)
            + ", reportPath=" + (reportPath == null ? "" : reportPath)
            + ", sQueueName=" + StringUtils.defaultString(sQueueName)
            + ", sGdsOrOasPath=" + StringUtils.defaultString(sGdsOrOasPath));

    final List<String> stclArgsList = new ArrayList<>();
    String sOut = "";
    int rc = -1;

    final Map<String, Object> mpSsgqiYaml = new LinkedHashMap<>();
    final Map<String, Object> mpReturn = new LinkedHashMap<>();
    final IMPStclcWrapper stclWrapper = new IMPStclcWrapper();

    try {
        // ===== LOCAL execution (no BSUB) =====
        IMPLog.trace(logPfx + "Step(1) LOCAL mode: skipping BSUB prepend");
        final boolean appendedBsub = false;

        if (StringUtils.isNotBlank(sQueueName) || StringUtils.isNotBlank(sGdsOrOasPath)) {
            IMPLog.info(logPfx + "LOCAL mode active; ignoring queueName/gdsOrOasPath for BSUB");
        }

        IMPLog.trace(logPfx + "Step(2) Build SSGQI command");
        final long tc0 = System.currentTimeMillis();

        final List<String> cmd = Utility.getSsgqiCommand(socName, specFile, ipExtraFilesDir, reportPath);

        IMPLog.info(logPfx + "getSsgqiCommand built cmdCount=" + (cmd == null ? -1 : cmd.size())
                + " (elapsedMs=" + (System.currentTimeMillis() - tc0) + ")");

        if (cmd != null) {
            stclArgsList.addAll(cmd);
        }

        IMPLog.info(logPfx + "Running ssgqi for soc " + socName + " (bsub=" + appendedBsub + ")");
        IMPLog.info(logPfx + "SSGQI command: " + String.join(" ", stclArgsList));

        IMPLog.trace(logPfx + "Step(3) Create ProcessBuilder (local)");
        final ProcessBuilder pb = new ProcessBuilder(stclArgsList);
        pb.redirectErrorStream(true);

        IMPLog.trace(logPfx + "Step(4) Set environment SSGQITOOLSVER=3.0");
        pb.environment().put("SSGQITOOLSVER", "3.0");

        IMPLog.trace(logPfx + "Step(5) Start process");
        final long tp0 = System.currentTimeMillis();
        final Process process = pb.start();
        IMPLog.info(logPfx + "Process started (elapsedMs=" + (System.currentTimeMillis() - tp0) + ")");

        IMPLog.trace(logPfx + "Step(6) Capture combined stdout/stderr");
        final long to0 = System.currentTimeMillis();
        sOut = stclWrapper.outputForYaml(process);
        sOut = (sOut == null) ? "" : sOut.trim();

        IMPLog.info(logPfx + "Captured output chars=" + sOut.length()
                + " (elapsedMs=" + (System.currentTimeMillis() - to0) + ")");

        final int preview = Math.min(1500, sOut.length());
        IMPLog.trace(logPfx + "Output preview(<=1500): " + (preview == 0 ? "" : sOut.substring(0, preview)));

        IMPLog.trace(logPfx + "Step(7) Apply output length cap (10,000,000 chars)");
        final int lengthCap = 10_000_000;
        if (sOut.length() > lengthCap) {
            sOut = sOut.substring(0, lengthCap);
            IMPLog.warn(logPfx + "Output capped to " + lengthCap + " chars; remainder ignored");
        }

        IMPLog.trace(logPfx + "Step(8) Wait for process exit");
        final long tw0 = System.currentTimeMillis();
        rc = process.waitFor();
        IMPLog.info(logPfx + "Process exit rc=" + rc + " (waitMs=" + (System.currentTimeMillis() - tw0) + ")");

        IMPLog.trace(logPfx + "Step(9) Build YAML-like structured return map");
        mpSsgqiYaml.put("soc", socName);
        mpSsgqiYaml.put("spec_file", specFile == null ? "" : specFile.toString());
        mpSsgqiYaml.put("ip_extra_files_dir", ipExtraFilesDir == null ? "" : ipExtraFilesDir.toString());
        mpSsgqiYaml.put("report_path_base", reportPath == null ? "" : reportPath.toString());
        mpSsgqiYaml.put("result", rc);
        mpSsgqiYaml.put("bsub_invoked", appendedBsub);
        mpSsgqiYaml.put("queue_name", StringUtils.defaultString(sQueueName));

        IMPLog.trace(logPfx + "Step(10) Determine report xlsx existence");
        final Path reportXlsx = (reportPath == null) ? null : Paths.get(reportPath.toString() + ".xlsx");
        final boolean reportExists = (reportXlsx != null && Files.exists(reportXlsx));

        mpSsgqiYaml.put("report_xlsx_path", reportXlsx == null ? "" : reportXlsx.toString());
        mpSsgqiYaml.put("report_exists", reportExists);

        IMPLog.info(logPfx + "reportXlsx=" + (reportXlsx == null ? "" : reportXlsx.toString())
                + ", exists=" + reportExists);

        // Copy XLSX file to server if it exists
        String serverReportPath = "";
        if (reportExists && reportXlsx != null) {
            try {
                String serverDir = "/tmp/";
                int uploadResult = Utility.uploadFileToServer(reportXlsx.toString(), serverDir);

                if (uploadResult == 0) {
                    serverReportPath = serverDir + reportXlsx.getFileName().toString();
                    IMPLog.info(logPfx + "Successfully copied XLSX report to server: " + serverReportPath);

                    mpSsgqiYaml.put("server_report_xlsx_path", serverReportPath);

                    try {
                        IMPLog.info(logPfx + "Converting Excel to JSON and storing in attribute of verify object " + verifyId);

                        boolean conversionSuccess = enoviaWrapper.executeCSKValidateBOM(
                                serverReportPath,
                                "Sheet1",
                                verifyId
                        );

                        if (conversionSuccess) {
                            IMPLog.info(logPfx + "Successfully converted Excel to JSON and stored in attribute");
                        } else {
                            IMPLog.error(logPfx + "Failed to convert Excel to JSON");
                            mpSsgqiYaml.put("json_conversion_error", "Conversion failed");
                        }

                    } catch (Exception e) {
                        IMPLog.error(logPfx + "Exception during Excel to JSON conversion: " + e.getMessage());
                        mpSsgqiYaml.put("json_conversion_error", e.getMessage());
                    }

                } else {
                    IMPLog.error(logPfx + "Failed to copy XLSX report to server");
                    mpSsgqiYaml.put("server_report_xlsx_error", "Upload failed");
                }

            } catch (Exception e) {
                IMPLog.error(logPfx + "Exception while copying XLSX to server: " + e.getMessage());
                mpSsgqiYaml.put("server_report_xlsx_error", e.getMessage());
            }
        }

        IMPLog.trace(logPfx + "Step(11) Pass/fail + output behavior (LLC-like)");
        if (rc != 0) {
            final Map<String, Object> yamlMap = getYamlOutputForDLCorOASIS(sOut, false);
            mpSsgqiYaml.put("output", yamlMap.get("yamlfileOutput"));

            final Map<String, Object> htmlMap = getYamlOutputForDLCorOASIS(sOut, true);
            final String ssgqiOutputHtml = (String) htmlMap.get("displayAndEmail");

            mpReturn.put("ssgqipassorfail", "fail");
            mpReturn.put("ssgqi_output_html", ssgqiOutputHtml);
            mpReturn.put("emailandconsoleoutput",
                    "ssgqi command for soc " + socName + " failed"
                            + "<br>Output from ssgqi:<br>"
                            + StringUtils.defaultString(ssgqiOutputHtml));

            IMPLog.warn(logPfx + "SSGQI marked FAIL (rc=" + rc + ")");

        } else {
            // UPDATED: avoid "ssgqi command passed for soc <socName>" anywhere in PASS artifacts
            mpSsgqiYaml.put("output",
                    getYamlOutputForDLCorOASIS("ssgqi_pass", false).get("yamlfileOutput"));

            mpReturn.put("ssgqipassorfail", "pass");

            // UPDATED: keep pass output empty/minimal (no socName, no server path)
            String passMsg = "";
            if (reportExists && reportXlsx != null) {
                passMsg = "<br>Report generated: " + reportXlsx.toString() + "<br>";
            }

            mpReturn.put("ssgqi_output_html", passMsg);
            mpReturn.put("emailandconsoleoutput", passMsg);

            IMPLog.info(logPfx + "SSGQI marked PASS");
        }

        mpReturn.put("yamlfile", mpSsgqiYaml);

        IMPLog.info(logPfx + "EXIT runSSGQI ok (elapsedMs=" + (System.currentTimeMillis() - t0) + ")");
        return mpReturn;

    } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        IMPLog.error(logPfx + "Interrupted while waiting; elapsedMs=" + (System.currentTimeMillis() - t0), e);
        throw new IOException("Exception while performing ssgqi " + e, e);

    } catch (IOException e) {
        IMPLog.error(logPfx + "IOException while running ssgqi; elapsedMs=" + (System.currentTimeMillis() - t0), e);
        throw new IOException("Exception while performing ssgqi " + e, e);

    } catch (RuntimeException e) {
        IMPLog.error(logPfx + "RuntimeException while running ssgqi; elapsedMs=" + (System.currentTimeMillis() - t0), e);
        throw e;
    }
}
	//Added for SWIMP-883: End




















	}

