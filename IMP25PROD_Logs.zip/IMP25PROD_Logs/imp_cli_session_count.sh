#ADMIN_EMAIL="vivek.kalra@broadcom.com ramakrishna.gokeda@broadcom.com khoa.phan@broadcom.com sujatha.ramakrishnan@broadcom.com"
ADMIN_EMAIL="vivek.kalra@broadcom.com ramakrishna.gokeda@broadcom.com khoa.phan@broadcom.com dt-imp-ams.pdl@broadcom.com"
echo "Sending email to admin..."
MONTH=$((10#$(date -d '-1 day' +%m)))

YEAR=$(date +%Y)
if [ 12 == "$MONTH" ]
then
  YEAR=$(($(date +%Y) - 1))
fi

while [[ $(echo -n ${MONTH} | wc -c) -lt 2 ]] ; do
    MONTH="0${MONTH}"
done

echo "$MONTH-$YEAR..."
cd /opt/app/3DSpaceBase/tomee_NoCAS/logs/
NoOfSession=$(grep -oR --include "localhost_access_log.$YEAR-$MONTH-*.txt" 'checkAllUsers'  /opt/app/3DSpaceBase/tomee_NoCAS/logs/ | wc -l)
echo "No of CLI Session in $MONTH-$YEAR: $NoOfSession"
MESSAGE="3DSpace Node-1 Number of CLI Sessions are $NoOfSession"
mail -s "PROD: 3DSpace Node-1 CLI Sessions for $MONTH-$YEAR" "$ADMIN_EMAIL" <<< $MESSAGE
