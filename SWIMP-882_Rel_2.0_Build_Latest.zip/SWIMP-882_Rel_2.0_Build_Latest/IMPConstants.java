
/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : IMPConstants.java
 * DESCRIPTION  : Interface class for the constants in IMP
 * 
 * USAGE        : java -jar ${PATH}/imp.jar
 *              
 * CREATED      : 17-August-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * HISTORY:
 * 
 * Name                     Modified Date                 Description
 * 
 * Sai Prasad               17-Aug-2016                   Initial version.
 * Aravala Raju             14-Sep-2016                   Updated with IPICA related property entries
 * Aravala Raju				03-Oct-2016                   IMPBRCM-171 implemented
 * Sai Prasad               31-Oct-2016                   Modified date format to yyyy-mm-dd to the console
 * Sai Prasad               23-Nov-2016                   Added constants for dtree spec
 * Kesava Chekka            29-Nov-2016                   Bug fix for #662
 * Kesava Chekka            29-Nov-2016                   Fixed bug for #IMPBRCM-291 
 * Sai/ Raju                15-Feb-2017                   Moved getUserNameAndPass from IMPConstants class. for bug 803
 * Mahammed Irshad K S		15-Oct-2018					  Added constants IMP_CONST_PROJ_NAME and IMP_CONST_EXEC_FAILED for SWIMP-262
 * Mahammed Irshad K S		03-May-2019					  Added Constants for SWIMP-354
 * Mahammed Irshad K S		05-Apr-2020					  Added method getAllToolMappings and Constants for SWIMP-425
 * Mahammed Irshad K S		15-May-2021					  Added a constant variable for SWIMP-531 (Change Request)
 *------------------------------------------------------------------------------------------------------------------------------------------
 */
package com.broadcom.impcli.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Interface Constants.
 */
public interface IMPConstants{

  /** The Constant NAME. */
  public static final String SYNC_DIR = getPropertyValue("Sync_Dir");
  public static final String SYNC_CUSTOM_DIR = getPropertyValue("Sync_Custom_Dir");
  public static final String SYNC_DIR_BRCM = getPropertyValue("Sync_Dir_Brcm");
  public static final String SYNC_CUSTOM_DIR_BRCM = getPropertyValue("Sync_Custom_Dir_Brcm");
  public static final String MISSING_IP_ID = getPropertyValue("Missing_IP_ID");
  public static final String MISSING_ARGS = getPropertyValue("Missing_Create_or_Update");
  public static final String SCRIPT_FILE = getPropertyValue("Script_File");
  public static final String INVALID_KEY = getPropertyValue("InValid_Key");
  public static final String IMPCLI_IPDIR = getPropertyValue("IMPCLI_IPDIR");
  public static final String IMPCLI_IPID = getPropertyValue("IMPCLI_IPID");
  public static final String IMPCLI_DEBUG = getPropertyValue("IMPCLI_DEBUG");
  public static final String IMP_CLI_PROCEDURE_PREPARE_SA = getPropertyValue("IMP_CLI_PROCEDURE_PREPARE-SA");
  public static final String IMP_CLI_PROCEDURE_WATERMARK = getPropertyValue("IMP_CLI_PROCEDURE_WATERMARK");
  public static final String IMP_CLI_PROCEDURE_LS = getPropertyValue("IMP_CLI_PROCEDURE_LS");
  public static final String IMP_CLI_PROCEDURE_DIFF = getPropertyValue("IMP_CLI_PROCEDURE_DIFF");
  public static final String IMP_CLI_PROCEDURE_PREFIX = getPropertyValue("IMP_CLI_PROCEDURE_PREFIX");
  public static final String IMP_CLI_PROCEDURE_INFO = getPropertyValue("IMP_CLI_PROCEDURE_INFO"); //Added for SWIMP-6
  public static final String IMP_CLI_PURGE_DAY_COUNT = getPropertyValue("IMP_CLI_PURGE_DAY_COUNT"); //Added for SWIMP-76

  public static final String IMP_AUTH_USER = getPropertyValue("IMP_AUTH_USER");
  public static final String IMP_LINE_SEPERATOR = System.getProperty("line.separator");
  public static final String IMP_CLI_PROCEDURE_DOWNLOAD = getPropertyValue("IMP_CLI_PROCEDURE_DOWNLOAD");
  public static final String IMP_CLI_PROCEDURE_GETIPREVISIONS = getPropertyValue("IMP_CLI_PROCEDURE_GETIPREVISIONS");
  public static final String IMP_MESSAGE = "message";
  
  public static final String IMP_AUTHORIZATION = "authorization";
  public static final String IMP_CLI_SERVER_HOST = getPropertyValue("IMP_CLI_SERVER_HOST");
  public static final String IMP_CLI_SERVER_HOST_2 = getPropertyValue("IMP_CLI_SERVER_HOST_2");
  public static final String IMP_CLI_SERVER_USER = getPropertyValue("IMP_CLI_SERVER_USER");
  public static final String IMP_CLI_SERVER_PASS = getPropertyValue("IMP_CLI_SERVER_PASS");
  public static final String IMP_CLI_SERVER_WORKING_DIR = getPropertyValue("IMP_CLI_SERVER_WORKING_DIR");
  public static final String IMP_CLI_WORKING_DIR = getPropertyValue("IMP_CLI_WORKING_DIR");
  public static final String IMP_IPINFO = getPropertyValue("IMP_IPINFO");
  public static final String IMP_DLC_CMD = getPropertyValue("IMP_DLC_CMD");
  public static final String IMP_LLC_CMD = getPropertyValue("IMP_LLC_CMD");
  public static final String IMP_SOC_IPSCORE = getPropertyValue("IMP_SOC_IPSCORE");
  public static final String IMP_IPINFO_OPTS = getPropertyValue("IMP_IPINFO_OPTS");
  public static final String IMP_3PIP_WATERMARK_RUN_PATH = getPropertyValue("IMP_3PIP_WATERMARK_RUN_PATH");
  public static final String IMPCLI_MODULE_CACHE = getPropertyValue("IMPCLI_MODULE_CACHE");
  public static final String IMP_SYNC_DIR = "SYNC_DIR";
  public static final String IMP_SYNC_CUST_DIR = "SYNC_CUSTOM_DIR";
  public static final String IMP_CLI_PROCEDURE_DOWNLOAD_CACHE = getPropertyValue("IMP_CLI_PROCEDURE_DOWNLOAD_CACHE");
  public static final String IMP_FILE = getPropertyValue("IMP_DUMMY_FILE");
  public static final String IMP_UNIQUIFY_OUTPUTFILES = getPropertyValue("IMP_UNIQUIFY_OUTPUTFILES"); //Added for SWIMP-87
  
  //Added for SWIMP-425: Starts
  public static final String IMP_TOOL_BASED_MAPPING = getPropertyValue("IMP_TOOLS_MAPPING");
  public static final String IMP_CHECKLAYER_TOOL_PATH = getPropertyValue("IMP_GDSLAYERCHECK_PATH");
  public static final String IMP_TECHSTACK_EXCEPTION_FILE = getPropertyValue("IMP_TECHSTACK_EXCEPTION_FILE");
  public static final String IMP_CLI_ETC_FOLDER = getPropertyValue("IMP_CLI_ETC_FOLDER");
  public static final String IMP_CHECKLAYER_ERRORFILE = "checklayers.err";
  public static final String IMP_CHECKLAYER_OUTPUTFILE = "checklayers.out";
  public static final String CONST_LINESPEPARATOR = "line.separator";
  public static final String IMP_ATTRIBUTE_IPSOURCE = "attribute[IMP_IPSource]";
  public static final String IMP_ATTRIBUTE_IPTYPE = "attribute[IMP_IPType]";
  public static final String IMP_ATTRIBUTE_IPTYPE_HARDCUSTOM = "Hard IP (custom)";
  public static final String IMP_ATTRIBUTE_IPTYPE_HARDSTD = "Hard IP (standard)";
  public static final String IMP_ATTRIBUTE_IPSOURCE_3PIP = "3PIP";
  public static final String IMP_TECHSTACK_ATTR_FOUNDRY = "foundry";
  public static final String IMP_TECHSTACK_ATTR_PROCESSNODE = "node";
  public static final String IMP_TECHSTACK_ACTUALATTR_PROCESSNODE = "process_node";
  public static final String IMP_TECHSTACK_ATTR_SUBPROCESS = "sub_process";
  public static final String IMP_TECHSTACK_ATTR_METALSTACK = "metal_stack";
  public static final String REGX_LOWERCASE = "lowerCase";
  public static final String REGX_UPPERCASE = "lowerCase";
  public static final String MAPKEY_NAME = "name";
  public static final String MAPKEY_TECHSTACKSPEC = "tech_stack_spec";
  public static final String TOOL_CHECKLAYERS = "checklayers";
  public static final String IMP_TECHSTACK_ATTR_SEL_SUBPROCESS = "attribute[IMP_SubProcess]";
  public static final String IMP_TECHSTACK_ATTR_SEL_METALSTACK = "attribute[IMP_MetalStack]";
  public static final String IMP_TECHSTACK_ATTR_SEL_FOUNDRY = "attribute[IMP_Foundry]";
  public static final String IMP_TECHSTACK_ATTR_SEL_PROCESSNODE = "attribute[IMP_ProcessNode]";
  //Added for SWIMP-425: Ends

  public static final String IMP_CLI_TMP_FOLDER = getPropertyValue("IMP_CLI_TMP_FOLDER"); //Added for SWIMP-471

  public static final String ENOVIA_BASE_URL = getBaseURL("ENOVIA_BASE_URL");
  
  public static final String IMP_SERVICE_URL = ENOVIA_BASE_URL+"/resources/IMP/";
  
  public static final String IPICA_BASE_PATH = getPropertyValue("IPICA_BASE_PATH");
  public static final String IPICA_EXEC_NAME = getPropertyValue("IPICA_EXEC_NAME");
  public static final String IPICA_RUNPATH = getPropertyValue("IPICA_RUNPATH");
  
  public static final String WATERMARK_RUNPATH = getPropertyValue("WATERMARK_RUNPATH");
  public static final String IMP_UNIQUIFY_RUN_PATH = getPropertyValue("IMP_UNIQUIFY_RUN_PATH"); //Added for SWIMP-87
  
  public static final String TIME_STAMP = "yyyyMMddHHmmssSSS";
  public static final String DDMMYYYYhhmmss = "yyyy-M-dd hh:mm:ss";
  public static final String GMT_TIMEZONE = "GMT";
  
  public static final String IMP_CONST_IP_NAME = "IPName";
  public static final String IMP_CONST_U_NAME = "UserName";
  public static final String IMP_CONST_EVENT = "Event";
  //Added for the SWIMP-262: Starts
  public static final String IMP_CONST_PROJ_NAME = "ProjectName";
  public static final String IMP_CONST_EXEC_FAILED = "Execution Failed.";
  public static final String IMP_CONST_OBJECTTYPE = "ObjectType";
  public static final String IMP_CONST_OBJECTNAME = "ObjectName";
  public static final String IMP_CONST_COMMAND = "Command";
  public static final String IMP_CONST_TYPE_IPPRODUCT = "IMP_IPProduct";
  public static final String IMP_CONST_TYPE_IMPSOC = "IMP_SoC";
  public static final String IMP_CONST_TYPE_IMPDTREESPEC = "IMP_DirectoryTreeSpec";
  public static final String IMP_CONST_SPECVERSION = "SpecVersion";
  public static final String IMP_CONST_AUTHENTICATIONSUCCESS = "Authentication success";
  public static final String IMP_CONST_AUTHENTICATIONFAILED = "Authentication failed";
  //Added for the SWIMP-262: Ends
  public static final String IMP_CONST_HTTP_ERROR = "Failed : HTTP error code : ";
  
  public static final String HELP_ALL = "help-all.out.ref";
  public static final String HELP_BASIC = "help-basic.out.ref";
  public static final String HELP_PREPARE_SA = "help-prepare-sa.out.ref";
  public static final String HELP_PUBLISH = "help-publish.out.ref";
  public static final String HELP_CHECK_BOM = "help-check-bom.out.ref";
  public static final String HELP_DIFF = "help-diff.out.ref";
  public static final String HELP_DOWNLOAD = "help-download.out.ref";
  public static final String HELP_EXPORT_BOM = "help-export-bom.out.ref";
  public static final String HELP_MAKE_BRANCH = "help-make-branch.out.ref";
  public static final String HELP_PREFIX = "help-uniquify.out.ref";
  public static final String HELP_QUERY = "help-query.out.ref";
  public static final String HELP_SWITCH_BRANCH = "help-switch-branch.out.ref";
  public static final String HELP_VERIFYIP = "help-verify-ip.out.ref";
  public static final String HELP_WATER_MARK = "help-watermark.out.ref";
  public static final String HELP_LS = "help-ls.out.ref";
  public static final String HELP_DTREE = "help-dtree-spec.out.ref";
  public static final String HELP_INFO = "help-info.out.ref"; //SWIMP-6
  public static final String HELP_ACTIVATEUSER = "help-activate-user.out.ref"; //SWIMP-267
  
  public static final String IMP_OUT_COMMANDLINE = "commandline";
  public static final String IMP_OUT_VERSION = "impversion";
  public static final String IMP_OUT_STARTTIME = "starttime"; //Modified for SWIMP-568
  public static final String IMP_OUT_LOGFILE = "logfile";
  public static final String IMP_OUT_ENDTIME = "endtime"; //Modified for SWIMP-568
  public static final String IMP_OUT_ELAPSEDTIME = "elapsedtime"; //Modified for SWIMP-568
  public static final String IMP_OUT_EXITSTATUS = "exitstatus";
  public static final String IMP_OUT_DOMAIN = "hostname";
  public static final String IMP_OUT_RESULT = "result";
  public static final String IMP_USERNAME = "userlogin";
  public static final String IMP_HEADER = "execution_info_header";
  public static final String IMP_FOOTER = "execution_info_footer";
  public static final String IMP_LOG_PATH = "/.imp/log/";
  
  public static final String IMP_OUT_VERSION_YAML = "impversion";
  public static final String IMP_OUT_COMMANDLINE_YAML = "commandline";
  public static final String IMP_OUT_STARTTIME_YAML = "starttime";
  public static final String IMP_OUT_LOGFILE_YAML = "logfile";
  public static final String IMP_OUT_ENDTIME_YAML = "endtime";
  public static final String IMP_OUT_ELAPSEDTIME_YAML = "    elapsedtime(sec)";
  public static final String IMP_OUT_EXITSTATUS_YAML = "    exitstatus";
  public static final String IMP_OUT_DOMAIN_YAML = "    hostname";
  public static final String IMP_OUT_ERRORMSG_YAML = "    errormsg";
  public static final String IMP_OUT_MSG_YAML = "    msg";
  public static final String IMP_USERNAME_YAML = "    userlogin";
  
  public static final String AVAGO = "AVAGO";
  public static final String BROADCOM = "BRCM";
  public static final String SITE = "SITE_VAR";
  public static final String IMP_COMPANY = "Broadcom Limited";
  public static final String IMP_DATE_FORMAT = "yyyy-MM-dd hh:mm:ss a";
  
  public static final String DTREE_ERROR = getPropertyValue("DTREE_ERROR");
  
  public static final String IMP_CLI_LOGLEVEL = getBaseURL("IMP_CLI_LOGLEVEL");
  public static final String IMP_CLI_CHK_BOM_SPEC_ERR_KEY = "Directory Tree specification you have selected has internal errors; Please file a 1.SUPPORT ticket"; //Modified for SWIMP-219
  public static final String IMP_CLI_CHK_BOM_CONFIG_ERR_KEY = " has errors. Please correct and re-run.";
  
  public static Logger log = LoggerFactory.getLogger(IMPConstants.class);
  

  public static final String IMP_STCL_SERVICE_ACCOUNT_TEMP_FILE = getPropertyValue("IMP_STCL_SERVICE_ACCOUNT_TEMP_FILE");
  public static final String IMP_MODULE_URL = getPropertyValue("IMP_MODULE_URL");
  
  public static final String IMP_REPLOC = "strRepLocations";
  public static final String IMP_CONST_IP_TAG = "IPTag";
  public static final String IMP_PUBLISHSITE = "strPublishSite";
  
  public static final String IMP_STCL_TEMP_FILE = getPropertyValue("IMP_STCL_TEMP_FILE");
  
  public static final String IMP_STCL_TEMP_USERREGISTRY = getPropertyValue("IMP_STCL_TEMP_USERREGISTRY");
  public static final String IMP_STCL_SYNC_USER_CFGDIR = getPropertyValue("IMP_STCL_SYNC_USER_CFGDIR");
  public static final String IMP_STCL_SYNC_SITE_CFGDIR = getPropertyValue("IMP_STCL_SYNC_SITE_CFGDIR");
  public static final String IMP_STCL_SYNC_PROJECT_CFGDIR = getPropertyValue("IMP_STCL_SYNC_PROJECT_CFGDIR");
 
  
  public static final String IMP_STCL_Temp_UserRegistry_VDI = getPropertyValue("IMP_STCL_Temp_UserRegistry_VDI_PATH");
  public static final String IMP_STCL_SiteRegistry_VDI = getPropertyValue("IMP_STCL_Temp_SiteRegistry_VDI_PATH");
  public static final String IMP_STCL_ProjectRegistry_VDI = getPropertyValue("IMP_STCL_Temp_ProjectRegistry_VDI_PATH");
  
  public static final String IMP_CLI_PROCEDURE_SWITCH_BRANCH = getPropertyValue("IMP_CLI_PROCEDURE_SWITCH_BRANCH");
  public static final String IMPCLI_HELP = getPropertyValue("IMPCLI_HELP");
  public static final String IMPCLI_HELP_FULL = getPropertyValue("IMPCLI_HELP_FULL");
  public static final String IMPCLI_IPDIR_FULL = getPropertyValue("IMPCLI_IPDIR_FULL");
  public static final String IMPCLI_OFILE = getPropertyValue("IMPCLI_OFILE");
  public static final String IMPCLI_OFILE_FULL = getPropertyValue("IMPCLI_OFILE_FULL");
  public static final String IMPCLI_DRYRUN = getPropertyValue("IMPCLI_DRYRUN");
  public static final String IMPCLI_DRYRUN_FULL = getPropertyValue("IMPCLI_DRYRUN_FULL");
  public static final String IMPCLI_VERBOSE = getPropertyValue("IMPCLI_VERBOSE");
  public static final String IMPCLI_VERBOSE_FULL = getPropertyValue("IMPCLI_VERBOSE_FULL");
  public static final String IMPCLI_MISSING_BRANCH = getPropertyValue("IMPCLI_MISSING_BRANCH");
  public static final String IMPCLI_NOARGS_HELP = getPropertyValue("IMPCLI_NOARGS_HELP");
  public static final String IMP_CLI_PROCEDURE_MAKE_BRANCH = getPropertyValue("IMP_CLI_PROCEDURE_MAKE_BRANCH");
  public static final String IMPCLI_IPID_FULL = getPropertyValue("IMPCLI_IPID_FULL");
  public static final String IMPCLI_FROM_TAG = getPropertyValue("IMPCLI_FROM_TAG");
  public static final String IMPCLI_NOT_VALID_OPT = getPropertyValue("IMPCLI_NOT_VALID_OPT");
  public static final String IMPCLI_DUPLICATED_EX = getPropertyValue("IMPCLI_DUPLICATED_EX");
  
  public static final String IMPCLI_TAG = getPropertyValue("IMPCLI_TAG");
  public static final String IMPCLI_TAG_FULL = getPropertyValue("IMPCLI_TAG_FULL");
  public static final String IMPCLI_OUTPUTFILE = getPropertyValue("IMPCLI_OUTPUTFILE");
  public static final String IMPCLI_OUTPUTFILE_FULL = getPropertyValue("IMPCLI_OUTPUTFILE_FULL");
  public static final String IMPCLI_UNIQUIFY = getPropertyValue("IMPCLI_UNIQUIFY");
  public static final String IMPCLI_FORCENEWPREFIX = getPropertyValue("IMPCLI_FORCENEWPREFIX");
  public static final String IMPCLI_RUNQA = getPropertyValue("IMPCLI_RUNQA");
  public static final String IMP_DOWNLOAD_FROM_CACHE = getPropertyValue("IMP_DOWNLOAD_FROM_CACHE");
  public static final String IMP_DOWNLOAD_FROM_VAULT = getPropertyValue("IMP_DOWNLOAD_FROM_VAULT");
  public static final String IMP_CLI_USERNAME = "UserName";
  public static final String IMP_CLI_PASSPHRASE = "Password";
  public static final String IMP_CLI_ENV = getPropertyValue("IMP_ENV");
  public static final String IMP_ENV = "IMP_ENV";

  public static final String IMP_GENPREFIX_TXT = getPropertyValue("IMP_GENPREFIX_TXT");
  
  public static final String IMP_NO_ARGS_ALLOWED = "Too many arguments: ";
  //Added/Modified for 1113---Start
  public static final String IMP_ENOVIA_DATE_FORMAT = "MM/dd/yyyy hh:mm:ss a";
  //Added/Modified for 1113---End
  public static final String IMP_ERROR = "ERROR";
 
  //Added For SWIMP-3
  public static final String REGEX_FILE_EXTENTION_FOR_WATERMARKING =getPropertyValue("REGEX_FILE_EXTENTION_FOR_WATERMARKING");

  //Added for SWIMP-166 - s
  static final String IMP_PROJECT = "Project";
  static final String IMP_SUBSCRIPTIONUSER = "SubscriptionUser";
  //Added for SWIMP-166 - e
  //Added for SWIMP-281: Starts
  public static final String IMP_CLI_FILE_POST_DOWNLOAD_MSG = getPropertyValue("IMP_CLI_FILE_POST_DOWNLOAD_MSG");
  public static final String FILES_ALLOWED_IN_IMP_DIR = getPropertyValue("FILES_ALLOWED_IN_IMP_DIR")+IMP_CLI_FILE_POST_DOWNLOAD_MSG+";";
  public static final String IMP_CLI_IMP_FOLDER = getPropertyValue("IMP_CLI_IMP_FOLDER");
  //Added for SWIMP-281: Ends
  
  //Added for SWIMP-278: Starts
  public static final int IMP_VERIFY_IP_WATERMARK_DEDUCT_FILE_SIZE_MULTIPLIER = Integer.parseInt(getPropertyValue("IMP_VERIFY_IP_WATERMARK_DEDUCT_FILE_SIZE_MULTIPLIER"));
  public static final String IMP_LSF_RUN_PATH  = getPropertyValue("IMP_LSF_RUN_PATH");
  //Added for SWIMP-278: Ends
  
  //Added for SWIMP-318: Starts
  public static final String IMP_RESTRIICTED_COUNTRIES = getPropertyValue("IMP_RESTRICTED_COUNTRYS");
  public static final String IMP_PQDN_SITE_MAPPING = getPropertyValue("IMP_PQDN_SITE_MAPPING");
  //Added for SWIMP-318: Ends

  //Added for SWIMP-354: Starts
  public static final String CONST_IPDIR_OPTION = "-I";
  public static final String CONST_IP_OPTION = "-i";
  public static final String CONST_CURRDIR_OPTION = "-cwd";
  public static final String CONST_STR_DESIGNSYNC_OUTPUT = "IMP Stcl designsync output";
  public static final String CONST_STR_ERROR = "Error:";
  public static final String CONST_STR_SPACE = " ";
  public static final String CONST_STR_SETREDIRECT_ERROR = "set redirect error...";
  public static final String CONST_STR_DESIGNSYNC_ERROR = "Design Sync Error: ";
  //Added for SWIMP-354: Ends
  
  //Added for SWIMP-367 - s
  public static final String IMP_FILE_TYPES_UNIQUIFICATION = getPropertyValue("IMP_FILE_TYPES_UNIQUIFICATION");
  //Added for SWIMP-367 - e

  // Added for SWIMP-31: Starts
  public static final String ATTRIBUTE_IMP_PRODUCTTYPE = "attribute[IMP_ProductType]";
  // Added for SWIMP-31: Ends

  //Added for SWIMP-558 : Starts
  public static final String BCM_UNIQUIFY_IP_USERGUIDE_URL = getPropertyValue("BCM_UNIQUIFY_IP_USERGUIDE_URL");
  public static final String INFO_BCM_UNIQUIFY_IP_USERGUIDE_REFERENCE_MSG = "Please refer to the User Guide at " + BCM_UNIQUIFY_IP_USERGUIDE_URL + " for information on the different failure modes.";
  //Added for SWIMP-558 : Ends

  public static final String KEY_DECLARED_USAGE = "DECLARED_USAGE"; //Added for SWIMP-531
  public static final String STR_NO = "No"; //Added for SWIMP-531
  public static final String BLOCK_IP = "Block IP"; //Added for SWIMP-569

  //Added for SWIMP-554 : Starts
  public static final String DEFAULT_BRANCH = "Trunk";
  public static final String DSKEY_LATEST= "latest";
  //Added for SWIMP-554 : Ends


  //Added for SWIMP-568 : Starts
  public static final String CONST_OWNER = "owner";
  public static final String CONST_BU = "bu";
  public static final String CONST_REVISION = "revision";
  public static final String CONST_LATESTREVISION = "latest_revision";
  public static final String CONST_DECLATEDFORUSE = "declared_for_use";
  public static final String CONST_ALERT = "alert";
  public static final String CONST_LINEAGE = "lineage";
  public static final String CONST_WATERMARK = "watermark";
  public static final String CONST_INSTANCECOUNT = "instance_count";
  public static final String CONST_CHILDREN = "children";
  public static final String CONST_IPSOURCE = "ip_source";
  public static final String CONST_DESIGNFILE = "design_file";
  public static final String CONST_DEPRECATEDBY = "deprecated_by";
  public static final String CONST_INSTANCES = "instances";
  public static final String CONST_VENDOR = "vendor";
  public static final String CONST_INTERNAL = "internal";
  public static final String CONST_3PIP = "3pip";
  public static final String CONST_DEPRECATED_BY = "deprecated_by";
  public static final String KEY_DETECTEDIPS = "detected_ips";
  public static final String KEY_UNDETECTED_WATERMARKS = "undetected_watermarks";

  public static final String KEY_ID = "id";
  public static final String KEY_IP_HIERARCHY = "ip_hierarchy";
  public static final String ATTRIBUTE_IMP_IPID = "attribute[IMP_IPID]";
  public static final String ATTRIBUTE_IMP_IPTAG = "attribute[IMP_IPTag]";
  public static final String ATTRIBUTE_DESIGN_FILE = "attribute[IMP_Design_File]";
  public static final String ATTRIBUTE_IPREVISIONWATERMARK = "attribute[IMP_IPRevisionWatermark]";
  public static final String ATTRIBUTE_IPXWATERMARK = "attribute[IMP_IPXWaterMark]";
  public static final String ATTRIBUTE_NOOFINSTANCES = "attribute[IMP_NoOfInstances]";
  public static final String ATTRIBUTE_IPOWNER_FROM_IPWATERMARK = "to[IMP_IP_Watermark].from.to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.owner";
  public static final String ATTRIBUTE_IPBU_FROM_IPWATERMARK = "to[IMP_IP_Watermark].from.to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_ProductDivision]";
  public static final String ATTRIBUTE_ALERT_FROM_IPWATERMARK = "to[IMP_IP_Watermark].from.attribute[IMP_Alert]";
  public static final String ATTRIBUTE_IPSOURCE_FROM_IPWATERMARK = "to[IMP_IP_Watermark].from.to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPSource]";
  public static final String ATTRIBUTE_3PIPVENDOR_FROM_IPWATERMARK = "to[IMP_IP_Watermark].from.to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_Vendor]";
  //Added for SWIMP-568 : Ends

  //Added for SWIMP-570 : Starts
  public static final String KEY_REVISION = "revision";
  public static final String KEY_LINEAGE = "LINEAGE";
  public static final String KEYSTRING_DETECTEDWM_BUTNOTFOUNDINIMP = "The Following watermarks (IP name/revision) were detected BUT NOT FOUND IN IMP:";
  public static final String KEY_TOTAL_DETECTED_IPS = "total_detected_ips";
  public static final String KEY_TOTAL_DETECTED_3PIPS = "total_detected_3pips";
  public static final String KEY_TOTAL_DETECTED_INTERNALIPS = "total_detected_internal_ips";
  public static final String KEY_TOTAL_DETECTEDIPS_WITH_ZEROINSTANCECOUNT = "total_detected_ips_with_zero_instance_count";
  public static final String KEY_COUNT = "count";
  public static final String KEY_QUERY_CONSUMED_IPS_VRINFO = "QUERY_CONSUMED_IPS_VRINFO";
  public static final String KEY_IP_STRUCTURE = "ip_structure";
  public static final String KEY_DECLARED_IPS = "declared_ips";
  public static final String KEY_DOWNLOADED_IPS = "downloaded_ips";
  public static final String KEY_VERIFIED_IPS = "verified_ips";
  public static final String KEY_WARNING = "warning";
  public static final String KEY_IPID = "ipid";
  public static final String KEY_USER = "user";
  public static final String KEY_CONST_LINEAGE = "Lineage";
  public static final String KEY_CONST_REQUESTID = "request_id";
  public static final String KEY_CONST_RELEASE = "release";
  public static final String KEY_VERIFY_IPID = "verify_ip_id";
  public static final String KEY_VERIFY_OBJECTNAME = "VerifyObjectName";
  public static final String MAPKEY_REF_COUNT_MAP = "refCountMap";
  public static final String MAPKEY_WM_OBJECTINFO_MAP = "wmObjInfoMap";
  public static final String MAPKEY_WM_CHILDINFO_MAP = "wmChildInfoMap";
  public static final String MAPKEY_ORIGINAL_COUNT = "OriginalCount";
  public static final String MAPKEY_NOT_AVAILABLE_WM = "NotAvaiableWM";
  public static final String MAPKEY_DETECTED_IP_INFO = "detected_ip_info";
  public static final String MAPKEY_MISSING_PROGENY = "MissingProgeny";
  public static final String EVENT_DOWNLOAD = "Download";
  public static final String EVENT_DECLARED = "Declared";
  public static final String EVENT_QUERY = "Query";
  //Added for SWIMP-570 : Ends

  //Added for SWIMP-162 : Starts
  public static final String YAMLKEY_MSG = "msg";
  public static final String YAMLKEY_ERRORMSG = "errormsg";
  public static final String EXPORTBOM_FAIL = "export-bom failed";
  //Added for SWIMP-162 : Ends
  public static final String FOUNDARY_KEY_FOR_SAMSUNG = "samsung";
  public static final String FOUNDARY_VALUE_FOR_SAMSUNG = "ss";
  //Added for SWIMP-720
  public static final String STR_IMP_IPID = "imp_ip_id"; 
  public static final String STR_IMP_IPNAME = "imp_ip_name"; 
  public static final String STR_IMP_IPSOURCE = "imp_ip_source";
  public static final String STR_IMP_DIVISON = "imp_product_division";
  public static final String STR_IMP_IPTYPE = "imp_ip_type"; 
  public static final String STR_IMP_IPLIB = "imp_ip_library";
  public static final String STR_IMP_IPSTYPE = "imp_ip_stype";
  public static final String STR_IMP_IPFOUNDRY = "imp_ip_foundry";
  public static final String STR_IMP_IPPROCESS = "imp_ip_process";
  public static final String STR_IMP_IPSUBPROCESS = "imp_ip_subprocess";
  
  //Added for SWIMP-834
  public static final String SYMBOL_DOT = ".";
  public static final String IMP_CLI_SYNC_FOLDER = getPropertyValue("IMP_CLI_SYNC_FOLDER");
  public static final String CONST_COMMAND_OPTION = "-cmd";
  public static final String CONST_STR_DESIGNSYNC_OUTPUT_COMPARISION_OF = "Comparison of";
  public static final String CONST_STR_DESIGNSYNC_OUTPUT_IDENTICAL_OBJECTS_NOT_REPORTED = "identical objects not reported";
  
  //Added for SWIMP-850
  public static final String IMP_CLI_PREPARE_SA_MARKER_DIR_ERROR = "Directory does not exist or is not a directory:";
  public static final String IMP_CLI_REQUIRES_LIGHTWEIGHT_PUBLISH = getPropertyValue("IMP_CLI_REQUIRES_LIGHTWEIGHT_PUBLISH");
  public static final String IMP_CLI_PREPARE_SA_SELECTOR = getPropertyValue("IMP_CLI_PREPARE_SA_SELECTOR");
  public static final String IMP_CLI_PREPARE_SA_MARKER_EXISTS_MSG = "Marker file already exists:";
  public static final String IMP_CLI_PREPARE_SA_MARKER_FAIL_MSG = "failed to delete marker file:";
  public static final String IMP_CLI_PREPARE_SA_PARTIAL_FAIL_MSG = "failed to create staging area:";
  public static final String IMP_CLI_PREPARE_SA_MARKER_CREATED_KEY = "Marker file created:";
  public static final String IMP_CLI_PREPARE_SA_MARKER_REMOVED_KEY = "Marker file deleted:";
  public static final String IMP_CLI_PREPARE_SA_DEBUG_KEY = "Marker file is in expected state";
  
  public static final String IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_WARN_KEY = "publishing from a partial staging area; forcing a lightweight publish";
  public static final String IMP_CLI_PUBLISH_MARKER_EXISTS_KEY = "Marker file exists:";
  public static final String IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_CHECKBOM_MSG = "skipping check-bom because of the use of --lightweight";
  public static final String IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_CHECKBOM_MSG = "skipping check-bom; forcing a lightweight publish";
  public static final String IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_CHECKLAYERS_MSG = "skipping checklayers because of the use of --lightweight";
  public static final String IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_CHECKLAYERS_MSG = "skipping checklayers; forcing a lightweight publish";
  public static final String IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_WATERMARK_MSG = "Not inserting watermark because of the use of --lightweight";
  public static final String IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_WATERMARK_MSG = "Not inserting watermark; forcing a lightweight publish";
  public static final String IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_IPICA_MSG = "skipping IPICA because of the use of --lightweight";
  public static final String IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_IPICA_MSG = "skipping IPICA; forcing a lightweight publish";
  
  //Added for SWIMP-882
  public static final String IMP_CLI_SSGQI_USERGUIDE_URL = getPropertyValue("IMP_CLI_SSGQI_USERGUIDE_URL");
  public static final String IMP_CLI_SSGQI_TOOL_PATH = getPropertyValue("IMP_CLI_SSGQI_TOOL_PATH");
  public static final String IMP_CLI_SSGQI_IMPID_OPTION = getPropertyValue("IMP_CLI_SSGQI_IMPID_OPTION");
  public static final String IMP_CLI_SSGQI_EXTRA_FILE_OPTION = getPropertyValue("IMP_CLI_SSGQI_EXTRA_FILE_OPTION");
  public static final String IMP_CLI_SSGQI_SPEC_FILE_OPTION = getPropertyValue("IMP_CLI_SSGQI_SPEC_FILE_OPTION");
  public static final String IMP_CLI_SSGQI_REPORT_OPTION = getPropertyValue("IMP_CLI_SSGQI_REPORT_OPTION");
  public static final String IMP_CLI_SSGQI_TEMP_CFG_FOLDER = getPropertyValue("IMP_CLI_SSGQI_TEMP_CFG_FOLDER");
  
  /**
   * Gets the base URL.
   *
   * @param sKey the s key
   * @return the base URL
   */
  static String getBaseURL(String sKey) {
    String sBaseURL = System.getenv(sKey);
    if (sBaseURL != null && sBaseURL.length() > 0) {
      return sBaseURL;
    } else {
      return getPropertyValue(sKey);
    }
  }

  /**
   * Gets the property file.
   *
   * @param propertyKey the operation
   * @return the string
   */
  static String getPropertyValue(String propertyKey) {
    Properties prop = IMPCommon.getProps();
    String sReturn = "";
    if (!propertyKey.isEmpty()) {
      sReturn = prop.getProperty(propertyKey);
      //Added for SWIMP-66 :Start
      if (sReturn != null && sReturn.length() > 0)
      {
    	  sReturn = sReturn.trim();
      }
    //Added for SWIMP-66 :End
    } else {
      log.debug(INVALID_KEY);
    }
    return sReturn;
  }

  //Added for SWIMP-318: Starts
  public static Map<String,String> getPQDNSiteMapping(){
	  Map<String,String> mPQDNSite = new HashMap<>();
	  Arrays.asList(IMP_PQDN_SITE_MAPPING.split("\\~")).forEach(sPQDNSite->{
		  String[] saPQDNSite = sPQDNSite.split(":");
		  mPQDNSite.put(saPQDNSite[0], saPQDNSite[1].split("\\|")[1]);
	  });
	  return mPQDNSite;
  }

  public static List<String> getRestrictedCommands(){
	  List<String> lRestrictedCommands = new ArrayList<>();
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_DOWNLOAD);
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_PREPARE_SA);
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_MAKE_BRANCH);
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_SWITCH_BRANCH);
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_DIFF);
	  lRestrictedCommands.add(IMP_CLI_PROCEDURE_LS);
	  lRestrictedCommands.add("publish");
	  return lRestrictedCommands;
  }
  //Added for SWIMP-318: Ends


  //Added for SWIMP-425: Starts
  public static Map<String,String> getAllToolMappings(){
	  Map<String,String> mToolMap = new HashMap<>();
	  Arrays.asList(IMP_TOOL_BASED_MAPPING.split(",")).forEach(sToolMap->{
		  String[] saToolMap = sToolMap.split("\\|");
		  mToolMap.put(saToolMap[0], saToolMap[1]);
	  });
	  return mToolMap;
  }
  //Added for SWIMP-425: Ends
  public static List<Map> getFoundaryMapping(){
	List<Map> lsAllFoundaryMapping = new ArrayList<>();
	Map<String, String> mpSingleFoundaryMapping = new HashMap<>();
	mpSingleFoundaryMapping.put(FOUNDARY_KEY_FOR_SAMSUNG, FOUNDARY_VALUE_FOR_SAMSUNG);
	lsAllFoundaryMapping.add(mpSingleFoundaryMapping);
	return lsAllFoundaryMapping;
  }
  
}
