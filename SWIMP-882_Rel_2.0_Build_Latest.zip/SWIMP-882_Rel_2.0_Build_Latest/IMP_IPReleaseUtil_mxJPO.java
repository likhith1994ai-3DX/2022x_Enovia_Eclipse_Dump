/*
 * History
 * Rajesh K Sinha 04-May-18 Desc: Modified for SWIMP-128
 * Mahammed Irshad K S 24-Aug-18 Desc: Added Method getAllWaterMarkValues, getTagInfo, getWaterMarkObjectInfoFromReleaseObj and getAllWMsFromWMObject for SWIMP-222
 * Mahammed Irshad K S 19-Sep-18 Desc: Added Method getWaterMarkInfoForIPProduct and Added Constants
 * Manish              21-Sep-18 Desc: Added Code for SWIMP-210
 * Manish              11-Jan-19 Desc: Added/Modified Code for SWIMP-284
 * Manish              15-Mar-19 Desc: Added/Modified Code for SWIMP-334
 * Mahammed Irshad K S 25-Mar-19 Desc: Removed method connectProjectWithIP and added connectProjectToBranch for SWIMP-345
 * Mahammed Irshad K S 25-Mar-19 Desc: Modified method consumeAutoSubsciption for SWIMP-345
 * Mahammed Irshad K S 27-Mar-19 Desc: Added method disconnectLogicalProductsRelationshipFromSoCHIPOnAutoSubscription for SWIMP-345
 * Manish              08-May-19 Replaced deprecated Class com.matrixone.json.JSONArray, com.matrixone.json.JSONObject with org.codehaus.jettison.json.JSONArray, org.codehaus.jettison.json.JSONObject 
 * Mahammed Irshad K S 09-May-19 Desc: Added the method getLogicalProductRelationship for SWIMP-345
 * Mahammed Irshad K S 10-Jun-19 Desc: Modified method consumeAutoSubsciption for SWIMP-341
 * Mahammed Irshad K S 10-Jun-19 Desc: Added setter and getter methods on Auto Subscription for SWIMP-341
 * Mahammed Irshad K S 11-Sep-19 Desc: Modified method getIncompatibleTechStack for SWIMP-380
 * Mahammed Irshad K S 18-Jun-20 Desc: Modified method getJSONStringForSoCInfo and getJSONStringForIPProductInfo for SWIMP-322
 * Mahammed Irshad K S 01-Jul-20 Desc: Modified method getPreapprovedProjectsValues for SWIMP-31
 * Mahammed Irshad K S 30-Oct-20 Desc: Modified method getAttributevaluesInIPRelease for SWIMP-527
 * Mahammed Irshad K S 18-Mar-21 Desc: Modified methods getSoCHIPStructure and getHIPStructure4VerifyIP for SWIMP-564
 * Mahammed Irshad K S 07-Jul-21 Desc: Modified getSoCHIPStructure & getHIPStructure4VerifyIP and added getLatestRevisionofIP & getDeclaredForUsage for SWIMP-568
 * Mahammed Irshad K S 24-Jul-21 Desc: Modified methods getSoCHIPStructure & getHIPStructure4VerifyIP and added methods getSoCHierarchyStructure & getLatestNonDryRunVerifyObjectDetails for SWIMP-570
 * Mahammed Irshad K S 28-Jul-21 Desc: Modified method getBranchConnectedReleasesData for SWIMP-235
 */
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.ParseException; //Added for SWIMP-568
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Arrays;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger; //Added for SWIMP-222

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.matrixone.apps.common.Person;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.domain.util.XSSUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;

import matrix.db.Access;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Page;
import matrix.util.MatrixException;
import matrix.util.Pattern;
import matrix.util.StringItr;
import matrix.util.StringList;

public class IMP_IPReleaseUtil_mxJPO {
	private static String sSPROCESSNODE;
	private static String sTAG_SUBPROCESS = "IMP_SubProcess";
	private static String sTAG_POLYORIENTATION = "IMP_PolyOrientation";
	private static String sFOUNDRY;
	private static String sTAG_IOTYPE = "IMP_IOType";
	protected static final int JSON_INDENT_FACTOR = 2;
	
	//Added for the SWIMP-222 --starts
	private static final String IPIDEXISTS = "IPIDEXISTS";
	private static final String IPNAME = "IPNAME";
	private static final String WATERMARK = "WATERMARK";
	private static final String BRANCHEXISTS = "BRANCHEXISTS";
	private static final String ANYREVISIONPUBLISHEDFORBRANCH = "ANYREVISIONPUBLISHEDFORBRANCH";
	private static final String REVISIONEXISTS = "REVISIONEXISTS";
	private static final String BRANCHNAME = "BRANCHNAME";
	private static final String IPTAG = "IPTAG";
	private static final String IPTAGEXISTS = "IPTAGEXISTS";
	//Added for the SWIMP-222 --ends
	
	/** A string constant with the value emxSemiTeamCollabStringResource. */
	private static final String RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR = "emxSemiTeamCollabStringResource";
	//Added for the SWIMP-222
	private static Logger logger = Logger.getLogger(IMP_IPReleaseUtil_mxJPO.class);
	//Added for SWIMP-284 - s
	private static final String INCOMPACTIBLE_TECHSTACK_MSG ="incompatibleTechStackMsg";			
	private static final String IS_SOCHIPIP_TECHSTACK_SAME ="isSocHIPIPTechStackSame";
	//Added for SWIMP-284 - e

	//Added for SWIMP-341: Starts
	private static String strSubscriptionUserList = "";
	private static String strContextUser = "";
	private static String strIPRevision = "";

	//Set subscription user list
	public static void setStrSubscriptionUserList(String strSubscriptionUserList) {
		IMP_IPReleaseUtil_mxJPO.strSubscriptionUserList = strSubscriptionUserList;
	}

	//Get subscription user list
	public static String getStrSubscriptionUserList() {
		return strSubscriptionUserList;
	}

	//Set CLI Context user
	public static void setContextUser(String strContextUser) {
		IMP_IPReleaseUtil_mxJPO.strContextUser = strContextUser;
	}

	//get CLI Context user
	public static String getContextUser() {
		return strContextUser;
	}

	//Set Downloading revision/tag
	public static void setIPRevision(String strIPRevision) {
		IMP_IPReleaseUtil_mxJPO.strIPRevision = strIPRevision;
	}

	//Get Downloading revision/tag
	public static String getIPRevision() {
		return strIPRevision;
	}
	//Added for SWIMP-341 --Ends

	private static String sbRelWhere = "("+IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS + " != 'Pending' && " + IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS + "!= 'Detected')"; //Added for SWIMP-31

	//Added for SWIMP-570 : Starts
	private Map<String, Object> mpQueryConsumedIPsMap = new HashMap<>();
	private String sCLIOperation = "";
	//Added for SWIMP-570 : Ends


	/**
	 * This method is executed if a specific method is not specified.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds no arguments
	 * @returns int
	 * @throws Exception
	 *             if the operation fails
	 */
	public int mxMain(Context context, String[] args) throws Exception {
		if (!context.isContextSet())
			throw new Exception("not supported on desktop client");
		return 0;
	}

	/**
	 * This method Creates a Branch Object and connects the created Branch
	 * Object to IP object and updates attributes on the Branch object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName , Branch Name and Branch Parent Revision
	 * @returns nothing
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
  public void createBranchAndReleasePostPublish(Context context, String args[]) throws Exception {
		Boolean isContextPushed = false;
		HashMap hm = JPO.unpackArgs(args);
		try {

			String ipName = (String) hm.get("IPName");
			String branchName = (String) hm.get("IMP_IPTag");
			String branchParentTag = (String) hm.get("IMP_BranchParent");
			// Added for the bug IMPBRCM-965
			String sUserName = (String) hm.get("User");
			
			ContextUtil.pushContext(context, sUserName, "", PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
			isContextPushed = true;

			if (branchName.startsWith("\"")) {
				branchName = branchName.substring(1, branchName.length());
			}
			if (branchName.endsWith("\"")) {
				branchName = branchName.substring(0, branchName.length() - 1);
			}

			if (branchParentTag.startsWith("\"")) {
				branchParentTag = branchParentTag.substring(1, branchParentTag.length());
			}
			if (branchParentTag.endsWith("\"")) {
				branchParentTag = branchParentTag.substring(0, branchParentTag.length() - 1);
			}

			String strObjectGeneratorName = FrameworkUtil.getAliasForAdmin(context, DomainConstants.SELECT_TYPE,
					PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), true);
			String strAutoName = DomainObject.getAutoGeneratedName(context, strObjectGeneratorName, null);
			DomainObject domBranchId = new DomainObject();
			domBranchId.createObject(context, PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), strAutoName,
					"-", PropertyUtil.getSchemaProperty(context, "policy_IMP_Branch"),
					PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));

			DomainObject domIPObj = null;
			String sIPid = getIPIdFromIPName(context, ipName);
			domIPObj = new DomainObject(sIPid);

			domBranchId.setAttributeValue(context, "IMP_BranchName", branchName.replace("\"", ""));
			domBranchId.setAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag"),
					branchName);
			domBranchId.setAttributeValue(context,
					PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision"), branchParentTag);

			DomainRelationship.connect(context, domIPObj, "IMP_IPBranch", domBranchId);
			
            String sComment = "--ipid: " + ipName + "; --from-tag: "+ branchParentTag +"; branch name: "+branchName; //SWIMP-576

			IMP_SoC_mxJPO.getIPDeliveryMilestones(context, domBranchId.getId(context));
			
			Map mpData = new HashMap();
	        mpData.put("Tag", branchName);
	        mpData.put("IPID", sIPid);
	        mpData.put("OPERATION", "make-branch");
	        mpData.put("COMMENTS", sComment); //Added for SWIMP-576
	        
	        JPO.invoke(context, "IMP_IPVerification", null, "updateAuditRecords",
	            JPO.packArgs(mpData));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (context != null && isContextPushed) {
				ContextUtil.popContext(context);
			}
		}
	}

	/**
	 * This method Creates a Branch Object Trunk and connects the created Branch
	 * Object to IP object and updates attributes on the Branch object during IP
	 * Creation.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName
	 * @returns int
	 * @throws Exception
	 *             if the operation fails
	 */
	public static int createBranchTrunk(Context context, String sIPid) throws Exception {
		try {
			String branchName = "Trunk";

			String strObjectGeneratorName = FrameworkUtil.getAliasForAdmin(context, DomainConstants.SELECT_TYPE,
					PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), true);
			String strAutoName = DomainObject.getAutoGeneratedName(context, strObjectGeneratorName, null);
			// String branchId = FrameworkUtil.autoName(context,
			// "type_IMP_Branch", "policy_IMP_Branch");
			DomainObject domBranchId = new DomainObject();
			domBranchId.createObject(context, PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), strAutoName,
					"-", PropertyUtil.getSchemaProperty(context, "policy_IMP_Branch"),
					PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));

			DomainObject domIPObj = null;
			domIPObj = new DomainObject(sIPid);
			domBranchId.setAttributeValue(context, "IMP_BranchName", branchName);
			domBranchId.setAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag"),
					branchName);

			DomainRelationship.connect(context, domIPObj, "IMP_IPBranch", domBranchId);

			IMP_SoC_mxJPO.getIPDeliveryMilestones(context, domBranchId.getId(context));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return 0;
	}

	/**
	 * This method Creates a Release Object and connects the created Release
	 * Object to Branch object and updates attribute values on the Release
	 * object during IP publish.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName,IP Revision,IP Publish Comments , Pre
	 *            approve,Published User,Unique WaterMarkID ,IP QASummary , Is
	 *            Prefixed,Quality Class ,GDS Version ,IP QAStatus
	 * @returns nothing.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList connectBranchAndReleaseAfterPublish(Context context, String args[]) throws Exception {		
		String strRepLocations = "";
		Map returnMap = new HashMap();
		MapList mapList = new MapList();
		Boolean isContextPushed = false;

		try {

			String sIPRPolicyAdminAlias = FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_POLICY,
					PropertyUtil.getSchemaProperty(context, "policy_IMP_IPRelease"), true);
			String sIPRTypeAdminAlias = FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_TYPE,
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), true);

			HashMap hm = JPO.unpackArgs(args);
			Map mpAttibMap = new HashMap();
			Map brAttrMap = new HashMap();
			String ipName = (String) hm.get("IPName");
			String sUserName = (String) hm.get("User");
			String sTag = (String) hm.get("IMP_IPTag");
			//Modified for SWIMP-113 Starts
			String sPath=(String)hm.get("sPath");
			String sUploadStatus="";
			String sPubDocs=(String)hm.get("sPubDocs");
			//Modified for SWIMP-113 ends
			
			//Added for SWIMP-882
			String sFTPSSGQICfgPath=(String)hm.get("sFTPSSGQICfgPath");
			String sFTPSSGQICfgFileName=(String)hm.get("sFTPSSGQICfgFileName");
			if (!sFTPSSGQICfgPath.isEmpty() && !sFTPSSGQICfgFileName.isEmpty()) {
				Map mpReturnData = getSSGQICfgYamlUpLoadStatus(context,sUserName,ipName,sTag,sFTPSSGQICfgPath,sFTPSSGQICfgFileName);
				String sSSGQIUploadStatus = (String) mpReturnData.get("SSGQI Status");
				String sSSGQIUploadFileName = (String) mpReturnData.get("SSGQI FileName");
				if(sSSGQIUploadStatus.equals("Success")) {
					returnMap.put("SSGQI Status", "Success");
				} else if(sSSGQIUploadStatus.equals("Failure")) {
					returnMap.put("SSGQI Status", "Failure");
				} else {
					returnMap.put("SSGQI Status", "");
				}
				returnMap.put("SSGQI FileName", sSSGQIUploadFileName);
			}
			//Added for SWIMP-882
			
						
			//Modified for IMPBRCM-1074 Starts
			String sBranchandTag;
			//Modified for IMPBRCM-1074 Ends
			//Added for URL Issue in Publish and Download Emails Starts
			String sIMP_ENV = (String) hm.get("IMP_ENV");
			//Added for URL Issue in Publish and Download Emails Ends
			String sComments = (String) hm.get("IMP_IPPublishComments");
			String sBranchid = "";
			// Added for the bug IMPBRCM-965
			ContextUtil.pushContext(context, sUserName, "", PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
			isContextPushed = true;

			if (sTag.startsWith("\"")) {
				sTag = sTag.substring(1, sTag.length());
			}
			if (sTag.endsWith("\"")) {
				sTag = sTag.substring(0, sTag.length() - 1);
			}
			//Modified for IMPBRCM-1074 Starts
			sBranchandTag = sTag;
			//Modified for IMPBRCM-1074 Ends
			String sPreapprove = (String) hm.get("IMP_Preapprove");
			String sUser = (String) hm.get("User");
			//Added for SWIMP-1 for changing attribute name to IMP_IPRevisionWatermark
			Map <String,String> mWMFile = (Map <String,String>) hm.get("IMP_IPRevisionWatermark");
			//Added for SWIMP-849
			String sWmDerivedFrom = (String) hm.get("IMP_WMDerivedFrom");
			String sIPQASummary = (String) hm.get("IMP_IPQASummary");
			String sIsPrefixed = (String) hm.get("IMP_IsPrefixed");
			String sQualityClass = (String) hm.get("IMP_QualityClass");
			String sGDSVersion = (String) hm.get("IMP_GDSVersion");
			String sIPQAStatus = (String) hm.get("IMP_IPQAStatus");
			String sIPPublishComments = (String) hm.get("IMP_IPPublishComments");
			String sRecommendedRevision = (String) hm.get("RecommendedRevision");
			// Added for IMPBRCM-1102
			String sDefaultRevision = (String) hm.get("DefaultRevision");
			String sDefaultRevTag = "";
			//Added for SWIMP-31
			String sDesignFileNChildIPs2Connect = (String)hm.get("childIpsToConnect");
			String sDesignFileNLineageMap = (String)hm.get("lineageMapInfo");
			String sImpMissingProgenyInstanceWarning = (String)hm.get("IMP_MISSING_PROGENY_INSTANCE_WARNING");
			String sIsRevisionPublishedAsHIP = (String)hm.get("IsRevisionPublishedAsHIP");
			String sIMPUnknownComponentWatermark = (String)hm.get("IMPUnknownComponentWatermark");
            //Added for SWIMP-31
			String sAlert = (String) hm.get("IMP_Alert");

			if (sIsPrefixed != null && !sIsPrefixed.equals("")) {
				mpAttibMap.put("IMP_IsPrefixed", sIsPrefixed);
			}
			if (sPreapprove != null && !sPreapprove.equals("")) {
				mpAttibMap.put("IMP_Preapprove", sPreapprove);
			}
			if (sIPQASummary != null && !sIPQASummary.equals("")) {
				mpAttibMap.put("IMP_IPQASummary", sIPQASummary);
			}
			if (sUser != null && !sUser.equals("")) {
				mpAttibMap.put("IMP_IPPublisher", sUser);
			}
			if (sQualityClass != null && !sQualityClass.equals("")) {
				mpAttibMap.put("IMP_QualityClass", sQualityClass);
			}
			if (sGDSVersion != null && !sGDSVersion.equals("")) {
				mpAttibMap.put("IMP_GDSVersion", sGDSVersion);
			}
			if (sTag != null && !sTag.equals("")) {
				mpAttibMap.put("IMP_IPTag", sTag);
			}

			if (sIPQAStatus != null && !sIPQAStatus.isEmpty()) {
				mpAttibMap.put("IMP_IPQAStatus", sIPQAStatus);
			}

			if (sIPPublishComments != null && !sIPPublishComments.isEmpty()) {
				mpAttibMap.put("IMP_IPPublishComments", sIPPublishComments);
			}

			if (UIUtil.isNotNullAndNotEmpty(sRecommendedRevision) && "true".equalsIgnoreCase(sRecommendedRevision)) {
				brAttrMap.put("IMP_Recommended_Revision", sTag);
			}	
			if (UIUtil.isNotNullAndNotEmpty(sDefaultRevision) && "true".equalsIgnoreCase(sDefaultRevision)) {
				sDefaultRevTag = sTag;
			}	

			if (sAlert != null && !sAlert.isEmpty()) {
				mpAttibMap.put("IMP_Alert", sAlert);
			}
			//Added for SWIMP-31: Starts
			if (UIUtil.isNotNullAndNotEmpty(sImpMissingProgenyInstanceWarning)) {
				mpAttibMap.put(IMP_Constants_mxJPO.ATTRIIBUTE_IMP_MISSINGPROGENYINSTANCEWARNING, sImpMissingProgenyInstanceWarning);
			}
			if (UIUtil.isNotNullAndNotEmpty(sIMPUnknownComponentWatermark)) {
				mpAttibMap.put(IMP_Constants_mxJPO.ATTRIIBUTE_IMP_UNKNOWNWATERMARKWARNING, sIMPUnknownComponentWatermark);
			}
			mpAttibMap.put(IMP_Constants_mxJPO.ATTRIIBUTE_IMP_REVISION_PUBLISHED_AS_HIP, sIsRevisionPublishedAsHIP);
			//Added for SWIMP-31: Ends
			String branchName = "Trunk";
			if (sTag.contains("/")) {
				String[] str_array = sTag.split("/");
				branchName = str_array[0];
				sTag = str_array[1];
			}
			brAttrMap.put("IMP_BranchName", sTag);
			brAttrMap.put("IMP_IPPublishComments", sComments);

			MapList mlRelatedObjList = new MapList();
			DomainObject domIPObj = null;
			String sIPReleaseId = FrameworkUtil.autoName(context, sIPRTypeAdminAlias, "", sIPRPolicyAdminAlias,
					PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
			DomainObject domIPReleaseId = new DomainObject(sIPReleaseId);
			//modified for SWIMP-129
			brAttrMap.put("IMP_PublishDate", domIPReleaseId.getInfo(context, DomainConstants.SELECT_ORIGINATED));

			String sIPid = getIPIdFromIPName(context, ipName);
			domIPObj = new DomainObject(sIPid);

			StringBuffer sbWhere = new StringBuffer();
			sbWhere.append("(attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "] == '");
			sbWhere.append(branchName.trim());
			sbWhere.append("')");

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);

			mlRelatedObjList = (MapList) domIPObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch"), // relationship
					// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), // type
					// pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sbWhere.toString(), // object where
					null, // relationship where
					0); // limit
			if (!mlRelatedObjList.isEmpty()) {
				Map mBranchInfo = (Map) mlRelatedObjList.get(0);
				sBranchid = (String) mBranchInfo.get(DomainConstants.SELECT_ID);
				DomainObject domBranchObj = new DomainObject(sBranchid);
				domBranchObj.setAttributeValues(context, brAttrMap);
				brAttrMap.put("objectId", sBranchid);
				String args0[] = JPO.packArgs(brAttrMap);
				domIPReleaseId.setAttributeValues(context, mpAttibMap);

				DomainRelationship.connect(context, domBranchObj, "IMP_IPBranchRelease", domIPReleaseId);
				//Added for SWIMP-1 starts
				Map wmAttrMap = new HashMap();
				if (null != mWMFile) {
					Set<String> keySet = mWMFile.keySet();
					Iterator<String> keySetIterator = keySet.iterator();
					int nOfWMs = mWMFile.size();
					String value = "";
					String sWMObjId = "";
					DomainObject domWMObj;
					while (keySetIterator.hasNext()) {
						String key = keySetIterator.next();
						if ((String) mWMFile.get(key) != null) {
							value = mWMFile.get(key);

							sWMObjId = FrameworkUtil.autoName(context, "type_IMP_IP_Watermark", "", "policy_IMP_WaterMarkString",
									PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
							domWMObj = new DomainObject(sWMObjId);
							if (mWMFile.size() > 1) 
								wmAttrMap.put("IMP_Design_File", key);
							wmAttrMap.put("IMP_IPTag", sBranchandTag);
							//Added for SWIMP-1 for changinge attribute name to IMP_IPRevisionWatermark 
							wmAttrMap.put("IMP_IPRevisionWatermark", value);
							wmAttrMap.put("IMP_IPID", ipName);
							wmAttrMap.put("IMP_WMDerivedFrom", sWmDerivedFrom);
							domWMObj.setAttributeValues(context, wmAttrMap);

							DomainRelationship.connect(context, domIPReleaseId,PropertyUtil.getSchemaProperty(context, "relationship_IMP_IP_Watermark"),domWMObj);

							// Added for SWIMP-31: Starts
							String strPublishIPProductType = domWMObj.getInfo(context,IMP_Constants_mxJPO.SELECT_PRODUCT_TYPE_FROM_WATERMARK);
							if (UIUtil.isNotNullAndNotEmpty(strPublishIPProductType) && (IMP_Constants_mxJPO.ATTRIBUTE_IMP_PRODUCT_TYPE_RANGE_BLOCKIP).equalsIgnoreCase(strPublishIPProductType) && domWMObj != null && UIUtil.isNotNullAndNotEmpty(sDesignFileNChildIPs2Connect) && UIUtil.isNotNullAndNotEmpty(sDesignFileNLineageMap)) {
								connectIMPIPCHILDRelationship(context, key, sDesignFileNChildIPs2Connect, domWMObj);
							    connectVerificationStatus4HIP(context, nOfWMs, key, sDesignFileNLineageMap, domWMObj,ipName,sBranchandTag);
							}
							// Added for SWIMP-31: Ends

						}
					}
				}
				//Added for SWIMP-1 ends
				updateListofIPDeliveryMilestones(context, args0);
			}
			// 48 User wants to quickly consume the IP cached locally
			if (!"".equals(sBranchid) && sBranchid.length() > 0) {
				strRepLocations = getReplicationLocations(context, sBranchid,ipName,domIPReleaseId,sIMP_ENV, sIPid);
				if (strRepLocations != null && strRepLocations.length() > 0) {
					createHierarchicalReference(context, sIPid, (String) hm.get("IMP_IPTag"), ipName, strRepLocations,sIMP_ENV);					
				}				
			}
			if (UIUtil.isNotNullAndNotEmpty(sDefaultRevision) && "true".equalsIgnoreCase(sDefaultRevision)) {
				domIPObj.setAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IP_Default_Revision"), sDefaultRevTag);
			}			

			String strReleaseTag = (String) mpAttibMap.get("IMP_IPTag");
			String sComment = "--ipid: " + ipName + "; --tag: "+strReleaseTag+"; --comment: " +sIPPublishComments;
			returnMap.put("strRepLocations", strRepLocations);
			returnMap.put("releaseId", sIPReleaseId);
			//Modified for SWIMP-113 Starts
			List<String> lsFinalDocuments = new ArrayList<>();
			if (!sPath.isEmpty() && !sPubDocs.isEmpty()){

				Map mpReturnData = getDocumentUpLoadStatus(context,sPath,ipName,sUserName,sPubDocs);
				lsFinalDocuments = (ArrayList) mpReturnData.get("lsFinalDocuments");
				sUploadStatus = (String) mpReturnData.get("sUploadStatus");

			} else if(sPath.isEmpty() && !sPubDocs.isEmpty()){
				lsFinalDocuments = getArrLtPublicDocuments(sPubDocs);
				sUploadStatus="Partial";
			}
			returnMap.put("lsFinalDocuments", lsFinalDocuments);
			returnMap.put("sUploadStatus",sUploadStatus);
			mapList.add(returnMap);
			//Modified for SWIMP-113 ends
			Map mpData = new HashMap();
			mpData.put("Tag", sBranchandTag);
			mpData.put("IPID", sIPid);
			mpData.put("COMMENTS", sComment); //Added for SWIMP-576
			mpData.put("OPERATION", "publish");
			JPO.invoke(context, "IMP_IPVerification", null, "updateAuditRecords",
					JPO.packArgs(mpData));
			// 207 publish mail notification start
			Map hsmap = new HashMap();
			hsmap.put("strObjectId", sIPid);
			hsmap.put("strAction", "Publish");
			hsmap.put("IPName", ipName);
			//Modified for IMPBRCM-1074 Starts
			hsmap.put("IPTag", sBranchandTag);
			//Modified for IMPBRCM-1074 Ends
			//Modified for IMPBRCM-928 Starts
			hsmap.put("IPPublishComments",sComments);
			//Modified for IMPBRCM-928 Ends
			//Modified For IMPBRCM-718,717,745 & 446 Starts
			hsmap.put("sOktaID", sUser);
			//Added for URL Issue in Publish and Download Emails Starts
			hsmap.put("env", sIMP_ENV);
			//Added for URL Issue in Publish and Download Emails Ends
			hsmap.put("sUploadStatus", sUploadStatus);
			
			// Added for SWIMP-385 - s
			hsmap.put("IMP_Version", hm.get("IMP_Version"));
			hsmap.put("IMP_Commandline", hm.get("IMP_Commandline"));
			hsmap.put("IMP_IPDir", hm.get("IMP_IPDir"));
			hsmap.put("IMP_UsernameDomain", hm.get("IMP_UsernameDomain"));
			// Added for SWIMP-385 - e
			
			
			String args0[] = JPO.packArgs(hsmap);
			//Modified for IMPBRCM-998 Starts
			JPO.invoke(context, "IMP_NotificationUtil", null, "sendMailNotificationwhenIPPublishOrConsume", args0);
			//Modified for IMPBRCM-998 Ends

			// 207 publish mail notification End
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			if (context != null && isContextPushed) {
				ContextUtil.popContext(context);
			}
		}


		return mapList;
	}

	/**
	 * This method gets attribute values on the Release object based on IP Name. 
	 * 	While downloading if the last revision is inactive, it will get the last active revision of the Trunk branch
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName,IP Revision
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList getAttributevaluesInIPRelease(Context context, String args[]) throws Exception {
		HashMap hm = JPO.unpackArgs(args);
		DomainObject domIPObj = null;
		DomainObject domBranchObj = null;
        DomainObject domReleaseObj = null;//Added for SWIMP-1
		HashMap returnMap = new HashMap();
		MapList returnMapList = new MapList();
		MapList mlRelatedObjList = new MapList();
		MapList mlRelatedIPReleaseList = new MapList();
		StringList slRevTag = new StringList();
		Date date;
		SimpleDateFormat formatter = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);

		boolean bGivenTagInactive = false;
		boolean bAllRevInactive = false;
		boolean bRevExists = true;
		//Added for SWIMP-133 :Starts
		boolean bBranchExists = false;
		boolean bRevPublishedforBranch = false;
		//Added for SWIMP-133 :Ends
		int iInactiveRevCount = 0;
		int iTotalRevCount = 0;

		try {
			String ipName = (String) hm.get("IPName");
			String sTag = (String) hm.get("IMP_IPTag");
			boolean isTagSpecified = (boolean) hm.get("isTagSpecified");

			if (sTag.startsWith("\"")) {
				sTag = sTag.substring(1, sTag.length());
			}
			if (sTag.endsWith("\"")) {
				sTag = sTag.substring(0, sTag.length() - 1);
			}

			String branchName = "Trunk";
			if (sTag.contains("/")) {
				String[] strArray = sTag.split("/");
				branchName = strArray[0];
			}
			String sIPid = getIPIdFromIPName(context, ipName);
			domIPObj = new DomainObject(sIPid);
			//Added for SWIMP-190 :Starts
			//Modified for SWIMP-527: Starts
			StringList slselects = new StringList();
			slselects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PRODUCTTYPE);
			slselects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPWATERMARKSEED);
			slselects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTYPE); //Added for SWIMP-527

			Map<String, String> mpIPMap = domIPObj.getInfo(context, slselects);
			String sProductType = mpIPMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PRODUCTTYPE);
			String sIPIDWMSeed = mpIPMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPWATERMARKSEED);
			String sIPType = mpIPMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTYPE); //Added for SWIMP-527
			StringBuilder sbWhere = new StringBuilder();
			sbWhere.append("(" + IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG + " == '");
			sbWhere.append(branchName.trim());
			sbWhere.append("')");
			//Modified for SWIMP-527: Ends

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			mlRelatedObjList = domIPObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_BRANCH, // type pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sbWhere.toString(), // object where
					null, // relationship where
					0); // limit

			if (!mlRelatedObjList.isEmpty()) {
				//Added for SWIMP-133 :Starts
				bBranchExists = true;
				//Added for SWIMP-133 :Ends
				Map mBranchInfo = (Map) mlRelatedObjList.get(0);
				String sBranchid = (String) mBranchInfo.get(DomainConstants.SELECT_ID);
				domBranchObj = new DomainObject(sBranchid);
				// Modified for the Bug IMPBRCM-1003 - START
				
				// ignore Other Top Branches as it is a dummy revision in IMP
				String sWhere = IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG+"!= 'Other Top Branches'";

				StringList slIPRelSelects = new StringList();
				slIPRelSelects.add(DomainConstants.SELECT_ID);
				slIPRelSelects.add(DomainConstants.SELECT_NAME);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASUMMARY);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_REASONFORDEACTIVATION);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ISPREFIXED);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TOPCELL);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_MISSINGPROGENYINSTANCEWARNING);
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_UNKNOWNWATERMARKWARNING);
				slIPRelSelects.add(DomainConstants.SELECT_CURRENT);
				slIPRelSelects.add(DomainConstants.SELECT_ORIGINATED);
				
				slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALERT); // Added for CR 253

				mlRelatedIPReleaseList = domBranchObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
						slIPRelSelects, // Object selects
						null, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						sWhere, // object where
						null, // relationship where
						0); // limit
			}
			if (!mlRelatedIPReleaseList.isEmpty()) {
				//Added for SWIMP-133:Starts
				bRevPublishedforBranch = true;
				//Added for SWIMP-133:Ends
				iTotalRevCount = mlRelatedIPReleaseList.size();
				Iterator iterate = mlRelatedIPReleaseList.iterator();
				String sCurrent = "";
				String sRevTag = "";
				String sWaterMarkId = "";
				String sIPQAStatus = "";
				String sIPQASummary = "";
				String sReasonForDeactivation = "";
				String sIsPrefixed = "";
				String sTopcell = "";
				String sReleaseObjectName = "";
				String strOriginated = "";
				String sAlert = ""; // Added for CR 253
                String sReleaseObjectID = "";//Added for SWIMP-1
				//Added for SWIMP-569 -Start
				String sMissingProgenyInstanceWarn = "";
				String sUnknownWMWarn = "";
				HashMap<String, String> designFileMappingToWM = new HashMap<String, String>();
				String sAttrWMDerivedFrom = "";
				//Added for SWIMP-569 -End
				StringBuilder sbInactiveRev = new StringBuilder();
				TreeMap<Date, Object> mpLatestTagData = new TreeMap<>(Collections.reverseOrder());
				List<String> lsIPXWMList = new ArrayList<>(); //Added for SWIMP-527

				Map mIPReleaseInfo = null;
				while (iterate.hasNext()) {
					mIPReleaseInfo = (Map) iterate.next();
					sRevTag = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
                    //Added for SWIMP-1 start
                    sReleaseObjectID = (String) mIPReleaseInfo.get(DomainConstants.SELECT_ID);
                    domReleaseObj = new DomainObject(sReleaseObjectID);
                    //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
                    StringList slMultipleWMIds = new StringList();
					StringList slWMSelects = new StringList();
                        slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
						slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
						slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
						slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_WMDERIVEDFROM);
						slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
					
						MapList mlWaterMarkList = domReleaseObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
						slWMSelects, // Object selects
						null, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit

						String sAttrIPRevisionWatermark = "";
						String sAttrIPXWaterMark = "";
						String sAttrDesignFile = "";
						String sIPTag = "";
					if (!mlWaterMarkList.isEmpty()) {
						Iterator iterateWM = mlWaterMarkList.iterator();
						Map mIWaterMarkInfo = null;
						HashMap<String, String> mapOfFiles = new HashMap<String, String>();
						while (iterateWM.hasNext()) {
							mIWaterMarkInfo = (Map) iterateWM.next();
							sAttrIPRevisionWatermark = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
							sAttrIPXWaterMark = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
							sAttrDesignFile = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
							sAttrWMDerivedFrom = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_WMDERIVEDFROM);
							sIPTag = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
							//Adding for SWIMP-527: Starts
							if(UIUtil.isNotNullAndNotEmpty(sAttrIPRevisionWatermark)) {
								slMultipleWMIds.add(sAttrIPRevisionWatermark);
								if(sTag.contains(sIPTag)) {
									mapOfFiles.put(sAttrDesignFile, sAttrIPRevisionWatermark);
								}
							} else {
								slMultipleWMIds.add(sAttrIPXWaterMark);
								if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPTYPE_RANGE_SOFT_IP.equalsIgnoreCase(sIPType)) {
									lsIPXWMList.add(sAttrIPXWaterMark);
								}
							}
							//Adding for SWIMP-527: Ends
						}
						designFileMappingToWM.putAll(mapOfFiles);
					}
                    sWaterMarkId = FrameworkUtil.join(slMultipleWMIds, ",");
                    //Added for SWIMP-1 end
					if (!UIUtil.isNullOrEmpty(sRevTag) && !slRevTag.contains(sRevTag)) {
						slRevTag.add(sRevTag);
					}
					strOriginated = (String) mIPReleaseInfo.get(DomainConstants.SELECT_ORIGINATED);
					sCurrent = (String) mIPReleaseInfo.get(DomainConstants.SELECT_CURRENT);
					if (isTagSpecified && sTag.equals(sRevTag)) {
						sReleaseObjectName = (String) mIPReleaseInfo.get(DomainConstants.SELECT_NAME);
						sIPQAStatus = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
						sIPQASummary = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASUMMARY);
						sReasonForDeactivation = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_REASONFORDEACTIVATION);
						sIsPrefixed = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ISPREFIXED);
						sTopcell = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TOPCELL);
						sAlert = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALERT);
						sMissingProgenyInstanceWarn = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_MISSINGPROGENYINSTANCEWARNING);
						sUnknownWMWarn = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_UNKNOWNWATERMARKWARNING);
						break;
					} else if (!isTagSpecified && sTag.equals(sRevTag)) { // if tag is not given, check the tag taken from Designsync is active in IMP
						if ("Inactive".equals(sCurrent)) {
							bGivenTagInactive = true;
						} else {
							sReleaseObjectName = (String) mIPReleaseInfo.get(DomainConstants.SELECT_NAME);
							sIPQAStatus = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
							sIPQASummary = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASUMMARY);
							sReasonForDeactivation = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_REASONFORDEACTIVATION);
							sIsPrefixed = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ISPREFIXED);
							sTopcell = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TOPCELL);
							sAlert = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALERT);
							sMissingProgenyInstanceWarn = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_MISSINGPROGENYINSTANCEWARNING);
							sUnknownWMWarn = (String) mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_UNKNOWNWATERMARKWARNING);
							break;
						}
					}
					if ("Inactive".equals(sCurrent)) {
						iInactiveRevCount++;
					}
					date = formatter.parse(strOriginated);
					mpLatestTagData.put(date, sRevTag);
				}
				boolean flag = false;
				// if tag is not given and the last tag taken from Designsync is inactive, get the last active revision
				if (!isTagSpecified && bGivenTagInactive) {
					for (Map.Entry<Date, Object> entry : mpLatestTagData.entrySet()) {
						String value = (String) entry.getValue();
						Iterator itrRevList = mlRelatedIPReleaseList.iterator();
						Map mIPRevInfo;
						
						while (itrRevList.hasNext()) {
							mIPRevInfo = (Map) itrRevList.next();
							sRevTag = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
							sCurrent = (String) mIPRevInfo.get(DomainConstants.SELECT_CURRENT);
							strOriginated = (String) mIPRevInfo.get(DomainConstants.SELECT_ORIGINATED);
                            //Added for SWIMP-1 start
                            sReleaseObjectID = (String) mIPRevInfo.get(DomainConstants.SELECT_ID);
                            domReleaseObj = new DomainObject(sReleaseObjectID);
                            //Added for SWIMP-1 eend
							if (value != null && value.length() > 0 && sRevTag.equalsIgnoreCase(value)) {
								if (sCurrent.equalsIgnoreCase("Inactive")) {
									sbInactiveRev.append(sRevTag);
									sbInactiveRev.append(", ");
									break;
								} else {
									sReleaseObjectName = (String) mIPRevInfo.get(DomainConstants.SELECT_NAME);
									//Added for SWIMP-1 start
									//Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
                                    StringList slMultipleWMIds = new StringList();
                                    StringList slWMSelects = new StringList();
										slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
										slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
										slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
										slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_WMDERIVEDFROM);
										slWMSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
										MapList mlWaterMarkList = domReleaseObj.getRelatedObjects(context,
										IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK, // relationship pattern
										IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
										slWMSelects, // Object selects
										null, // relationship selects
										false, // from
										true, // to
										(short) 1, // expand level
										null, // object where
										null, // relationship where
										0); // limit
										String sAttrIPRevisionWatermark = "";
										String sAttrIPXWaterMark = "";
										String sAttrDesignFile = "";
										String sIPTag = "";
									if (!mlWaterMarkList.isEmpty()) {
										Iterator iterateWM = mlWaterMarkList.iterator();
										Map mIWaterMarkInfo = null;
										HashMap<String, String> mapOfFiles = new HashMap<String, String>();
										while (iterateWM.hasNext()) {
											mIWaterMarkInfo = (Map) iterateWM.next();
											sAttrIPRevisionWatermark = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
											sAttrIPXWaterMark = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
											sAttrDesignFile = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
											sAttrWMDerivedFrom = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_WMDERIVEDFROM);
											sIPTag = (String) mIWaterMarkInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
											//Adding for SWIMP-527: Starts
											if(UIUtil.isNotNullAndNotEmpty(sAttrIPRevisionWatermark)) {
												slMultipleWMIds.add(sAttrIPRevisionWatermark);
												if(sTag.contains(sIPTag)) {
													mapOfFiles.put(sAttrDesignFile, sAttrIPRevisionWatermark);
												}
											} else {
												slMultipleWMIds.add(sAttrIPXWaterMark);
												if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPTYPE_RANGE_SOFT_IP.equalsIgnoreCase(sIPType)) {
													lsIPXWMList.add(sAttrIPXWaterMark);
												}
											}
											//Adding for SWIMP-527: Ends
										}
										designFileMappingToWM.putAll(mapOfFiles);
									}
									sWaterMarkId = FrameworkUtil.join(slMultipleWMIds, ",");
                                    //Added for SWIMP-1 end
									sIPQAStatus = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
									sIPQASummary = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASUMMARY);
									sCurrent = (String) mIPRevInfo.get(DomainConstants.SELECT_CURRENT);
									sReasonForDeactivation = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_REASONFORDEACTIVATION);
									sIsPrefixed = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ISPREFIXED);
									sTopcell = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_TOPCELL);
									sAlert = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALERT);
									sMissingProgenyInstanceWarn = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_MISSINGPROGENYINSTANCEWARNING);
									sUnknownWMWarn = (String) mIPRevInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_UNKNOWNWATERMARKWARNING);
									//Added for SWIMP-190 :Ends
									flag = true;
									break;
								}
							}
						}
						if (flag) {
							break;
						}
					}
				}
				if (isTagSpecified && !slRevTag.contains(sTag)) {
					bRevExists = false;
				} 
				if (iTotalRevCount == iInactiveRevCount) {
					bAllRevInactive = true;
				}
				String sInactiveRev = "";
				if (sbInactiveRev != null && sbInactiveRev.length() > 0) {
					sInactiveRev = sbInactiveRev.toString();
					sInactiveRev = sInactiveRev.substring(0, sInactiveRev.length() - 2);
				}
				returnMap.put("ReleaseObjectName", sReleaseObjectName);
				//Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark
				returnMap.put("IMP_IPRevisionWatermark", sWaterMarkId);
				returnMap.put("IMP_IPQAStatus", sIPQAStatus);
				returnMap.put("IMP_IPQASummary", sIPQASummary);
				returnMap.put("IMP_IPTag", sRevTag);
				returnMap.put(DomainConstants.SELECT_CURRENT, sCurrent);
				returnMap.put(DomainConstants.SELECT_ORIGINATED, strOriginated);
				returnMap.put("IMP_ReasonForDeactivation", sReasonForDeactivation);
				returnMap.put("IMP_IsPrefixed", sIsPrefixed); // Added for bug 762
				returnMap.put("Inactive_Rev", sInactiveRev);
				returnMap.put("AllRevisionsInactive", bAllRevInactive);
				returnMap.put("RevisionExists", bRevExists);
				returnMap.put("IMP_Alert", sAlert); // Added for CR 253
				returnMap.put("IMP_ProductType", sProductType); //Added for CR 931
				returnMap.put("sIPIDWMSeed", sIPIDWMSeed); //Added for SWIMP-1
				returnMap.put("IMP_Topcell", sTopcell); //Added for SWIMP-87
				returnMap.put("MissingProgenyInstanceWarn", sMissingProgenyInstanceWarn);
				returnMap.put("UnknownWMWarn", sUnknownWMWarn);
				returnMap.put("IMP_DesignFileMappingToFile", designFileMappingToWM);//Added for SWIMP-849
				returnMap.put("WMDerivedFrom", sAttrWMDerivedFrom);//Added for SWIMP-849
			}
			//Added for SWIMP-133:Starts
			returnMap.put("BranchExists", bBranchExists);
			returnMap.put("AnyRevisionPublishedforBranch", bRevPublishedforBranch);
			returnMap.put("BranchName", branchName);
			returnMapList.add(returnMap);
			//Added for SWIMP-133:Ends
			
			// Modified for the Bug IMPBRCM-1003 - END
		} catch (Exception e) {
			throw e;
		}
		return returnMapList;
	}

	/**
	 * This method returns IP Object Id based on IP Name.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public String getIPIdFromIPName(Context context, String ipName) throws Exception {
		Map mIPInfo = null;
		String sIPid = "";
		try {
			StringList slIPDetails = new StringList();
			slIPDetails.add(DomainConstants.SELECT_ID);
			slIPDetails.add(DomainConstants.SELECT_NAME);

			MapList mlIPObjects = DomainObject.findObjects(context,
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct"), ipName,
					DomainConstants.QUERY_WILDCARD, DomainConstants.QUERY_WILDCARD,
					PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"), null, false, slIPDetails);
			if (mlIPObjects.size() > 0) {
				mIPInfo = (Map) mlIPObjects.get(0);
				sIPid = (String) mIPInfo.get(DomainConstants.SELECT_ID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return sIPid;
	}

	/**
	 * This method returns IP Object Id based on IP Name.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public String getIPIdFromIPName(Context context, String args[]) throws Exception {
		Map mIPInfo = null;
		String sIPid = "";
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		try {
			String strIPName = (String) programMap.get("strIPName");
			StringList slIPDetails = new StringList();
			slIPDetails.add(DomainConstants.SELECT_ID);
			slIPDetails.add(DomainConstants.SELECT_NAME);
			MapList mlIPObjects = DomainObject.findObjects(context,
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct"), strIPName,
					DomainConstants.QUERY_WILDCARD, DomainConstants.QUERY_WILDCARD,
					PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"), null, false, slIPDetails);
			if (mlIPObjects.size() > 0) {
				mIPInfo = (Map) mlIPObjects.get(0);
				sIPid = (String) mIPInfo.get(DomainConstants.SELECT_ID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return sIPid;
	}

	/**
	 * This method returns SoC Object Id based on SoC Name.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds SoC Name.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public String getSoCIdFromSoCName(Context context, String args[]) throws Exception {
		Map mSoCInfo = null;
		String sSoCid = "";
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		try {
			String strSoCName = (String) programMap.get("strSoCName");
			StringList slSoCDetails = new StringList();
			slSoCDetails.add(DomainConstants.SELECT_ID);
			slSoCDetails.add(DomainConstants.SELECT_NAME);
			MapList mlSoCObjects = DomainObject.findObjects(context,
					PropertyUtil.getSchemaProperty(context, "type_IMP_SoC"), strSoCName, DomainConstants.QUERY_WILDCARD,
					DomainConstants.QUERY_WILDCARD, PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
					null, false, slSoCDetails);
			if (mlSoCObjects.size() > 0) {
				mSoCInfo = (Map) mlSoCObjects.get(0);
				sSoCid = (String) mSoCInfo.get(DomainConstants.SELECT_ID);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return sSoCid;
	}

	/**
	 * This method gets all the IP Connected Branches and Branch connected
	 * Releases and displays in a Indented view.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IPName.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList getBranchAndReleaseObjects(Context context, String args[]) throws Exception {
		MapList mlReturnObjList = new MapList();
		MapList mlAllReturnObjList = new MapList();
		MapList mlChildObjList = new MapList();

		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strIPID = (String) programMap.get("objectId");
			String expandLevel = (String) programMap.get("expandLevel");

			int iGivenLevel = 1;

			if ("All".equalsIgnoreCase(expandLevel)) {
				iGivenLevel = 0;
			} else if (!UIUtil.isNullOrEmpty(expandLevel) && expandLevel.matches("^[0-9]+$")) {
				iGivenLevel = Integer.parseInt(expandLevel);
			}

			mlReturnObjList = getBranchAndReleaseObjects(context, strIPID, "0", iGivenLevel);
			mlAllReturnObjList.addAll(mlReturnObjList);

			if (iGivenLevel != 1) {
				Iterator objListItr;
				String sChildObjId;
				Map objListMap;
				String sLevel = null;
				while (!mlReturnObjList.isEmpty() || !mlChildObjList.isEmpty()) {
					if (!mlChildObjList.isEmpty()) {
						mlReturnObjList = mlChildObjList;
					}
					mlChildObjList = new MapList();
					objListItr = mlReturnObjList.iterator();
					while (objListItr.hasNext()) {
						objListMap = (Map) objListItr.next();
						sChildObjId = (String) objListMap.get(DomainConstants.SELECT_ID);
						sLevel = (String) objListMap.get("level");
						mlReturnObjList = new MapList();
						if (sChildObjId != null && sChildObjId.length() > 0) {
							mlReturnObjList = getBranchAndReleaseObjects(context, sChildObjId, sLevel, iGivenLevel);
							if (!mlReturnObjList.isEmpty()) {
								mlAllReturnObjList.addAll(mlReturnObjList);

								mlChildObjList.addAll(mlReturnObjList);
							}
						}
					}
				}
				mlAllReturnObjList = reorderBranchAndRev(context, mlAllReturnObjList);
			}
			// add flag expandMultiLevelsJPO
			HashMap<String, String> hmJPO = new HashMap<String, String>(1);
			hmJPO.put("expandMultiLevelsJPO", "true");
			mlAllReturnObjList.add(hmJPO);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlAllReturnObjList;
	}

	/**
	 * This method gets all the IP Connected Branches and Branch connected Releases and displays in a Indented view.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds IP Object Id, iGivenLevel - given level, sLevel - current object level.
	 * @returns MapList.
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MapList getBranchAndReleaseObjects(Context context, String strIPID, String sLevel, int iGivenLevel) throws FrameworkException {
		MapList mlReturnObjList = new MapList();

		String branchRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String branchReleaseRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String branchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPReleaseType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		String strIPProductType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
		String attrIPTag = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag");
		String attrRecommendedRev = PropertyUtil.getSchemaProperty(context, "attribute_IMP_Recommended_Revision");
		String attrBranchParentRev = PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision");

		String sCurrent;
		String sType;

		String strObjWhere = null;
		Pattern relPattern;
		String sRecommendedRev = "";

		DomainObject dobj = DomainObject.newInstance(context, strIPID);

		// context object type
		String strCtxObjType = dobj.getInfo(context, DomainConstants.SELECT_TYPE);
		relPattern = new Pattern(branchRel);
		relPattern.addPattern(branchReleaseRel);
		Pattern typePattern = new Pattern(branchType);
		typePattern.addPattern(sIPReleaseType);

		StringList slObjSelects = new StringList();
		slObjSelects.add(DomainConstants.SELECT_ID);
		slObjSelects.add(DomainConstants.SELECT_CURRENT);
		slObjSelects.add(DomainConstants.SELECT_TYPE);
		slObjSelects.add("attribute[" + attrIPTag + "]");
		slObjSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublisher") + "]");
		slObjSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublishComments") + "]");
		slObjSelects.add("attribute[" + attrBranchParentRev + "]");

		if (strCtxObjType.equalsIgnoreCase(strIPProductType)) {
			relPattern = new Pattern(branchRel);
			strObjWhere = "attribute[" + attrIPTag + "].value == 'Trunk' || attribute[" + attrIPTag + "].value == 'trunk'";
		} else if (strCtxObjType.equalsIgnoreCase(branchType)) {
			sRecommendedRev = dobj.getInfo(context, "attribute[" + attrRecommendedRev + "].value");
			relPattern = new Pattern(branchReleaseRel);
			typePattern = new Pattern(sIPReleaseType);
		} else if (strCtxObjType.equalsIgnoreCase(sIPReleaseType)) {
			String strIPId = dobj.getInfo(context, "to[" + branchReleaseRel + "].from.to[" + branchRel + "].from.id");
			String strIPTagVal = dobj.getInfo(context, "attribute[" + attrIPTag + "].value");
			relPattern = new Pattern(branchRel);
			typePattern = new Pattern(branchType);
			strObjWhere = "attribute[" + attrBranchParentRev + "].value == '" + strIPTagVal + "'";
			dobj.setId(strIPId);
		}

		MapList mlRelatedObjList = dobj.getRelatedObjects(context,
				relPattern.getPattern(), // relationship
				typePattern.getPattern(), // type pattern
				slObjSelects, // Object selects
				null, // relationship selects
				false, // from
				true, // to
				(short) 1, // expand level
				strObjWhere, // object where
				null, // relationship where
				0); // limit

		if (!mlRelatedObjList.isEmpty()) {
			String sNewLevel;
			int iOldLevel = Integer.parseInt(sLevel);
			int iNewLevel;
			String sIPTag;
			String sObjId;
			DomainObject domRevObj;
			String sDefaultRevision;
			for (int i = 0; i < mlRelatedObjList.size(); i++) {
				Map mpData = (Map) mlRelatedObjList.get(i);
				sType = (String) mpData.get(DomainConstants.SELECT_TYPE);
				sCurrent = (String) mpData.get(DomainConstants.SELECT_CURRENT);
				sObjId = (String) mpData.get(DomainConstants.SELECT_ID);
				sIPTag = (String) mpData.get("attribute[" + attrIPTag + "]");
				sNewLevel = (String) mpData.get("level");
				iNewLevel = Integer.parseInt(sNewLevel);
				iNewLevel = iNewLevel + iOldLevel;
				mpData.put("level", String.valueOf(iNewLevel));
				if (sIPReleaseType.equals(sType) && sCurrent.equals("Inactive")) {
					mpData.put("styleRows", "RemovedRow");
				} else if (sIPReleaseType.equals(sType) && sRecommendedRev.equals(sIPTag)) {
					mpData.put("styleRows", "custDarkGreen");
				}
				// if Default revision, color the row background
				if (sIPReleaseType.equals(sType)) {
					domRevObj = DomainObject.newInstance(context, sObjId);
					sDefaultRevision = domRevObj.getInfo(context,
							"to[" + branchReleaseRel + "].from.to[" + branchRel + "].from.attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IP_Default_Revision") + "]");
					 if (sIPReleaseType.equals(sType) && UIUtil.isNotNullAndNotEmpty(sDefaultRevision) && sDefaultRevision.equals(sIPTag) && sRecommendedRev.equals(sIPTag)) {
						mpData.put("styleRows", "custDarkGreenBackground");
					} else if (UIUtil.isNotNullAndNotEmpty(sDefaultRevision) && sDefaultRevision.equals(sIPTag)) {
						mpData.put("styleRows", "custGreenBackground");
					}
				}
				if (iGivenLevel == 0 || iNewLevel <= iGivenLevel) {
					mlReturnObjList.add(mpData);
				}
			}

		}
		return mlReturnObjList;

	}
	
	/**
	 * This method orders branch based on it parent revision and put it in the list in a hierarchical way.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds mlInputList.
	 * @returns MapList.
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static MapList reorderBranchAndRev(Context context, MapList mlInputList) {
		MapList mlReturnList = mlInputList;
		String attrBranchParentRev = PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision");
		String attrIPTag = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag");

		Map mpData1;
		Map mpData2;
		String sBranchParentRev1;
		String sIPTag1;
		String sIPTag2;
		String[] temp;
		for (int i = 0; i < mlInputList.size(); i++) {
			mpData1 = (Map) mlInputList.get(i);
			sBranchParentRev1 = (String) mpData1.get("attribute[" + attrBranchParentRev + "]");
			sIPTag1 = (String) mpData1.get("attribute[" + attrIPTag + "]");
			if (sBranchParentRev1 != null && sBranchParentRev1.length() > 0) {
				for (int j = 0; j < mlInputList.size(); j++) {
					mpData2 = (Map) mlInputList.get(j);
					sIPTag2 = (String) mpData2.get("attribute[" + attrIPTag + "]");
					if (sBranchParentRev1.equals(sIPTag2)) {
						mlReturnList.remove(i);
						mlReturnList.add(j + 1, mpData1);
					}
				}
			}

			if (sIPTag1 != null && sIPTag1.contains("/")) {
				temp = sIPTag1.split("/");
				for (int j = 0; j < mlInputList.size(); j++) {
					mpData2 = (Map) mlInputList.get(j);
					sIPTag2 = (String) mpData2.get("attribute[" + attrIPTag + "]");
					if (temp[0].equals(sIPTag2)) {
						mlReturnList.remove(i);
						mlReturnList.add(j + 1, mpData1);
					}
				}
			}
		}

		return mlReturnList;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList getBranchAndRelObjects(Context context, String[] args) throws Exception {
		MapList mlReturnObjList = new MapList();
		String sCurrent = "";
		String sType = "";
		Pattern relPattern = null;
		try {
			HashMap programMap =  JPO.unpackArgs(args);
			String strIPID = (String) programMap.get("objectId");
			String sExpandLevel = (String) programMap.get("levelTwo"); //Added for SWIMP-288
			DomainObject dobj = DomainObject.newInstance(context, strIPID);
			// context object type
			relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);
			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_CURRENT);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			slObjSelects.add(DomainConstants.SELECT_ORIGINATED); // Added for 224
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHER);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHCOMMENTS);
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision") + "]");

			MapList mlRelatedObjList = dobj.getRelatedObjects(context, relPattern.getPattern(), // relationship //Modified for SWIMP-288 to reduce sonar count
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) (("levelTwo").equalsIgnoreCase(sExpandLevel)?2:1), // expand level - Modified for SWIMP-288
					null, // object where
					null, // relationship where
					0); // limit

			if (!mlRelatedObjList.isEmpty()) {
				for (int i = 0; i < mlRelatedObjList.size(); i++) {
					Map mpData = (Map) mlRelatedObjList.get(i);
					sType = (String) mpData.get(DomainConstants.SELECT_TYPE);
					sCurrent = (String) mpData.get(DomainConstants.SELECT_CURRENT);
					if (IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(sType) && sCurrent.equals("Inactive")) {
						mpData.put("styleRows", "RemovedRow");
					}
					mlReturnObjList.add(mpData);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlReturnObjList;
	}

	/**
	 * This method updates IMP_LatestVersion attribute value with Object
	 * revision.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns int.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public int updateLatestRevisionWithRevision(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		try {
			HashMap paramMap = (HashMap) programMap.get("paramMap");
			String sDTreeID = (String) paramMap.get("objectId");
			DomainObject dTreeId = new DomainObject(sDTreeID);

			// ContextUtil.startTransaction(context,true);
			dTreeId.setAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_LatestVersion"),
					dTreeId.getInfo(context, DomainConstants.SELECT_REVISION));
			// ContextUtil.commitTransaction(context);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return 0;
	}

	/**
	 * This method updates IMP_LatestVersion attribute value on all revisions of
	 * an object with Next revision in policy.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns int.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public int updateAllLatestRevisionWithRevision(Context context, String args[]) throws Exception {
		HashMap dTreeMap = null;
		DomainObject dtreeObj = null;
		try {
			String sDTreeID = args[0];
			String sDTreeRev = args[1];
			StringList sRevids = null;
			DomainObject dTreeId = DomainObject.newInstance(context, sDTreeID);
			String strdTreeOldRev = dTreeId.getInfo(context, DomainConstants.SELECT_REVISION);
			BusinessObject lastRevObj = dTreeId.getLastRevision(context);
			String objectId=lastRevObj.getObjectId();
			DomainObject dTreeNewRevId = DomainObject.newInstance(context, objectId);
			String sNewMajorRev = "";
			String sNewRevision = "";
			String sCurrentMinRev = strdTreeOldRev.substring(strdTreeOldRev.indexOf(".")+1);
			if("9".equals(sCurrentMinRev)){
				sNewMajorRev = strdTreeOldRev.substring(0,strdTreeOldRev.indexOf("."));
				int iNewMajorRev=Integer.parseInt(sNewMajorRev); 
				iNewMajorRev = iNewMajorRev+1;
				sNewRevision = Integer.toString(iNewMajorRev)+".0";
				MqlUtil.mqlCommand(context, "mod bus " + objectId + " name '" + dTreeNewRevId.getInfo(context, DomainConstants.SELECT_NAME) + "' revision '" + sNewRevision + "'", false, false);
				sDTreeRev = sNewRevision;
			}
			StringList objselects = new StringList();
			objselects.add(DomainConstants.SELECT_REVISION);
			objselects.add(DomainConstants.SELECT_ID);
			MapList revInfo = dTreeId.getRevisionsInfo(context, new StringList(), objselects);
			Iterator itr = revInfo.iterator();
			while (itr.hasNext()) {
				dTreeMap = (HashMap) itr.next();
				sRevids = (StringList) dTreeMap.get(DomainConstants.SELECT_ID);
				dtreeObj = new DomainObject((String) sRevids.get(0));
				dtreeObj.setAttributeValue(context,
						PropertyUtil.getSchemaProperty(context, "attribute_IMP_LatestVersion"), sDTreeRev);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return 0;
	}

	/**
	 * This method gets the Branch connected Maturity Level Objects and updates
	 * attribute values on Maturity Level Objects with Latest Revision in the
	 * Branch and Latest published date.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList updateListofIPDeliveryMilestones(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		Map mlInfo = null;
		String sMLId = "";
		String sLatesttag = "";
		String sBranchtag = "";
		MapList mlRelatedMLList = new MapList();
		try {
			DomainObject domMlObj = DomainObject.newInstance(context);
			String sBranchID = (String) programMap.get("objectId");

			DomainObject dmBid = DomainObject.newInstance(context, sBranchID);
			sBranchtag = dmBid.getAttributeValue(context,
					PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchName"));

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_MaturityLevel") + "]");

			mlRelatedMLList = (MapList) dmBid.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_MaturityLevel"), // relationship
																								// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_MaturityLevel"), // type
					// pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			Iterator sMLIterator = mlRelatedMLList.iterator();
			programMap.remove("objectId");
			while (sMLIterator.hasNext()) {
				mlInfo = (Hashtable) sMLIterator.next();
				sMLId = (String) mlInfo.get(DomainConstants.SELECT_ID);
				sLatesttag = (String) mlInfo.get(
						"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_MaturityLevel") + "]");
				programMap.put("IMP_LatestTag", sBranchtag);
				domMlObj.setId(sMLId);
				if (sBranchtag.startsWith(sLatesttag)) {
					domMlObj.setAttributeValues(context, programMap);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlRelatedMLList;
	}

	/**
	 * This method gets the Branch connected Maturity Level Objects .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Branch objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public static MapList getListofIPDeliveryMilestones(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList mlRelatedMLList = new MapList();
		try {
			String sBranchID = (String) programMap.get("objectId");
			DomainObject dmBid = DomainObject.newInstance(context, sBranchID);

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_MaturityLevel") + "]");
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LatestTag") + "]");

			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_CommitDate") + "]");
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ActualDate") + "]");
			slObjSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_TrendDate") + "]");

			mlRelatedMLList = (MapList) dmBid.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_MaturityLevel"), // relationship
																								// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_MaturityLevel"), // type
					// pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlRelatedMLList;
	}

	/**
	 * This method enables Check box only for Release Objects.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList of table row id's.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector showCheckbox(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		MapList objectList = (MapList) programMap.get("objectList");
		Vector enableCheckbox = new Vector();
		try {
			Iterator objectListItr = objectList.iterator();
			while (objectListItr.hasNext()) {
				Map objectMap = (Map) objectListItr.next();
				String strIPReleaseObj = (String) objectMap.get(DomainObject.SELECT_ID);

				DomainObject domIPReleaseObj = DomainObject.newInstance(context, strIPReleaseObj);
				String strIPReleaseType = domIPReleaseObj.getInfo(context, DomainObject.SELECT_TYPE);

				if (strIPReleaseType.equalsIgnoreCase("IMP_IPRelease")) {
					enableCheckbox.add("true");
				} else {
					enableCheckbox.add("false");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return enableCheckbox;
	}

	@SuppressWarnings("rawtypes")
	public StringList highlightTaginInactive(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		StringList slResults = new StringList();
		String sResult = "";
		try {
			MapList mlObjects = (MapList) programMap.get("objectList");
			if (!mlObjects.isEmpty()) {
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_CURRENT);
				for (int i = 0; i < mlObjects.size(); i++) {
					Map mObject = (Map) mlObjects.get(i);
					String sOID = (String) mObject.get(DomainConstants.SELECT_ID);
					DomainObject dObject = new DomainObject(sOID);
					Map mData = dObject.getInfo(context, busSelects);
					String sCurrent = (String) mData.get(DomainConstants.SELECT_CURRENT);
					if (sCurrent.equals("Inactive")) {
						sResult = "RemovedRow";
					} else {
						sResult = "";
					}
					slResults.add(sResult);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return slResults;
	}

	/**
	 * This method returns true if context user is owner or a co-owner .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns boolean.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public boolean checkIsOwnerorCoowner(Context context, String[] args) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) programMap.get("objectId");
			String ctxUser = context.getUser();
			String sCoOwners = "";
			String sOwner = "";

			StringList ownerList = new StringList();
			DomainObject dmObj = DomainObject.newInstance(context, objectId);

			StringList objSelects = new StringList();
			objSelects.add(DomainConstants.SELECT_OWNER);
			objSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");

			Map objInfo = dmObj.getInfo(context, objSelects);

			if (objInfo.size() > 0) {
				sOwner = (String) objInfo.get(DomainConstants.SELECT_OWNER);
				sCoOwners = (String) objInfo
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");
				ownerList = FrameworkUtil.split(sCoOwners, "~");
				ownerList.add(sOwner);
			}
			if (ownerList.contains(ctxUser)) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return false;
	}

	/**
	 * This method enables a hyper link .On clicking on the link opens a popup
	 * window which shows Release object De-activation info.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getAlertMessage(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramList");
		String userReportFormat = (String) paramMap.get("reportFormat");
		Vector columnVals = new Vector();
		String sType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		Map objMap = null;
		DomainObject domObj = null;
		String objectType = "";
		String sObjectid = "";
		String sState = "";
		String ctxUser = context.getUser();
		String sDeactivationReason = "";
		try {
			MapList objList = (MapList) programMap.get("objectList");

			Date date = new Date();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			String strDate = dateFormat.format(date);

			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				StringBuffer outPut = new StringBuffer();
				domObj = new DomainObject(sObjectid);
				sState = domObj.getInfo(context, DomainConstants.SELECT_CURRENT);
				objectType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
				sDeactivationReason = domObj.getInfo(context, "attribute["
						+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_ReasonForDeactivation") + "]");
				if (objectType.equalsIgnoreCase(sType) && sState.equals("Inactive") && !sDeactivationReason.isEmpty()) {
					if (UIUtil.isNotNullAndNotEmpty(userReportFormat)) {
						columnVals.add(sState);
					}else {
					outPut.append(
							"<a href=\"javascript:showModalDialog('../semiteamcollab/imp_IPProductUtil.jsp?objectId="
									+ sObjectid + "&amp;mode=highlight&amp;user=" + ctxUser + "&amp;DeactivationReason="
									+ sDeactivationReason + "&amp;date=" + strDate + "',150,150,true, 'Small');\">");
					outPut.append("<p style='color:rgb(255,0,0);'>Deactivated</p>");
					outPut.append("</a>");
					columnVals.add(outPut.toString());
					}
				} else {
					columnVals.add("");
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return columnVals;
	}

	/**
	 * This method returns the user list who downloaded the Revision object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Release objectId.
	 * @returns StringList.
	 * @throws Exception
	 *             if the operation fails
	 */
	public StringList getConsumedHistory(Context context, String strIPRelObjId) throws Exception {
		String sConsumeHistory = "";
		String suser = "";
		StringList returnList = new StringList();
		try {
			DomainObject domObj = DomainObject.newInstance(context, strIPRelObjId);
			StringList strIPRelHistory = domObj.getHistory(context);

			for (int i = 0; i < strIPRelHistory.size(); i++) {
				sConsumeHistory = (String) strIPRelHistory.get(i);
				if ((sConsumeHistory.trim()).startsWith("(Consume IP")) {
					suser = sConsumeHistory.substring(13, sConsumeHistory.indexOf(")"));
					if (Person.doesPersonExists(context, suser.trim())) {
						returnList.add(suser.trim());
					}
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return returnList;
	}

	/**
	 * This method returns the SoC connected Branch and Release objects with
	 * Logical Products Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds SoC objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList getIPHierarchyForSoCorBlockIP(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		MapList mlRelatedObjList = new MapList();
		//Modified for IMPBRCM-858 Starts
		MapList mlIPName = new MapList();
		try {
			Map mpData;

			String sType = "";
			String sId = "";
			String sName = "";
			DomainObject domObjOfIPRelease;
			DomainObject domObjOfBranch;

			String sRelIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
			String sRelIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
			String objectId = (String) programMap.get("objectId");
			DomainObject dmObj = DomainObject.newInstance(context, objectId);

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_NAME);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			slObjSelects.add(IMP_Constants_mxJPO.IPBRANCH_TO_IPID);  //Added for SWIMP-541
			slObjSelects.add(IMP_Constants_mxJPO.IPID);              //Added for SWIMP-541

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_NoOfInstances") + "]");
			slRelSelects.add(DomainRelationship.SELECT_ORIGINATED);
			slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);

			Pattern typePattern = new Pattern(PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"));
			typePattern.addPattern(PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"));

			mlRelatedObjList = (MapList) dmObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_LogicalProducts"), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit

			Iterator itr = mlRelatedObjList.iterator();
			while (itr.hasNext()) {
				mpData = (Map) itr.next();
				sType = (String) mpData.get(DomainConstants.SELECT_TYPE);
				sId = (String) mpData.get(DomainConstants.SELECT_ID);
				if (PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease").equals(sType)) {
					domObjOfIPRelease = DomainObject.newInstance(context, sId);
					sName = (String) domObjOfIPRelease.getInfo(context,
							"to[" + sRelIPBranchRelease + "].from.to[" + sRelIPBranch + "].from.name");
					if(UIUtil.isNotNullAndNotEmpty(sName)){
						mpData.put("Name", sName);
					} else {
						mpData.put("Name", "");
					}
				} else {
					domObjOfBranch = DomainObject.newInstance(context, sId);
					sName = (String) domObjOfBranch.getInfo(context, "to[" + sRelIPBranch + "].from.name");
					if(UIUtil.isNotNullAndNotEmpty(sName)){
						mpData.put("Name", sName);
					} else {
						mpData.put("Name", "");
					}
				}

				//Added for SWIMP-541 --START
				if (IMP_Constants_mxJPO.TYPE_IMP_BRANCH.equalsIgnoreCase(sType)) {
					mlIPName.add(IMP_Utility_mxJPO.getAccessMap(context, (String) mpData.get(IMP_Constants_mxJPO.IPBRANCH_TO_IPID), mpData));
				} else if (IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equalsIgnoreCase(sType)) {
					mlIPName.add(IMP_Utility_mxJPO.getAccessMap(context, (String) mpData.get(IMP_Constants_mxJPO.IPID), mpData));
				} else {
					mlIPName.add(IMP_Utility_mxJPO.getAccessMap(context, sId, mpData));
				}
				//Added for SWIMP-541 --END
			}
			mlIPName.sortStructure("Name", "ascending", "string");
		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return mlIPName;
		//Modified for IMPBRCM-858 Ends
	}

	/**
	 * This method returns the IP object Id's by splitting the i/p argument.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds String.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MapList getIPBranchReleaseHierarchy(Context context, String args[]) throws Exception {
		MapList returnList = new MapList();
		Map objIDMap = null;
		BusinessObject bObj = null;
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String objList = (String) programMap.get("objectIds");
			String strobjectId = (String) programMap.get("dummyKey");
			StringTokenizer st = new StringTokenizer(objList, "|");
			while (st.hasMoreTokens()) {
				String token = st.nextToken();
				bObj = new BusinessObject(token);
				if (bObj.exists(context) && !token.equalsIgnoreCase(strobjectId)) {
					objIDMap = new HashMap();
					objIDMap.put("id", token);
					objIDMap.put("disableSelection", "true");
					returnList.add(objIDMap);
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			throw ex;
		}
		return returnList;
	}
//Added for SWIMP-126 - FP-1743 - Label issue
	public StringList getTagColumnValue(Context context, String args[]) throws Exception{
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		StringList slResults = new StringList();
		String sResult = "";
		try {
			String strSelectIMPIPTagAttr = "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]";
			String strIPType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
			String sDisplayIPType = EnoviaResourceBundle.getProperty(context, "emxFrameworkStringResource", context.getLocale(), "emxFramework.Type.IMP_IPProduct");
			MapList mlObjects = (MapList) programMap.get("objectList");
			if (!mlObjects.isEmpty()) {
				StringList busSelects = new StringList();
				busSelects.add(DomainConstants.SELECT_TYPE);
				busSelects.add(DomainConstants.SELECT_NAME);
				busSelects.add(DomainConstants.SELECT_REVISION);
				busSelects.add(strSelectIMPIPTagAttr);

				DomainObject dObject = null;
				Map mData = null;
				Map mObject = null;
				String sOID = null;
				String sName = null;
				String sType = null;
				String sRev = null;
				for (int i = 0; i < mlObjects.size(); i++) {
					mObject = (Map) mlObjects.get(i);
					sOID = (String) mObject.get(DomainConstants.SELECT_ID);
					dObject = DomainObject.newInstance(context, sOID);
					mData = dObject.getInfo(context, busSelects);
					sName = (String) mData.get(DomainConstants.SELECT_NAME);
					sType = (String) mData.get(DomainConstants.SELECT_TYPE);
					sRev = (String) mData.get(DomainConstants.SELECT_REVISION);
					if (sType.equals(strIPType)) {
						sResult = sDisplayIPType + " " + sName + " "+ sRev;
					} else {
						sResult = (String) mData.get(strSelectIMPIPTagAttr);
					}
					slResults.add(sResult);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return slResults;
	}
	/**
	 * This method updates only IP name for the IP Column in table whether it is
	 * a Branch or a Release object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector updateOnlyIPNameForIPColumn(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		String ipName = "";
		String sNoAccessIPName = null;
		String sIPObjId = "";
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;

		String sBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPRelType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		String sRelIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String sRelIPBranchRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String sTypeSoC = PropertyUtil.getSchemaProperty(context, "type_IMP_SoC");
		StringBuilder sbOutput = new StringBuilder();
		String sURL;

		try {
			MapList objList = (MapList) programMap.get("objectList");
			HashMap paramMap = (HashMap) programMap.get("paramList");
			String sReportFormat = (String) paramMap.get("reportFormat");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				if (sType.equalsIgnoreCase(sBranchType)) {
					ipName = dmObj.getInfo(context, "to[" + sRelIPBranch + "].from.name");
					sIPObjId = dmObj.getInfo(context, "to[" + sRelIPBranch + "].from.id");
					// if IP Name is null push to super context and get the IP Name to show it in the UI
					if (UIUtil.isNullOrEmpty(ipName)) {
						ContextUtil.pushContext(context);
						sNoAccessIPName = dmObj.getInfo(context, "to[" + sRelIPBranch + "].from.name");
						ContextUtil.popContext(context);
					}
				} else if (sType.equalsIgnoreCase(sIPRelType)) {
					ipName = dmObj.getInfo(context, "to[" + sRelIPBranchRel + "].from.to[" + sRelIPBranch + "].from.name");
					sIPObjId = dmObj.getInfo(context, "to[" + sRelIPBranchRel + "].from.to[" + sRelIPBranch + "].from.id");
					if (UIUtil.isNullOrEmpty(ipName)) {
						ContextUtil.pushContext(context);
						sNoAccessIPName = dmObj.getInfo(context, "to[" + sRelIPBranchRel + "].from.to[" + sRelIPBranch + "].from.name");
						ContextUtil.popContext(context);
					}
				} else {
					ipName = dmObj.getInfo(context, DomainConstants.SELECT_NAME);
					sIPObjId = dmObj.getInfo(context, DomainConstants.SELECT_ID);
				}
				if (ipName != null && !"".equals(ipName) && !sType.equals(sTypeSoC) && UIUtil.isNullOrEmpty(sReportFormat)) {
					sURL = "../common/emxTree.jsp?objectId=" + sIPObjId;
					sbOutput.append("<a href=\"javascript:showNonModalDialog('" + sURL + "',800,600)\">" + ipName + "</a>");
					returnList.add(sbOutput.toString());
					sbOutput.setLength(0);
				} else if (ipName != null && !"".equals(ipName) && !sType.equals(sTypeSoC) && UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
					returnList.add(ipName);
					sbOutput.setLength(0);
				} else if (ipName != null && !"".equals(ipName) && sType.equals(sTypeSoC)) {
					returnList.add(ipName);
				} else if (UIUtil.isNullOrEmpty(ipName) && UIUtil.isNotNullAndNotEmpty(sNoAccessIPName)) {
					returnList.add(sNoAccessIPName);
				} else {
					returnList.add("");
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}
	
	/**
	 * This method updates only Branch name for the Branch Column in table if it
	 * is a Branch object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector updateOnlyBranchNameForBranchColumn(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;
		String sBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		try {
			MapList objList = (MapList) programMap.get("objectList");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) objMap.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {  //Added for SWIMP-541
					if (sType.equalsIgnoreCase(sBranchType)) {
						returnList.add(dmObj.getInfo(context,
								"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]") + "/");
					} else {
						returnList.add("");
					}
				} else {
					returnList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);  //Added for SWIMP-541
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}

	/**
	 * This method updates only Release tag for the Release Column in table if
	 * it is a Release object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector updateOnlyTagNameForReleaseColumn(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;
		String sIPRelType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		try {
			MapList objList = (MapList) programMap.get("objectList");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				if (sType.equalsIgnoreCase(sIPRelType)) {
					returnList.add(dmObj.getInfo(context,
							"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]"));
				} else {
					returnList.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}

	/**
	 * This method returns IP connected Branch and Release objects.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList getBranchAndReleaseObjectsForSelectedIPS(Context context, String args[]) throws Exception {
		MapList mlReturnObjList = new MapList();
		MapList mlAllReturnObjList = new MapList();
		MapList mlChildObjList = new MapList();

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		try {
			String strIPID = (String) programMap.get("objectId");
			String strSoCID = (String) programMap.get("dummyKey");
			String expandLevel = (String) programMap.get("expandLevel");
			int iGivenLevel = 1;

			if ("All".equalsIgnoreCase(expandLevel)) {
				iGivenLevel = 0;
			} else if (!UIUtil.isNullOrEmpty(expandLevel) && expandLevel.matches("^[0-9]+$")) {
				iGivenLevel = Integer.parseInt(expandLevel);
			}

			mlReturnObjList = getBranchRevObjForSelectedIPs(context, strIPID, strSoCID, "0", iGivenLevel);
			mlAllReturnObjList.addAll(mlReturnObjList);

			if (iGivenLevel != 1) {
				Iterator objListItr;
				String sChildObjId;
				Map objListMap;
				String sLevel = null;
				while (!mlReturnObjList.isEmpty() || !mlChildObjList.isEmpty()) {
					if (!mlChildObjList.isEmpty()) {
						mlReturnObjList = mlChildObjList;
					}
					mlChildObjList = new MapList();
					objListItr = mlReturnObjList.iterator();
					while (objListItr.hasNext()) {
						objListMap = (Map) objListItr.next();
						sChildObjId = (String) objListMap.get(DomainConstants.SELECT_ID);
						sLevel = (String) objListMap.get("level");
						mlReturnObjList = new MapList();
						if (sChildObjId != null && sChildObjId.length() > 0) {
							mlReturnObjList = getBranchRevObjForSelectedIPs(context, sChildObjId, strSoCID, sLevel, iGivenLevel);
							if (!mlReturnObjList.isEmpty()) {
								mlAllReturnObjList.addAll(mlReturnObjList);

								mlChildObjList.addAll(mlReturnObjList);
							}
						}
					}
				}
				mlAllReturnObjList = reorderBranchAndRev(context, mlAllReturnObjList);
			}

			HashMap<String, String> hmJPO = new HashMap<String, String>(1);
			hmJPO.put("expandMultiLevelsJPO", "true");
			mlAllReturnObjList.add(hmJPO);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlAllReturnObjList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MapList getBranchRevObjForSelectedIPs(Context context, String strIPID, String strSoCID, String sLevel, int iGivenLevel) throws Exception {

		MapList mlReturnObjList = new MapList();
		String sCurrent = "";
		String sType = "";
		String strObjId = "";
		String strConnectedID = "";
		String strConnectedType = "";
		String strRelationship = "";
		Map mpconnectedData = null;
		Map mpData = null;
		String strObjWhere = null;
		String branchRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String branchReleaseRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String strLogicalProRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_LogicalProducts");
		String branchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPReleaseType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		String strIPType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");

		try {
			HashMap argsMap = new HashMap();
			argsMap.put("objectId", strSoCID);
			MapList mlSoCConnectedList = getIPHierarchyForSoCorBlockIP(context, JPO.packArgs(argsMap));

			DomainObject dobj = DomainObject.newInstance(context, strIPID);
			Pattern relPattern = new Pattern(branchRel);
			relPattern.addPattern(branchReleaseRel);
			Pattern typePattern = new Pattern(branchType);
			typePattern.addPattern(sIPReleaseType);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_CURRENT);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			slObjSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
			slObjSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision") + "]");
			String strCtxObjType = dobj.getInfo(context, DomainConstants.SELECT_TYPE);

			if (strCtxObjType.equalsIgnoreCase(strIPType)) {
				relPattern = new Pattern(branchRel);
				strObjWhere = "attribute[IMP_IPTag].value == 'Trunk' || attribute[IMP_IPTag].value == 'trunk'";

			} else if (strCtxObjType.equalsIgnoreCase(branchType)) {
				relPattern = new Pattern(branchReleaseRel);
				typePattern = new Pattern(sIPReleaseType);
			} else if (strCtxObjType.equalsIgnoreCase(sIPReleaseType)) {
				String strIPId = dobj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
				String strIPTagVal = dobj.getInfo(context, "attribute[IMP_IPTag].value");
				relPattern = new Pattern(branchRel);
				typePattern = new Pattern(branchType);
				strObjWhere = "attribute[IMP_BranchParentRevision].value == '" + strIPTagVal + "'";

				dobj.setId(strIPId);

			}
			MapList mlRelatedObjList = (MapList) dobj.getRelatedObjects(context,
					relPattern.getPattern(), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					strObjWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlRelatedObjList.isEmpty()) {
				String sNewLevel;
				int iOldLevel = Integer.parseInt(sLevel);
				int iNewLevel;
				for (int i = 0; i < mlRelatedObjList.size(); i++) {
					mpData = (Map) mlRelatedObjList.get(i);
					sType = (String) mpData.get(DomainConstants.SELECT_TYPE);
					sCurrent = (String) mpData.get(DomainConstants.SELECT_CURRENT);
					strObjId = (String) mpData.get(DomainConstants.SELECT_ID);
					sNewLevel = (String) mpData.get("level");
					iNewLevel = Integer.parseInt(sNewLevel);
					iNewLevel = iNewLevel + iOldLevel;
					mpData.put("level", String.valueOf(iNewLevel));
					if (sIPReleaseType.equals(sType) && sCurrent.equals("Inactive")) {
						mpData.put("styleRows", "RemovedRow");
						mpData.put("disableSelection", "true");

					}
					if (!mlSoCConnectedList.isEmpty()) {
						for (int j = 0; j < mlSoCConnectedList.size(); j++) {
							mpconnectedData = (Map) mlSoCConnectedList.get(j);
							strConnectedID = (String) mpconnectedData.get(DomainConstants.SELECT_ID);
							strConnectedType = (String) mpconnectedData.get(DomainConstants.SELECT_TYPE);
							strRelationship = (String) mpconnectedData.get("relationship");
							if ((sIPReleaseType.equals(strConnectedType) || branchType.equals(strConnectedType)) && strRelationship.equals(strLogicalProRel)) {
								if (strObjId.equals(strConnectedID)) {
									mpData.put("disableSelection", "true");
									// mlReturnObjList.add(mpData);
								}
							}
						}
					}

					if (iGivenLevel == 0 || iNewLevel <= iGivenLevel) {
						mlReturnObjList.add(mpData);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return mlReturnObjList;

	}

	/**
	 * This method returns Tech Stack values based on the selected current
	 * field.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns Map.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map getTechStackForIPSubscription(Context context, String[] args) throws Exception {
		HashMap returnMap = new HashMap();
		String sFoundryTag = "IP_TECH_STACK_FOUNDRY";
		String sProcessNodeTag = "IP_TECH_STACK_PROCESSNODE";
		String sSubProcessTag = "IP_TECH_STACK_SUBPROCESS";
		String sMetalStackTag = "IP_TECH_STACK_METALSTACK";
		String sIOTypeTag = "IP_TECH_STACK_IOTYPE";
		String sPolyOriTag = "IP_TECH_STACK_POLYORIENTATION";

		try {
			HashMap argMap = (HashMap) JPO.unpackArgs(args);

			String sCurrentField = (String) argMap.get("currentField");
			Map requestMap = (Map) argMap.get("requestMap");
			String sObjectId = (String) requestMap.get("objectId");

			DomainObject domObj = DomainObject.newInstance(context, sObjectId);
			String sFoundry = domObj.getAttributeValue(context,
					PropertyUtil.getSchemaProperty(context, "attribute_IMP_Foundry"));
			String sProcessNode = domObj.getAttributeValue(context,
					PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProcessNode"));

			if (sCurrentField.equalsIgnoreCase(sFoundryTag)) {

				if (sFoundry != null && sFoundry.length() > 0) {
					returnMap.put(sFoundry, sFoundry);
					// slReturnList.add(sFoundry);
				}

			} else if (sCurrentField.equalsIgnoreCase(sProcessNodeTag)) {

				if (sProcessNode != null) {
					returnMap.put(sProcessNode, sProcessNode);
				}
			} else if (sCurrentField.equalsIgnoreCase(sSubProcessTag)) {
				sFOUNDRY = sFoundry;
				sSPROCESSNODE = sProcessNode;

				HashMap map = IMP_TechStackUtil_mxJPO.getTechStackValues(context, sTAG_SUBPROCESS);
				Iterator entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry entry = (Map.Entry) entries.next();
					String key = (String) entry.getKey();

					if (key.equals(sSPROCESSNODE)) {
						ArrayList listSubProcess = (ArrayList) entry.getValue();
						Iterator itr = listSubProcess.iterator();
						while (itr.hasNext()) {
							String strSubProcess = (String) itr.next();
							returnMap.put(strSubProcess, strSubProcess);
						}
					}
				}
			} else if (sCurrentField.equalsIgnoreCase(sMetalStackTag)) {
				sFOUNDRY = sFoundry;
				sSPROCESSNODE = sProcessNode;
				StringList slSubProcess = new StringList();

				HashMap map = IMP_TechStackUtil_mxJPO.getTechStackValues(context, sTAG_SUBPROCESS);
				Iterator entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry entry = (Map.Entry) entries.next();
					String key = (String) entry.getKey();

					if (key.equals(sSPROCESSNODE)) {
						ArrayList listSubProcess = (ArrayList) entry.getValue();
						Iterator itr = listSubProcess.iterator();
						while (itr.hasNext()) {
							String strSubProcess = (String) itr.next();
							slSubProcess.add(strSubProcess);
						}
					}
				}

				returnMap = (HashMap) IMP_TechStackUtil_mxJPO.getMetalStackForIPSubscription(context, slSubProcess);

			} else if (sCurrentField.equalsIgnoreCase(sIOTypeTag)) {

				HashMap map = IMP_TechStackUtil_mxJPO.getTechStackValues(context, sTAG_IOTYPE);

				Iterator entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry entry = (Map.Entry) entries.next();
					String key = (String) entry.getKey();

					if (key.equals(sFoundry)) {
						ArrayList listIOType = (ArrayList) entry.getValue();
						Iterator itr = listIOType.iterator();
						while (itr.hasNext()) {
							String strIOType = (String) itr.next();
							returnMap.put(strIOType, strIOType);
						}
					}
				}

			} else if (sCurrentField.equalsIgnoreCase(sPolyOriTag)) {
				HashMap map = IMP_TechStackUtil_mxJPO.getTechStackValues(context, sTAG_POLYORIENTATION);

				Iterator entries = map.entrySet().iterator();
				while (entries.hasNext()) {
					Map.Entry entry = (Map.Entry) entries.next();
					String key = (String) entry.getKey();

					if (key.equals(sFoundry)) {
						ArrayList listPoly = (ArrayList) entry.getValue();
						Iterator itr = listPoly.iterator();
						while (itr.hasNext()) {
							String strPoly = (String) itr.next();
							returnMap.put(strPoly, strPoly);
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}


		return returnMap;

	}

	@SuppressWarnings("rawtypes")
	public int checkForSubscriptionAccess(Context context, String args[]) throws Exception {
		int iReturn = 0;
		try {
			HashMap hmData = JPO.unpackArgs(args);
			String[] sArrObjectIds = (String[]) hmData.get("sArrObjectIds");
			String sBranchId;
			StringList slAccess = new StringList();

			for (int i = 0; i < sArrObjectIds.length; i++) {
				sBranchId = sArrObjectIds[i];
				slAccess.add(checkForAccess(context, sBranchId));
			}


			if (slAccess.contains("false")) {
				iReturn = 1;
			}
		} catch (Exception e) {
			throw e;
		}
		return iReturn;
	}

	/**
	 * This method returns true if the context user has check in access for the
	 * business object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Branch objectId.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	public String checkForAccess(Context context, String sBranchObjId) throws Exception {
		String sReturn = "false";
		try {
			DomainObject domBranchObj = DomainObject.newInstance(context, sBranchObjId);
			DomainObject domIPRelObj = DomainObject.newInstance(context);

			String sIPObjId = domBranchObj.getInfo(context, "to[IMP_IPBranch].from.id");

			if (sIPObjId != null && sIPObjId.length() > 0) {
				domIPRelObj.setId(sBranchObjId);
				String strBranchId = domIPRelObj.getInfo(context, "to[IMP_IPBranchRelease].from.id");
				domBranchObj.setId(strBranchId);
				sIPObjId = domBranchObj.getInfo(context, "to[IMP_IPBranch].from.id");
			}

			DomainObject domIPObj = DomainObject.newInstance(context, sIPObjId);
			Access access = domIPObj.getAccessMask(context);

			if (access.hasCheckoutAccess()) {
				sReturn = "true";
			}

		} catch (Exception e) {
			throw e;
		}
		return sReturn;
	}

	/**
	 * This method returns Branch connected Release objects.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds string array of Branch objectId's.
	 * @returns StringList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public StringList getBranchConnectedReleases(Context context, String args[]) throws Exception {
		MapList mlRelatedIPReleaseList = new MapList();
		StringList slReturnList = new StringList();
		StringList slIPRelSelects = new StringList();
		slIPRelSelects.add(DomainConstants.SELECT_ID);
		DomainObject domBranchObj = null;
		String strRelID = "";

		try {
			for (int i = 0; i < args.length; i++) {
				domBranchObj = DomainObject.newInstance(context, args[i]);
				mlRelatedIPReleaseList = (MapList) domBranchObj.getRelatedObjects(context,
						PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship
																										// pattern
						PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type
																						// pattern
						slIPRelSelects, // Object selects
						null, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit

				if (!mlRelatedIPReleaseList.isEmpty()) {
					for (int j = 0; j < mlRelatedIPReleaseList.size(); j++) {
						Map mpRelObj = (Map) mlRelatedIPReleaseList.get(j);
						strRelID = (String) mpRelObj.get(DomainConstants.SELECT_ID);
						slReturnList.add(strRelID);
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return slReturnList;
	}

	@SuppressWarnings("rawtypes")
	public StringList getBranchConnectedReleases(Context context, String strBranchId, boolean bflag) throws Exception {
		MapList mlRelatedIPReleaseList = new MapList();
		StringList slReturnList = new StringList();
		StringList slIPRelSelects = new StringList();
		slIPRelSelects.add(DomainConstants.SELECT_ID);
		slIPRelSelects.add(DomainConstants.SELECT_NAME);
		slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
		DomainObject domBranchObj = null;
		String strRelName = "";

		try {
			domBranchObj = DomainObject.newInstance(context, strBranchId);
			mlRelatedIPReleaseList = (MapList) domBranchObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship
																									// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type
																					// pattern
					slIPRelSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit

			if (!mlRelatedIPReleaseList.isEmpty()) {
				for (int j = 0; j < mlRelatedIPReleaseList.size(); j++) {

					Map mpRelObj = (Map) mlRelatedIPReleaseList.get(j);
					strRelName = (String) mpRelObj
							.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
					if (bflag) {
						slReturnList.add((String) mpRelObj.get(DomainConstants.SELECT_ID));
					} else {
						slReturnList.add(strRelName);
					}

				}
			}
		} catch (Exception e) {
			throw e;
		}
		return slReturnList;
	}

	/**
	 * This method returns MapList containing Directory Tree ObjectId.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public MapList getDirectoryTreeFilesInfo(Context context, String args[]) throws Exception {
		MapList mlReturnList = new MapList();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strObjectId = (String) programMap.get("objectId");
			if (strObjectId != null && strObjectId.length() > 0) {
				Map mapData = new HashMap();
				mapData.put(DomainConstants.SELECT_ID, strObjectId);
				mlReturnList.add(mapData);
			}
		} catch (Exception e) {
			throw e;
		}
		return mlReturnList;
	}

	/**
	 * This method updates only IP Type column for the table whether it is a
	 * Branch or Release object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector updateIPTypeColumn(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		String strIPType = "";
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;
		String sBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPRelType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		try {
			MapList objList = (MapList) programMap.get("objectList");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) objMap.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {  //Added for SWIMP-541
					if (sType.equalsIgnoreCase(sBranchType)) {
						strIPType = dmObj.getInfo(context, "to[IMP_IPBranch].from.attribute[IMP_IPType].value");
						if (UIUtil.isNullOrEmpty(strIPType)) {
							ContextUtil.pushContext(context);
							strIPType = dmObj.getInfo(context, "to[IMP_IPBranch].from.attribute[IMP_IPType].value");
							ContextUtil.popContext(context);
						}
					} else if (sType.equalsIgnoreCase(sIPRelType)) {
						strIPType = dmObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType].value");
						if (UIUtil.isNullOrEmpty(strIPType)) {
							ContextUtil.pushContext(context);
							strIPType = dmObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType].value");
							ContextUtil.popContext(context);
						}
					} else {
						strIPType = dmObj.getInfo(context, "attribute[IMP_IPType].value");
					}
					if (strIPType != null && !"".equals(strIPType)) {
						returnList.add(strIPType);
					} else {
						returnList.add("");
					}
				} else {
						returnList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);  //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnList;
	}

	/**
	 * This method updates only IP BU column for the table whether it is a
	 * Branch or Release object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector updateIPBU(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		String strIPBU = "";
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;
		String sBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPRelType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		String sRelIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String sRelIPBranchRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String attrProductDiv = PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision");
		
		try {
			MapList objList = (MapList) programMap.get("objectList");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) objMap.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
				
					if (sType.equalsIgnoreCase(sBranchType)) {
						strIPBU = dmObj.getInfo(context, "to["+sRelIPBranch+"].from.attribute["+attrProductDiv+"].value");
						if(UIUtil.isNullOrEmpty(strIPBU)){
							ContextUtil.pushContext(context);
							strIPBU = dmObj.getInfo(context, "to["+sRelIPBranch+"].from.attribute["+attrProductDiv+"].value");
							ContextUtil.popContext(context);
						}
					} else if (sType.equalsIgnoreCase(sIPRelType)) {
						strIPBU = dmObj.getInfo(context, "to["+sRelIPBranchRel+"].from.to["+sRelIPBranch+"].from.attribute["+attrProductDiv+"].value");
						if(UIUtil.isNullOrEmpty(strIPBU)){
							ContextUtil.pushContext(context);
							strIPBU = dmObj.getInfo(context, "to["+sRelIPBranchRel+"].from.to["+sRelIPBranch+"].from.attribute["+attrProductDiv+"].value");
							ContextUtil.popContext(context);
						}
					}
					if (strIPBU != null && !"".equals(strIPBU)) {
						returnList.add(strIPBU);
					} else {
						returnList.add("");
					}
				} else {
					returnList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);  //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}

	/**
	 * This method updates only IP Owner column for the table whether it is a
	 * Branch or Release object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector updateIPOwner(Context context, String args[]) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnList = new Vector();
		String strIPOwner = "";
		Map objMap = null;
		String sObjectid = "";
		String sType = "";
		DomainObject dmObj = null;
		String sBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPRelType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		String sRelIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String sRelIPBranchRel = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		
		try {
			MapList objList = (MapList) programMap.get("objectList");
			for (int iCnt = 0; iCnt < objList.size(); iCnt++) {
				objMap = (Map) objList.get(iCnt);
				sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
				dmObj = DomainObject.newInstance(context, sObjectid);
				sType = dmObj.getInfo(context, DomainConstants.SELECT_TYPE);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) objMap.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {  //Added for SWIMP-541
					if (sType.equalsIgnoreCase(sBranchType)) {
						strIPOwner = dmObj.getInfo(context, "to[" + sRelIPBranch + "].from.owner");
						if (UIUtil.isNullOrEmpty(strIPOwner)) {
							ContextUtil.pushContext(context);
							strIPOwner = dmObj.getInfo(context, "to[" + sRelIPBranch + "].from.owner");
							ContextUtil.popContext(context);
						}
					} else if (sType.equalsIgnoreCase(sIPRelType)) {
						strIPOwner = dmObj.getInfo(context, "to[" + sRelIPBranchRel + "].from.to[" + sRelIPBranch + "].from.owner");
						if (UIUtil.isNullOrEmpty(strIPOwner)) {
							ContextUtil.pushContext(context);
							strIPOwner = dmObj.getInfo(context, "to[" + sRelIPBranchRel + "].from.to[" + sRelIPBranch + "].from.owner");
							ContextUtil.popContext(context);
						}
					}
					if (strIPOwner != null && !"".equals(strIPOwner)) {
						returnList.add(strIPOwner);
					} else {
						returnList.add("");
					}
				} else {
					returnList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);  //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}

	// Modified for user story 224
    /**
     * This method returns JSON String for IP Product object.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds IP objectId.
     * @returns String.
     * @throws Exception
     *             if the operation fails
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map getJSONStringForIPProductInfo(Context context, String args[]) throws Exception {

        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        String objectId = (String) programMap.get("objectId");

        StringList slList = new StringList();
        slList.add(objectId);

        Hashtable mapSoC = null;
        Hashtable mapTechStack = null;
        Hashtable mapBranchInfo = null;
        Hashtable mapUserAccessReq = null;
        Hashtable mapBUUserAccessReq = null;

        String strSoCName = "";
        String strBranchTag = "";
        String sAttBUReq = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsBUAccessRequest");
        String strFoundary = "";
        String strProcessNode = "";
        String strSubProcess = "";
        String strMetalstack = "";
        Object oIOType;
        String strPolyOrientation = "";
        String strSocApprovalStatus = "";
        String strStatus = "";
        String strSoCOwner = "";
        String strAccessName = "";
        String strReasonForRequest = "";
        String strRequestedIP = "";
        String strApprovedRejectedBY = "";
        String strRequestedBy = "";
        String strAccessStatus = "";
        String strReasonForReject = "";
        // Added for user story 224
        Object oNullObject = null;
        
        Map<String, Object> retMap = new LinkedHashMap<>();
        Map<String, Object> mpValuesForBranchAndRel = new LinkedHashMap<>();
        Map<String, Object> mpValuesForIPProductHierarchy = new LinkedHashMap<>();
        try {

            Map returnMap = getIPProductInfoFromIPID(context, objectId);
            // Get IP attribute information
            String strProductType = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductType") + "]");
            String strUniqueID = (String) returnMap.get(DomainConstants.SELECT_NAME);
            String strIPName = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]");
            String strRev = (String) returnMap.get(DomainConstants.SELECT_REVISION);
            String strType = (String) returnMap.get(DomainConstants.SELECT_TYPE);
            String strPolicy = (String) returnMap.get(DomainConstants.SELECT_POLICY);
            String strCurrent = (String) returnMap.get(DomainConstants.SELECT_CURRENT);
            String strLibrary = IMP_LibrarySublibrary_mxJPO.getLibraryAttrVal(context, objectId);
            String strLegacyIP = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyIPName") + "]");
            String strDesc = (String) returnMap.get(DomainConstants.SELECT_DESCRIPTION);
            String strIPSource = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource") + "]");
            String strProductDiv = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");
            String strVendor = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Vendor") + "]");
            String strLegacyCom = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyCompany") + "]");
            String strIPTYpe = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
            String strAccessControl = (String) returnMap.get("attribute["
                    + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessControl_Protection") + "]");
            String strOwnerSCMTag = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_OwnerSCMTag") + "]");
            String strJiraPro = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_JIRAProjectLink") + "]");
            String strWorkspaceLoc = (String) returnMap.get(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_WorkspaceLocation") + "]");
            String strDesignSyncRepo = (String) returnMap.get("attribute["
                    + PropertyUtil.getSchemaProperty(context, "attribute_IMP_DesignSynchRepoReference") + "]");
            String strBroadcomStandards = (String) returnMap.get(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BroadcomStandards") + "]");
            String strIndustryStandards = (String) returnMap.get(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IndustryStandards") + "]");
            String strSoftWareIPDesc = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SoftwareIPDesc") + "]");
            String strLinkToSoftWare = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "IMP_LinktoSoftwareInventory") + "]");
            String strPrefix = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPrefix") + "]");
            String sRoyaltyGroupID = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_RoyaltyGroupID") + "]");
            String strLegacyFieldSet = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyFieldSet") + "]");
            String strOriginator = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
            String strOriginated = (String) returnMap.get(DomainConstants.SELECT_ORIGINATED);
            String strModified = (String) returnMap.get(DomainConstants.SELECT_MODIFIED);
            String strCoOwner = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");
            String strBUAccess = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BUAccess") + "]");
			// Modified for user story 224
            String strDesignSybcURL = (String) returnMap
                .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]");
			//Added for SWIMP-1 for changing attribute name to IMP_IPRevisionWatermark
            String strWaterMark = (String) returnMap
                .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPRevisionWatermark") + "]");
            String strOwner = (String) returnMap
                    .get(DomainConstants.SELECT_OWNER);
            String strIpAlias = (String) returnMap
                    .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPAliases") + "]");
            
            
            retMap.put("objectid", objectId);
            retMap.put("product_type", (strProductType == null || strProductType.equals("")) ? oNullObject : strProductType);
            retMap.put("unique_id", (strUniqueID == null || strUniqueID.equals("")) ? oNullObject : strUniqueID);
            retMap.put("ip_name", (strIPName == null || strIPName.equals("")) ? oNullObject : strIPName);
            retMap.put("revision", (strRev == null || strRev.equals("")) ? oNullObject : strRev);
            retMap.put("type", (strType == null || strType.equals("")) ? oNullObject : strType);
            retMap.put("policy", (strPolicy == null || strPolicy.equals("")) ? oNullObject : strPolicy);
            retMap.put("lifecycle", (strCurrent == null || strCurrent.equals("")) ? oNullObject : strCurrent);
            retMap.put("library", (strLibrary == null || strLibrary.equals("")) ? oNullObject : strLibrary);
            retMap.put("legacy_ip_name", (strLegacyIP == null || strLegacyIP.equals("")) ? oNullObject : strLegacyIP);
            retMap.put("description", (strDesc == null || strDesc.equals("")) ? oNullObject : strDesc);
            retMap.put("ip_source", (strIPSource == null || strIPSource.equals("")) ? oNullObject : strIPSource);
            retMap.put("product_division", (strProductDiv == null || strProductDiv.equals("")) ? oNullObject : strProductDiv);
            retMap.put("vendor", (strVendor == null || strVendor.equals("")) ? oNullObject : strVendor);
            retMap.put("legacy_company", (strLegacyCom == null || strLegacyCom.equals("")) ? oNullObject : strLegacyCom);
            retMap.put("ip_type", (strIPTYpe == null || strIPTYpe.equals("")) ? oNullObject : strIPTYpe);
            retMap.put("access_control_protection",
                    (strAccessControl == null || strAccessControl.equals("")) ? oNullObject : strAccessControl);
            retMap.put("owner_scm_tag", (strOwnerSCMTag == null || strOwnerSCMTag.equals("")) ? oNullObject : strOwnerSCMTag);
            retMap.put("jira_project_link", (strJiraPro == null || strJiraPro.equals("")) ? oNullObject : strJiraPro);
            retMap.put("workspace_location",
                    (strWorkspaceLoc == null || strWorkspaceLoc.equals("")) ? oNullObject : strWorkspaceLoc);
            retMap.put("design_sync_repo_reference",
                    (strDesignSyncRepo == null || strDesignSyncRepo.equals("")) ? oNullObject : strDesignSyncRepo);
            retMap.put("broadcom_standards",
                    (strBroadcomStandards == null || strBroadcomStandards.equals("")) ? oNullObject : strBroadcomStandards);
            retMap.put("industry_standards",
                    (strIndustryStandards == null || strIndustryStandards.equals("")) ? oNullObject : strIndustryStandards);
            retMap.put("software_description",
                    (strSoftWareIPDesc == null || strSoftWareIPDesc.equals("")) ? oNullObject : strSoftWareIPDesc);
            retMap.put("link_to_software_inventory",
                    (strLinkToSoftWare == null || strLinkToSoftWare == null || strLinkToSoftWare.equals("")) ? oNullObject
                            : strLinkToSoftWare);
            retMap.put("ip_prefix", (strPrefix == null || strPrefix.equals("")) ? oNullObject : strPrefix);
            retMap.put("royalty_group_id", (sRoyaltyGroupID == null || sRoyaltyGroupID.equals("")) ? oNullObject : sRoyaltyGroupID);
            retMap.put("legacy_field_set",
                    (strLegacyFieldSet == null || strLegacyFieldSet.equals("")) ? oNullObject : strLegacyFieldSet);
            retMap.put("originator", (strOriginator == null || strOriginator.equals("")) ? oNullObject : strOriginator);
            retMap.put("originated", (strOriginated == null || strOriginated.equals("")) ? oNullObject : strOriginated);
            retMap.put("modified", (strModified == null || strModified.equals("")) ? oNullObject : strModified);
            retMap.put("watermark", (strWaterMark == null || strWaterMark.equals("")) ? oNullObject : strWaterMark);
            retMap.put("aliases", (strIpAlias == null || strIpAlias.equals("")) ? oNullObject : strIpAlias);
            retMap.put("designsync_url", (strDesignSybcURL == null || strDesignSybcURL.equals("")) ? oNullObject : strDesignSybcURL);
            retMap.put("owner", (strOwner == null || strOwner.equals("")) ? oNullObject : strOwner);
            retMap.put("co_owners", getListObjects(strCoOwner, "~"));
            retMap.put("bu_access", getListObjects(strBUAccess, "~"));
            retMap.put("deprecates", returnMap.get("deprecates"));
            retMap.put("deprecated_by", returnMap.get("deprecated_by"));

            String strAccessUser = getRelatedUserAccess(context, objectId);
            retMap.put("user_access", getListObjects(strAccessUser, ","));

            String strSoftwareIPOwner = getSoftwareIPOwner(context, objectId);
            retMap.put("software_ip_owner", getListObjects(strSoftwareIPOwner, ","));

            // Get tech stack connected to the IP
            MapList mlRelatedTechStackList = IMP_TechStackUtil_mxJPO.getRelatedTechStackForIP(context, objectId);
            Map<String, Object> mpTechValue;
            List<Map> lsTechStack = new ArrayList<>();
            String sIOType;
            StringList slIOType ;
            for (int i = 0; i < mlRelatedTechStackList.size(); i++) {
                mapTechStack = (Hashtable) mlRelatedTechStackList.get(i);
                mpTechValue = new LinkedHashMap<>();
                
                strFoundary = (String) mapTechStack.get("attribute[IMP_Foundry]");
                strProcessNode = (String) mapTechStack.get("attribute[IMP_ProcessNode]");
                strSubProcess = (String) mapTechStack.get("attribute[IMP_SubProcess]");
                strMetalstack = (String) mapTechStack.get("attribute[IMP_MetalStack]");
                oIOType = mapTechStack.get("attribute[IMP_IOType]");
                strPolyOrientation = (String) mapTechStack.get("attribute[IMP_PolyOrientation]");
                
                if(oIOType instanceof StringList){
                	slIOType = (StringList) oIOType;
                	sIOType = FrameworkUtil.join(slIOType, "~");
                } else {
                	sIOType = (String) oIOType;
                }                
                
                mpTechValue.put("foundry", (strFoundary == null || strFoundary.equals("")) ? oNullObject : strFoundary);
                mpTechValue.put("process_node",
                        (strProcessNode == null || strProcessNode.equals("")) ? " " : strProcessNode);
                mpTechValue.put("sub_process", (strSubProcess == null || strSubProcess.equals("")) ? oNullObject : strSubProcess);
                mpTechValue.put("metal_stack", (strMetalstack == null || strMetalstack.equals("")) ? oNullObject : strMetalstack);
                mpTechValue.put("io_type", (sIOType == null || sIOType.equals("")) ? oNullObject : sIOType);
                mpTechValue.put("poly_orientation",
                        (strPolyOrientation == null || strPolyOrientation.equals("")) ? oNullObject : strPolyOrientation);
                lsTechStack.add(mpTechValue);
            }
             retMap.put("technology_stacks",lsTechStack);

            // Get subscribed SOC for the releases connected to the IP.
            HashMap programMapSoC = new HashMap();
            programMapSoC.put("objectId", objectId);
            MapList mlRelatedSubscribedSoCList = IMP_IPProductUtil_mxJPO.getSOCsForIP(context,
                    JPO.packArgs(programMapSoC));
            Map<String, Object> mpSubValues;
            List<Map> lsSubscribeSoc = new ArrayList<>();
            for (int i = 0; i < mlRelatedSubscribedSoCList.size(); i++) {
                mapSoC = (Hashtable) mlRelatedSubscribedSoCList.get(i);
                String sRelRev = (String) mapSoC.get("sRelRev");
                strSoCName = (String) mapSoC.get(DomainConstants.SELECT_NAME);
                strSocApprovalStatus = (String) mapSoC.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS + IMP_Constants_mxJPO.VALUE);//Modified for SWIMP-322
                strStatus = (String) mapSoC.get(DomainConstants.SELECT_CURRENT);
                strSoCOwner = (String) mapSoC.get(DomainConstants.SELECT_OWNER);
                mpSubValues = new LinkedHashMap<>();
                mpSubValues.put("name", (strSoCName == null || strSoCName.equals("")) ? oNullObject : strSoCName);
                mpSubValues.put("approval_status",
                        (strSocApprovalStatus == null || strSocApprovalStatus.equals("")) ? oNullObject : strSocApprovalStatus);
                mpSubValues.put("design_status", (strStatus == null || strStatus.equals("")) ? oNullObject : strStatus);
                mpSubValues.put("owner", (strSoCOwner == null || strSoCOwner.equals("")) ? oNullObject : strSoCOwner);
                mpSubValues.put("revision", (sRelRev == null || sRelRev.equals("")) ? oNullObject : sRelRev);            
                lsSubscribeSoc.add(mpSubValues);
            }
            retMap.put("subscribing_socs",lsSubscribeSoc);

            // Get user access request
            String whereClause = "attribute[" + sAttBUReq + "]=='FALSE'";
            MapList resultList = listAccessRequests(context, objectId, whereClause);
            List<Map> lsUserAccess = new ArrayList<>();
            Map<String, Object> mpUserAccess;
            for (int i = 0; i < resultList.size(); i++) {
                mapUserAccessReq = (Hashtable) resultList.get(i);

                strAccessName = (String) mapUserAccessReq.get(DomainConstants.SELECT_NAME);
                strReasonForRequest = (String) mapUserAccessReq.get(
                        "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_ReasonforRequest") + "]");
                strRequestedIP = (String) mapUserAccessReq.get("from["
                        + PropertyUtil.getSchemaProperty(context, "relationship_IMP_RequestedObject") + "].to.name");
                strApprovedRejectedBY = (String) mapUserAccessReq.get("attribute["
                        + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestApprovedRejectedBy")
                        + "]");
                strRequestedBy = (String) mapUserAccessReq
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
                strAccessStatus = (String) mapUserAccessReq.get(DomainConstants.SELECT_CURRENT);
                strReasonForReject = (String) mapUserAccessReq.get("attribute["
                        + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestRejectionReason") + "]");
                mpUserAccess = new LinkedHashMap<>();

                mpUserAccess.put("name",
                    (strAccessName == null || strAccessName.equals("")) ? oNullObject : strAccessName);
                mpUserAccess.put("reason_for_request",
                        (strReasonForRequest == null || strReasonForRequest.equals("")) ? oNullObject : strReasonForRequest);
                mpUserAccess.put("requested_ip",
                        (strRequestedIP == null || strRequestedIP.equals("")) ? oNullObject : strRequestedIP);
                mpUserAccess.put("approved_rejectedby",
                        (strApprovedRejectedBY == null || strApprovedRejectedBY.equals("")) ? oNullObject
                                : strApprovedRejectedBY);
                mpUserAccess.put("requested_by",
                        (strRequestedBy == null || strRequestedBy.equals("")) ? oNullObject : strRequestedBy);
                mpUserAccess.put("status",
                        (strAccessStatus == null || strAccessStatus.equals("")) ? oNullObject : strAccessStatus);
                mpUserAccess.put("reason_for_reject",
                        (strReasonForReject == null || strReasonForReject.equals("")) ? oNullObject : strReasonForReject);
                lsUserAccess.add(mpUserAccess);
            }
            retMap.put("user_access_requests",lsUserAccess);

            // Get bu user access request
            String swhereClause = "attribute[" + sAttBUReq + "]=='TRUE'";
            MapList sresultList = listAccessRequests(context, objectId, swhereClause);
            Map<String, Object> mpBUUserAccess;
            List<Map> lsBuAccess = new ArrayList<>();
            for (int i = 0; i < sresultList.size(); i++) {
                mapBUUserAccessReq = (Hashtable) sresultList.get(i);
                strAccessName = (String) mapBUUserAccessReq.get(DomainConstants.SELECT_NAME);
                strReasonForRequest = (String) mapBUUserAccessReq.get(
                        "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_ReasonforRequest") + "]");
                strRequestedIP = (String) mapBUUserAccessReq.get("from["
                        + PropertyUtil.getSchemaProperty(context, "relationship_IMP_RequestedObject") + "].to.name");
                strApprovedRejectedBY = (String) mapBUUserAccessReq.get("attribute["
                        + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestApprovedRejectedBy")
                        + "]");
                strRequestedBy = (String) mapBUUserAccessReq
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
                strAccessStatus = (String) mapBUUserAccessReq.get(DomainConstants.SELECT_CURRENT);
                strReasonForReject = (String) mapBUUserAccessReq.get("attribute["
                        + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestRejectionReason") + "]");
                mpBUUserAccess = new LinkedHashMap<>();

                mpBUUserAccess.put("name",
                        (strAccessName == null || strAccessName.equals("")) ? " " : strAccessName);
                mpBUUserAccess.put("reason_for_request",
                        (strReasonForRequest == null || strReasonForRequest.equals("")) ? " " : strReasonForRequest);
                mpBUUserAccess.put("requested_ip",
                        (strRequestedIP == null || strRequestedIP.equals("")) ? " " : strRequestedIP);
                mpBUUserAccess.put("approved_rejectedby",
                        (strApprovedRejectedBY == null || strApprovedRejectedBY.equals("")) ? " "
                                : strApprovedRejectedBY);
                mpBUUserAccess.put("requested_by",
                        (strRequestedBy == null || strRequestedBy.equals("")) ? " " : strRequestedBy);
                mpBUUserAccess.put("status",
                        (strAccessStatus == null || strAccessStatus.equals("")) ? " " : strAccessStatus);
                mpBUUserAccess.put("reason_for_reject",
                        (strReasonForReject == null || strReasonForReject.equals("")) ? " " : strReasonForReject);
                lsBuAccess.add(mpBUUserAccess);
            }
            
            retMap.put("bu_user_access_requests",lsBuAccess);

            HashMap pMap = new HashMap();
            pMap.put("objectId", objectId);
            // Get Branch and Revisions for the IP
            MapList mlBranchAndReleaseObjects = getBranchAndRelObjects(context, JPO.packArgs(pMap));
            mpValuesForBranchAndRel = new LinkedHashMap<>();
            Map<String, Object> mpValue;
            
            for (int i = 0; i < mlBranchAndReleaseObjects.size(); i++) {
                Map<String, Object> mpBranchAttr = new LinkedHashMap<>();
                mapBranchInfo = (Hashtable) mlBranchAndReleaseObjects.get(i);
                strBranchTag = (String) mapBranchInfo.get("attribute[IMP_IPTag]");
                slList.add((String) mapBranchInfo.get(DomainConstants.SELECT_ID));
                
               mpValue = new LinkedHashMap<>();
                StringList mlGetRelIDInfo = getBranchConnectedReleases(context,
                        (String) mapBranchInfo.get(DomainConstants.SELECT_ID), true);
                slList.addAll(mlGetRelIDInfo);

                List<Map> mlGetRelInfo = getBranchConnectedReleasesData(context,
                        (String) mapBranchInfo.get(DomainConstants.SELECT_ID));
				// Added for 224
                String sBranchCreateDate = (String) mapBranchInfo.get(DomainConstants.SELECT_ORIGINATED);
                String sBranchAcestor = (String) mapBranchInfo.get("attribute["+PropertyUtil.getSchemaProperty(context, "attribute_IMP_BranchParentRevision")+"]");
                mpBranchAttr.put("created_date", sBranchCreateDate == null || sBranchCreateDate.isEmpty() ? oNullObject : sBranchCreateDate);
                mpBranchAttr.put("ancestor", sBranchAcestor == null || sBranchAcestor.isEmpty() ? oNullObject : sBranchAcestor);
                mpValue.putAll(mpBranchAttr);
                mpValue.put("revisions", mlGetRelInfo);
                mpValuesForBranchAndRel.put(strBranchTag, mpValue);
            }
             retMap.put("branches_and_revisions", mpValuesForBranchAndRel);
            // Get Product Hierarchy for the IP
			// Modified for user story 224
                mpValuesForIPProductHierarchy = getConnectedBranchAndRevisions(context, slList);
                retMap.putAll(mpValuesForIPProductHierarchy);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return retMap;
    }

	/**
	 * This method returns IP Product Object Info for Given IP Object id.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP objectId.
	 * @returns Map.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public Map getIPProductInfoFromIPID(Context context, String strIPID) throws Exception {
		Map returnMap = new HashMap();
		try {
			StringList slIPObjectSelects = new StringList();
			slIPObjectSelects.add(DomainConstants.SELECT_NAME);
			slIPObjectSelects.add(DomainConstants.SELECT_OWNER);
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductType") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]");
			slIPObjectSelects.add(DomainConstants.SELECT_REVISION);
			slIPObjectSelects.add(DomainConstants.SELECT_TYPE);
			slIPObjectSelects.add(DomainConstants.SELECT_POLICY);
			slIPObjectSelects.add(DomainConstants.SELECT_CURRENT);
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyIPName") + "]");
			slIPObjectSelects.add(DomainConstants.SELECT_DESCRIPTION);
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Vendor") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyCompany") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
			slIPObjectSelects.add("attribute["
					+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessControl_Protection") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_OwnerSCMTag") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_JIRAProjectLink") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_WorkspaceLocation") + "]");
			slIPObjectSelects.add("attribute["
					+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_DesignSynchRepoReference") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BroadcomStandards") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IndustryStandards") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SoftwareIPDesc") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "IMP_LinktoSoftwareInventory") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPrefix") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_RoyaltyGroupID") + "]");
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyFieldSet") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
			slIPObjectSelects.add(DomainConstants.SELECT_ORIGINATED);
			slIPObjectSelects.add(DomainConstants.SELECT_MODIFIED);
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BUAccess") + "]");
			slIPObjectSelects
            .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]");
			//Added for SWIMP-1 for changinge attribute name IMP_IPRevisionWatermark
			slIPObjectSelects
            .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPRevisionWatermark") + "]");
			DomainObject domIPObj = DomainObject.newInstance(context, strIPID);
			returnMap = domIPObj.getInfo(context, slIPObjectSelects);
			
			String aliasAttr = "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPAliases") + "]";
			StringList slIPAliases = domIPObj.getInfoList(context, aliasAttr);
			String sIPAliases = FrameworkUtil.join(slIPAliases, ","); 
			
			returnMap.put(aliasAttr, sIPAliases);
			returnMap.put("deprecates", IMP_IPDeprecate_mxJPO.getDeprecates(context, strIPID));
			returnMap.put("deprecated_by", IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, strIPID));
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnMap;
	}

	// Modified for user story 224
    /**
     * This method returns JSON String for SoC object.
     *
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds SoC objectId.
     * @returns String.
     * @throws Exception
     *             if the operation fails
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map getJSONStringForSoCInfo(Context context, String args[]) throws Exception {
        String sAttBUReq = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsBUAccessRequest");
        String branchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
        String sIPReleaseType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");

        String strSoCName = "";
        String strSoCLifeCycle = "";
        String strSoCDescription = "";
        String strSoCOwner = "";
        String strSoCType = ""; //Added for SWIMP-878
        String strBUAccess = "";
        String strSoCCOOwner = "";
        String strProductDivision = "";
        String strAccessControlProtection = "";
        String strFoundary = "";
        String strProcessNode = "";
        String strSubProcess = "";
        String strMetalStack = "";
        String strPolyOrientation = "";
        String strMaturityLevel = "";
        String strSoftIPNeedBy = "";
        String strHardIPNeedBy = "";
        String strType = "";
        String strIPID = "";
        String strAccessName = "";
        String strReasonForRequest = "";
        String strRequestedSoC = "";
        String strApprovedRejectedBY = "";
        String strRequestedBy = "";
        String strAccessStatus = "";
        String strReasonForReject = "";
        String strRequestID = "";
        String strStatus = "";
        String strSubmittedOn = "";
        String strSubmittedBy = "";
        String strDryRun = "";
        String strIPName = "";
        String strIPType = "";
        String strNOOfInst = "";
        String strIPOwner = "";
        String strBUIP = "";
        String strOriginated ="";
        String strModified = "";
		//Added for SWIMP:313 -Start
		String strIMPAllowIPVerification="";
		String strIMPEPSProjectId="";
		String strIMPEPSProjectRevision="";
		String strSyncWithEPS="";
		String nidowner="";
		//Added for SWIMP:313 - End
        
        Object oNullObject = null;

        Map returnMap = null;
        Hashtable mapMLObj = null;
        Hashtable mapUserAccessReq = null;
        Hashtable mapBUUserAccessReq = null;
        Hashtable mapBranchAndRelObj = null;
        Hashtable mapIPVerifyObj = null;
        
        Map<String, Object> retMap = new LinkedHashMap<>();
        
        Map<String, Object> mapValuesForTechStack = new LinkedHashMap<>();

        DomainObject dmObj = null;

        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        String objectId = (String) programMap.get("objectId");

        try {
            StringList slIPObjectSelects = new StringList();
            slIPObjectSelects.add(DomainConstants.SELECT_NAME);
            slIPObjectSelects
                    .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
            slIPObjectSelects.add(DomainConstants.SELECT_OWNER);
            slIPObjectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");

            StringList objectSelects = new StringList();
            objectSelects.add(DomainConstants.SELECT_ID);
            objectSelects.add(DomainConstants.SELECT_NAME);
            objectSelects.add(DomainConstants.SELECT_OWNER);
            objectSelects.add(DomainConstants.SELECT_CURRENT);
            objectSelects.add(DomainConstants.SELECT_DESCRIPTION);
            objectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SocType") + "]");//Added for SWIMP-878
            objectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");
            objectSelects.add("attribute["
                    + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessControl_Protection") + "]");
            objectSelects
                    .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Foundry") + "]");
            objectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProcessNode") + "]");
            objectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SubProcess") + "]");
            objectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_MetalStack") + "]");
            objectSelects
                    .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IOType") + "]");
            objectSelects.add(
                    "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_PolyOrientation") + "]");
            objectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");
            objectSelects
                    .add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BUAccess") + "]");
            objectSelects.add(DomainConstants.SELECT_MODIFIED);
            objectSelects.add(DomainConstants.SELECT_ORIGINATED);
			//Added for SWIMP:313 -Start
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_PROJECT_ID);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_REVISION);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_SYNC_WITH_EPS);
			//Added for SWIMP:313 -End
            DomainObject domSoC = DomainObject.newInstance(context, objectId);
            // Get attributes for the SOC
            Map mlSoCInfo = domSoC.getInfo(context, objectSelects);
            
            StringList slIOType = domSoC.getInfoList(context, "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IOType") + "]");       
            String sIOType = "";            
			if (!slIOType.isEmpty()) {
				sIOType = FrameworkUtil.join(slIOType, "~");
			}
    		
            if (!mlSoCInfo.isEmpty()) {
                strSoCName = (String) mlSoCInfo.get(DomainConstants.SELECT_NAME);
                strSoCOwner = (String) mlSoCInfo.get(DomainConstants.SELECT_OWNER);
                strSoCLifeCycle = (String) mlSoCInfo.get(DomainConstants.SELECT_CURRENT);
                strSoCDescription = (String) mlSoCInfo.get(DomainConstants.SELECT_DESCRIPTION);
                strSoCType = (String) mlSoCInfo.get(
                        "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SocType") + "]"); //Added for SWIMP-878
				//Added for SWIMP:313 -Start
				String strOwnerPersonID = PersonUtil.getPersonObjectID(context, strSoCOwner);
				DomainObject domPersonObj = DomainObject.newInstance(context, strOwnerPersonID);
				nidowner = domPersonObj.getInfo(context,IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PERSON_ID);

				strIMPAllowIPVerification = (String)mlSoCInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION);
				strIMPEPSProjectId = (String)mlSoCInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_PROJECT_ID);
				strIMPEPSProjectRevision = (String)mlSoCInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_REVISION);
				strSyncWithEPS = (String)mlSoCInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_EPS_PROJECT_SYNC_WITH_EPS);
				//Added for SWIMP:313 -End             
                strProductDivision = (String) mlSoCInfo.get(
                        "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");
                strAccessControlProtection = (String) mlSoCInfo.get("attribute["
                        + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessControl_Protection") + "]");
                strFoundary = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Foundry") + "]");
                strProcessNode = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProcessNode") + "]");
                strSubProcess = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_SubProcess") + "]");
                strMetalStack = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_MetalStack") + "]");
                strPolyOrientation = (String) mlSoCInfo.get(
                        "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_PolyOrientation") + "]");
                strSoCCOOwner = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_CoOwner") + "]");
                strBUAccess = (String) mlSoCInfo
                        .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_BUAccess") + "]");
                strOriginated = (String) mlSoCInfo.get(DomainConstants.SELECT_ORIGINATED);
                strModified = (String) mlSoCInfo.get(DomainConstants.SELECT_MODIFIED);
				retMap.put("objectid", objectId);
                retMap.put("name", (strSoCName == null || strSoCName.equals("")) ? oNullObject : strSoCName);
                retMap.put("owner", (strSoCOwner == null || strSoCOwner.equals("")) ? " " : strSoCOwner);
                retMap.put("lifeCycle", (strSoCLifeCycle == null || strSoCLifeCycle.equals("")) ? oNullObject : strSoCLifeCycle);
                retMap.put("soc_type", (strSoCType == null || strSoCType.equals("")) ? oNullObject : strSoCType);//Added for SWIMP-878
                retMap.put("description", (strSoCDescription == null || strSoCDescription.equals("")) ? oNullObject : strSoCDescription);
                retMap.put("originated", (strOriginated == null || strOriginated.equals("")) ? oNullObject : strOriginated);
                retMap.put("modified", (strModified == null || strModified.equals("")) ? oNullObject : strModified);
                //Added for SWIMP:484 -Start
                if(UIUtil.isNotNullAndNotEmpty(strIMPAllowIPVerification)) {
                	strIMPAllowIPVerification = "true".equalsIgnoreCase(strIMPAllowIPVerification)?"FALSE" : "TRUE";
                }
                //Added for SWIMP:484 -End
                //Added for SWIMP:313 -Start
				retMap.put("imp_verification_flag", (strIMPAllowIPVerification == null || strIMPAllowIPVerification.equals("")) ? oNullObject : strIMPAllowIPVerification);
				retMap.put("project_id", (strIMPEPSProjectId == null || strIMPEPSProjectId.equals("")) ? oNullObject : strIMPEPSProjectId);
				retMap.put("project_revision", (strIMPEPSProjectRevision == null || strIMPEPSProjectRevision.equals("")) ? oNullObject : strIMPEPSProjectRevision);
				retMap.put("sync_with_eps", (strSyncWithEPS == null || strSyncWithEPS.equals("")) ? oNullObject : strSyncWithEPS);      
				retMap.put("nid_owner", (nidowner == null || nidowner.equals("")) ? oNullObject : nidowner);
				List <String>lsCoOwner = new ArrayList<>();

				for (String strCoOwner: getListObjects(strSoCCOOwner, "~")) {
					String strCoOwnerPersonID = PersonUtil.getPersonObjectID(context, strCoOwner);
					DomainObject domCoOwnPersonObj = DomainObject.newInstance(context, strCoOwnerPersonID);					 
					lsCoOwner.add(domCoOwnPersonObj.getInfo(context,IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PERSON_ID));
				}
				retMap.put("nid_co_owners", lsCoOwner);
				 //Added for SWIMP:313 -End
                retMap.put("product_division",
                        (strProductDivision == null || strProductDivision.equals("")) ? " " : strProductDivision);
                retMap.put("access_control_protection",
                        (strAccessControlProtection == null || strAccessControlProtection.equals("")) ? oNullObject
                                : strAccessControlProtection);
                
                retMap.put("co_owners", getListObjects(strSoCCOOwner, "~"));
                retMap.put("bu_access",getListObjects(strBUAccess, "~"));

                String strAccessUser = getRelatedUserAccess(context, objectId);
                retMap.put("user_access", getListObjects(strAccessUser, ","));
                
                IMP_SecurityCheck_mxJPO securityObj = new IMP_SecurityCheck_mxJPO();
                StringList slRepLocation = securityObj.getExistingLocations(context, objectId);
                
                retMap.put("replication_location", slRepLocation);
                
                // Get technology stack for the SOC
                Map<String, Object> mpTechValue = new LinkedHashMap<>();                    

                mpTechValue.put("foundary", (strFoundary == null || strFoundary.equals("")) ? oNullObject : strFoundary);
                mpTechValue.put("process_node",
                        (strProcessNode == null || strProcessNode.equals("")) ? " " : strProcessNode);
                mpTechValue.put("sub_process", (strSubProcess == null || strSubProcess.equals("")) ? oNullObject : strSubProcess);
                mpTechValue.put("metal_stack", (strMetalStack == null || strMetalStack.equals("")) ? oNullObject : strMetalStack);
                mpTechValue.put("io_type", (sIOType == null || sIOType.equals("")) ? oNullObject : sIOType);
                mpTechValue.put("poly_orientation",
                        (strPolyOrientation == null || strPolyOrientation.equals("")) ? oNullObject : strPolyOrientation);
                mapValuesForTechStack.put("technology_stack", mpTechValue);

                retMap.putAll(mapValuesForTechStack);


                // Get user access request for the SOC
                String whereClause = "attribute[" + sAttBUReq + "]=='FALSE'";
                MapList resultList = listAccessRequests(context, objectId, whereClause);
                List<Map> lsUserAccess = new ArrayList<>();
                for (int i = 0; i < resultList.size(); i++) {
                    mapUserAccessReq = (Hashtable) resultList.get(i);
                    strAccessName = (String) mapUserAccessReq.get(DomainConstants.SELECT_NAME);
                    strReasonForRequest = (String) mapUserAccessReq.get(
                            "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_ReasonforRequest") + "]");
                    strRequestedSoC = (String) mapUserAccessReq
                            .get("from[" + PropertyUtil.getSchemaProperty(context, "relationship_IMP_RequestedObject")
                                    + "].to.name");
                    strApprovedRejectedBY = (String) mapUserAccessReq.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestApprovedRejectedBy")
                            + "]");
                    strRequestedBy = (String) mapUserAccessReq
                            .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
                    strAccessStatus = (String) mapUserAccessReq.get(DomainConstants.SELECT_CURRENT);
                    strReasonForReject = (String) mapUserAccessReq.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestRejectionReason")
                            + "]");

                     Map<String, Object> mapUserAccessReqValue = new LinkedHashMap<>();

                     mapUserAccessReqValue.put("name",
                            (strAccessName == null || strAccessName.equals("")) ? oNullObject : strAccessName);
                     mapUserAccessReqValue.put("reason_for_request",
                            (strReasonForRequest == null || strReasonForRequest.equals("")) ? oNullObject
                                    : strReasonForRequest);
                     mapUserAccessReqValue.put("requested_soc",
                            (strRequestedSoC == null || strRequestedSoC.equals("")) ? oNullObject : strRequestedSoC);
                     mapUserAccessReqValue.put("approved_rejectedby",
                            (strApprovedRejectedBY == null || strApprovedRejectedBY.equals("")
                                    || "null".equals(strApprovedRejectedBY)) ? oNullObject : strApprovedRejectedBY);
                     mapUserAccessReqValue.put("requested_by",
                            (strRequestedBy == null || strRequestedBy.equals("")) ? oNullObject : strRequestedBy);
                     mapUserAccessReqValue.put("status",
                            (strAccessStatus == null || strAccessStatus.equals("")) ? oNullObject : strAccessStatus);
                     mapUserAccessReqValue.put("reason_for_reject",
                            (strReasonForReject == null || strReasonForReject.equals("")) ? oNullObject : strReasonForReject);
                     lsUserAccess.add(mapUserAccessReqValue);
                }

                retMap.put("user_access_requests",lsUserAccess);

                // Get bu user access request
                String swhereClause = "attribute[" + sAttBUReq + "]=='TRUE'";
                MapList sresultList = listAccessRequests(context, objectId, swhereClause);
                List<Map> lsBuAccessRequest = new ArrayList<>();
                for (int i = 0; i < sresultList.size(); i++) {
                    mapBUUserAccessReq = (Hashtable) sresultList.get(i);

                    strAccessName = (String) mapBUUserAccessReq.get(DomainConstants.SELECT_NAME);
                    strReasonForRequest = (String) mapBUUserAccessReq.get(
                            "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_ReasonforRequest") + "]");
                    strRequestedSoC = (String) mapBUUserAccessReq
                            .get("from[" + PropertyUtil.getSchemaProperty(context, "relationship_IMP_RequestedObject")
                                    + "].to.name");
                    strApprovedRejectedBY = (String) mapBUUserAccessReq.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestApprovedRejectedBy")
                            + "]");
                    strRequestedBy = (String) mapBUUserAccessReq
                            .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
                    strAccessStatus = (String) mapBUUserAccessReq.get(DomainConstants.SELECT_CURRENT);
                    strReasonForReject = (String) mapBUUserAccessReq.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestRejectionReason")
                            + "]");

                    Map<String, Object> mapBUUserAccessReqValue = new LinkedHashMap<>();

                    mapBUUserAccessReqValue.put("name",
                            (strAccessName == null || strAccessName.equals("")) ? oNullObject : strAccessName);
                    mapBUUserAccessReqValue.put("reason_for_request",
                            (strReasonForRequest == null || strReasonForRequest.equals("")) ? oNullObject
                                    : strReasonForRequest);
                    mapBUUserAccessReqValue.put("requested_soc",
                            (strRequestedSoC == null || strRequestedSoC.equals("")) ? oNullObject : strRequestedSoC);
                    mapBUUserAccessReqValue.put("approved_rejectedby",
                            (strApprovedRejectedBY == null || strApprovedRejectedBY.equals("")) ? oNullObject
                                    : strApprovedRejectedBY);
                    mapBUUserAccessReqValue.put("requested_by",
                            (strRequestedBy == null || strRequestedBy.equals("")) ? oNullObject : strRequestedBy);
                    mapBUUserAccessReqValue.put("status",
                            (strAccessStatus == null || strAccessStatus.equals("")) ? oNullObject : strAccessStatus);
                    mapBUUserAccessReqValue.put("reason_for_reject",
                            (strReasonForReject == null || strReasonForReject.equals("")) ? oNullObject : strReasonForReject);
                    lsBuAccessRequest.add(mapBUUserAccessReqValue);
                }
                retMap.put("bu_access_requests",lsBuAccessRequest);

                // Get Quality_Class for the SOC
                MapList mlMLObjects = IMP_SoC_mxJPO.getMLObjects(context, objectId);
                List<Map> lsQualityClass = new ArrayList<>();
                for (int i = 0; i < mlMLObjects.size(); i++) {
                    mapMLObj = (Hashtable) mlMLObjects.get(i);
                    Map<String, Object> mpMLValue = new LinkedHashMap<>();

                    strMaturityLevel = (String) mapMLObj.get("attribute[IMP_MaturityLevel]");
                    strSoftIPNeedBy = (String) mapMLObj.get("attribute[IMP_SoftIPNeedBy]");
                    strHardIPNeedBy = (String) mapMLObj.get("attribute[IMP_HardIPNeedBy]");

                    mpMLValue.put("quality_class",
                            (strMaturityLevel == null || strMaturityLevel.equals("")) ? oNullObject : strMaturityLevel);
                    mpMLValue.put("soft_ip_needby",
                            (strSoftIPNeedBy == null || strSoftIPNeedBy.equals("")) ? oNullObject : strSoftIPNeedBy);
                    mpMLValue.put("hard_ip_needby",
                            (strHardIPNeedBy == null || strHardIPNeedBy.equals("")) ? oNullObject : strHardIPNeedBy);
                    lsQualityClass.add(mpMLValue);
                }
                retMap.put("quality_classes", lsQualityClass);

                // Get Verification objects for the SOC.
                HashMap programMapIPverify = new HashMap();
                programMapIPverify.put("parentOID", objectId);
                MapList mlIPVerifications = IMP_IPVerification_mxJPO.getIPVerifications(context,
                        JPO.packArgs(programMapIPverify));
				// Modified for user story 224
                Map<String, Object> mpIPVerification;
                List<Map> lsFinalSOC = new ArrayList<>();
                for (int i = 0; i < mlIPVerifications.size(); i++) {
                    mapIPVerifyObj = (Hashtable) mlIPVerifications.get(i);
                    strRequestID = (String) mapIPVerifyObj.get(DomainConstants.SELECT_NAME);
                    strStatus = (String) mapIPVerifyObj.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_STATUS_VALUE);
                    strSubmittedOn = (String) mapIPVerifyObj.get(DomainConstants.SELECT_ORIGINATED);
                    strSubmittedBy = (String) mapIPVerifyObj.get(DomainConstants.SELECT_OWNER);
                    strDryRun = (String) mapIPVerifyObj.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DRYRUN_VALUE);
                    
                    Object revsionID = mapIPVerifyObj.get(IMP_Constants_mxJPO.SELECT_IMP_VERIFY_RUN_FROM_SOC+IMP_Constants_mxJPO.DOT+DomainConstants.SELECT_ID);
                    mpIPVerification = new LinkedHashMap<>();

                    mpIPVerification.put("request_id",
                            (strRequestID == null || strRequestID.equals("")) ? oNullObject : strRequestID);
                    mpIPVerification.put("status", (strStatus == null || strStatus.equals("")) ? oNullObject : strStatus);
                    mpIPVerification.put("submitted_on",
                            (strSubmittedOn == null || strSubmittedOn.equals("")) ? oNullObject : strSubmittedOn);
                    mpIPVerification.put("submitted_by",
                        (strSubmittedBy == null || strSubmittedBy.equals("")) ? oNullObject : strSubmittedBy);
                    mpIPVerification.put("dry_run",
                        (strDryRun == null || strDryRun.equals("")) ? oNullObject : strDryRun);
                    StringList slRevisionIPName;
                    
                    
                    if(revsionID instanceof StringList){
                      slRevisionIPName = (StringList) revsionID;
                      List<Map> lsMapData = new ArrayList<>();
                      StringList objectRevSelects = new StringList();
                      objectRevSelects.add(IMP_Constants_mxJPO.SELECT_BRANCH_NAME_FROM_VERIFYRUN);
                      objectRevSelects.add(IMP_Constants_mxJPO.SELECT_IP_SOURCE_FROM_VERIFYRUN);
                      objectRevSelects.add(IMP_Constants_mxJPO.SELECT_IP_TYPE_FROM_VERIFYRUN);
                      objectRevSelects.add(IMP_Constants_mxJPO.SELECT_BRANCH_LIFECYCLE_FROM_VERIFYRUN);
                      objectRevSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
                     for (int j = 0; j < slRevisionIPName.size(); j++) {
                        Map mpRevData = new LinkedHashMap<>();
                        String objID = (String) slRevisionIPName.get(j);
                        DomainObject domRevObj = new DomainObject(objID);
                        String strTypes = domRevObj.getType(context);
                          if(!"IMP_SoC".equals(strTypes)){
                            String relID = IMP_IPVerification_mxJPO.getRelID(context, objectId, objID);
                            if(!relID.isEmpty()) {
                              DomainRelationship domRelObject = new DomainRelationship(relID);
                              Map relAttributemap = domRelObject.getAttributeMap(context);
                              Hashtable mpRevAttDetails = (Hashtable) domRevObj.getInfo(context, objectRevSelects);
                              String strBranchName = (String) mpRevAttDetails.get(IMP_Constants_mxJPO.SELECT_BRANCH_NAME_FROM_VERIFYRUN);
                              String strIPSource = (String) mpRevAttDetails.get(IMP_Constants_mxJPO.SELECT_IP_SOURCE_FROM_VERIFYRUN);
                              String sIPType = (String) mpRevAttDetails.get(IMP_Constants_mxJPO.SELECT_IP_TYPE_FROM_VERIFYRUN);
                              String sRevisions = (String) mpRevAttDetails.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
                              //Modified for SWIMP-322: Starts
                              String sApproveStatus = (String) relAttributemap.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
                              String sNoInstance = (String) relAttributemap.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_NOOFINSTANCES);
                              String sDesignStatus = (String) mpRevAttDetails.get(IMP_Constants_mxJPO.SELECT_BRANCH_LIFECYCLE_FROM_VERIFYRUN);
                              String sComments = (String) relAttributemap.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS);
                              String sApprover = (String) relAttributemap.get(IMP_Constants_mxJPO.ATTRIBUTE_APPROVER);
                              //Modified for SWIMP-322: Ends
                              
                              mpRevData.put("ipid", (strBranchName == null || strBranchName.equals("")) ? oNullObject : strBranchName);
                              mpRevData.put("ip_source", (strIPSource == null || strIPSource.equals("")) ? oNullObject : strIPSource);
                              mpRevData.put("ip_type", (sIPType == null || sIPType.equals("")) ? oNullObject : sIPType);
                              mpRevData.put("revision", (sRevisions == null || sRevisions.equals("")) ? oNullObject : sRevisions);
                              mpRevData.put("approval_status", (sApproveStatus == null || sApproveStatus.equals("")) ? oNullObject : sApproveStatus);
                              mpRevData.put("no_of_instances", (sNoInstance == null || sNoInstance.equals("")) ? oNullObject : sNoInstance);
                              mpRevData.put("design_status", (sDesignStatus == null || sDesignStatus.equals("")) ? oNullObject : sDesignStatus);
                              mpRevData.put("approver", (sApprover == null || sApprover.equals("")) ? oNullObject : sApprover);
                              mpRevData.put("approval_rejection_comments", (sComments == null || sComments.equals("")) ? oNullObject : sComments);
                              lsMapData.add(mpRevData);
                            }
                          }
                    }
                      mpIPVerification.put("ip_revisions",
                          (lsMapData == null || lsMapData.isEmpty() ) ? " " : lsMapData);
                    }
                    lsFinalSOC.add(mpIPVerification);
                }
                retMap.put("soc_ip_verifications", lsFinalSOC);


                // Get subscription for the SOC.
                HashMap programMapSubscribedSoC = new HashMap();
                programMapSubscribedSoC.put("objectId", objectId);
                MapList mlSubscribedBranchAndRel = getIPHierarchyForSoCorBlockIP(context,
                        JPO.packArgs(programMapSubscribedSoC));
                List<Map> lsIPSubscriptions = new ArrayList<>();
                for (int i = 0; i < mlSubscribedBranchAndRel.size(); i++) {
                    mapBranchAndRelObj = (Hashtable) mlSubscribedBranchAndRel.get(i);
                    strType = (String) mapBranchAndRelObj.get(DomainConstants.SELECT_TYPE);
                    dmObj = DomainObject.newInstance(context,
                            (String) mapBranchAndRelObj.get(DomainConstants.SELECT_ID));
                    String strBranchTag = "";
                    String strReleaseTag = "";
                    if (strType.equals(branchType)) {
                        strIPID = dmObj.getInfo(context, "to[IMP_IPBranch].from.id");
                        strBranchTag = dmObj.getInfo(context,
                                "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
                    }
                    if (strType.equals(sIPReleaseType)) {
                        strIPID = dmObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
                        strReleaseTag = dmObj.getInfo(context,
                                "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
                    }
                    dmObj.setId(strIPID);
                    returnMap = dmObj.getInfo(context, slIPObjectSelects);
                    strIPName = (String) returnMap.get(DomainConstants.SELECT_NAME);
                    strIPType = (String) returnMap
                            .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
                    strNOOfInst = (String) mapBranchAndRelObj.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_NoOfInstances") + "]");
                    strIPOwner = (String) returnMap.get(DomainConstants.SELECT_OWNER);
                    strBUIP = (String) returnMap.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");

                    Map<String, Object> mpSubscribeSOC = new LinkedHashMap<>();

                    mpSubscribeSOC.put("ipid",
                            (strIPName == null || strIPName.equals("")) ? oNullObject : strIPName);
                    mpSubscribeSOC.put("ip_type",
                            (strIPType == null || strIPType.equals("")) ? oNullObject : strIPType);
                    mpSubscribeSOC.put("branch",
                            (strBranchTag == null || strBranchTag.equals("")) ? oNullObject : strBranchTag);
                    mpSubscribeSOC.put("release",
                            (strReleaseTag == null || strReleaseTag.equals("")) ? oNullObject : strReleaseTag);
                    mpSubscribeSOC.put("no_of_instances",
                            (strNOOfInst == null || strNOOfInst.equals("")) ? oNullObject : strNOOfInst);
                    mpSubscribeSOC.put("ip_owner",
                            (strIPOwner == null || strIPOwner.equals("")) ? oNullObject : strIPOwner);
                    mpSubscribeSOC.put("bu_of_the_ip", (strBUIP == null || strBUIP.equals("")) ? oNullObject : strBUIP);
                    lsIPSubscriptions.add(mpSubscribeSOC);
                }
                retMap.put("ip_subscriptions",lsIPSubscriptions);

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return retMap;
    }

	/**
	 * This method returns Person objects connected with IMP_AccessControlUser
	 * Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public static String getRelatedUserAccess(Context context, String sObjectId) throws Exception {
		MapList resultList = new MapList();
		Hashtable mapPersonObj;
		StringBuffer sbUserAccess = new StringBuffer();
		try {
			DomainObject domObj = DomainObject.newInstance(context, sObjectId);

			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);

			resultList = (MapList) domObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_AccessControlUser"), // relationship
																									// pattern
					PropertyUtil.getSchemaProperty(context, "type_Person"), // type
																			// pattern
					busSelects, // Object selects
					null, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			for (int i = 0; i < resultList.size(); i++) {
				mapPersonObj = (Hashtable) resultList.get(i);
				if (sbUserAccess.length() > 0) {
					sbUserAccess.append(",");
				}
				sbUserAccess.append((String) mapPersonObj.get(DomainConstants.SELECT_NAME));
			}

		} catch (Exception exception) {
			throw new Exception("JPO::IMP_IPReleaseUtil::getRelatedUserAccess()->" + exception);
		}
		return sbUserAccess.toString();
	}

	/**
	 * This method returns Person objects connected with IMP_AccessControlUser
	 * Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public static String getSoftwareIPOwner(Context context, String sObjectId) throws Exception {
		MapList resultList = new MapList();
		Hashtable mapPersonObj;
		StringBuffer sbSoftwareIPOwners = new StringBuffer();
		try {
			DomainObject domObj = DomainObject.newInstance(context, sObjectId);

			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(DomainConstants.SELECT_NAME);

			resultList = (MapList) domObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_SoftwareIPOwner"), // relationship
																									// pattern
					PropertyUtil.getSchemaProperty(context, "type_Person"), // type
																			// pattern
					busSelects, // Object selects
					null, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			for (int i = 0; i < resultList.size(); i++) {
				mapPersonObj = (Hashtable) resultList.get(i);
				if (sbSoftwareIPOwners.length() > 0) {
					sbSoftwareIPOwners.append(",");
				}
				sbSoftwareIPOwners.append((String) mapPersonObj.get(DomainConstants.SELECT_NAME));
			}

		} catch (Exception exception) {
			throw new Exception("JPO::IMP_IPReleaseUtil::getSoftwareIPOwner()->" + exception);
		}
		return sbSoftwareIPOwners.toString();
	}

	/**
	 * Method for list all the Access Requests for an IP Object
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param objectId
	 *            of the IP Object
	 * @throws Exception
	 *             if the operations fails
	 */

	public MapList listAccessRequests(Context context, String strObjId, String sWhereClause) throws MatrixException {
		MapList resultList = new MapList();
		String RELATIONSHIP_REQUESTED_OBJECT = PropertyUtil.getSchemaProperty(context,
				"relationship_IMP_RequestedObject");

		try {

			DomainObject domObj = DomainObject.newInstance(context, strObjId);

			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID);
			busSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestedFor") + "]");
			busSelects.add(DomainConstants.SELECT_NAME);
			busSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_ReasonforRequest") + "]");
			busSelects.add("from[" + PropertyUtil.getSchemaProperty(context, "relationship_IMP_RequestedObject")
					+ "].to.name");
			busSelects.add("attribute["
					+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestApprovedRejectedBy") + "]");
			busSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_Originator") + "]");
			busSelects.add(DomainConstants.SELECT_CURRENT);
			busSelects.add("attribute["
					+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_AccessRequestRejectionReason") + "]");

			StringList relSelects = new StringList();
			relSelects.add(DomainRelationship.SELECT_ID);

			resultList = domObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, RELATIONSHIP_REQUESTED_OBJECT), // relationship
																							// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_AccessRequest"), // type
																						// pattern
					busSelects, // Object selects
					relSelects, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					sWhereClause, // object where
					null, // relationship where
					0); // limit

		} catch (MatrixException exception) {
			throw new MatrixException("Error in getting Access Requests for the Object" + exception);
		}

		return resultList;
	}

	/**
	 * This method returns vector for new window pop up only for Release
	 * objects.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector hasAccessForNodes(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		Vector returnVector = new Vector();
		MapList objectList = (MapList) programMap.get("objectList");
		String strObj = "";
		Map objectMap = null;
		DomainObject domObj = null;
		String strActualType = "";
		String strPopUp = EnoviaResourceBundle.getProperty(context, RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR, context.getLocale(), "imp.emxSemiTeamCollab.Label.BranchAttributes");

		String strBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String sIPRelease = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		
		StringBuilder strTableColBuff = new StringBuilder();
		try {
			Iterator objectListItr = objectList.iterator();
			while (objectListItr.hasNext()) {
				objectMap = (Map) objectListItr.next();
				strObj = (String) objectMap.get(DomainObject.SELECT_ID);
				domObj = DomainObject.newInstance(context, strObj);
				strActualType = domObj.getInfo(context, DomainObject.SELECT_TYPE);

				if (strActualType.equalsIgnoreCase(strBranchType) || strActualType.equalsIgnoreCase(sIPRelease)) {

					strTableColBuff.append("<a href=\"");
					strTableColBuff.append("JavaScript:emxTableColumnLinkClick('emxTree.jsp?"
							+ "mode=insert&amp;objectId=" + XSSUtil.encodeForHTMLAttribute(context, strObj)
							+ "', 'null', 'null', 'false', 'popup')" + "\">");
					strTableColBuff.append("<img src=\"images/iconNewWindow.gif\" border=\"0\" alt='" + strPopUp
							+ "' title='" + strPopUp + "' height=\"16\"></img>");
					strTableColBuff.append("</a>");
					returnVector.add(strTableColBuff.toString());
				} else {
					returnVector.add("");
				}
				strTableColBuff.setLength(0);
			}

		} catch (Exception e) {
			throw e;
		}
		return returnVector;
	}

	/**
	 * This method returns connected SoC objects with Logical Products
	 * Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectId.
	 * @returns StringList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StringList getSoCsForBranchAndRev(Context context, String[] args) throws Exception {
		StringList returnList = new StringList();
		StringList finalReturnList = new StringList();
		StringList returnSoCListFromRel = new StringList();
		StringList returnSoCListFromBranch = new StringList();
		Hashtable mapRel = new Hashtable<>();
		Set hs = new HashSet();
		HashMap programMap = JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) programMap.get("requestMap");
		String strBranchid = (String) requestMap.get("objectId");
		String strRelId = "";
		try {
			returnSoCListFromBranch = getConnectedSocFromBranch(context, strBranchid,false);
			if (returnSoCListFromBranch.size() > 0) {
				returnList.addAll(returnSoCListFromBranch);
			}
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(DomainConstants.SELECT_ID);
			DomainObject domBranch = DomainObject.newInstance(context, strBranchid);
			MapList mlRelatedRelObjList = domBranch.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type
																					// pattern
					objectSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			for (int i = 0; i < mlRelatedRelObjList.size(); i++) {
				mapRel = (Hashtable) mlRelatedRelObjList.get(i);
				strRelId = (String) mapRel.get(DomainConstants.SELECT_ID);
				returnSoCListFromRel = getConnectedSocFromRel(context, strRelId);
				if (returnSoCListFromRel.size() > 0) {
					returnList.addAll(returnSoCListFromRel);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		hs.addAll(returnList.toList());
		finalReturnList.addAll(hs);
		return finalReturnList;
	}

	/**
	 * This method returns Release connected SoC objects with Logical Products
	 * Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Release objectId.
	 * @returns StringList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public StringList getConnectedSocFromRel(Context context, String strRelId) throws Exception {
		DomainObject domObj = DomainObject.newInstance(context, strRelId);
		StringList returnList = new StringList();
		Hashtable mapSoc = null;
		String strSoCName = "";
		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_NAME);
			MapList mlRelatedSoCObjList = (MapList) domObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_LogicalProducts"), // relationship
					PropertyUtil.getSchemaProperty(context, "type_IMP_SoC"), // type
																				// pattern
					objectSelects, // Object selects
					null, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			for (int i = 0; i < mlRelatedSoCObjList.size(); i++) {
				mapSoc = (Hashtable) mlRelatedSoCObjList.get(i);
				strSoCName = (String) mapSoc.get(DomainConstants.SELECT_NAME);
				returnList.add(strSoCName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnList;
	}

	/**
	 * This method returns Branch connected SoC objects with Logical Products
	 * Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Branch objectId.
	 * @returns StringList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public StringList getConnectedSocFromBranch(Context context, String strBranchId, boolean bflag) throws Exception {

		DomainObject domObj = DomainObject.newInstance(context, strBranchId);
		StringList returnList = new StringList();
		StringList slRepLoc = new StringList();
		Hashtable mapSoc = null;
		String strSoCName = "";
		Object strRepLoc = null;

		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ReplicationLocation") + "]");

			MapList mlRelatedSoCObjList = (MapList) domObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_LogicalProducts"), // relationship
					PropertyUtil.getSchemaProperty(context, "type_IMP_SoC"), // type
																				// pattern
					objectSelects, // Object selects
					null, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					null, // object where
					null, // relationship where
					0); // limit
			for (int i = 0; i < mlRelatedSoCObjList.size(); i++) {

				mapSoc = (Hashtable) mlRelatedSoCObjList.get(i);
				strSoCName = (String) mapSoc.get(DomainConstants.SELECT_NAME);
				strRepLoc = mapSoc.get("attribute["
						+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_ReplicationLocation") + "]");

				if (bflag) {

					if (strRepLoc != null && !"".equals(strRepLoc) && strRepLoc instanceof String) {
						slRepLoc.add(strRepLoc.toString());
					}

					if (strRepLoc != null && !"".equals(strRepLoc) && strRepLoc instanceof StringList) {
						slRepLoc.addAll((StringList) strRepLoc);
					}

					if (slRepLoc != null && slRepLoc.size() > 0) {
						for (int j = 0; j < slRepLoc.size(); j++) {
							returnList.add((String) slRepLoc.get(j));
						}
					}

				}
				if (!bflag) {
					returnList.add(strSoCName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnList;
	}

	/**
	 * This method returns true if the context user has check in access for the
	 * business object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Branch objectId.
	 * @returns boolean.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public boolean hasRelatedAccessForEditBranchCommand(Context context, String args[]) throws Exception {
		boolean hasCheckinAccess = false;
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		try {
			String objectId = (String) programMap.get("objectId");
			DomainObject domBranchObj = DomainObject.newInstance(context);
			domBranchObj.setId(objectId);
			String strIPID = domBranchObj.getInfo(context, "to[IMP_IPBranch].from.id");
			domBranchObj.setId(strIPID);
			Access access = domBranchObj.getAccessMask(context);
			if (access.hasCheckinAccess()) {
				hasCheckinAccess = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return hasCheckinAccess;
	}

	/**
	 * This method returns connected Branch and Release objects with Logical
	 * Products Relationship.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP/Branch/Release objectId.
	 * @returns MapList.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings("rawtypes")
    public Map getConnectedBranchAndRevisions(Context context, StringList strObjectIds) throws Exception {
		DomainObject domObj = null;
		MapList mlRelatedObjList = new MapList();
		Hashtable mapBranchAndRelObj = new Hashtable();
		Map returnMap = null;

		String strType = "";
		String strIPID = "";
		String strComponentName = "";
		String strComponentType = "";
		String strIPOwner = "";
		String strIPBU = "";
		String strIPName = "";
		String strBranchType = PropertyUtil.getSchemaProperty(context, "type_IMP_Branch");
		String strIPReleaseType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		// Added for user story 224
		Object oNullObject = null;

        Map<String, Object> mpReturn = new LinkedHashMap<>();

		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_TYPE);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			slRelSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_NoOfInstances") + "]");

			StringList slIPObjectSelects = new StringList();
			slIPObjectSelects.add(DomainConstants.SELECT_NAME);
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]");
			slIPObjectSelects
					.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
			slIPObjectSelects.add(DomainConstants.SELECT_OWNER);
			slIPObjectSelects.add(
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");

			Pattern typePattern = new Pattern(strBranchType);
			typePattern.addPattern(strIPReleaseType);
			
			StringList slObjectSelect = new StringList(2);
			slObjectSelect.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			slObjectSelect.add(DomainConstants.SELECT_TYPE);
			slObjectSelect.add(IMP_Constants_mxJPO.SELECT_BRANCH_TAG_FROM_RELEASE);
			// Modified for user story 224
			List<Object> lsBranchAndRelease = new ArrayList<>();
			List<Object> lsObjectSubscriptionDetails ;
			Map<String,Object> objectSubscriptionDetails ;
			for (int i = 0; i < strObjectIds.size(); i++) {
				lsObjectSubscriptionDetails = new ArrayList<>();
				domObj = DomainObject.newInstance(context, (String) strObjectIds.get(i));
				mlRelatedObjList = domObj.getRelatedObjects(context,
						PropertyUtil.getSchemaProperty(context, "relationship_IMP_LogicalProducts"), // relationship
						typePattern.getPattern(), // type pattern
						objectSelects, // Object selects
						slRelSelects, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit
				
				Map objectDetailsap  = domObj.getInfo(context, slObjectSelect);
				String strObjType = (String)objectDetailsap.get(DomainConstants.SELECT_TYPE);
				String strIpTag = (String)objectDetailsap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
				objectSubscriptionDetails = new HashMap<>();
				if(IMP_Constants_mxJPO.TYPE_IMP_BRANCH.equals(strObjType)) {
					objectSubscriptionDetails.put("branch", strIpTag);
					objectSubscriptionDetails.put("revision", oNullObject);
				} else if (IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(strObjType)) {
					objectSubscriptionDetails.put("branch", objectDetailsap.get(IMP_Constants_mxJPO.SELECT_BRANCH_TAG_FROM_RELEASE));
					objectSubscriptionDetails.put("revision",strIpTag );
				} else {
					objectSubscriptionDetails.put("branch", oNullObject);
					objectSubscriptionDetails.put("revision",oNullObject );
				}
				
				for (int j = 0; j < mlRelatedObjList.size(); j++) {
					mapBranchAndRelObj = (Hashtable) mlRelatedObjList.get(j);
					strType = (String) mapBranchAndRelObj.get(DomainConstants.SELECT_TYPE);
					domObj.setId((String) mapBranchAndRelObj.get(DomainConstants.SELECT_ID));

					String strBranchTag = " ";
					String strReleaseTag = " ";

					if (strType.equals(strBranchType)) {
						strIPID = domObj.getInfo(context, "to[IMP_IPBranch].from.id");
						strBranchTag = domObj.getInfo(context,
								"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
					} else if (strType.equals(strIPReleaseType)) {
						strIPID = domObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
						strReleaseTag = domObj.getInfo(context,
								"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
					}

					domObj.setId(strIPID);
					returnMap = domObj.getInfo(context, slIPObjectSelects);
					strComponentName = (String) returnMap.get(DomainConstants.SELECT_NAME);
					strComponentType = (String) returnMap
							.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
					strIPOwner = (String) returnMap.get(DomainConstants.SELECT_OWNER);
					strIPBU = (String) returnMap.get("attribute["
							+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision") + "]");
					strIPName = (String) returnMap
							.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]");

                    Map<String, Object> mpSubscribedBlockIPValue = new LinkedHashMap<>();
					// Modified for user story 224
                    mpSubscribedBlockIPValue.put("component_unique_id",
                            (strComponentName == null || strComponentName.equals("")) ? oNullObject : strComponentName);
                    mpSubscribedBlockIPValue.put("component_ip_name",
                            (strIPName == null || strIPName.equals("")) ? oNullObject : strIPName);
                    mpSubscribedBlockIPValue.put("component_ip_type",
                            (strComponentType == null || strComponentType.equals("")) ? oNullObject : strComponentType);
                    mpSubscribedBlockIPValue.put("component_ip_branch", (strBranchTag == null || strBranchTag.equals("")) ? oNullObject : strBranchTag);
                    mpSubscribedBlockIPValue.put("component_ip_revision", (strReleaseTag == null || strReleaseTag.equals("")) ? oNullObject : strReleaseTag);
                    mpSubscribedBlockIPValue.put("no_of_instances", mapBranchAndRelObj.get("attribute["
                            + PropertyUtil.getSchemaProperty(context, "attribute_IMP_NoOfInstances") + "]"));
                    mpSubscribedBlockIPValue.put("ip_owner",
                            (strIPOwner == null || strIPOwner.equals("")) ? oNullObject : strIPOwner);
                    mpSubscribedBlockIPValue.put("bu_of_the_ip",
                            (strIPBU == null || strIPBU.equals("")) ? oNullObject : strIPBU);
                    lsObjectSubscriptionDetails.add(mpSubscribedBlockIPValue);

                }
				 objectSubscriptionDetails.put("hierarchy", lsObjectSubscriptionDetails);
				 lsBranchAndRelease.add(objectSubscriptionDetails);
            }

			mpReturn.put("product_hierarchy",lsBranchAndRelease);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
        return mpReturn;
	}

	/**
	 * This method returns JSON String for IP Product object.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP objectId.
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getJSONStringForIPProductBranchAndReleaseInfo(Context context, String args[]) throws Exception {

		JSONObject retJson = new JSONObject();
		Field map = retJson.getClass().getDeclaredField("_map");
		map.setAccessible(true);// because the field is private final...
		map.set(retJson, new LinkedHashMap());
		map.setAccessible(false);// return flag

		StringList mlGetRelIDInfo = new StringList();
		Hashtable mapBranchInfo = new Hashtable();
		String strBranchTag = "";
		JSONArray jsonValuesForBranchAndRel = new JSONArray();
		JSONArray jsonValuesForRel = new JSONArray();

		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) programMap.get("objectId");

			HashMap pMap = new HashMap();
			pMap.put("objectId", objectId);

			MapList mlBranchAndReleaseObjects = getBranchAndRelObjects(context, JPO.packArgs(pMap));

			for (int i = 0; i < mlBranchAndReleaseObjects.size(); i++) {

				mapBranchInfo = (Hashtable) mlBranchAndReleaseObjects.get(i);
				strBranchTag = (String) mapBranchInfo.get("attribute[IMP_IPTag]");

				JSONObject jsonValue = new JSONObject();
				Field mapBranchAndRev = jsonValue.getClass().getDeclaredField("_map");
				mapBranchAndRev.setAccessible(true);// because the field is
													// private final...
				mapBranchAndRev.set(jsonValue, new LinkedHashMap());
				mapBranchAndRev.setAccessible(false);// return flag
				jsonValue.put("IP Branch Tag", strBranchTag);

				mlGetRelIDInfo = getBranchConnectedReleases(context,
						(String) mapBranchInfo.get(DomainConstants.SELECT_ID), true);

				if (mlGetRelIDInfo != null && mlGetRelIDInfo.size() > 0) {
					jsonValuesForRel = getReleaseObjectInfo(context, mlGetRelIDInfo);
				}
				jsonValue.put("Releases under Branch Tag " + strBranchTag, jsonValuesForRel);

				jsonValuesForBranchAndRel.put(jsonValue);

			}
			if (jsonValuesForBranchAndRel != null) {
				retJson.put("Branch And Revisions", jsonValuesForBranchAndRel);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return retJson.toString(JSON_INDENT_FACTOR);

	}

	/**
	 * This method returns JSON Array for Release Object Info.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP/Branch/Release objectId.
	 * 
	 * @returns JSONArray.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public JSONArray getReleaseObjectInfo(Context context, StringList slRelIds) throws Exception {
		JSONArray returnJSONArray = new JSONArray();
		StringList slRelObjectSelects = new StringList();
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublisher") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsPrefixed") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_GDSVersion") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_QualityClass") + "]");
		slRelObjectSelects.add(DomainConstants.SELECT_ORIGINATED);
		slRelObjectSelects.add(
				"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublishComments") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Preapprove") + "]");
		slRelObjectSelects
				.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPQAStatus") + "]");

		DomainObject dmObj = null;
		Map returnMap = null;
		String strRelTag = "";
		String strIPPublisher = "";
		String strIsPrefixed = "";
		String strGDSVersion = "";
		String strQualityClass = "";
		String strOriginated = "";
		String strComments = "";
		String strPreapprove = "";
		String strQAStatus = "";

		try {
			for (int i = 0; i < slRelIds.size(); i++) {
				dmObj = DomainObject.newInstance(context, (String) slRelIds.get(i));
				returnMap = dmObj.getInfo(context, slRelObjectSelects);
				strRelTag = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
				strIPPublisher = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublisher") + "]");
				strIsPrefixed = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsPrefixed") + "]");
				strGDSVersion = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_GDSVersion") + "]");
				strQualityClass = (String) returnMap.get(
						"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_QualityClass") + "]");
				strOriginated = (String) returnMap.get(DomainConstants.SELECT_ORIGINATED);
				strComments = (String) returnMap.get("attribute["
						+ PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublishComments") + "]");
				strPreapprove = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Preapprove") + "]");
				strQAStatus = (String) returnMap
						.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPQAStatus") + "]");

				JSONObject jsonValue = new JSONObject();
				Field mapBranchAndRev = jsonValue.getClass().getDeclaredField("_map");
				mapBranchAndRev.setAccessible(true);// because the field is
													// private final...
				mapBranchAndRev.set(jsonValue, new LinkedHashMap());
				mapBranchAndRev.setAccessible(false);// return flag

				jsonValue.put("Tag", (strRelTag == null || strRelTag.equals("")) ? " " : strRelTag);
				jsonValue.put("IP Publisher",
						(strIPPublisher == null || strIPPublisher.equals("")) ? " " : strIPPublisher);
				jsonValue.put("Is Prefixed", (strIsPrefixed == null || strIsPrefixed.equals("")) ? " " : strIsPrefixed);
				jsonValue.put("GDS Version", (strGDSVersion == null || strGDSVersion.equals("")) ? " " : strGDSVersion);
				jsonValue.put("Quality Class",
						(strQualityClass == null || strQualityClass.equals("")) ? " " : strQualityClass);
				jsonValue.put("Originated", (strOriginated == null || strOriginated.equals("")) ? " " : strOriginated);
				jsonValue.put("Comments", (strComments == null || strComments.equals("")) ? " " : strComments);
				jsonValue.put("Pre-approved List",
						(strPreapprove == null || strPreapprove.equals("")) ? " " : strPreapprove);
				jsonValue.put("QAStatus", (strQAStatus == null || strQAStatus.equals("")) ? " " : strQAStatus);
				returnJSONArray.put(jsonValue);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnJSONArray;
	}
	
	/**
	 * Excludes replication disabled in from the SoC Replication locations.
	 *
	 * @param context the context
	 * @param sSoCReplicationLoc the SoC replication locations
	 * @param sIPObjId the IP object id
	 * @return the string
	 * @throws Exception if the operation fails
	 */
	public StringList excludeReplicationDisIn(Context context, StringList slSoCReplicationLoc, String sIPObjId) throws Exception {
		StringList slFinalRepLoc = new StringList();
		try {
			StringList slReplicationDisabledIn = IMP_DesignsyncModule_mxJPO.getReplicationDisabledLoc(context, sIPObjId);
			if (slReplicationDisabledIn != null && !slReplicationDisabledIn.isEmpty()) {
				StringItr strItrLocList = new StringItr(slSoCReplicationLoc);
				String sReplicationLoc;
				while (strItrLocList.next()) {
					sReplicationLoc = strItrLocList.obj();
					if (UIUtil.isNotNullAndNotEmpty(sReplicationLoc) && !slReplicationDisabledIn.contains(sReplicationLoc)) {
						slFinalRepLoc.add(sReplicationLoc);
					}
				}
			} else {
				return slSoCReplicationLoc;
			}
			
		} catch (Exception e) {
			throw new Exception("Exception in excluding replication location " + e);
		}
		return slFinalRepLoc;
	}

	/**
	 * This method returns Comma Separated String for Replicated Location Module
	 * URL.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Branch objectId.
	 * 
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */

	@SuppressWarnings({ "rawtypes" })
	public String getReplicationLocations(Context context, String strBranchId , String strIPName , DomainObject domIPReleaseId , String sIMP_ENV, String sIPObjId) throws Exception {
		StringList returnSoCListFromBranch = new StringList();
		StringBuffer sb = new StringBuffer();
		StringBuffer sbRepLocs = new StringBuffer();
		Set<String> hs = new HashSet<String>();
		String strDistLoc = "";
		
		try {
			returnSoCListFromBranch = getConnectedSocFromBranch(context, strBranchId, true);
			if(!returnSoCListFromBranch.isEmpty()){
				returnSoCListFromBranch = excludeReplicationDisIn(context, returnSoCListFromBranch, sIPObjId);
			}
			hs.addAll(returnSoCListFromBranch.toList());
			
			//Remove Actual IP Location from Replicated Locations as there is no need to replicate to the same server.
			Map<String,String> mapPubSite = new HashMap<String,String>();
			mapPubSite.put("IPName", strIPName);
			mapPubSite.put("IMP_ENV", sIMP_ENV);
			String sIPActLoc = getIPPublishSite(context,JPO.packArgs(mapPubSite));
			hs.remove(sIPActLoc);
			
			for (String s : hs) {
				if (sbRepLocs != null && sbRepLocs.length() > 0) {
					sbRepLocs.append(",");
				}
				sbRepLocs.append(s);
			}
			domIPReleaseId.setAttributeValue(context, PropertyUtil.getSchemaProperty(context,"attribute_IMP_IPReplicatedLocations"), sbRepLocs.toString());
			
			Map<String,String> mPublicDisURLs = getXMLToMap(context, "IMP_PublicDistribURLS",sIMP_ENV);

			Iterator itr = hs.iterator();
			while (itr.hasNext()) {
				
				String strNext =  (String) itr.next();
			
				if (null != mPublicDisURLs && mPublicDisURLs.containsKey(strNext)) {
					strDistLoc = mPublicDisURLs.get(strNext);
				}

				if (sb != null && sb.length() > 0) {
					sb.append(",");
				}

				if (null != strDistLoc) {
					sb.append(strDistLoc.trim());
				}
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return sb.toString();
	}

	/**
	 * This method returns Comma Separated String for Replicated Location.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP Name and IP Revision .
	 * 
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */

	@SuppressWarnings({ "rawtypes" })
	public String getReplicationLocations(Context context, String args[]) throws Exception {
		String sRepLocs = DomainConstants.EMPTY_STRING;
		MapList mlRelObjList = new MapList();
		try {

			HashMap hashMap = JPO.unpackArgs(args);
			String strIPName = (String) hashMap.get("strIPName");
			String strTag = (String) hashMap.get("strIPTag");

			if (strTag.startsWith("\"")) {
				strTag = strTag.substring(1, strTag.length());
			}
			if (strTag.endsWith("\"")) {
				strTag = strTag.substring(0, strTag.length() - 1);
			}

			String branchName = "Trunk";
			if (strTag.contains("/")) {
				String[] str_array = strTag.split("/");
				branchName = str_array[0];
			}
			String strIPid = getIPIdFromIPName(context, strIPName);
			DomainObject domIPObj = new DomainObject(strIPid);

			StringBuffer sbWhere = new StringBuffer();
			sbWhere.append("(attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "] ~~ '");
			sbWhere.append(branchName.trim());
			sbWhere.append("')");

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);

			MapList mlRelatedObjList = domIPObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch"), // relationship
																							// pattern
					PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), // type
																				// pattern
					slObjSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sbWhere.toString(), // object where
					null, // relationship where
					0); // limit

			StringBuffer sWhere = new StringBuffer();
			sWhere.append("(attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "] ~~ '");
			sWhere.append(strTag.trim());
			sWhere.append("')");

			slObjSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPReplicatedLocations") + "]");

			if (!mlRelatedObjList.isEmpty()) {
				Map mBranchInfo = (Map) mlRelatedObjList.get(0);
				String strBranchId = (String) mBranchInfo.get(DomainConstants.SELECT_ID);
				DomainObject domRelObj = DomainObject.newInstance(context, strBranchId);
				mlRelObjList = domRelObj.getRelatedObjects(context,
						PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship
																								// pattern
						PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type
																					// pattern
						slObjSelects, // Object selects
						null, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						sWhere.toString(), // object where
						null, // relationship where
						0); // limit

			}

			if (mlRelObjList != null && !mlRelObjList.isEmpty()) {
				Map mRelInfo = (Map) mlRelObjList.get(0);
				sRepLocs = (String) mRelInfo.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPReplicatedLocations") + "]");
				if (UIUtil.isNotNullAndNotEmpty(sRepLocs)) {
					StringList slRepLocs = FrameworkUtil.split(sRepLocs, ",");
					StringList slFinalRepLocation = excludeReplicationDisIn(context, slRepLocs, strIPid);
					if (!slFinalRepLocation.isEmpty()) {
						sRepLocs = FrameworkUtil.join(slFinalRepLocation, ",");
					} else {
						sRepLocs = "";
					}
				}
				sRepLocs = (null == sRepLocs || "null".equals(sRepLocs)) ? DomainConstants.EMPTY_STRING : sRepLocs;
			}

		} catch (Exception e) {
			throw new Exception("IMP_IPReleaseUtil : getReplicationLocations Error in getting IP Revision replicated location " + e);
		}
		return sRepLocs;
	}

	/**
	 * This method returns Publish Site based on Unix Domain.
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Unix Domain .
	 * 
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */

	@SuppressWarnings("rawtypes")
	public String getSiteForUniXDomain(Context context, String args[]) throws Exception {
		String returnString = "";
		HashMap hashMap = JPO.unpackArgs(args);
		String strUnixDomain = (String) hashMap.get("strUnixDomain");
		String sIMP_ENV = (String) hashMap.get("IMP_ENV");

		try {
			Map<String,String> mUnixDomains = getXMLToMap(context, "IMP_UnixDomainLocationMapping", sIMP_ENV);
			if (null != mUnixDomains && mUnixDomains.containsKey(strUnixDomain)) {
				returnString = mUnixDomains.get(strUnixDomain);
				returnString = (null == returnString) ? DomainConstants.EMPTY_STRING : returnString;
			}
			
		}  catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return returnString;
	}

	/**
	 * This method Creates Hierarchical Reference based on Replicated Locations
	 * .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds IP Object id , Tag , IP Name , Replicated Locations .
	 * 
	 * @returns nothing.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public void createHierarchicalReference(Context context, String sIPId, String strTag, String strIPName,
			String strRepLocs,String sIMP_ENV) throws Exception {
		ProcessBuilder pb;
		Process p;
		String output;
		String error;
		int pValue;
		try {

			Page pgAdminObjSpawn = new Page("IMP_HierarchicalReference");
			pgAdminObjSpawn.open(context);
			String strPgContentSpawn = pgAdminObjSpawn.getContents(context);

			char c1 = '\\';
			char c2 = '/';
			String strWorkSpacePath = context.createWorkspace();
			strWorkSpacePath = strWorkSpacePath.replace(c1, c2);
			strWorkSpacePath = strWorkSpacePath.substring(0, strWorkSpacePath.indexOf((context.getWorkspacePath()).replace(c1, c2)));
			

			String strSpawnTCLPath = strWorkSpacePath + "/hierarchicalReference.stcl";

			// get modURL from 'DesignSync URL' attribute on IP Product.
			DomainObject domObj = DomainObject.newInstance(context, sIPId);
			String strModURL = domObj.getInfo(context,
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]");
			strModURL = strModURL.substring(0, strModURL.indexOf(";"));

			File file = new File(strSpawnTCLPath);
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
				file.setReadable(true, false);
				file.setExecutable(true, false);
				file.setWritable(true, false);
				FileWriter fw = new FileWriter(file.getAbsoluteFile());
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(strPgContentSpawn.trim());
				bw.close();
			}

			// get Username and password from page object
			Map map = getUserAndPasswordFromPage(context,sIMP_ENV);
			String strUserName = (String) map.get("Username");
			String strPassword = (String) map.get("Password");
			
			String[] sEachRepURL = strRepLocs.split(",");
			
			for (int i = 0; i < sEachRepURL.length; i++) {
				pb = new ProcessBuilder("stclc", strSpawnTCLPath, strTag, strIPName, sEachRepURL[i], strModURL,
						strUserName, strPassword, "createHref");
				p = pb.start();
				output = IMP_DesignsyncModule_mxJPO.output(p.getInputStream());
				error = IMP_DesignsyncModule_mxJPO.output(p.getErrorStream());
				pValue = p.waitFor();
				if (pValue != 0) {
					throw new Exception("Exception in creating Hierarchical Reference for Replicated Locations :" + output);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * This method returns Username and Password from page object .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * 
	 * @returns Map.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map getUserAndPasswordFromPage(Context context,String sContextEnv) throws Exception {
		Map returnMap = new HashMap();
		String strContent = null;
		String sEnoviaUserName = "";
		String sEnoviaPassword = "";
		try {
			Page pgObjForReadingUserInfo = new Page("IMP_DesignSyncModuleCreationServiceAccount");
			pgObjForReadingUserInfo.open(context);
			strContent = pgObjForReadingUserInfo.getContents(context);
			strContent = strContent.trim();
			pgObjForReadingUserInfo.close(context);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new ByteArrayInputStream(strContent.getBytes("utf-8")));
			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("Environment");
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					String sEnvironment = eElement.getAttribute("name");
					if (sEnvironment != null && sEnvironment.length() > 0 && sEnvironment.equalsIgnoreCase(sContextEnv)) {
						NodeList nUserNameList = eElement.getElementsByTagName("Username");
						Node nUserNameNode = nUserNameList.item(0);
						sEnoviaUserName = nUserNameNode.getTextContent();

						NodeList nListPass = eElement.getElementsByTagName("Password");
						Node nPass = nListPass.item(0);
						sEnoviaPassword = nPass.getTextContent();
					}
				}
			}

			returnMap.put("Username", sEnoviaUserName);
			returnMap.put("Password", IMP_IPProductUtil_mxJPO.decodePassword(sEnoviaPassword));
		} catch (Exception ex) {
			ex.printStackTrace();

		}

		return returnMap;
	}

	/**
	 * This method returns Publish Site based on Design Sync Url from page
	 * object .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * 
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public String getIPPublishSite(Context context, String args[]) throws Exception {
		String retString = "";
		try {
			HashMap hashMap = JPO.unpackArgs(args);
			String strIPName = (String) hashMap.get("IPName");
			String sIMP_ENV = (String) hashMap.get("IMP_ENV");

			String sIPId = getIPIdFromIPName(context, strIPName);

			DomainObject dobj = DomainObject.newInstance(context, sIPId);
			String strDesignSyncURL = dobj.getInfo(context,
					"attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]");
			strDesignSyncURL = strDesignSyncURL.substring(0, strDesignSyncURL.indexOf("/Modules"));

			Map<String,String> map = getXMLToMap(context,"IMP_URLMappingToPublishSite", sIMP_ENV);
			
			if (null != map && map.containsKey(strDesignSyncURL)) {
				retString = map.get(strDesignSyncURL);
				retString = (null == retString) ? DomainConstants.EMPTY_STRING : retString;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return retString;
	}

	/**
	 * This method returns Local Cache Path based on Publish Site from page
	 * object .
	 *
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * 
	 * @returns String.
	 * @throws Exception
	 *             if the operation fails
	 * 
	 */
	@SuppressWarnings("rawtypes")
	public String getLocalCacheFromPublishSite(Context context, String args[]) throws Exception {
		String retString = "";
		try {
			HashMap hashMap = JPO.unpackArgs(args);
			String strPublishSite = (String) hashMap.get("strPublishSite");
			String sIMP_ENV = (String) hashMap.get("IMP_ENV");
			
			Map<String,String> mapCahePaths = getXMLToMap(context,"IMP_LocalCachePath",sIMP_ENV);

			if (null != strPublishSite && mapCahePaths.containsKey(strPublishSite)) {
				retString = mapCahePaths.get(strPublishSite);
				retString = (null == retString ) ? DomainConstants.EMPTY_STRING : retString;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return retString;
	}

	public Map<String,String> getXMLToMap(Context context,String sPageObject,String sContextEnv) throws Exception
	{
		Map<String,String> retMap = new HashMap<>();
		Node nNode = null;
		Element eElement = null;
		String sEnvironment = null;
		NodeList nNodeList = null;
		Node nNodeChild = null;
		Element eElementChild =null;
		String sKey = null;
		String sVal = null;
		try {
			Page pgAdminObj = new Page(PropertyUtil.getSchemaProperty(context,"pageobject_"+sPageObject));
			pgAdminObj.open(context);
			String strPgContent = pgAdminObj.getContents(context);
			strPgContent = strPgContent.trim();
			pgAdminObj.close(context);

			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

			Document doc = dBuilder.parse(new ByteArrayInputStream(strPgContent.getBytes("utf-8")));

			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("Server");
			for (int i = 0; i < nList.getLength(); i++) {
				nNode = nList.item(i);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					eElement = (Element) nNode;
					sEnvironment = eElement.getAttribute("name");
					if (sEnvironment.equalsIgnoreCase(sContextEnv)) {
						nNodeList = eElement.getChildNodes();
						for (int j = 0; j < nNodeList.getLength(); j++) {
							nNodeChild = nNodeList.item(j);
							if (nNodeChild.getNodeType() == Node.ELEMENT_NODE) {
								eElementChild = (Element) nNodeChild;
								sKey = eElementChild.getAttribute("name");
								sVal = eElementChild.getTextContent();
								retMap.put(sKey, sVal);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return retMap;
	}
	
	// Added for user story 224
  private List<String> getListObjects(String sValue, String sOperand) {

    List<String> lsReturn = new ArrayList<>();
    StringTokenizer stCoOwner = new StringTokenizer(sValue, sOperand);
    while (stCoOwner.hasMoreTokens()) {
      String token = stCoOwner.nextToken();
      lsReturn.add(token);
    }
    return lsReturn;
  }
  
  /**
   * Gets the branch connected releases data.
   *
   * @param context the context
   * @param strBranchId the str branch id
   * @return the branch connected releases data
   * @throws Exception the exception
   */
  // Added for user story 224
  public List<Map> getBranchConnectedReleasesData(Context context, String strBranchId) throws Exception {
    
    MapList mlRelatedIPReleaseList = new MapList();
    StringList slIPRelSelects = new StringList();
    slIPRelSelects.add(DomainConstants.SELECT_ID);
    slIPRelSelects.add(DomainConstants.SELECT_NAME);
    slIPRelSelects.add(DomainConstants.SELECT_CURRENT);
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_PublishDate") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_QualityClass") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsPrefixed") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_GDSVersion") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublishComments") + "]");
    slIPRelSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublisher") + "]");
    //Added for SWIMP-1 for changing attribute name IMP_IPRevisionWatermark

    //Removed Watermark attributes from Release Object and added directly from IPWatermark Object for SWIMP-235 : Starts
    slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK_FROM_IPRELEASE);
    slIPRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK_FROM_IPRELEASE);
    //Removed Watermark attributes from Release Object and added directly from IPWatermark Object for SWIMP-235 : Starts

    String strRelName = "";
    String strCurrent = "";
    String strPubDate = "";
    String strQualityClass = "";
    String strIsPrefixed = "";
    String strGDSVersion = "";
    String strUniqueWaterMarkID = "";
    String strIPXWaterMarkID = "";
    Object strComments = null;
    String strPublisher = "";

    Object oNullObj = null;
    
    List<Map> lsReturn = new ArrayList<>();  

    try {
        DomainObject domBranchObj = DomainObject.newInstance(context, strBranchId);
        mlRelatedIPReleaseList = domBranchObj.getRelatedObjects(context,
                PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship pattern
                PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type pattern
                slIPRelSelects, // Object selects
                null, // relationship selects
                false, // from
                true, // to
                (short) 1, // expand level
                null, // object where
                null, // relationship where
                0); // limit

        if (!mlRelatedIPReleaseList.isEmpty()) {
            for (int j = 0; j < mlRelatedIPReleaseList.size(); j++) {
              Map<String, Object> mpData = new LinkedHashMap<>();
              Map mpRelObj = (Map) mlRelatedIPReleaseList.get(j);
              strCurrent = (String) mpRelObj
            		  .get(DomainConstants.SELECT_CURRENT);
              strRelName = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag") + "]");
              strPubDate = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_PublishDate") + "]");
              strQualityClass = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_QualityClass") + "]");
              strIsPrefixed = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IsPrefixed") + "]");
              strGDSVersion = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_GDSVersion") + "]");               
              strComments = mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublishComments") + "]");              
              strPublisher = (String) mpRelObj
            		  .get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPublisher") + "]");
              //Added for SWIMP-1 for changing attribute name to IMP_IPRevisionWatermark

              //Added for SWIMP-235 : Starts
              Object oIPRevisionWatermark = mpRelObj.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK_FROM_IPRELEASE);
              if (oIPRevisionWatermark instanceof StringList) {
            	  StringList slIPRevisionWatermarkAttribute = (StringList) oIPRevisionWatermark;
            	  strUniqueWaterMarkID = FrameworkUtil.join(slIPRevisionWatermarkAttribute, ",");
              } else {
            	  strUniqueWaterMarkID = (String) oIPRevisionWatermark;
              }

              Object oIPXWatermark = mpRelObj.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK_FROM_IPRELEASE);
              if (oIPXWatermark instanceof StringList) {
            	  StringList slIPXWatermark = (StringList) oIPXWatermark;
            	  strIPXWaterMarkID = FrameworkUtil.join(slIPXWatermark, ",");
              } else {
            	  strIPXWaterMarkID = (String) oIPXWatermark;
              }
              //Added for SWIMP-235 : Ends

              mpData.put("tag",
            		  (strRelName == null || strRelName.isEmpty()) ? oNullObj : strRelName);  
              mpData.put("lifecycle",
            		  (strCurrent == null || strCurrent.isEmpty()) ? oNullObj : strCurrent);
              mpData.put("publish_date",
            		  (strPubDate == null || strPubDate.isEmpty()) ? oNullObj : strPubDate);
              mpData.put("quality_class",
            		  (strQualityClass == null || strQualityClass.isEmpty()) ? oNullObj : strQualityClass);
              mpData.put("is_prefixed",
            		  (strIsPrefixed == null || strIsPrefixed.isEmpty()) ? oNullObj : strIsPrefixed);
              mpData.put("gds_version",
            		  (strGDSVersion == null || strGDSVersion.isEmpty()) ? oNullObj : strGDSVersion);
              mpData.put("publish_comments",
            		  (strComments == null || strComments.toString().isEmpty()) ? oNullObj : strComments);
              mpData.put("publisher",
            		  (strPublisher == null || strPublisher.isEmpty()) ? oNullObj : strPublisher);
              //Modified for SWIMP-235 : Starts
              mpData.put("watermarkid",
            		  (UIUtil.isNullOrEmpty(strUniqueWaterMarkID) ? oNullObj : strUniqueWaterMarkID));
              mpData.put("ipx_watermarkid",
            		  (UIUtil.isNullOrEmpty(strIPXWaterMarkID) ? oNullObj : strIPXWaterMarkID));
              //Modified for SWIMP-235 : Ends
              lsReturn.add(mpData);
            }
        }
    } catch (Exception e) {
        throw e;
    }
    return lsReturn;
}
  
  /**
   * Generate water mark hash code.
   *
   * @param context the context
   * @param args the args
   * @return the string
   * @throws Exception the exception
   */
  public String generateWaterMarkHashCode(Context context, String[] args) throws Exception{
    HashMap programMap = (HashMap) JPO.unpackArgs(args);
    String sIMPObjectName = programMap.get("IPID").toString();
    String strFinalWaterMarkId = null;
    String RELATIONSHIP_IMP_TechStack = PropertyUtil.getSchemaProperty(context, "relationship_IMP_TechStack");
    String ATTRIBUTE_IMP_Vendor = PropertyUtil.getSchemaProperty(context, "attribute_IMP_Vendor");
    String ATTRIBUTE_IMP_IPName = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName");
    String ATTRIBUTE_IMP_Foundry = PropertyUtil.getSchemaProperty(context, "attribute_IMP_Foundry");
    String ATTRIBUTE_IMP_SubProcess = PropertyUtil.getSchemaProperty(context, "attribute_IMP_SubProcess");
    String ATTRIBUTE_IMP_ProductDivision = PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductDivision");
    DomainObject domObj;
    DomainObject techObj;
    String sTSKey = "";
    String sFoundary = "";
    String sSubProcess = "";
    String sProcessNode = "";
    StringBuilder sWaterMarkedID = new StringBuilder();
    StringList slObjectSel = new StringList(DomainConstants.SELECT_ID);
    try {
      MapList mpList = DomainObject.findObjects(context,
          PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct"), sIMPObjectName, DomainConstants.QUERY_WILDCARD,
          DomainConstants.QUERY_WILDCARD, PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
          null, false, slObjectSel);
      if(!mpList.isEmpty()){
        Map mpData = (Map) mpList.get(0);
        String sObjId = mpData.get(DomainConstants.SELECT_ID).toString();
        domObj = DomainObject.newInstance(context, sObjId);
        //Added for SWIMP-1 for changing attribute name IMP_IPWatermarkSeed
        String strWaterMark = domObj.getAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPWatermarkSeed"));
        if(UIUtil.isNullOrEmpty(strWaterMark)){
          String techObjID = domObj.getInfo(context, "from[" + RELATIONSHIP_IMP_TechStack + "].to.id");
          if (techObjID != null) {
            techObj = DomainObject.newInstance(context, techObjID);
            sTSKey = techObj.getAttributeValue(context,
                PropertyUtil.getSchemaProperty(context, "attribute_IMP_TSKey"));
            sProcessNode = techObj.getAttributeValue(context,
                PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProcessNode"));
            sFoundary = techObj.getAttributeValue(context, ATTRIBUTE_IMP_Foundry);
            sSubProcess = techObj.getAttributeValue(context, ATTRIBUTE_IMP_SubProcess);
          }
          String sIPID = domObj.getInfo(context, DomainConstants.SELECT_NAME);
          String sOwner = domObj.getInfo(context, DomainConstants.SELECT_OWNER);
          String sIPRevision = domObj.getInfo(context, DomainObject.SELECT_REVISION);
          String sVendor = domObj.getAttributeValue(context, ATTRIBUTE_IMP_Vendor);
          String sIPName = domObj.getAttributeValue(context, ATTRIBUTE_IMP_IPName);
          String sProductDivision = domObj.getAttributeValue(context, ATTRIBUTE_IMP_ProductDivision);
          sWaterMarkedID.append(sIPName);
          if (sTSKey != null && sTSKey.equals("FirstStack")) {
            sWaterMarkedID.append(sFoundary);
            sWaterMarkedID.append(sProcessNode);
            sWaterMarkedID.append(sSubProcess);
          }
          if (sProductDivision != null) {
            sWaterMarkedID.append(sProductDivision);
          } else {
            sWaterMarkedID.append(sVendor);
          }
          sWaterMarkedID.append(sOwner);
          sWaterMarkedID.append(sIPRevision);
          sWaterMarkedID.append(sIPID);

          strFinalWaterMarkId = sWaterMarkedID.toString();
          strFinalWaterMarkId = strFinalWaterMarkId.replaceAll("[^a-zA-Z0-9]", "");
          //Added for SWIMP-1 for changing attribute name to IMP_IPWatermarkSeed
          domObj.setAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPWatermarkSeed"), strFinalWaterMarkId);
        }        
      }      
    } catch (Exception e) {
      e.printStackTrace();
    }
    return strFinalWaterMarkId;
  }
  
  /**
   * Update water mark for IP.
   *
   * @param context the context
   * @param sIPID the s IPID
   * @throws Exception
   */
  public void updateWaterMarkForIP(Context context, String[] args) throws Exception {
    HashMap hmArgs = new HashMap<>();
    hmArgs.put("IPID", args[0]);
    try {
      JPO.invoke(context, "IMP_IPReleaseUtil", null, "generateWaterMarkHashCode",
          JPO.packArgs(hmArgs), String.class);
    } catch (Exception e) {
      e.printStackTrace();
      throw new Exception(e);
    }
  }

	/**
	 * This method returns connected active revisions of a Branch to set recommended revisions.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectId.
	 * @returns StringList.
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings({ "rawtypes" })
	public StringList getRevForBranch(Context context, String[] args) throws Exception {
		StringList returnList = new StringList();
		returnList.add("");
		HashMap programMap = JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) programMap.get("requestMap");
		String strBranchid = (String) requestMap.get("objectId");
		TreeMap<Date, Object> mpLatestTagData = new TreeMap<>();
		Date date = null;
		SimpleDateFormat formatter = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);
		String attrIPTag = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag");
		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainConstants.SELECT_ORIGINATED);
			objectSelects.add("attribute[" + attrIPTag + "]");

			String sWhere = "current==Active";

			DomainObject domBranchObj = DomainObject.newInstance(context, strBranchid);
			MapList mlRelatedRelObjList = domBranchObj.getRelatedObjects(context,
					PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // relationship
					PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"), // type pattern
					objectSelects, // Object selects
					null, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit
			if (!mlRelatedRelObjList.isEmpty()) {
				String sRevTag;
				String sRevState;
				String strOriginated;
				Map mIPReleaseObjDetails;

				for (int i = 0; i < mlRelatedRelObjList.size(); i++) {
					mIPReleaseObjDetails = (Hashtable) mlRelatedRelObjList.get(i);
					sRevTag = (String) mIPReleaseObjDetails.get("attribute[" + attrIPTag + "]");
					sRevState = (String) mIPReleaseObjDetails.get(DomainConstants.SELECT_CURRENT);
					strOriginated = (String) mIPReleaseObjDetails.get(DomainConstants.SELECT_ORIGINATED);
					date = formatter.parse(strOriginated);
					if (!sRevState.equals("Inactive") && !"Other Top Branches".equals(sRevTag)) {
						mpLatestTagData.put(date, sRevTag);
					}
				}
				
				String value;
				for (Map.Entry<Date, Object> entry : mpLatestTagData.entrySet()) {
					value = (String) entry.getValue();
					returnList.add(value);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return returnList;
	}

  /**
   * Gets the JSON string all IP releases.
   *
   * @param context the context
   * @param args the args
   * @return the JSON string all IP releases
   * @throws Exception the exception
   */
  @SuppressWarnings({"rawtypes", "unchecked"})
  public Map getJSONStringAllIPReleases(Context context, String args[]) throws Exception {
    HashMap programMap = (HashMap) JPO.unpackArgs(args);
    String objectId = (String) programMap.get("objectId");

    Map<String, Object> mpFinalData = new LinkedHashMap<>();
    TreeMap<Date, Object> mpLatestTagData;
    Date date;
    String strWhere = "attribute[IMP_IPTag]!='Other Top Branches'";
    SimpleDateFormat formatter =
        new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);
    try {
      Pattern typePattern = new Pattern(PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"));
      Pattern typeReleasePattern =
          new Pattern(PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease"));

      StringList slObjectSelects = new StringList();
      slObjectSelects.add(DomainConstants.SELECT_TYPE);
      slObjectSelects.add("attribute[IMP_IPTag]");
      slObjectSelects.add("attribute[IMP_BranchParentRevision]");
      slObjectSelects.add(DomainConstants.SELECT_NAME);
      slObjectSelects.add(DomainConstants.SELECT_ID);
      slObjectSelects.add(DomainConstants.SELECT_ORIGINATED); // Added for 1019

      StringList slReleaseObjectSelects = new StringList();
      slReleaseObjectSelects.add("attribute[IMP_IPTag]");
      slReleaseObjectSelects.add(DomainConstants.SELECT_ORIGINATED);

      DomainObject masterObject = new DomainObject(objectId);
      MapList mlBranchReleaseObjects = masterObject.getRelatedObjects(context,
          PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch"), // relationship
                                                                                // pattern
          typePattern.getPattern(), // type pattern
          slObjectSelects, // Object selects
          null, // relationship selects
          true, // from
          true, // to
          (short) 1, // expand level
          null, // object where
          null, // relationship where
          0); // limit

      if (!mlBranchReleaseObjects.isEmpty()) {
        Iterator itrBranchReleaseObjects = mlBranchReleaseObjects.iterator();
        while (itrBranchReleaseObjects.hasNext()) {
          mpLatestTagData = new TreeMap<>();
          Map mIPObjectDetails = (Map) itrBranchReleaseObjects.next();
          String strBranchID = (String) mIPObjectDetails.get(DomainConstants.SELECT_ID);
          String strBranchtag = (String) mIPObjectDetails.get("attribute[IMP_IPTag]");

          DomainObject masterObjectRelease = new DomainObject(strBranchID);
          MapList mlIPObjectsReleaseBranch = masterObjectRelease.getRelatedObjects(context,
              PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease"), // rel pattern
              typeReleasePattern.getPattern(), // type pattern
              slReleaseObjectSelects, // Object selects
              null, // relationship selects
              true, // from
              true, // to
              (short) 1, // expand level
              strWhere, // object where
              null, // relationship where
              0); // limit

          if (!mlIPObjectsReleaseBranch.isEmpty()) {
            Iterator itrReleaseObjects = mlIPObjectsReleaseBranch.iterator();
            String strReleasetag;
            String strOriginated;
            String strLatestTag;
            while (itrReleaseObjects.hasNext()) {
              Map mIPReleaseObjectDetails = (Map) itrReleaseObjects.next();
              strReleasetag = (String) mIPReleaseObjectDetails.get("attribute[IMP_IPTag]");
              String sActualTag = strReleasetag.substring(strReleasetag.lastIndexOf('/') + 1);
              strOriginated =
                  (String) mIPReleaseObjectDetails.get(DomainConstants.SELECT_ORIGINATED);
              date = formatter.parse(strOriginated);
              if (sActualTag.startsWith("ML")) {
                mpLatestTagData.put(date, sActualTag);
              }
            }
            if (!mpLatestTagData.isEmpty()) {
              strLatestTag = mpLatestTagData.get(mpLatestTagData.lastKey()).toString();
              mpFinalData.put(strBranchtag, strLatestTag);
            } else {
              mpFinalData.put(strBranchtag, "");
            }
          } else {
            mpFinalData.put(strBranchtag, "");
          }
        }
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return mpFinalData;
  }
       
    /**
     * Gets the preapproved projects values.
     *
     * @param context the context
     * @param args the args
     * @return the preapproved projects values
     * @throws Exception the exception
     */
	@SuppressWarnings("unchecked")
	public String getPreapprovedProjectsValues(Context context, String[] args) throws Exception
    {
      //Modified for SWIMP-31: Starts
      Map<String, Object> mProgramMap = JPO.unpackArgs(args);
      Map<String, Object> mParamMap= (Map<String, Object>) mProgramMap.get("paramMap");
      Map<String, Object> requestMap = (Map<String, Object>) mProgramMap.get("requestMap");
      String sObjectId = (String) mParamMap.get("objectId");
      String strMode = (String) requestMap.get("mode");
      DomainObject domIPRelease = DomainObject.newInstance(context,sObjectId);

      //Added for SWIMP-31: Starts
      String sPreApproved = "";
      String sIPID = "";
      StringList slAttributeList = new StringList();
      slAttributeList.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PREAPPROVE);
      slAttributeList.add(IMP_Constants_mxJPO.SELECT_IPID_FROM_IPRELEASE);
      Map<String, String> mpObject = domIPRelease.getInfo(context, slAttributeList);
      if (!mpObject.isEmpty()) {
    	  sPreApproved = mpObject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PREAPPROVE);
    	  sIPID = mpObject.get(IMP_Constants_mxJPO.SELECT_IPID_FROM_IPRELEASE);
      }
      //Added for SWIMP-31: Ends

      if (strMode!=null && strMode.equals("edit")) {
    	//Modified for SWIMP-31, Added String sIPID to filter same object in search results
        StringBuilder output = new StringBuilder();
        output.append("<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n");
        output.append("    <tr>\n");
        output.append("        <td><input type=\"text\" id =\"Pre-ApprovedDisplay\" name=\"Pre-ApprovedDisplay\" value=\""+sPreApproved+"\" size=\"40\" readonly /></td>\n");
        output.append("        <td><input type=\"checkbox\" id=\"Pre-ApprovedAll\" name=\"All\" value=\"\" onClick=\"onClickCheckBox(this)\">All</input> </td>\n");
        output.append("        <td><input type=\"button\" id=\"Pre-ApprovedBtn\" name=\"Pre-ApprovedBtn\" "+
                "value=\"...\" onclick=\"showModalDialog("+
                "'../common/emxFullSearch.jsp?" +
                "field=TYPES=type_IMP_SoC,type_IMP_IPProduct:LatestRevision=true:IMP_PROD_TYPE!=Component IP:NAME!=" +sIPID+
                "&amp;showInitialResults=true" +
                "&amp;formInclusionList=PROJECT_NAME,IMP_PRODUCT_DVISION,COMPONENT_IP_NAME,SOC_OWNER,IMP_PROD_TYPE" +
                "&amp;table=IMP_SoCSearchResults" +
                "&amp;selection=multiple" +
                "&amp;&hideHeader=true" +
                "&amp;submitURL=../common/emxSemiAddSelectedPersons.jsp"+
                "&amp;fieldNameDisplay=Pre-ApprovedDisplay&amp;"+
                "fieldNameActual=Pre-ApprovedActual'"+
                ");\"/></td>\n");
        output.append("<td><input type=\"hidden\" name=\"Pre-ApprovedActual\" value=\"\"/></td>\n");

        output.append("        <td><a href=\"javascript:clearPreapprovedSoCs()\">Clear</a></td>\n");
        output.append("    </tr>\n");
        output.append("</table>\n");
        
        output.append("<script language=\"JavaScript\">");
        output.append("  function onClickCheckBox(chkbox) {");
        output.append(" if(chkbox.checked){ document.getElementById(\"Pre-ApprovedDisplay\").value=\"all\";} document.getElementById(\"Pre-ApprovedBtn\").disabled=chkbox.checked;");
        output.append("}  ");
        output.append("  function clearPreapprovedSoCs() {document.getElementById(\"Pre-ApprovedDisplay\").value=\"\";}");
        output.append("</script> ");
        //Modified for SWIMP-31: Ends
        return output.toString();
    } else {
        return sPreApproved;
    }
  }
    
    
    /**
     * Update IP release.
     *
     * @param context the context
     * @param args the args
     * @throws Exception the exception
     */
    @com.matrixone.apps.framework.ui.PostProcessCallable
    public void updateIPRelease(Context context, String[] args)
    throws Exception
    {
       HashMap programMap = JPO.unpackArgs(args);
       HashMap<String, Object> requestMap = (HashMap<String, Object>)programMap.get("requestMap");
       String sIPReleaseId = (String)requestMap.get("objectId");
       
       Map mAttrValues = new HashMap();
       
       String sIsUniquified = (String) requestMap.get("IsUniquified");
       String sGDSVersion = (String) requestMap.get("GDSVersion");
       String sPreApproved = (String) requestMap.get("Pre-ApprovedDisplay");
       
       if(sIsUniquified != null){
         mAttrValues.put("IMP_IsPrefixed", sIsUniquified);
       }
       
       if( sGDSVersion != null){
         mAttrValues.put("IMP_GDSVersion", sGDSVersion);
       }
       
       if(sPreApproved != null){
         mAttrValues.put("IMP_Preapprove", sPreApproved);
       }
                     
       if(UIUtil.isNotNullAndNotEmpty(sIPReleaseId) && !mAttrValues.isEmpty()){
         DomainObject domIPRelease = DomainObject.newInstance(context,sIPReleaseId);
         String attrIPapprove = domIPRelease.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_PREAPPROVE); //getting the attribute value before setting to new value
         domIPRelease.setAttributeValues(context, mAttrValues);
         if(sPreApproved != null && !attrIPapprove.equalsIgnoreCase(sPreApproved)){ // Added for SWIMP-213
        	 HashMap argsMap = new HashMap();
             argsMap.put("sIPReleaseId",sIPReleaseId);
             argsMap.put("sPreApproved",sPreApproved);
             argsMap.put("attrIPapprove", attrIPapprove);
             JPO.invoke(context, "IMP_FabricationApprovals", null, "setAppStatusofPreapprovedSocList", JPO.packArgs(argsMap),null);
         }
         
       }
   
    }
    
    //Added for CR 253 : Start
    /**
	 * This method shows alert message when clicked on image for IP Revision table
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds objectList.
	 * @returns Vector.
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getIPAlertMessage(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramList");
		String userReportFormat = (String) paramMap.get("reportFormat");
		Vector outVal = new Vector();
		String sType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
		Map objMap = null;
		DomainObject domObj = null;
		String objectType = "";
		String sObjectid = "";
		String alert = "";
		
		try {
						
						MapList objList = (MapList) programMap.get("objectList");
												
						for (int i = 0; i < objList.size(); i++) {
							objMap = (Map) objList.get(i);
							sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
							StringBuffer outPut = new StringBuffer();
						
							domObj = new DomainObject(sObjectid);
							objectType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
							alert = domObj.getInfo(context, "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Alert") + "].value");
							
							if(objectType.equalsIgnoreCase(sType) && !alert.isEmpty()){
							
							if (UIUtil.isNotNullAndNotEmpty(userReportFormat)) {
								outVal.add(alert);
							}else {
								outPut.append("<a href=\"javascript:showModalDialog('../semiteamcollab/imp_ShowAlertMessage.jsp?objectId=" + sObjectid + "',150,150,true,'Small');\">");
								outPut.append("<img src=\"../common/images/iconActionCreateIssue.png\" align=\"center\" width=\"20\" height=\"20\"></img>");
								outPut.append("</a>");
								outVal.add(outPut.toString());
								}
							} else
							{
								outVal.add("");
							}
							
				
						}
						
						

		} catch (Exception e) {
			throw e;
		}
		return outVal;
	}
	//Added for CR 253 : End
    //Added for SWIMP-1 start
    /**
     * This method shows alert message when clicked on image for IP Revision table
     * 
     * @param context
     *            the eMatrix <code>Context</code> object
     * @param args
     *            holds objectList.
     * @returns Vector.
     * @throws Exception
     *             if the operation fails
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Vector getIPAlertMessageVerify(Context context, String[] args) throws Exception {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);
        HashMap paramMap = (HashMap) programMap.get("paramList");
        String userReportFormat = (String) paramMap.get("reportFormat");
        Vector outVal = new Vector();
        String sType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPRelease");
        Map objMap = null;
        DomainObject domObj = null;
        String objectType = "";
        String sObjectid = "";
        String alert = "";
        StringBuffer outPut = new StringBuffer();
        DomainObject domWMObj;
        String strRelObjectId = "";
        try {
                        
                MapList objList = (MapList) programMap.get("objectList");
                                        
                for (int i = 0; i < objList.size(); i++) {
                    objMap = (Map) objList.get(i);
                    sObjectid = (String) objMap.get(DomainConstants.SELECT_ID);
                    outPut = new StringBuffer();
                    
                    
                    domWMObj = DomainObject.newInstance(context, sObjectid);
                    strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
                    
                    domObj = new DomainObject(strRelObjectId);
                    objectType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
                    alert = domObj.getInfo(context, "attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_Alert") + "].value");
                    
                    if(objectType.equalsIgnoreCase(sType) && !alert.isEmpty()){
                    
                        if (UIUtil.isNotNullAndNotEmpty(userReportFormat)) {
                            outVal.add(alert);
                        }else {
                            outPut.append("<a href=\"javascript:showModalDialog('../semiteamcollab/imp_ShowAlertMessage.jsp?objectId=" + sObjectid + "',150,150,true,'Small');\">");
                            outPut.append("<img src=\"../common/images/iconActionCreateIssue.png\" align=\"center\" width=\"20\" height=\"20\"></img>");
                            outPut.append("</a>");
                            outVal.add(outPut.toString());
                        }
                    } else {
                        outVal.add("");
                    }
                }
        } catch (Exception e) {
            throw e;
        }
        return outVal;
    }
    //Added for SWIMP-1 end

  /**
   * Gets the consumed records.
   *
   * @param context the context
   * @param args the args
   * @return the consumed records
   * @throws Exception the exception
   */
  public MapList getConsumedRecords(Context context, String[] args) throws Exception {
      HashMap map = (HashMap) JPO.unpackArgs(args);
      String objectId = (String) map.get("objectId");
      MapList mpList;
      DomainObject busObj = DomainObject.newInstance(context, objectId);
      Pattern typeReleasePattern =
          new Pattern(PropertyUtil.getSchemaProperty(context, "type_IMP_IPAuditRecords"));
      StringList busSelects = new StringList(1);
      busSelects.add(DomainObject.SELECT_ID);
      mpList = busObj.getRelatedObjects(context,
          PropertyUtil.getSchemaProperty(context, "relationship_IMP_ConsumedRecords"), // rel pattern
          typeReleasePattern.getPattern(), // type pattern
          busSelects, // Object selects
          null, // relationship selects
          true, // from
          true, // to
          (short) 1, // expand level
          null, // object where
          null, // relationship where
          0); // limit
      return mpList;
  }
  
  /**
   * Gets the Product Type for IP.
   *
   * @param context the context
   * @param args the args
   * @return the Product Type for IP
   * @throws Exception the exception
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public String getProductTypeForIP(Context context, String args[]) throws Exception {
    HashMap hm = JPO.unpackArgs(args);
    DomainObject domIPObj = null;
    String sProductType = ""; 

    String attrProductType = PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductType");

    try {
      String ipName = (String) hm.get("IPName");
      String sIPid = getIPIdFromIPName(context, ipName);
      domIPObj = new DomainObject(sIPid);
      sProductType = domIPObj.getInfo(context, "attribute[" + attrProductType + "].value");
	  
    } catch (Exception e) {
      throw e;
    }
    return sProductType;
  }
  
  /**
   * Gets the WMSeed for IP.
   *
   * @param context the context
   * @param args the args
   * @return the Product Type for IP
   * @throws Exception the exception
   */
  //Added for SWIMP-1 Start
  @SuppressWarnings({ "rawtypes", "unchecked" })
  public String getWatermarkSeedForIP(Context context, String args[]) throws Exception {
    HashMap hm = JPO.unpackArgs(args);
    DomainObject domIPObj = null;
    String sProductWMSeed = ""; 

    String attrProductWMSeed = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPWatermarkSeed");

    try {
      String ipName = (String) hm.get("IPName");
      String sIPid = getIPIdFromIPName(context, ipName);
      domIPObj = new DomainObject(sIPid);
      sProductWMSeed = domIPObj.getInfo(context, "attribute[" + attrProductWMSeed + "].value");
	  
    } catch (Exception e) {
      throw e;
    }
    return sProductWMSeed;
  }
//Added for SWIMP-1 End
  /**
   * Gets the Recommended Revisions of Branch
   *
   * @param context the context
   * @param args the args
   * @return the maplist containing Branch details
   * @throws Exception the exception
   */
  //Added for SWIMP-53: Starts
  @SuppressWarnings({ "rawtypes", "unchecked" })
    public MapList getRecommendedRevisionsofBranch(Context context, String args[]) throws Exception {
        HashMap hm = JPO.unpackArgs(args);
        DomainObject domIPObj = null;
        HashMap returnMap = new HashMap();
        MapList returnMapList = new MapList();
        String sRecommendedRev = "";

        String attrRecommendedRevision = PropertyUtil.getSchemaProperty(context, "attribute_IMP_Recommended_Revision"); //Added for 
        String attrIPTag = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag");

        try {
            String ipName = (String) hm.get("IPName");
            String sBranch = (String) hm.get("IPBranch");

            String sIPid = getIPIdFromIPName(context, ipName);
            domIPObj = new DomainObject(sIPid);

            StringBuilder sbWhere = new StringBuilder();
            sbWhere.append("(attribute[" + attrIPTag + "] == '");
            sbWhere.append(sBranch.trim());
            sbWhere.append("')");

            StringList slObjSelects = new StringList();
            slObjSelects.add(DomainConstants.SELECT_ID);
            slObjSelects.add("attribute["+attrRecommendedRevision+"].value");
            MapList mlRelatedObjList = domIPObj.getRelatedObjects(context,
                    PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch"), // relationship pattern
                    PropertyUtil.getSchemaProperty(context, "type_IMP_Branch"), // type pattern
                    slObjSelects, // Object selects
                    null, // relationship selects
                    false, // from
                    true, // to
                    (short) 1, // expand level
                    sbWhere.toString(), // object where
                    null, // relationship where
                    0); // limit
            if (!mlRelatedObjList.isEmpty()) {
                Map mBranchInfo = (Map) mlRelatedObjList.get(0);
                sRecommendedRev = (String) mBranchInfo.get("attribute["+attrRecommendedRevision+"].value");
            }
            returnMap.put("Recommendedrevision", sRecommendedRev);
            if (!returnMap.isEmpty())
                returnMapList.add(returnMap);
            }catch(Exception e) {
                e.printStackTrace();
                throw e;
            }
            return returnMapList;
    } //Added for SWIMP-53: Ends
  
  //Added for SWIMP-119
  public Map getIPCoreData(Context context, String[] args) throws Exception {
		
	  HashMap hm = JPO.unpackArgs(args);
		DomainObject domIPObj = null;
		Map returnMap = new HashMap();
		String sIMP_ENV = (String) hm.get("IMP_ENV");
		String sIPBranch = (String) hm.get("ipBranch");
		String ipObjID = (String) hm.get("ipObjID");
		List<String> lsReturn = new ArrayList<>();
		
		StringList slIPObjectSelects = new StringList();
		slIPObjectSelects.add("name");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductType") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IP_Default_Revision") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPrefix") + "]");
		slIPObjectSelects.add("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyCompany") + "]");
		
		Map<String,String> mapPubSite = new HashMap<>();
		
		try {
			
			domIPObj = new DomainObject(ipObjID);	
			String ipName = domIPObj.getInfo(context, DomainObject.SELECT_NAME);
			//get IP Attributes Data		
			Map ipDataMap = domIPObj.getInfo(context, slIPObjectSelects);
			returnMap.put("ID", ipObjID);		//Added for SWIMP-284
			returnMap.put("ProductType", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_ProductType") + "]"));
			returnMap.put("IPName", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPName") + "]"));
			returnMap.put("IPSource", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource") + "]"));
			returnMap.put("IPType", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPType") + "]"));
			returnMap.put("DesignSyncURL", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_DesignSyncURL") + "]"));
			returnMap.put("DefaultRevision", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IP_Default_Revision") + "]"));
			returnMap.put("IPPrefix", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPPrefix") + "]"));
			returnMap.put("LegacyCompany", (String) ipDataMap.get("attribute[" + PropertyUtil.getSchemaProperty(context, "attribute_IMP_LegacyCompany") + "]"));
			
			//get Publish Site of the IP
			mapPubSite.put("IPName", ipName);
			mapPubSite.put("IMP_ENV", sIMP_ENV);
			String sIPActLoc = getIPPublishSite(context,JPO.packArgs(mapPubSite));
			returnMap.put("IPPublishSite", sIPActLoc);
			
			//IP Deprecated List
			lsReturn = IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, ipObjID);
			returnMap.put("DeprecatedIPList", lsReturn);
			
			//get Recommended Revision of the Branch of the IP
			HashMap<String,String> hmPackData = new HashMap<>();
	        hmPackData.put("IPName", ipName);
	        hmPackData.put("IPBranch", sIPBranch);
	        MapList retunMapList = getRecommendedRevisionsofBranch(context,JPO.packArgs(hmPackData));
	        if (!retunMapList.isEmpty()) {
              Map mpInfo = (Map) retunMapList.get(0);
              String sRecommendedRev = (String) mpInfo.get("Recommendedrevision");
              returnMap.put("RecommendedRev", sRecommendedRev);
            }
	        
            StringList slObjSelects = new StringList();
			slObjSelects.add(DomainObject.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_NAME);
			slObjSelects.add("attribute[IMP_Foundry]");
			slObjSelects.add("attribute[IMP_ProcessNode]");
	        slObjSelects.add("attribute[IMP_SubProcess]");
			slObjSelects.add("attribute[IMP_MetalStack]");
			
			//Get the TechStackData of IP
            MapList mlTechStack = domIPObj.getRelatedObjects(context,
                    PropertyUtil.getSchemaProperty(context, "IMP_TechStack"), "IMP_TechStack", slObjSelects, null, false, true, (short) 1, "", null, 0);
            MapList mlTechStackModified = new MapList();
            Map<String, String> ipTechStackMp = null;
            Map mTSObjectDetails = null; 
            		
            if (!mlTechStack.isEmpty()) {
            	 Iterator iterateTechStack = mlTechStack.iterator();
                 while (iterateTechStack.hasNext()) {
                	 ipTechStackMp = new LinkedHashMap<>();
                     mTSObjectDetails = (Map) iterateTechStack.next();
                     ipTechStackMp.put("Foundry", mTSObjectDetails.get("attribute[IMP_Foundry]").toString());
                     ipTechStackMp.put("ProcessNode", mTSObjectDetails.get("attribute[IMP_ProcessNode]").toString());
                     ipTechStackMp.put("SubProcess", mTSObjectDetails.get("attribute[IMP_SubProcess]").toString());
                     ipTechStackMp.put("MetalStack", mTSObjectDetails.get("attribute[IMP_MetalStack]").toString());
                     mlTechStackModified.add(ipTechStackMp);                     
                 }
				returnMap.put("TechnologyStacks", mlTechStackModified);
            }
			
		} catch (Exception e) {
			e.printStackTrace();
		    throw new Exception(e);
		}
		
		return returnMap;
	}
  
  //Added for SWIMP-119
  public Map getSoCCoreData(Context context, String[] args) throws Exception {
		
	  HashMap hm = JPO.unpackArgs(args);
		DomainObject domSoCObj = null;
		Map returnMap = new HashMap();
		String socObjID = (String) hm.get("socObjID");
		StringList slObjSelects = new StringList();
		slObjSelects.add(DomainConstants.SELECT_NAME);
		slObjSelects.add("attribute[IMP_Foundry]");
		slObjSelects.add("attribute[IMP_ProcessNode]");
        slObjSelects.add("attribute[IMP_SubProcess]");
		slObjSelects.add("attribute[IMP_MetalStack]");
		Map<String, String> ipTechStackMp = new LinkedHashMap<>();
		MapList mlTechStackModified = new MapList();
		 
		try {
			
			domSoCObj = new DomainObject(socObjID);	
			//get SoC TechStack Attributes Data		
			Map socDataMap = domSoCObj.getInfo(context, slObjSelects);
			ipTechStackMp.put("Foundry", (String) socDataMap.get("attribute[IMP_Foundry]").toString());
			ipTechStackMp.put("ProcessNode", (String) socDataMap.get("attribute[IMP_ProcessNode]").toString());
			ipTechStackMp.put("SubProcess", (String) socDataMap.get("attribute[IMP_SubProcess]").toString());
			ipTechStackMp.put("MetalStack", (String) socDataMap.get("attribute[IMP_MetalStack]").toString());
			mlTechStackModified.add(ipTechStackMp); 
			returnMap.put("ID", socObjID);			//Added for SWIMP-284
			returnMap.put("TechnologyStacks", mlTechStackModified);
		    returnMap.put("SoCName", (String) socDataMap.get(DomainConstants.SELECT_NAME).toString());
        
		} catch (Exception e) {
			e.printStackTrace();
		    throw new Exception(e);
		}
		
		return returnMap;
	}

  //Added for SWIMP-154:Starts
  public Map getIPRevisionForWatermark(Context context, String[] args) throws Exception {
	Map returnMap = new HashMap();
	try {
		HashMap hm = JPO.unpackArgs(args);
		String sWatermark = (String) hm.get("Watermark");
		StringList slObjSelects = new StringList();
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);

		StringBuilder sbWhere = new StringBuilder();
		if(sWatermark.contains(" ")){
			String[] stringArray = sWatermark.split("\\s+");
			if (stringArray != null && stringArray.length >= 3) {
				String strIPName = stringArray[0];
				String strTech = stringArray[1];
				String strRelease = stringArray[2];
				sWatermark = strIPName + "___" + strTech + "___" + strRelease;
				sbWhere.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK+IMP_Constants_mxJPO.EQUALS_APOSTROPHE);
			}else{
				return returnMap;
			}
			//Modified for SWIMP-203
		}else if(sWatermark.contains("___")){
			sbWhere.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK+IMP_Constants_mxJPO.EQUALS_APOSTROPHE);
		}else{
			sbWhere.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK+IMP_Constants_mxJPO.EQUALS_APOSTROPHE);
		}
		sbWhere.append(sWatermark);
		sbWhere.append("'");
		MapList mpList = IMP_Utility_mxJPO.impFindObjects(context, IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, sbWhere.toString(), slObjSelects, 0); //Modified for SWIMP-824
		if(!mpList.isEmpty()){
			Map mpData = (Map) mpList.get(0);
			String sIPReleaseObjId = (String) mpData.get(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
			String sIPID = (String) mpData.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID);
			if(!UIUtil.isNullOrEmpty(sIPReleaseObjId)){
				DomainObject domIPReleaseObj = DomainObject.newInstance(context, sIPReleaseObjId);
				slObjSelects.clear();
				slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHER);
				slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
				slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHDATE);
				slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
				slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHCOMMENTS);
				slObjSelects.add(DomainConstants.SELECT_CURRENT);
				Map mIPReleaseInfo = domIPReleaseObj.getInfo(context, slObjSelects);
				String sIPRevPublisher = (String)mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHER);
				String sIPTag = (String)mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
				String sIPPublishDate = (String)mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHDATE);
				String sIPQAStatus = (String)mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPQASTATUS);
				String sPublishComment = (String)mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHCOMMENTS);
				String sCurrent = (String)mIPReleaseInfo.get(DomainConstants.SELECT_CURRENT);
				returnMap.put("IPID", sIPID);
				returnMap.put("tag", sIPTag);
				returnMap.put("qa_status", sIPQAStatus);
				returnMap.put("state", sCurrent);
				returnMap.put("publish_date", sIPPublishDate);
				returnMap.put("publish_comment", sPublishComment);
				returnMap.put("publisher", sIPRevPublisher);
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
	    throw new Exception(e);
	}		
	return returnMap;
}
  //Added for SWIMP-154:Ends
	
	/* Method ADDED FOR maintain consume Audit Record */
  @SuppressWarnings({"rawtypes", "unchecked", "deprecation"})
  public void consumeAuditRecord(Context context, String[] args) throws Exception {
    Boolean isContextPushed = false;
    try {
    	HashMap programMap = (HashMap) JPO.unpackArgs(args);
      String strIPName = (String) programMap.get("sIPName");
      String strTag = (String) programMap.get("sTag");
      String strOktaId = (String) programMap.get("sOktaID");
      String strAction = (String) programMap.get("strAction");

      // Added for URL Issue in Publish and Download Emails Start
      String sIMP_ENV = (String) programMap.get("IMP_ENV");
      String sProject = (String) programMap.get("Project");
      String sComment = (String) programMap.get("Comment");
      sComment = UIUtil.isNullOrEmpty(sComment) ? "" : sComment;
      // Added for URL Issue in Publish and Download Emails Ends
      // Added for Bug 965
      ContextUtil.pushContext(context, strOktaId, "",
          PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
      isContextPushed = true;
      String sWhere = "attribute[IMP_IPTag]=='" + strTag
          + "'&&to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.name=='" + strIPName + "'";
      StringList slSelects = new StringList(DomainConstants.SELECT_ID);
      slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.name");
      slSelects.add("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");
      slSelects.add("attribute[IMP_ForceNewPrefix].value");

      MapList mRelMapList = DomainObject.findObjects(context, "IMP_IPRelease", "*", "A", "*",
          "eService Production", sWhere, false, slSelects);
      if (!mRelMapList.isEmpty()) {
        Map mRelObjMap = (Map) mRelMapList.get(0);
        String strIPID =
            (String) mRelObjMap.get("to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.id");        
        String sRelObjId = (String) mRelObjMap.get(DomainConstants.SELECT_ID);
        Map mpData = new HashMap();
        mpData.put("IPName", strIPName);
        mpData.put("Tag", strTag);
        mpData.put("IPID", strIPID);
        mpData.put("RELID", sRelObjId);
        mpData.put("COMMENTS", sComment);
        mpData.put("PROJECT", sProject);
        mpData.put("OPERATION", "download");
        JPO.invoke(context, "IMP_IPVerification", null, "updateAuditRecords",
            JPO.packArgs(mpData));
        // Add history
        String strHistory =
            "mod bus " + sRelObjId + " add history 'Consume IP - " + strOktaId + "'";
        MqlUtil.mqlCommand(context, strHistory);
        DomainObject domObj = new DomainObject(sRelObjId);
        // Below code for sendMailNotificationwhenIPPublishOrConsume
        HashMap mailNotificationwhenArgs = new HashMap();
        mailNotificationwhenArgs.put("strObjectId", strIPID);
        mailNotificationwhenArgs.put("strAction", strAction);
        // Modified For IMPBRCM-718,717,745 & 446 Starts
        mailNotificationwhenArgs.put("sOktaID", strOktaId);
        // Added for URL Issue in Publish and Download Emails Starts
        mailNotificationwhenArgs.put("env", sIMP_ENV);
        //Modified for IMPBRCM-1026 Starts
        mailNotificationwhenArgs.put("IPTag", strTag);
        mailNotificationwhenArgs.put("Project", sProject);
        mailNotificationwhenArgs.put("Comment", sComment);
        // Added for URL Issue in Publish and Download Emails Ends
        // Modified For IMPBRCM-718,717,745 & 446 Ends
        JPO.invoke(context, "IMP_NotificationUtil", null,
            "sendMailNotificationwhenIPPublishOrConsume", JPO.packArgs(mailNotificationwhenArgs),
            Map.class);
        //Modified for IMPBRCM-1026 Ends
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      if (context != null && isContextPushed) {
        ContextUtil.popContext(context);
      }
    }
  }
//Added for SWIMP-113
  private Map getDocumentUpLoadStatus(Context context,String sPath, String ipName,String sUserName,String sPubDocs) throws Exception {

	  List<String> lsFinalDocuments = new ArrayList<>();
	  HashMap hmreturnUpdateData = new HashMap();
	  String sUploadStatus="";
	  try {
		  List<String> arListpubDocs = getArrLtPublicDocuments(sPubDocs);
		  String [] arFinalPubDocs = new String[arListpubDocs.size()];
		  arListpubDocs.toArray(arFinalPubDocs);
		  Arrays.sort(arFinalPubDocs);

		  HashMap hmUpdateData = new HashMap();
		  hmUpdateData.put("sIPName", ipName);
		  hmUpdateData.put("sPath", sPath);
		  hmUpdateData.put("sUser", sUserName);
		  Map mpReturnData = JPO.invoke(context, "IMP_IPVerification", null, "checkinPublicDocumentsToIP",
				  JPO.packArgs(hmUpdateData), Map.class);

		  String sUpLoadMessage=(String) mpReturnData.get("Message");

		  if("Success".equals(sUpLoadMessage)){
			  String fileNamesList = ((StringBuilder) mpReturnData.get("Files_List")).toString();
			  fileNamesList = fileNamesList.substring(0, fileNamesList.lastIndexOf(','));
			  String [] arrfileList = fileNamesList.split(",");
			  Arrays.sort(arrfileList);
			  sUploadStatus="Success";

			  if ((arFinalPubDocs.length != arrfileList.length) && !Arrays.equals(arFinalPubDocs,arrfileList))
			  {
				  sUploadStatus="Partial";
				  boolean hasPublished = false;
				  for(int i=0; i<arFinalPubDocs.length; i++) {
					  for(int j=0; j<arrfileList.length; j++) 
					  {
						  if(arFinalPubDocs[i].equals(arrfileList[j])) {
							  hasPublished = true;
							  break;
						  }
					  }

					  if(!hasPublished) {
						  lsFinalDocuments.add(arFinalPubDocs[i]);
					  } else {
						  hasPublished = false;
					  }
				  }	
			  }
		  }else {
			  sUploadStatus=(String) mpReturnData.get("Message");
		  }
		  hmreturnUpdateData.put("lsFinalDocuments",lsFinalDocuments);
		  hmreturnUpdateData.put("sUploadStatus",sUploadStatus);

	  } catch (Exception e) {
		  e.printStackTrace();
	  }
	  return hmreturnUpdateData;
  }
  
  public List<String> getArrLtPublicDocuments(String sPubDocs) {
	  List<String> arListpubDocs = new ArrayList<>();
	  sPubDocs = sPubDocs.replace("[", "").replaceAll("]","");
	  String [] arPubDocs = sPubDocs.split(",");
	  for (String file : arPubDocs) {
		  if (file.contains("/")) {
			  String sFileName =  file.substring(file.lastIndexOf('/'),file.length());
			  sFileName = sFileName.replace("/", "");
			  sFileName=sFileName.trim();
			  arListpubDocs.add(sFileName);
		  } else {
			  file=file.trim();
			  arListpubDocs.add(file);
		  }
	  }
	  return arListpubDocs;
  }
  //Added for SWIMP-113		



  /**
   * This method used to add notification settings on IP Download and Connect relationship to Branch on Auto Subscription
   *
   * Added for SWIMP-166, Modified for SWIMP-284, Modified for SWIMP-345
   *
   * @param context the eMatrix <code>Context</code> object
   * @param args holds Project ID
   * @param args holds IPName
   * @param args holds download tag
   * @param args holds user name
   * @param args holds SoC/Project name
   * @param args holds Subscription user list (comma separated user name(s))
   * @returns String
   */
  @SuppressWarnings("unchecked")
  public String consumeAutoSubsciption(Context context, String[] args) throws Exception {
	  String sRetUserList = "";
	  try {
		  //Modified for SWIMP-345: Starts
		  Map<String, Object> programMap = JPO.unpackArgs(args);
		  String strProjectId = (String) programMap.get(IMP_Constants_mxJPO.STR_PROJECT_ID);
		  String strIPName = (String) programMap.get(IMP_Constants_mxJPO.STR_IPNAME);
		  String strTag = (String) programMap.get(IMP_Constants_mxJPO.STR_IMP_IPTAG);
		  String strUserName = (String) programMap.get(IMP_Constants_mxJPO.STR_USERNAME);
		  String sProject = (String) programMap.get(IMP_Constants_mxJPO.STR_PROJECT);
		  String strSubscriptionUser = (String) programMap.get(IMP_Constants_mxJPO.STR_SUBSCRIPTIONUSER);
		  String sIPid = "";
		  StringList slIPAccessUserList = null;
		  String sReleaseObjId = "";
		  String sBranchObjId = "";

		  StringList slSelects = new StringList(DomainConstants.SELECT_ID);
		  slSelects.add(IMP_Constants_mxJPO.IPID);
		  slSelects.add(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_RELEASE);
		  String sWhere = IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG + "=='" + strTag + "'&& " + IMP_Constants_mxJPO.IPNAME + "=='" + strIPName + "'";
		  MapList mRelMapList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE,
				  DomainConstants.QUERY_WILDCARD,
				  DomainConstants.QUERY_WILDCARD,
				  DomainConstants.QUERY_WILDCARD,
				  IMP_Constants_mxJPO.PROD_VALUT,
				  sWhere,
				  null,
				  false,
				  slSelects,
				  (short) 1);

		  if (!mRelMapList.isEmpty()) {
			  Map<String, String> mRelObjMap = (Map<String, String>) mRelMapList.get(0);
			  sIPid = mRelObjMap.get(IMP_Constants_mxJPO.IPID);
			  sBranchObjId = mRelObjMap.get(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_RELEASE);
			  sReleaseObjId = mRelObjMap.get(DomainConstants.SELECT_ID);
		  }
		  //Modified for SWIMP-345: Ends

		  if (UIUtil.isNotNullAndNotEmpty(strSubscriptionUser)) {
			  // to remove owners/co-owners from the subscribing list
			  List<String> list = removeOwnersCoOwners(context, sIPid, strSubscriptionUser);

			  String[] sArrSubUser = list.toArray(new String[0]);
			  // To get list of users who have access to the IP
			  slIPAccessUserList = IMP_IPProductUtil_mxJPO.getSubListBasedOnCLI(context, strSubscriptionUser, sIPid);
			  setStrSubscriptionUserList(slIPAccessUserList.toString()); //Added for SWIMP-341, setting the subscription users after checking the person access to IP.

			  //ADDED for SWIMP-334 - STARTS
			  StringList slIPSubscribersList = IMP_IPProductUtil_mxJPO.getSubscriberList(context, sIPid, strProjectId);
			  if(!slIPSubscribersList.isEmpty()) { 
				  slIPAccessUserList.addAll(slIPSubscribersList);
			  }
			  //ADDED for SWIMP-334 - ENDS

			  //Here the context user has access to IP and
			  //he should be added to the access user list
			  if(!slIPAccessUserList.contains(strUserName)) {
				  slIPAccessUserList.add(strUserName);
			  }

			  String[] sArrValidSubUser = StringUtil.join(slIPAccessUserList, ",").split(",");

			  // To get the delta set of users who don't have access
			  HashSet<String> hs = new HashSet<>(Arrays.asList(sArrSubUser));
			  hs.removeAll(Arrays.asList(sArrValidSubUser));
			  sRetUserList = String.join(",", hs);

			  //Modified for SWIMP-345: Starts
			  if (UIUtil.isNotNullAndNotEmpty(slIPAccessUserList.toString())) {
				  boolean sAllowIPVerify = getAllowIPVerificationStatus(context, sProject);
				  //Added for SWIMP-341: Starts
				  setContextUser(strUserName);
				  setIPRevision(strTag);
				  //Added for SWIMP-341: Ends
				  if (!sAllowIPVerify) {
					  setSubscriptionList(context, sIPid, slIPAccessUserList);
				  } else {
					  connectProjectToBranch(context, slIPAccessUserList, strProjectId, sBranchObjId, sReleaseObjId, sIPid, sProject); //Modified method name and parameters for SWIMP-345
				  }
			  }
			  //Modified for SWIMP-345: Ends
		  }
	  } catch (Exception e) {
		  throw new MatrixException("Exception occured in IMP_IPReleaseUtil:consumeAutoSubsciption " + e);
	  }
	  return sRetUserList;
  }


	/**
	 * This method gets the allow IP verification status of SoC Added for
	 * SWIMP-166
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param sProject
	 *            holds SoC name
	 * @throws FrameworkException
	 * @returns List
	 */
	public boolean getAllowIPVerificationStatus(Context context, String sProject) throws Exception {
		boolean bAllowIPVerificationStatus = true;
		HashMap hmGetSoCID = new HashMap();
		hmGetSoCID.put("strSoCName", sProject);
		String strSoCId = JPO.invoke(context, "IMP_IPReleaseUtil", null, "getSoCIdFromSoCName",
				JPO.packArgs(hmGetSoCID), java.lang.String.class);
		if (UIUtil.isNotNullAndNotEmpty(strSoCId)) {
			DomainObject doSoC = DomainObject.newInstance(context, strSoCId);
			String sAllowIPVerify = doSoC.getInfo(context,
					IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_ALLOWIPVERIFICATION);
			if ("false".equalsIgnoreCase(sAllowIPVerify)) {
				bAllowIPVerificationStatus = false;
			}
		}
		return bAllowIPVerificationStatus;
	}

	/**
	 * This method used to remove owners & co-owners Added for SWIMP-166
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param sIPid
	 *            holds IPID
	 * @param strSubscriptionUser
	 *            holds comma separated user name(s)
	 * @throws FrameworkException
	 * @returns List
	 */

	public List<String> removeOwnersCoOwners(Context context, String sIPid, String strSubscriptionUser)
			throws FrameworkException {
		String sCoOwner = "";
		String sOwner = "";
		String[] sArrSubUser = strSubscriptionUser.split(",");
		List<String> list = new ArrayList<>(Arrays.asList(sArrSubUser));
		DomainObject doIP = DomainObject.newInstance(context, sIPid);
		StringList busSelects = new StringList();
		busSelects.add(DomainConstants.SELECT_OWNER);
		busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_COOWNER);
		Map<String, String> map = doIP.getInfo(context, busSelects);
		StringList slOwnerCoOwner = new StringList();
		if (map != null && !map.isEmpty()) {
			sCoOwner = map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_COOWNER);
			sOwner = map.get(DomainConstants.SELECT_OWNER);
			if (UIUtil.isNotNullAndNotEmpty(sCoOwner)) {
				slOwnerCoOwner = FrameworkUtil.split(sCoOwner, "~");
			}
			slOwnerCoOwner.add(sOwner);
			list.removeAll(slOwnerCoOwner);
		}
		return list;
	}


	//Added for SWIMP-345: Starts
	/**
	 * This method used to connect SoC/HIP to Branch on Auto Subscription, Added for SWIMP-345
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param slIPAccessUserList holds IP User Access list
	 * @param sProjectId holds SoC/HIP Id
	 * @param sBranchObjId holds Branch Id
	 * @param sReleaseObjId holds Release Id
	 * @param sIPid holds IP Id
	 * @param sProject holds SoC/HIP Name
	 * @throws Exception
	 * @returns void
	 */
	public void connectProjectToBranch(Context context, StringList slIPAccessUserList,
			String sProjectId, String sBranchObjId, String sReleaseObjId, String sIPid, String sProject) throws Exception {
		String sWhere = DomainConstants.SELECT_NAME + IMP_Constants_mxJPO.EQUALS_APOSTROPHE + sProject + IMP_Constants_mxJPO.APOSTROPHE;
		// Added for the SWIMP-595 Starts
		boolean isContextPushed = false;
		// Added for the SWIMP-595 Ends
		MapList mlBranchToSoCHIP = IMP_IPProductUtil_mxJPO.getRelatedForObject(context,
				sBranchObjId,
				IMP_Constants_mxJPO.STR_SYMBOLICNAME_RELATIONSHIP_LOGICALPRODUCTS,
				IMP_Constants_mxJPO.STR_TRUE,
				IMP_Constants_mxJPO.STR_FALSE,
				sWhere);

		//Check if Branch has "Logical Products" relationship with the SoC/HIP which is being used for download
		//If No, connect Branch and SoC/HIP with the relationship "Logical Products"
		//If Yes, Do not change anything
		if (mlBranchToSoCHIP.isEmpty()) {
			//Get the "Logical Products" relationship information for the current downloading revision with the SoC/HIP being used for download
			MapList mlReleaseToSoCHIP = IMP_IPProductUtil_mxJPO.getRelatedForObject(context,
					sReleaseObjId,
					IMP_Constants_mxJPO.STR_SYMBOLICNAME_RELATIONSHIP_LOGICALPRODUCTS,
					IMP_Constants_mxJPO.STR_TRUE,
					IMP_Constants_mxJPO.STR_FALSE,
					sWhere);

			//If the current revision is already subscribed to the same SoC/HIP being used, keep all the connections as it is.
			//If Not, check all the revision of the same branch is connected to the SoC being used for Download.
			//If there are, disconnect the relationship "Logical Products" from all the revisions and connect it to Branch, If not, connect the SoC/HIP to branch.
			if(mlReleaseToSoCHIP.isEmpty()) {
				String[] sBranchId = new String[] {sBranchObjId};

				//Disconnect Logical Products relationship from revisions of the same branch is connected to SoC/HIP which is currently being used for Download
				disconnectLogicalProductsRelationshipFromSoCHIPOnAutoSubscription(context, sProject, sBranchObjId);
				
				PropertyUtil.setGlobalRPEValue(context, IMP_Constants_mxJPO.STR_SUBSCRIPTIONUSER
						+ IMP_Constants_mxJPO.CONST_EMAIL_SUB_DELIMITER + context.getSession().getSessionId(),
						StringUtil.join(slIPAccessUserList, ","));
				// Modified for the SWIMP-595 Starts
				try {
					ContextUtil.pushContext(context, getContextUser(), "", IMP_Constants_mxJPO.PROD_VAULT);
					isContextPushed = true;
					// Connect Branch to SoC/HIP with "Logical Products" relationship
					DomainRelationship.connect(context, DomainObject.newInstance(context, sProjectId),
							IMP_Constants_mxJPO.RELATIONSHIP_LOGICAL_PRODUCTS, true, sBranchId);
				} finally {
					if (isContextPushed)
						ContextUtil.popContext(context);
				}
				// Modified for the SWIMP-595 Ends

			} else {
				//Add additional users to the subscription list if IP is already subscribed to the SoC
				setSubscriptionList(context, sIPid, slIPAccessUserList);
			}
		} else {
			//Add additional users to the subscription list if IP is already subscribed to the SoC
			setSubscriptionList(context, sIPid, slIPAccessUserList);
		}
	}
	//Added for SWIMP-345: Ends


	/**
	 * This method used to set subscription Added for SWIMP-166
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param sIPid
	 *            holds IPID
	 * @param slSubscriberList
	 *            subscription user list
	 * @throws Exception 
	 * @returns void
	 */

	public void setSubscriptionList(Context context, String sIPid, StringList slSubscriberList) throws Exception {
		//178 S
		DomainObject domObj = DomainObject.newInstance(context, sIPid);
		
		List<String> eventList = new ArrayList<>();
		eventList.add(IMP_Constants_mxJPO.NOTIFICATION_EVENT_PUBLISH);
		eventList.add(IMP_Constants_mxJPO.NOTIFICATION_EVENT_EDIT);
		eventList.add(IMP_Constants_mxJPO.NOTIFICATION_EVENT_DEACTIVATE);
		eventList.add(IMP_Constants_mxJPO.NOTIFICATION_EVENT_DEPRECATED);
		
		IMP_IPProductUtil_mxJPO.updateNotificationSettings(context, domObj, slSubscriberList, eventList, "Create", false);
		//178 E
	}

	/**
	 * This method used to display exclamation mark in UI on SoC/HIP subscription
	 * table for Incompatible SoC tech stack with IP tech stack values Added for
	 * SWIMP-166
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds Project object ID
	 * @param args
	 *            holds IP objectList
	 * @returns StringList
	 */
	@SuppressWarnings("unchecked")
	public StringList getIncompatibleIPs(Context context, String[] args) throws Exception {
		Map<String, Object> programMap = JPO.unpackArgs(args);
		Map<String, Object> paramList = (Map<String, Object>) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		
		// Added for SWIMP-848 : Starts
		String sTableName = (String) paramList.get("table");
		// Added for SWIMP-848 : Ends
		
		String sProjectObjId = (String) paramList.get("objectId");
		MapList objList = (MapList) programMap.get("objectList");
		StringList columnVals = new StringList();
		Map<String, String> objMap = null;
		String sBranchOrRelObjectid = "";
		String sIPObjectid = "";
		try {
			if (objList != null && !objList.isEmpty()) {
				Iterator<Map<String, String>> itr = objList.iterator();
				while (itr.hasNext()) {
					objMap = itr.next();
					// Modified for SWIMP-848 : Starts
					String sTableResult = (sTableName == null) ? null : (sTableName.contains("~") ? sTableName.substring(sTableName.indexOf('~') + 1).trim() : sTableName.trim());
					if(sTableResult.equalsIgnoreCase(IMP_Constants_mxJPO.KEY_STR_IMP_PRODUCTHIERARCHY_TABLE)) {
					sBranchOrRelObjectid = objMap.get(DomainConstants.SELECT_ID);
					sIPObjectid = IMP_Utility_mxJPO.getIPIDfromBranchOrRelease(context, sBranchOrRelObjectid);
					} else {
					if(sTableResult.equalsIgnoreCase(IMP_Constants_mxJPO.KEY_STR_IMP_IPRELEASE_SUMMARY_TABLE)) {
					sIPObjectid = objMap.get(IMP_Constants_mxJPO.SELECT_IPID_FROM_IPWATERMARK);
					  }
					}
					if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) objMap.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) { //Added for SWIMP-541
						if(UIUtil.isNotNullAndNotEmpty(sIPObjectid)) {
							if (isSocHIPIPTechStackSame(context, sProjectObjId, sIPObjectid)) {
								columnVals.add("");
							} else {
								columnVals.add(IMP_Constants_mxJPO.HTMLSTYLE_INCOMPATIBLE_TECH_STACK);
							}
						} else {
							columnVals.add("");
						}
					} else {
						columnVals.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS); //Added for SWIMP-541
					}
					// Modified for SWIMP-848 : Ends
			   	 } 
			  }		
           } catch (Exception e) {
			throw new MatrixException("Exception occured in IMP_IPReleaseUtil:getIncompatibleIPs " + e);
		}
		return columnVals;
	}

	/**
	 * This method checks whether SoC/HIP tech stack matches with any of the IP tech
	 * stack values Added for SWIMP-166, Modified Code for SWIMP-284
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param sSoCID
	 *            holds SoC/HIP object ID
	 * @param sIPID
	 *            holds IP object id
	 * @returns boolean
	 */
	public boolean isSocHIPIPTechStackSame(Context context, String sProjectID, String sIPID) throws FrameworkException {
		boolean isSocHIPIPTechStackSame = false;
		DomainObject domObj = DomainObject.newInstance(context, sProjectID);
		String sProjectType = domObj.getInfo(context, DomainConstants.SELECT_TYPE);
		Map<String, String> map = getIncompatibleTechStackMap(context, sProjectID, sIPID, "", sProjectType);
		String sSocHIPIPTechStackSame = map.get(IS_SOCHIPIP_TECHSTACK_SAME);
		if("true".equals(sSocHIPIPTechStackSame)) {
			isSocHIPIPTechStackSame = true;
		}
		return isSocHIPIPTechStackSame;
	}

	/**
	 * This method gets the incompatible tech stack, called from CLI-Restful
	 * Added for SWIMP-166, modified for SWIMP-284, Modified for SWIMP-380
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds SoC object name
	 * @param args
	 *            holds IP name
	 * @returns String
	 */
	@SuppressWarnings("unused")
	public String getIncompatibleTechStack(Context context, String[] args) throws Exception {
		Map<String, String> programMap = JPO.unpackArgs(args);
		String strIPName = programMap.get("IPName");
		String strProject = programMap.get("Project");
		String sIPID = "";
		String sType = "";
		String sIncompatibleTechStackMsg = "";
		String sProjectID = "";
		String sName = "";
		Map<String, String> map = null;
		StringBuilder sWhere = new StringBuilder(DomainConstants.SELECT_NAME);
		sWhere.append("=='").append(strIPName).append("' || ").append(DomainConstants.SELECT_NAME).append("=='")
		.append(strProject).append("'");
		Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RPODUCT);
		typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_SOC);
		String sQuery = "temp query bus " + typePattern.getPattern() + " * * where \"" + sWhere.toString()
		+ "\" select id dump | recordsep @";
		String sResult = MqlUtil.mqlCommand(context, true, sQuery, true);// Modified for SWIMP19XU-49
		String[] sRedcSep = sResult.split("@");
		for (String sTemp : sRedcSep) {
			StringList slIPSoc = FrameworkUtil.split(sTemp, "|");
			sType = (String) slIPSoc.get(0);
			sName = (String) slIPSoc.get(1);
			if (IMP_Constants_mxJPO.TYPE_IMP_IP_RPODUCT.equals(sType) && strIPName.equalsIgnoreCase(sName)) { //Modified for SWIMP-380, Ignoring the case
				sIPID = (String) slIPSoc.get(3);
			}
			sProjectID = (String) slIPSoc.get(3);
		}
		
		//Updated for SWIMP-279 
		map = getIncompatibleTechStackMap(context, sProjectID, sIPID, strIPName, sType);
		sIncompatibleTechStackMsg = map.get(INCOMPACTIBLE_TECHSTACK_MSG);
		return sIncompatibleTechStackMsg;
	}

	/**
	 * This method gets the incompatible tech stack map containing boolean value
	 * for in compatible tech stack and in compatible tech stack message to
	 * display in CLI, Added for SWIMP-166, Modified for SWIMP-284
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param sSoCID
	 *            holds SoC object ID
	 * @param sIPID
	 *            holds IP object id
	 * @param strIPName
	 *            holds IP name
	 * @returns Map
	 */
	@SuppressWarnings("unchecked")
	private Map<String, String> getIncompatibleTechStackMap(Context context, String sProjectId, String sIPID, String strIPName, String sProject) 
			throws FrameworkException {

		Map<String, String> hmInCompatibleTechstackMsgStatus = new HashMap<>();	
		MapList mlProjectTechStack = new MapList();
		StringBuilder sbStatusOfProjectTechstack = new StringBuilder();
		String sProjectIPTechStackSame = "true";

		MapList mlIPTechStack = IMP_TechStackUtil_mxJPO.getRelatedTechStackForIP(context, sIPID);
		if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equals(sProject)) {
			DomainObject doSoC = DomainObject.newInstance(context, sProjectId);
			StringList slSoC = new StringList();
			slSoC.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_FOUNDRY);
			slSoC.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PROCESSNODE);
			slSoC.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SUBPROCESS);
			Map<String, String> map = doSoC.getInfo(context, slSoC);
			mlProjectTechStack.add(map);
		} else {
			mlProjectTechStack = IMP_TechStackUtil_mxJPO.getRelatedTechStackForIP(context, sProjectId);
		}
		
		if (mlIPTechStack.isEmpty() || mlProjectTechStack.isEmpty()) {
			hmInCompatibleTechstackMsgStatus.put(IS_SOCHIPIP_TECHSTACK_SAME, sProjectIPTechStackSame);
			hmInCompatibleTechstackMsgStatus.put(INCOMPACTIBLE_TECHSTACK_MSG, sbStatusOfProjectTechstack.toString());
		} else {
			hmInCompatibleTechstackMsgStatus = compareIPProjectTechStack(strIPName, mlIPTechStack, mlProjectTechStack);
		}
		
		return hmInCompatibleTechstackMsgStatus;
	}
	// ADDED FOR SWIMP-284 -STARTS
	
	@SuppressWarnings("unchecked")
	private Map<String, String> compareIPProjectTechStack(String strIPName, MapList mlIPTechStack, MapList mlProjectTechStack) {
		HashMap<String, String> hmInComparisionTechstackMsgStatus = new HashMap<>();
		StringBuilder sbStatusOfProjectTechstack = new StringBuilder("Project tech stack ");
		StringBuilder sbStatusOfIPTechstack = new StringBuilder(" does not match any one of the tech stack values of ").append(strIPName).append(": ");
		Map<String, String> mapProject = null;
		String sProjectIPTechStackSame = "false";
		
		Set<String> hsIsProjectContainsIPTechStk = new HashSet<>();

		Map<String, String> mapIP;
		Iterator<Map<String, String>> itrIP = mlIPTechStack.iterator();
		while (itrIP.hasNext()) {
			StringBuilder sbIP = new StringBuilder();
			mapIP = itrIP.next();
			sbIP.append(mapIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_FOUNDRY)).append("/")
			.append(mapIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PROCESSNODE)).append("/")
			.append(mapIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SUBPROCESS));
			hsIsProjectContainsIPTechStk.add(sbIP.toString());// set of CIP Tech stack
			sbStatusOfIPTechstack.append(sbIP); // building message to show in case if does not match.
			sbStatusOfIPTechstack.append(",");
		}

		Iterator<Map<String, String>> itrProject = mlProjectTechStack.iterator();
		//check if CIP's tech stack matches with any HIP/SoC tech stack and build message to show in case if does not match
		while (itrProject.hasNext()) {
			mapProject = itrProject.next();
			StringBuilder sbProjectTechstack = new StringBuilder();
			// get HIP/SOC techstack details
			sbProjectTechstack.append(mapProject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_FOUNDRY)).append("/")
			.append(mapProject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PROCESSNODE)).append("/")
			.append(mapProject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SUBPROCESS));
			sbStatusOfProjectTechstack.append(sbProjectTechstack); // set of HIP/SOC Tech stack
			sbStatusOfProjectTechstack.append(",");

			if (hsIsProjectContainsIPTechStk.contains(sbProjectTechstack.toString())) {
				sProjectIPTechStackSame = "true";
				sbStatusOfProjectTechstack = new StringBuilder();
				break;
			}
		}

		if("false".equals(sProjectIPTechStackSame)) {
			sbStatusOfProjectTechstack.deleteCharAt(sbStatusOfProjectTechstack.length()-1);
			sbStatusOfProjectTechstack.append(sbStatusOfIPTechstack);
			sbStatusOfProjectTechstack.deleteCharAt(sbStatusOfProjectTechstack.length()-1);
		}
		hmInComparisionTechstackMsgStatus.put(IS_SOCHIPIP_TECHSTACK_SAME, sProjectIPTechStackSame);
		hmInComparisionTechstackMsgStatus.put(INCOMPACTIBLE_TECHSTACK_MSG, sbStatusOfProjectTechstack.toString());
		return hmInComparisionTechstackMsgStatus;
	}
	
	// ADDED FOR SWIMP-284 -ENDS
	
	//Added for the SWIMP-222 --starts
	/**
	 * This method gets watermarks, existence of revision, branch and any
	 * revision published for IP product under the respective IP Tag. Added for
	 * SWIMP-222
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param ipName
	 *            holds IP Name
	 * @param sTag
	 *            holds IP Revision Tag
	 * @returns MapList
	 */
	@SuppressWarnings("unchecked")
	public MapList getAllWaterMarkValues(Context context, String[] args) throws Exception {
		Map<String, List<String>> hm = JPO.unpackArgs(args);
		MapList listOfMaps = new MapList();
		try {
			List<String> lIPName = hm.get("IPList");
			List<String> lIPTag = hm.get("TAGList");

			if (!lIPName.isEmpty() && !lIPTag.isEmpty()) {
				Iterator<String> iIpList = lIPName.iterator();
				Iterator<String> iTagList = lIPTag.iterator();
				while (iIpList.hasNext() && iTagList.hasNext()) {
					String ipName = iIpList.next();
					String sTag = iTagList.next();
					MapList finalReturnMapList = getWaterMarkInfoForIPProduct(context, ipName, sTag);
					Iterator<Map<String, String>> iter = finalReturnMapList.iterator();
					while (iter.hasNext()) {
						Map<String, String> mpInfoList = iter.next();
						listOfMaps.add(mpInfoList);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Exception in getAllWaterMarkValues:   ", e);
			throw new MatrixException(e);
		}
		return listOfMaps;
	}
	
	/**
	 * This method gets all the Watermark values from IP product and respective
	 * IP Tag. Added for SWIMP-222
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param ipName
	 *            holds IP Name
	 * @param sTag
	 *            holds IP Revision Tag
	 * @returns MapList
	 */
	@SuppressWarnings({ "unchecked" })
	public MapList getWaterMarkInfoForIPProduct(Context context, String ipName, String sTag) throws Exception {
		MapList returnMapList = new MapList();
		Map<String, Object> dReturnMap = new HashMap<>();
		String sIPid = getIPIdFromIPName(context, ipName);

		if (UIUtil.isNotNullAndNotEmpty(sIPid)) {
			boolean bBranchExists = false;
			boolean bIsTagSpecified = false;

			List<String> lTagInfo = getTagInfo(sTag);
			sTag = lTagInfo.get(0);
			String branchName = lTagInfo.get(1);
			if (UIUtil.isNotNullAndNotEmpty(sTag)) {
				bIsTagSpecified = true;
			}
			DomainObject domIPObj = new DomainObject(sIPid);
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPTAG_FROM_IPRELEASEBRANCH_RELATIONSHIP);
			slObjSelects.add(
					IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPREVWATERMARK_FROM_RELEASE_IP_WATERMARK_RELATIONSHIP); //GetAll the IPRevision Watermarks available for the IP
			slObjSelects.add(
					IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPXWATERMARK_FROM_RELEASE_IP_WATERMARK_RELATIONSHIP); //GetAll the IPX Watermarks available for the IP

			MapList mlRelatedIPReleaseList = domIPObj.getRelatedObjects(context, relPattern.getPattern(), // relationship
					// pattern
					typePattern.getPattern(), // type pattern
					false, // from
					true, // to
					(short) 3, // expand level
					slObjSelects, // Object selects
					null, // relationship selects
					null, // object where
					null, // relationship where
					0, // limit
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // postRelPattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // postTypePattern
					null); // postPatterns

			if (mlRelatedIPReleaseList.isEmpty()) {
				if (sTag.equals("Trunk")) {
					if (branchName.equals("Trunk")) {
						bBranchExists = true;
					}
					dReturnMap.put(IPNAME, ipName);
					dReturnMap.put(BRANCHEXISTS, bBranchExists);
					dReturnMap.put(ANYREVISIONPUBLISHEDFORBRANCH, false);
					dReturnMap.put(REVISIONEXISTS, false);
					dReturnMap.put(BRANCHNAME, branchName);
					dReturnMap.put(IPTAG, sTag);
					dReturnMap.put(IPIDEXISTS, true);
					dReturnMap.put(IPTAGEXISTS, true);
				} else {
					dReturnMap.put(IPIDEXISTS, true);
					dReturnMap.put(IPTAGEXISTS, false);
					dReturnMap.put(BRANCHEXISTS, false);
					dReturnMap.put(ANYREVISIONPUBLISHEDFORBRANCH, false);
					dReturnMap.put(REVISIONEXISTS, false);
				}
				returnMapList.add(dReturnMap);
			} else {
				returnMapList = getWaterMarkObjectInfoFromReleaseObj(mlRelatedIPReleaseList, ipName, sTag,
						bIsTagSpecified, branchName);
			}
		} else {
			dReturnMap.put(IPNAME, ipName);
			dReturnMap.put(IPIDEXISTS, false);
			returnMapList.add(dReturnMap);
			logger.error("RelUtil:getWaterMarkInfoForIPProduct: Requested IPID '" + ipName + "' does not exist in IMP");
		}
		return returnMapList;
	}
	
	/**
	 * This method to get the branchName from Tag. Added for SWIMP-222
	 * 
	 * @param sTag
	 *            holds IP Revision Tag
	 * @returns List
	 */
	public List<String> getTagInfo(String sTag) {
		String branchName = "Trunk";
		List<String> lTagInfo = new ArrayList<>();
		if (sTag.contains("/")) {
			String[] strArray = sTag.split("/");
			branchName = strArray[0];
		}
		lTagInfo.add(sTag);
		lTagInfo.add(branchName);
		return lTagInfo;
	}
	
	/**
	 * This method gets all the Watermark values from IP product for respective
	 * IP Tag. Added for SWIMP-222
	 * 
	 * @param mlRelatedIPReleaseList
	 *            holds the IP Branch Release info in MapList
	 * @param ipName
	 *            holds IP Name
	 * @param sTag
	 *            holds IP Revision Tag
	 * @param bIsTagSpecified
	 *            holds IP_Tag is specified or not in the input
	 * @param branchName
	 *            holds branch Name from IP_Tag, default value is "Trunk"
	 * @returns MapList
	 */
	@SuppressWarnings({ "unchecked" })
	public MapList getWaterMarkObjectInfoFromReleaseObj(MapList mlRelatedIPReleaseList, String ipName, String sTag,
			boolean bIsTagSpecified, String branchName) {

		MapList returnMapList = new MapList();
		Map<String, String> mIPReleaseInfo = null;
		Map<String, Object> returnMapOnMLEmpty = new HashMap<>();
		Iterator<Map<String, String>> iterate = mlRelatedIPReleaseList.iterator();
		while (iterate.hasNext()) {
			mIPReleaseInfo = iterate.next();
			String sReleaseIPTaG = mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			String sBranchIPTag = mIPReleaseInfo
					.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPTAG_FROM_IPRELEASEBRANCH_RELATIONSHIP);

			if (!bIsTagSpecified || (sReleaseIPTaG.equals(sTag) && branchName.equals(sBranchIPTag))) {
				Map<String, Object> returnMap = new HashMap<>();

				Object sAttrIPRevisionWatermark = mIPReleaseInfo.get(
						IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPREVWATERMARK_FROM_RELEASE_IP_WATERMARK_RELATIONSHIP);
				Object sAttrIPXWaterMark = mIPReleaseInfo
						.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IPXWATERMARK_FROM_RELEASE_IP_WATERMARK_RELATIONSHIP);

				String sWaterMarkIdsForIP = getAllWMsFromWMObject(sAttrIPRevisionWatermark, sAttrIPXWaterMark);
				if (UIUtil.isNotNullAndNotEmpty(sWaterMarkIdsForIP)) {
					returnMap.put(IPNAME, ipName);
					returnMap.put(WATERMARK, sWaterMarkIdsForIP);
					returnMap.put(REVISIONEXISTS, true);
					returnMap.put(BRANCHEXISTS, true);
					returnMap.put(ANYREVISIONPUBLISHEDFORBRANCH, true);
					returnMap.put(BRANCHNAME, branchName);
					returnMap.put(IPTAG, sReleaseIPTaG);
					returnMap.put(IPIDEXISTS, true);
					returnMap.put(IPTAGEXISTS, true);

					returnMapList.add(returnMap);
				}
			}
		}
		if(returnMapList.isEmpty()) {
			returnMapOnMLEmpty.put(IPNAME, ipName);
			returnMapOnMLEmpty.put(IPTAG, sTag);
			returnMapOnMLEmpty.put(BRANCHEXISTS, true);
			returnMapOnMLEmpty.put(REVISIONEXISTS, false);
			returnMapOnMLEmpty.put(IPIDEXISTS, true);
			returnMapOnMLEmpty.put(IPTAGEXISTS, false);
			returnMapList.add(returnMapOnMLEmpty);
		}
		return returnMapList;
	}
	
	/**
	 * This method collects all the watermarks for the IP and Tag. Added for
	 * SWIMP-222
	 * 
	 * @param oAttrIPRevisionWatermark
	 *            holds IPRevisionWaterMark from IP Watermark Object
	 * @param oAttrIPXWaterMark
	 *            holds IPXWaterMark from IP Watermark Object
	 * @returns String
	 */
	@SuppressWarnings("unchecked")
	public String getAllWMsFromWMObject(Object oAttrIPRevisionWatermark, Object oAttrIPXWaterMark) {
		List<String> lMulipleWaterMarkIds = new ArrayList<>();
		StringList slMultipleWMIds = new StringList();
		if (oAttrIPRevisionWatermark != null) {
			if (oAttrIPRevisionWatermark instanceof String) {
				lMulipleWaterMarkIds.add((String) oAttrIPRevisionWatermark);
			} else {
				lMulipleWaterMarkIds.addAll((StringList) oAttrIPRevisionWatermark);
			}
		}
		if (oAttrIPXWaterMark != null) {
			if (oAttrIPXWaterMark instanceof String) {
				lMulipleWaterMarkIds.add((String) oAttrIPXWaterMark);
			} else {
				lMulipleWaterMarkIds.addAll((StringList) oAttrIPXWaterMark);
			}
		}
		for (String sWatermarkValue : lMulipleWaterMarkIds) {
			if (UIUtil.isNotNullAndNotEmpty(sWatermarkValue)) {
				slMultipleWMIds.add(sWatermarkValue);
			}
		}
		return FrameworkUtil.join(slMultipleWMIds, ",");
	}
	//Added for SWIMP-222 --Ends
	
		//Added for the SWIMP-210 -starts
	/**
	 * This method checks the IMP_IPType Attribute for the IP and gets executed when the Action trigger gets fired.
	 * 
	 * Added for SWIMP-210
	 * 
	 * @param args
	 *        holds IPName, Attribute Value, Object Id from IP Object
	 * 
	 */

	public void ipTypeModifiedFromHardToSoftIP (Context context, String[] args) throws MatrixException {
		String sIPName = args[0];
		String sAttrValue = args[1];
		String sIPid = args[2];

		if ((IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPTYPE_RANGE_SOFT_IP).equalsIgnoreCase(sAttrValue)) {	

			MapList mlRelatedIPReleaseList = getIPReleaseObjectInfo(context, sIPid);
			if (!mlRelatedIPReleaseList.isEmpty()) {
				String sIPWMSeedAttr = getIPWaterMarkSeedValue(context, sIPid, sIPName);				
				updateWMObject(context, mlRelatedIPReleaseList, sIPWMSeedAttr, sIPName);
				
			}
		}
	}

	@SuppressWarnings("unchecked") //create IPSeed if its blank
	public String getIPWaterMarkSeedValue (Context context, String sIPid, String sIPName) throws MatrixException {
		String sIPIDWMSeed = "";
		StringList slselects = new StringList(1);
		slselects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPWATERMARKSEED);
		Map<String,String> mpIPMap;
		try {
			DomainObject domIPObj = new DomainObject(sIPid);	
			mpIPMap = domIPObj.getInfo(context, slselects);
			sIPIDWMSeed = mpIPMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPWATERMARKSEED);
			
			if("".equalsIgnoreCase(sIPIDWMSeed) || sIPIDWMSeed==null) {
				sIPIDWMSeed = IMP_GenerateWMStringsForMigratedIPRevisions_mxJPO.generateWaterMarkHashCode(context, sIPName);
			}
		} catch (Exception e) {
			throw new MatrixException("IPReleaseUtil:getIPWaterMarkSeedValue method failed."+e); 
		}
		return sIPIDWMSeed;
	}

	public MapList getIPReleaseObjectInfo (Context context, String sIPid) throws MatrixException {
		MapList mlRelatedIPReleaseList =  new MapList();
		try {
			DomainObject domIPObj = new DomainObject(sIPid);
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_NAME);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IP_TAG_FROM_IMP_IP_WATERMARK);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_WATERMARK_ID_FROM_IPRELEASEBRANCH);

			mlRelatedIPReleaseList = domIPObj.getRelatedObjects(context, 
					relPattern.getPattern(), // relationship pattern
					typePattern.getPattern(), // type pattern
					false, // from
					true, // to
					(short) 3, // expand level
					slObjSelects, // Object selects
					null, // relationship selects
					null, // object where
					null, // relationship where
					0, // limit
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // postRelPattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // postTypePattern
					null); // postPatterns
		} catch (Exception e) {
			throw new MatrixException("IPReleaseUtil:getIPReleaseObjectInfo method failed."+e);
		}
		return mlRelatedIPReleaseList;
	}

	@SuppressWarnings("unchecked")
	public void updateWMObject(Context context, MapList mlRelatedIPReleaseList, String sIPWMSeedAttr, String sIPname) throws MatrixException {
		Map<String,String> mIPReleaseInfo;
		List<String> wmObjectIdList;
		Object oIPWaterMarkObjects;
		Iterator<Map<String,String>> iterate = mlRelatedIPReleaseList.iterator();
		while(iterate.hasNext()) {
			mIPReleaseInfo = iterate.next();	
			String sReleaseObjName =  mIPReleaseInfo.get(DomainConstants.SELECT_NAME);
			String sReleaseObjId =  mIPReleaseInfo.get(DomainConstants.SELECT_ID);

			if(!sReleaseObjName.isEmpty()){
				wmObjectIdList = new ArrayList<>();							
				oIPWaterMarkObjects = mIPReleaseInfo.get(IMP_Constants_mxJPO.SELECT_WATERMARK_ID_FROM_IPRELEASEBRANCH);
				if(oIPWaterMarkObjects!=null) {
					if(oIPWaterMarkObjects instanceof String) {
						wmObjectIdList.add((String)oIPWaterMarkObjects);
					} else {
						wmObjectIdList.addAll((StringList)oIPWaterMarkObjects);							
					}
					checkandSetIpRevisionWaterMark(context, wmObjectIdList, sIPWMSeedAttr );

				} else {
					createandConnectReleaseAndWMObject(context, sReleaseObjId, sIPname, sIPWMSeedAttr);	
				}
			}
		}
	}

	public void checkandSetIpRevisionWaterMark(Context context, List<String> wmObjectIdList, String sIPWMSeedAttr) throws MatrixException {
		try {
			DomainObject domWMId;
			for(String sIpWMObjectId : wmObjectIdList) {
				if(!checkIPWaterMarkAttributes(context, sIpWMObjectId)) {
					String sRevisionWatermarkID = IMP_GenerateWMStringsForMigratedIPRevisions_mxJPO.getWaterMarkString(context, sIPWMSeedAttr);
						domWMId = new DomainObject(sIpWMObjectId);
						domWMId.setAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPREVISIONWATERMARK,
								sRevisionWatermarkID);
				}
			}
		} catch (Exception e) {
			throw new MatrixException("IPReleaseUtil:checkandSetIpRevisionWaterMark method failed."+e);
		}
	}

	public void createandConnectReleaseAndWMObject(Context context, String sReleaseObjId, String sIPname, String sIPWMSeedAttr) throws MatrixException {

		Map<String,String> mAttributeValues = new HashMap<>();
		try {
			String strObjectGeneratorName = FrameworkUtil.getAliasForAdmin(context, DomainConstants.SELECT_TYPE,
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, true);
			String strAutoName = DomainObject.getAutoGeneratedName(context, strObjectGeneratorName, null);
			DomainObject domIPWaterMarkObj = new DomainObject();
			domIPWaterMarkObj.createObject(context,
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK,
					strAutoName,
					"",
					IMP_Constants_mxJPO.POLICY_IMP_WATERMARKSTRING,
					IMP_Constants_mxJPO.PROD_VALUT);

			DomainObject domIPReleaseObj = new DomainObject(sReleaseObjId);

			DomainRelationship.connect(context, domIPReleaseObj, IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK, domIPWaterMarkObj);
			String sIPtag= domIPReleaseObj.getInfo(context, IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			String sRevisionWatermarkID = IMP_GenerateWMStringsForMigratedIPRevisions_mxJPO.getWaterMarkString(context, sIPWMSeedAttr);

			mAttributeValues.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPID, sIPname);
			mAttributeValues.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPTAG, sIPtag);
			mAttributeValues.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_DUPLICATE_WATERMARK_EXISTS, "FALSE");
			mAttributeValues.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPREVISIONWATERMARK, sRevisionWatermarkID);

			domIPWaterMarkObj.setAttributeValues(context, mAttributeValues);

		} catch (Exception e) {
			throw new MatrixException("IPReleaseUtil:createandConnectReleaseAndWMObject method failed."+e);
		}
	}

	public boolean checkIPWaterMarkAttributes(Context context, String sWMObjectId) throws MatrixException {
		boolean isWMSAvailable = true;

		try {
			DomainObject domWMObj = new DomainObject(sWMObjectId);
			String lIPRevWMs = domWMObj.getInfo(context, IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
			if(lIPRevWMs.isEmpty()) {
				isWMSAvailable = false;
			}

		} catch (Exception e) {
			throw new MatrixException("IPReleaseUtil:checkIPWaterMarkAttributes method failed."+e); 
		}
		return isWMSAvailable;
	}
	//Added for SWIMP-210 -ENDs
	
	/**
	 * This method gets the name of the IP product and tag for the branch and
	 * release objects. Added for SWIMP-289
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds the objectId of the IP Product, Branch and Release
	 * @returns StringList
	 * @throws Exception
	 *             if the operation fails
	 */
	@SuppressWarnings({"unchecked"})
	public StringList getIPIDBranchReleaseColumnValue(Context context, String[] args) throws Exception {
		HashMap<String, MapList> programMap = JPO.unpackArgs(args);
		StringList slResults = new StringList();
		String sResult = "";
		try {
			MapList mlObjects = programMap.get("objectList");
			if (!mlObjects.isEmpty()) {
				DomainObject dObject = null;
				Map<String, String> mObject = null;
				String sOID = null;
				String sType = null;
				for (int i = 0; i < mlObjects.size(); i++) {
					mObject = (Map<String,String>) mlObjects.get(i);
					sType = mObject.get(DomainConstants.SELECT_TYPE);
					if (IMP_Constants_mxJPO.TYPE_IMP_IP_PRODUCT.equals(sType)) {
						sOID = mObject.get(DomainConstants.SELECT_ID);
						dObject = DomainObject.newInstance(context, sOID);
						sResult = dObject.getInfo(context, DomainConstants.SELECT_NAME);
					} else {
						sResult = mObject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
					}
					slResults.add(sResult);
				}
			}
		} catch (FrameworkException fe) {
			throw new FrameworkException(
					"Exception in IMP_IPReleaseUtil : getIPIDBranchReleaseColumnValue " + fe.getMessage());
		}
		return slResults;
	}

	//SWIMP:306 -S
	//this method used in webform to show publish comment
	@SuppressWarnings("unchecked")
	public static String showPublishComment (Context context, String[]args) throws Exception {
		Map<String,Object> programMap = JPO.unpackArgs(args);
		Map<String,Object> mParamMap= (HashMap<String,Object>) programMap.get("paramMap");
		String sObjectId = (String) mParamMap.get("objectId");
		DomainObject domIPRelease = DomainObject.newInstance(context,sObjectId);
		return domIPRelease.getInfo(context, IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPPUBLISHCOMMENTS);
	}
    // this method is called from UI to update publish comment on release.
	@SuppressWarnings("unchecked")
	public static void updatePublishComment(Context context, String []args) throws Exception {

		Map<String,Object> programMap = JPO.unpackArgs(args);
		Map<String,Object> paramMap = (HashMap<String,Object>) programMap.get("paramMap");
		String sObjectId = (String) paramMap.get("objectId");
		String sNewValue = (String) paramMap.get("New Value");
		updatePublishComment(context,sObjectId,sNewValue);

	}
	//actual method to update publish comment on release object
	public static void updatePublishComment(Context context, String sObjectId, String sNewValue ) throws Exception {
		DomainObject domIPRelease = new DomainObject(sObjectId);
		domIPRelease.setAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPPUBLISHCOMMENTS, sNewValue); //update release object
		Map<String,Object> branchAndLatestReleaseMap = getBranchAndLatestRelease(context, domIPRelease);
		String sLatestReleaseObjectId = (String)branchAndLatestReleaseMap.get(DomainConstants.SELECT_ID);
		String sBranchObjectId = (String)branchAndLatestReleaseMap.get("branchObjectId");
		if(sObjectId.equals(sLatestReleaseObjectId)) { // if we are modifying latest release object under branch then update branch and maturity comment 
			new DomainObject(sBranchObjectId).setAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPPUBLISHCOMMENTS, sNewValue); // update branch comment
			Map<String,Object>brAttrMap = new HashMap<>();
			brAttrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IPPUBLISHCOMMENTS, sNewValue);
			brAttrMap.put("objectId", sBranchObjectId);
			String[] args0 = JPO.packArgs(brAttrMap);
			new IMP_IPReleaseUtil_mxJPO().updateListofIPDeliveryMilestones(context, args0); // update maturity comment 
		}
		IMP_DesignsyncModule_mxJPO.updateRevisionCheckInComment(context,domIPRelease,sNewValue); // update DesignSync checkin comment
	}

	public static Map<String,Object> getBranchAndLatestRelease(Context context, DomainObject domIPRelease) throws Exception {
		StringList slObjSelects = new StringList(1);
		slObjSelects.add(DomainConstants.SELECT_ID);
		Map<String,Object>branchMap = getBranchMapFromRelease(context,domIPRelease,slObjSelects,null);
		String sBranchObjectId = (String)branchMap.get(DomainConstants.SELECT_ID);
		Map<String,Object> branchAndLatestReleaseMap = getLatestReleaseUnderABranch(context,sBranchObjectId,slObjSelects,null);
		branchAndLatestReleaseMap.put("branchObjectId",sBranchObjectId);
		return branchAndLatestReleaseMap;
	}
	
	@SuppressWarnings("unchecked")
	public static Map<String,Object>getBranchMapFromRelease(Context context, DomainObject domIPRelease , StringList sSelect, String sWhere) throws FrameworkException {
		MapList branchMapList = domIPRelease.getRelatedObjects(context,
				IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // relationship pattern
				IMP_Constants_mxJPO.TYPE_IMP_BRANCH, // type pattern
				sSelect, // Object selects
				null, // relationship selects
				true, // from
				false, // to
				(short) 1, // expand level
				sWhere, // object where
				null, // relationship where
				0); // limit
		return (Map<String,Object>) branchMapList.get(0);// we will always get one branch from Release
	}
	@SuppressWarnings("unchecked")
	public static Map<String,Object> getLatestReleaseUnderABranch(Context context, String sBranchObjectId, StringList sSlect, String sWhere) throws Exception {
		Map<String,Object>returnMap = new HashMap<>();
		sSlect = sSlect==null?new StringList():sSlect;
		sSlect.add(DomainConstants.SELECT_ORIGINATED);
		MapList releaseMapList = new DomainObject(sBranchObjectId).getRelatedObjects(context,
				IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // relationship pattern
				IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
				sSlect, // Object selects
				null, // relationship selects
				false, // from
				true, // to
				(short) 1, // expand level
				sWhere, // object where
				null, // relationship where
				0); // limit
		if(!releaseMapList.isEmpty()) {
			releaseMapList.sort(DomainConstants.SELECT_ORIGINATED, "decending","date");
			returnMap = (Map<String,Object>) releaseMapList.get(0);
			
		}
		return returnMap;
	}
	//tool to update release publish comment from mql
	//syntax execute program IMP_IPReleaseUtil -method updatePublishCommentFromMql <Release object id> <New comment>;
	public static void updatePublishCommentFromMql(Context context, String []args) throws Exception {

		try {
			String sObjectId = args[0];
			String sNewValue = args[1];
			ContextUtil.startTransaction(context,true);
			updatePublishComment(context,sObjectId,sNewValue);
			ContextUtil.commitTransaction(context) ;
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			logger.error("Exception in updatePublishCommentFromMql:   ", e);
			throw e;
		}
	}
	//SWIMP-306 - E

	//Added for SWIMP-345: Starts
	/**
	 * This method used to Disconnect SoC/HIP from all the revisions on Auto Subscription Added for SWIMP-345
	 *
	 * @param context
	 * @param sProject holds SoC/HIP Name
	 * @param sBranchObjId holds Branch Id
	 * @throws Exception
	 * @returns void
	 */
	private static void disconnectLogicalProductsRelationshipFromSoCHIPOnAutoSubscription(Context context, String sProject, String sBranchObjId) throws Exception {
		StringList busSelects = new StringList(IMP_Constants_mxJPO.SELECT_LOGICALPRODUCTS_RELATIONSHIP_ID);

		String sWhereClause = IMP_Constants_mxJPO.SELECT_LOGICALPRODUCTS_RELATIONSHIP_FROM_NAME
				+ IMP_Constants_mxJPO.EQUALS_APOSTROPHE + sProject + IMP_Constants_mxJPO.APOSTROPHE;

		//Get all revisions connected to SoC/HIP which is used for download, with the "Logical Products" relationship
		MapList mpRevisionList = IMP_IPProductUtil_mxJPO.getReleaseMapList(context, sBranchObjId, busSelects, null, sWhereClause, null);

		//Check if any revision of the branch having "Logical Products" relationship with currently using SoC/HIP for Download operation
		if(mpRevisionList != null && !mpRevisionList.isEmpty()) {
			//Get the revisions which are connected to the Same SoC/HIP with Logical Products relationships
			List<String> lReleaseToLogicalProductsRelIds = getLogicalProductRelationshipIds(context, mpRevisionList, sProject);
			for (String strRelLogicalProductIds : lReleaseToLogicalProductsRelIds) {
				//Disconnect "Logical Products" relationship from existing revisions
				if (UIUtil.isNotNullAndNotEmpty(strRelLogicalProductIds)) {
					DomainRelationship.disconnect(context, strRelLogicalProductIds);
				}
			}
		}
	}

	/**
	 * This method used to get the all the revision connected to the SoC/HIP which is being processed for download
	 * Added for SWIMP-345
	 *
	 * @param context
	 * @param mpRevisionList holds all logical product relationship ids and revision details connected to the SoC/HIP
	 * @param sProject holds SoC/HIP
	 * @throws MatrixException
	 * @returns List, which holds the list of Logical Product rel ids to be disconnected
	 */
	@SuppressWarnings("unchecked")
	private static List<String> getLogicalProductRelationshipIds(Context context, MapList mpRevisionList, String sProject) throws MatrixException {
		List<String> lReleaseToLogicalProductsRelIds = new ArrayList<>();
		List<String> lLogicalProductListToDisconnect = new ArrayList<>();
		try {
			Iterator<Map<String, Object>> itrRevisions = mpRevisionList.iterator();
			StringList slReAttrSelects = new StringList(IMP_Constants_mxJPO.SELECT_RELATIONSHIP_FROM_NAME);
			while(itrRevisions.hasNext()) {
				Map<String, Object> mpRelease = itrRevisions.next();
				Object obReleaseLogicalProductRelId = mpRelease.get(IMP_Constants_mxJPO.SELECT_LOGICALPRODUCTS_RELATIONSHIP_ID);

				if(obReleaseLogicalProductRelId instanceof String) {
					lReleaseToLogicalProductsRelIds.add((String) obReleaseLogicalProductRelId);
				} else {
					lReleaseToLogicalProductsRelIds.addAll((StringList) obReleaseLogicalProductRelId);
				}
			}
			for (String strRelLogicalProductIds : lReleaseToLogicalProductsRelIds) {
				String[] saRelLogIds = new String[] {strRelLogicalProductIds};
				MapList mlRelAttributes = DomainRelationship.getInfo(context, saRelLogIds, slReAttrSelects);

				if (!mlRelAttributes.isEmpty()) {
					Map<String, Object> mAttr = (Map<String, Object>) mlRelAttributes.get(0);
					String strProject = (String) mAttr.get(IMP_Constants_mxJPO.SELECT_RELATIONSHIP_FROM_NAME);
					if (strProject.equalsIgnoreCase(sProject) && UIUtil.isNotNullAndNotEmpty(strRelLogicalProductIds)) {
						lLogicalProductListToDisconnect.add(strRelLogicalProductIds);
					}
				}
			}
		} catch (Exception e) {
			throw new MatrixException("Exception in the method IMP_IPReleaseUtil::getLogicalProductRelationship: " + e);
		}
		return lLogicalProductListToDisconnect;
	}
	//Added for SWIMP-345: Ends

	// Added for SWIMP-31: Starts
	//Modified for SWIMP-31(Phase-2)
	public Map<String, Map> getSoCHIPStructure(Context context, String[] args) throws Exception {
		HashMap hmData = JPO.unpackArgs(args);
		return getSoCHIPStructure(context, (Map<String, String>) hmData.get("WMStrings"), (String) hmData.get("ID")); //Modified for SWIMP-568
	}

	public Map<String, String> convertMapdottoStringtoMap(String mapAsString) {
		return IMP_Utility_mxJPO.convertMapdottoStringtoMap(mapAsString);
	}


	public Map<String, Map<String, Map<String, String>>> getchildIPstoConnect(String sChildIPs) {
		Map<String, Map<String, Map<String, String>>> mReturn = new HashMap<>();
		Map<String, String> mDesignFileNChildIPs2Connect = convertMapdottoStringtoMap(sChildIPs);
		for (Map.Entry<String, String> childIPsToConnect : mDesignFileNChildIPs2Connect.entrySet()) {
			Map<String, Map<String, String>> mIPIDnRelAttributeInfo = new HashMap<>();
			String sChildIPs2Connect = childIPsToConnect.getValue();
			List<String> lChildIPs2Connect = Arrays.asList(sChildIPs2Connect.split("\\|"));
			for (String sTemp : lChildIPs2Connect) {
				String[] sArray = sTemp.split("\\^");
				Map<String, String> mrelInfoOfChildIPs = new HashMap<>();
				mrelInfoOfChildIPs.put("instanceCount", sArray[1]);
				mrelInfoOfChildIPs.put("isBlockIP", sArray[2].equalsIgnoreCase(IMP_Constants_mxJPO.ATTRIBUTE_IMP_PRODUCT_TYPE_RANGE_BLOCKIP) ? "True" : "False");
				mIPIDnRelAttributeInfo.put(sArray[0], mrelInfoOfChildIPs);
			}
			mReturn.put(childIPsToConnect.getKey(), mIPIDnRelAttributeInfo);
		}
		return mReturn;
	}

	public Map<String, Map<String, String>> getLineageMap(String sLinegeMap) {
		Map<String, Map<String, String>> mReturn = new HashMap<>();
		Map<String, String> mDesignFileNLineageInfoString = convertMapdottoStringtoMap(sLinegeMap);
		for (Map.Entry<String, String> lineageInfoMap : mDesignFileNLineageInfoString.entrySet()) {
			Map<String, String> mLineageINfo = new HashMap<>();
			String sLineageInfoString = lineageInfoMap.getValue();
			StringList slLineageInfo = StringUtil.split(sLineageInfoString, "$");
			for (String sLineageInfo : slLineageInfo) {
				String[] sArray = sLineageInfo.split("\\^");
				mLineageINfo.put(sArray[0], sArray[1]);
			}
			mReturn.put(lineageInfoMap.getKey(), mLineageINfo);
		}
		return mReturn;
	}

	public void connectIMPIPCHILDRelationship(Context context,String sDesignFileName,String sDesignFileNChildIPs2Connect,DomainObject domWMObj) throws Exception{
		Map<String, Map<String, Map<String, String>>> gdsSpecificChildInfoMap = getchildIPstoConnect(sDesignFileNChildIPs2Connect);
		if (gdsSpecificChildInfoMap != null && !gdsSpecificChildInfoMap.isEmpty()) {
			Map<String, Map<String, String>> mChildInfo = gdsSpecificChildInfoMap.get(sDesignFileName);
			DomainRelationship doRelImpIPChild;
			Map mpRelAttributes = new HashMap();
			if(mChildInfo != null && !mChildInfo.isEmpty()) {
				for (Map.Entry<String, Map<String, String>> entry : mChildInfo.entrySet()) {
					String sObjId = entry.getKey();
					String sRef = entry.getValue().get("instanceCount");
					String strIMPChildIsHIP = entry.getValue().get("isBlockIP");

					if (Integer.parseInt(sRef) > 0) {
						DomainObject domRevObj = new DomainObject(sObjId);
						mpRelAttributes.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_NOOFINSTANCES, sRef);
						mpRelAttributes.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_CHILD_IS_HIP, strIMPChildIsHIP);
						doRelImpIPChild = DomainRelationship.connect(context, domWMObj,IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_CHILD, domRevObj);
						doRelImpIPChild.setAttributeValues(context, mpRelAttributes);
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	public void connectVerificationStatus4HIP(Context context, int nOfWMs, String sDesignFileName,
			String sDesignFileNLineageMap, DomainObject domWMObj, String ipName, String sBranchandTag) throws Exception{
		Map<String, Map<String, String>> gdsSpecificLineageMap = getLineageMap(sDesignFileNLineageMap);
		if (gdsSpecificLineageMap != null && !gdsSpecificLineageMap.isEmpty()) {
			MapList mlIPVerificationStatusForHIPConnList;
			StringList slrelSelects = new StringList(2);
			slrelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
			slrelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS);
			slrelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_APPROVER);
			slrelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS);
			slrelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_APPROVED_DATE);

			DomainRelationship domIMPIPVerificationStatusForHIP = null;
			Iterator itrIPVerificationStatusForHIPConnList = null;
			Map mAttributeInfo = null;
			Map<String, String> mLineageInfo = gdsSpecificLineageMap.get(sDesignFileName);
			if(mLineageInfo != null && !mLineageInfo.isEmpty()) {
				for (Map.Entry<String, String> entry : mLineageInfo.entrySet()) {
					String strChildWMId = entry.getKey();
					String strLineageInfo = entry.getValue();
					DomainObject domChild = new DomainObject(strChildWMId);
					mlIPVerificationStatusForHIPConnList = domChild.getRelatedObjects(context,
							IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP, // relationship pattern
							IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
							null, // Object selects
							slrelSelects, // relationship selects
							true, // from
							false, // to
							(short) 1, // expand level
							null, // object where
							sbRelWhere, // relationship where
							0); // limit

					List<String> strLineageICList = StringUtil.split((String) strLineageInfo, ";");
					Map mIPVerificationStatusForHIP = null;
					String strTempLineage = null;

					for (String strLineageIC : strLineageICList) {
						boolean isLineageExists = false;
						String strChildLineage = strLineageIC.substring(0, strLineageIC.indexOf('#'));
						String strInstanceCount = strLineageIC.substring(strLineageIC.indexOf('#') + 1,strLineageIC.length());
						String sFinalChildLineage = getLineageString(sDesignFileName, ipName, sBranchandTag, strChildLineage, nOfWMs);
						itrIPVerificationStatusForHIPConnList = mlIPVerificationStatusForHIPConnList.iterator();
						while (itrIPVerificationStatusForHIPConnList.hasNext()) {
							mIPVerificationStatusForHIP = (Map) itrIPVerificationStatusForHIPConnList.next();
							strTempLineage = (String) mIPVerificationStatusForHIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
							isLineageExists = sFinalChildLineage.endsWith(strTempLineage);
							if (isLineageExists) {
								break;
							}
						}
						domIMPIPVerificationStatusForHIP = DomainRelationship.connect(context, domWMObj, IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP, domChild);
						mAttributeInfo = new HashMap();
						mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_LINEAGE, sFinalChildLineage);
						mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_NOOFINSTANCES, strInstanceCount);
						mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS, "Detected");

						if (isLineageExists) {
							mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS,(String) mIPVerificationStatusForHIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS));
							mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_APPROVER, (String) mIPVerificationStatusForHIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_APPROVER));
							mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS,(String) mIPVerificationStatusForHIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS));
							mAttributeInfo.put(IMP_Constants_mxJPO.ATTRIBUTE_APPROVED_DATE,(String) mIPVerificationStatusForHIP.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_APPROVED_DATE));
						}
						domIMPIPVerificationStatusForHIP.setAttributeValues(context, mAttributeInfo);
					}
				}
			}
		}

	}
	
	private String getLineageString (String sDesignFileName, String ipName, String sBranchandTag, String strChildLineage, int nOfWMs) {
		StringBuilder sbFinalChildLineage = new StringBuilder();
		if (nOfWMs > 1) {
			String strFileName = "(" + sDesignFileName + ")";// newly added
			sbFinalChildLineage.append(ipName).append(":").append(sBranchandTag).append(strFileName).append("|").append(strChildLineage);
		} else {
			sbFinalChildLineage.append(ipName).append(":").append(sBranchandTag).append("|").append(strChildLineage);
		}
		return sbFinalChildLineage.toString();
	}
	
	public String isHIPandTagValid(Context context, String[] args) throws Exception {
		String sReturn = "TRUE";
		HashMap programMap = JPO.unpackArgs(args);
		try {
			String sIPName = (String) programMap.get(IMP_Constants_mxJPO.STR_PROJECT_NAME);
			String sIPObjectId = getIPIdFromIPName(context, sIPName);
			if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_PRODUCT_TYPE_RANGE_COMPONENTIP
					.equalsIgnoreCase((String) getIPProductInfoFromIPID(context, sIPObjectId)
							.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_PRODUCTTYPE))) {
				return "FALSE";
			}
		} catch (Exception e) {
			throw e;
		}
		return sReturn;
	}
	
	//Modified for SWIMP-31(Phase-2) : Starts
	public Map<String, Map> getSoCHIPStructure(Context context, Map<String, String> mWMStrings, String sProjectID)
			throws Exception {
		Map<String, Map> returnMap = new HashMap<>();
		Map<String, Map<String, String>> mDSFilenWMObjIDsnRefCount = new HashMap<>();
		Map<String, Map<String, Map<String, String>>> mDSFilenWMObjIDsnWmObjInfo = new HashMap<>();
		Map<String, Map<String, Object>> mDSFilenWMObjIDsnWmChildInfo = new HashMap<>();
		Map<String, Map<String, String>> mDSFilenWMObjInstanceCount = new HashMap<>();
		Map<String, String> mDSFilenNotAvailableWM = new HashMap<>();
		Map<String, Object> mpDetectedWMIPsInfoMap = new HashMap<>(); // Added for SWIMP-568
		 String strBranchId ="";//578
		try { // Added for ITOP-1290
			if (!mWMStrings.isEmpty()) {
				for (Map.Entry<String, String> mDSFilenWMIDtrings : mWMStrings.entrySet()) {
					StringBuilder sbNotAvailableWM = new StringBuilder();
					Map<String, String> mWMObjIdnRefCount = new LinkedHashMap<>();
					IMP_Utility_mxJPO.getWatermarkObjectFromStrings(context, mDSFilenWMIDtrings.getValue(),
							sbNotAvailableWM, mWMObjIdnRefCount);
					Map<String, String> mOrigWMObjIdnRefCount = new HashMap<>(mWMObjIdnRefCount);
					List<String> lAllWmObjIdinaDSFile = new ArrayList<>(mWMObjIdnRefCount.keySet());
					Map<String, Map<String, String>> mWMObjInfo = IMP_Utility_mxJPO.getWMObjectInfo(context,
							lAllWmObjIdinaDSFile);
					Map<String, Object> mWMChildInfo = IMP_Utility_mxJPO.getWMObjectChildInfo(context,
							lAllWmObjIdinaDSFile, mWMObjInfo, mWMObjIdnRefCount, ""); // Modified for SWIMP-564

					// Added for SWIMP-568 : Starts
					String sDetectedIPObjID = "";
					String sDetectedIPReleaseID = "";
					String sLatestRevisionOfDetectedIP = "";
					String sIPDeclaredForUse = "";
					Map<String, Map<String, Object>> mpWMIpRevisionInfo = new HashMap<>();
					StringList slBusSelects = new StringList();
					slBusSelects.add(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
					slBusSelects.add(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
					for (String sWMChildID : IMP_Utility_mxJPO.lsDetectedWMIds) {
						Map<String, Object> mpInfo = new HashMap<>();
						Map<String, String> mpWMIpInfo = DomainObject.newInstance(context, sWMChildID).getInfo(context,
								slBusSelects);
						sDetectedIPObjID = mpWMIpInfo.get(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
						sDetectedIPReleaseID = mpWMIpInfo
								.get(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
						//578 Start
						strBranchId = (String)DomainObject.newInstance(context, sDetectedIPReleaseID).getInfo(context, "to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strBranchId)){
							HashMap mpIPMap = new HashMap();
							mpIPMap.put("IPID",strBranchId);
							mpIPMap.put("isBranch",IMP_Constants_mxJPO.STR_TRUE);
							sLatestRevisionOfDetectedIP=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
							JPO.packArgs(mpIPMap), String.class);
						}
						//578 End
						sIPDeclaredForUse = getDeclaredForUsage(context, sProjectID, sDetectedIPReleaseID);
						mpInfo.put(IMP_Constants_mxJPO.KEY_LATESTREVISION, sLatestRevisionOfDetectedIP);
						mpInfo.put(IMP_Constants_mxJPO.KEY_DECLARED_FOR_USE, sIPDeclaredForUse);
						mpInfo.put(IMP_Constants_mxJPO.KEY_DEPRECATED_BY,
								IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, sDetectedIPObjID));
						mpWMIpRevisionInfo.put(sWMChildID, mpInfo);
					}
					// Added for SWIMP-568 : Ends

					String sGDSFileName = mDSFilenWMIDtrings.getKey();
					mDSFilenWMObjIDsnRefCount.put(sGDSFileName, mWMObjIdnRefCount);
					mDSFilenWMObjIDsnWmObjInfo.put(sGDSFileName, mWMObjInfo);
					mDSFilenWMObjIDsnWmChildInfo.put(sGDSFileName, mWMChildInfo);
					mDSFilenWMObjInstanceCount.put(sGDSFileName, mOrigWMObjIdnRefCount);
					mDSFilenNotAvailableWM.put(sGDSFileName, sbNotAvailableWM.toString());
					mpDetectedWMIPsInfoMap.put(sGDSFileName, mpWMIpRevisionInfo); // Added for SWIMP-568
				}
				returnMap.put(IMP_Constants_mxJPO.KEY_REF_COUNTMAP, mDSFilenWMObjIDsnRefCount);
				returnMap.put(IMP_Constants_mxJPO.KEY_WMOBJ_INFOMAP, mDSFilenWMObjIDsnWmObjInfo);
				returnMap.put(IMP_Constants_mxJPO.KEY_WMCHILD_INFOMAP, mDSFilenWMObjIDsnWmChildInfo);
				returnMap.put(IMP_Constants_mxJPO.KEY_ORIGINALCOUNT, mDSFilenWMObjInstanceCount);
				returnMap.put(IMP_Constants_mxJPO.KEY_NOT_AVAILABLE_WM, mDSFilenNotAvailableWM);
				returnMap.put(IMP_Constants_mxJPO.KEY_DETECTED_IP_INFO, mpDetectedWMIPsInfoMap); // Added for SWIMP-568

				// Added for SWIMP-570 : Starts
				if (IMP_Constants_mxJPO.EVENTOPERATION_QUERY.equalsIgnoreCase(sCLIOperation)) {
					returnMap.put(IMP_Constants_mxJPO.KEY_QUERY_CONSUMED_IPS_VRINFO, mpQueryConsumedIPsMap);
				}
				// Added for SWIMP-570 : Ends
			}
			// Added for ITOP-1290 starts
		} catch (Exception ex) {
			throw new MatrixException("Exception in IMP_IPReleaseUtil_mxJPO : getSoCHIPStructure" + ex);
		} finally {
			IMP_Utility_mxJPO.lsDetectedWMIds.clear();// Added for SWIMP-568
		}
		// Added for ITOP-1290 Ends
		return returnMap;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String, Map> getHIPStructure4VerifyIP(Context context, String[] args) throws Exception{
		Map<String, String> hm = JPO.unpackArgs(args);
		String sProjectName = hm.get(IMP_Constants_mxJPO.STR_PROJECT_NAME);
		String sTag = hm.get(IMP_Constants_mxJPO.STR_KEY_TAG);
		String strOperation = hm.get(IMP_Constants_mxJPO.KEY_OPERATION); //Added for SWIMP-564
		String sDesignFileName = hm.containsKey(IMP_Constants_mxJPO.STR_DESIGNFILE) ? hm.get(IMP_Constants_mxJPO.STR_DESIGNFILE) : "";
		StringList slObjSelects = new StringList();
		Map<String, Map> returnMap = new HashMap<>();
		slObjSelects.add(DomainConstants.SELECT_ID);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTR_MISSINGPROGENYINSTWARNING_FROM_IPWATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTR_UNKNOWNWMWARNING_FROM_IPWATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
		//Added for SWIMP-31 (Phase-2) : Starts
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
		//Added for SWIMP-31 (Phase-2) : Ends

		//Added for SWIMP-568 : Starts
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_IP_OWNER_FROM_IMP_IP_WATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_IP_BU_FROM_IMP_IP_WATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_ALERT_FROM_IMP_IP_WATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_IPSOURCE_FROM_IMP_IP_WATERMARK);
		slObjSelects.add(IMP_Constants_mxJPO.SELECT_3PIPVENDOR_FROM_IMP_IP_WATERMARK);
		//Added for SWIMP-568 : Ends
		// Building the where condition to fetch the watermarks which match the where condition criteria.
		StringBuilder sbWhere = new StringBuilder();
		sbWhere.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG).append("=='").append(sTag).append("'&&")
		.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID).append("=='").append(sProjectName).append("'");
		if (UIUtil.isNotNullAndNotEmpty(sDesignFileName))
			sbWhere.append("&&").append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE).append("=='")
			.append(sDesignFileName).append("'");
		//MapList mlWMObjects = ${CLASS:IMP_Utility}.impFindObjects(context, ${CLASS:IMP_Constants}.TYPE_IMP_IP_WATERMARK, sbWhere.toString(), slObjSelects, 0); //Modified for SWIMP-824
		MapList mlWMObjects = DomainObject.findObjects(context, IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, "*", "*", "*",
				IMP_Constants_mxJPO.PROD_VAULT, sbWhere.toString(), false, slObjSelects);
		Map<String, String> wmObjMap1 = null;
		// Get the watermark information if the result set is not empty
		if (!mlWMObjects.isEmpty()) {
			String sgdsFileName = sProjectName + IMP_Constants_mxJPO.SYMBOL_PIPE + sTag;

			Iterator<Map<String, String>> itr = mlWMObjects.iterator();
			StringList busSelects = new StringList();
			busSelects.add(DomainConstants.SELECT_ID); 
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID);
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			//Added for SWIMP-568 : Starts
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_IP_OWNER_FROM_IMP_IP_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_IP_BU_FROM_IMP_IP_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_ALERT_FROM_IMP_IP_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
			busSelects.add(IMP_Constants_mxJPO.SELECT_IPSOURCE_FROM_IMP_IP_WATERMARK);
			busSelects.add(IMP_Constants_mxJPO.SELECT_3PIPVENDOR_FROM_IMP_IP_WATERMARK);
			//Added for SWIMP-568 : Ends
			StringList relSelects = new StringList();
			relSelects.add(DomainRelationship.SELECT_ID);
			relSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
			relSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);

			Map<String, Map<String, String>> mDSFilenWMObjIDsnRefCount = new HashMap<>();
			Map<String, Map<String, Map<String, String>>> mDSFilenWMObjIDsnWmObjInfo = new HashMap<>();
			Map<String, Map<String, Object>> mDSFilenWMObjIDsnWmChildInfo = new HashMap<>();
			Map<String, Map<String, String>> mDSFilenWMObjInstanceCount = new HashMap<>();
			Map<String, String> mDSFilenNotAvailableWM = new HashMap<>();
			Map<String, String> mDSFilenMissingProgenyInstance = new HashMap<>();
			Map<String, String> mDsFileNamenHIPId = new HashMap<>();
			Map<String, String> mpDSLineageInfo = new HashMap<>();//Added for SWIMP-31 (Phase-2)
			Map<String, Map<String, Object>> mpWMHasStructure = new HashMap<>(); //Added for SWIMP-31 (Phase-2)
			Map<String, Object> mpDetectedWMIPsInfoMap = new HashMap<>(); //Added for SWIMP-568

			while (itr.hasNext()) {
				Map<String, Object> mpBasicInfo = new HashMap<>();//Added for SWIMP-31 (Phase-2)
				boolean bStructureAvailable =  false; //Added for SWIMP-31 (Phase-2)
				Map<String, String> mWMObjIdnRefCount = new HashMap<>();
				StringBuilder sblineageInfo = new StringBuilder();
				wmObjMap1 = itr.next();
				String wmObjId = wmObjMap1.get(DomainConstants.SELECT_ID);
				String sHIPProjectID = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK); //Added for SWIMP-568
				String strIMPDesignFile = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
				//Added for SWIMP-31(Phase-2) : Starts
				String sUnknownWarning = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTR_UNKNOWNWMWARNING_FROM_IPWATERMARK);
				if(UIUtil.isNotNullAndNotEmpty(strIMPDesignFile) && UIUtil.isNotNullAndNotEmpty(sUnknownWarning)) {
				String[] saArrayWMs = sUnknownWarning.split("\\n");
				String sKey = strIMPDesignFile + IMP_Constants_mxJPO.KEYSTRING_DETECTEDWM_BUTNOTFOUNDINIMP;
				StringBuilder sbUnknownWM = new StringBuilder();
				boolean isFileFound = false;
				for (String sWMs : saArrayWMs) {
					if(sKey.equals(sWMs)){
						isFileFound = true;
						sbUnknownWM.append(sKey).append("\n");
					}else if(isFileFound && !sWMs.equals("")){
						sbUnknownWM.append(sWMs).append("\n");
					}else if(isFileFound && sWMs.equals("")){
						break;
					}
				}
				sUnknownWarning = sbUnknownWM.toString();
				}
				String sMissingProgeny = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTR_MISSINGPROGENYINSTWARNING_FROM_IPWATERMARK);
				sMissingProgeny = (sMissingProgeny).contains(strIMPDesignFile) ? sMissingProgeny : "";
				//Added for SWIMP-31(Phase-2) : Ends

				StringBuilder sbGDSFileName = new StringBuilder(sgdsFileName);
				if(mlWMObjects.size()>1) {
					sbGDSFileName.append(IMP_Constants_mxJPO.SYMBOL_PIPE).append(wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE));
				} else if (UIUtil.isNotNullAndNotEmpty(sDesignFileName)) {
					sbGDSFileName.append(IMP_Constants_mxJPO.SYMBOL_PIPE).append(sDesignFileName);
				} else {
					//Added for SWIMP-31 (Phase-2)
					if (UIUtil.isNullOrEmpty(strIMPDesignFile))
						strIMPDesignFile = "single_design_file";
				}

				//Added for SWIMP-31 (Phase-2) : Starts
				String sIPRevWatermark = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
				String sIPXWatermark = wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
				mpBasicInfo.put("Project", sbGDSFileName.toString());
				mpBasicInfo.put("WMID", wmObjId);
				mpBasicInfo.put("IPID", wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID));
				mpBasicInfo.put(IPTAG, wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG));
				mpBasicInfo.put("IP_Watermark", UIUtil.isNullOrEmpty(sIPRevWatermark) ? sIPXWatermark : sIPRevWatermark);
				mpBasicInfo.put("IMP_Design_File", UIUtil.isNotNullAndNotEmpty(sDesignFileName) ? sDesignFileName
						: wmObjMap1.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE));
				//Added for SWIMP-31 (Phase-2) : Ends

				//Creating the domain object of the detected watermark
				DomainObject doIP = new DomainObject(wmObjId);
				//fetching all the child objects of the detected watermark with relationship IMP_IPVERIFICATIONSTATUSFORHIP where from side is true
				MapList wmLilst = doIP.getRelatedObjects(context, IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP , // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
						busSelects, // Object selects
						relSelects, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit

				IMP_Utility_mxJPO.getChildIPRelDetails(context, wmObjId, busSelects, relSelects); //Added for SWIMP-564

				//If the result set is not empty prepare the input for Hierarchy display
				if(!wmLilst.isEmpty()) {
					bStructureAvailable = true; //Added for SWIMP-31 (Phase-2)
					Iterator<Map<String, String>> itr1 = wmLilst.iterator();
					List<String> lsTempList = new ArrayList<>(); //Added for SWIMP-564
					Map<String, Map<String, Object>> mpIPInfo = new HashMap<>(); //Added for SWIMP-568
					while(itr1.hasNext()){
						Map<String, String> wmObjMap = itr1.next();
						String wmId = wmObjMap.get(DomainConstants.SELECT_ID);
						Map<String, Object> mWMObjectLatestRevisionAndDeclaredUseInfo = new HashMap<>(); //Added for SWIMP-568

						//Added for SWIMP-564 : Starts
						String sLineage = wmObjMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
						String sNoOfInstances = wmObjMap.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
						String sChildIPNoOfInstances = IMP_Utility_mxJPO.getChildIPRelInstanceCount(wmId, sNoOfInstances);

						if (lsTempList.contains(wmId)) {
							IMP_Utility_mxJPO.lsDetectedMultiLineage.add(wmId); //Added for SWIMP-564
						} else {
							lsTempList.add(wmId);
						}
						//Added for SWIMP-564 : Ends

						//Added for SWIMP-568 : Starts
						String sDetectedIPObjID = wmObjMap.get(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
						String sDetectedIPReleaseID = wmObjMap.get(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
						//578 Start
						String sLatestRevisionOfDetectedIP = "";
						String strBranchId = "";
							strBranchId = (String)DomainObject.newInstance(context, sDetectedIPReleaseID).getInfo(context, "to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
						if(UIUtil.isNotNullAndNotEmpty(strBranchId)){
							HashMap mpIPMap = new HashMap();
							mpIPMap.put("IPID",strBranchId);
							mpIPMap.put("isBranch",IMP_Constants_mxJPO.STR_TRUE);
							sLatestRevisionOfDetectedIP=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
							JPO.packArgs(mpIPMap), String.class);
						}
						//578 End
						String sIPDeclaredForUse = getDeclaredForUsage(context, sHIPProjectID, sDetectedIPReleaseID);
						mWMObjectLatestRevisionAndDeclaredUseInfo.put(IMP_Constants_mxJPO.KEY_LATESTREVISION, sLatestRevisionOfDetectedIP);
						mWMObjectLatestRevisionAndDeclaredUseInfo.put(IMP_Constants_mxJPO.KEY_DECLARED_FOR_USE, sIPDeclaredForUse);
						mWMObjectLatestRevisionAndDeclaredUseInfo.put(IMP_Constants_mxJPO.KEY_DEPRECATED_BY, IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, sDetectedIPObjID));
						mpIPInfo.put(wmId, mWMObjectLatestRevisionAndDeclaredUseInfo);

						if (wmObjMap.containsKey(wmId)) {
							int count = Integer.parseInt(wmObjMap.get(wmId)) + Integer.parseInt(sChildIPNoOfInstances); //Modified for SWIMP-564
							mWMObjIdnRefCount.put(wmId, String.valueOf(count));
						} else {
							mWMObjIdnRefCount.put(wmId, sChildIPNoOfInstances); //Modified for SWIMP-564
						}
						sblineageInfo.append(wmId).append(IMP_Constants_mxJPO.SYMBOL_CARET)
						.append(sLineage)
						.append(IMP_Constants_mxJPO.SYMBOL_CARET)
						.append(sNoOfInstances)
						.append("$");
					}
					Map<String, String> mOrigWMObjIdnRefCount = new HashMap<>(mWMObjIdnRefCount);
					List<String> lAllWmObjIdinaDSFile = new ArrayList<>(mWMObjIdnRefCount.keySet());
					Map<String, Map<String, String>> mWMObjInfo = IMP_Utility_mxJPO.getWMObjectInfo(context,
							lAllWmObjIdinaDSFile);
					Map<String, Object> mWMChildInfo = IMP_Utility_mxJPO.getWMObjectChildInfo(context,
							lAllWmObjIdinaDSFile, mWMObjInfo, mWMObjIdnRefCount, strOperation); //Modified for SWIMP-564

					mDSFilenWMObjIDsnRefCount.put(sbGDSFileName.toString(), mWMObjIdnRefCount);
					mDSFilenWMObjIDsnWmObjInfo.put(sbGDSFileName.toString(), mWMObjInfo);
					mDSFilenWMObjIDsnWmChildInfo.put(sbGDSFileName.toString(), mWMChildInfo);
					mDSFilenWMObjInstanceCount.put(sbGDSFileName.toString(), mOrigWMObjIdnRefCount);
					mDSFilenNotAvailableWM.put(sbGDSFileName.toString(), sUnknownWarning);//Added for SWIMP-31 (Phase-2)
					mDSFilenMissingProgenyInstance.put(sbGDSFileName.toString(), sMissingProgeny);//Added for SWIMP-31 (Phase-2)
					mDsFileNamenHIPId.put(sbGDSFileName.toString(),wmObjId);
					if (sblineageInfo.toString().endsWith("$")) {
						sblineageInfo.deleteCharAt(sblineageInfo.length() - 1);
					}
					mpDSLineageInfo.put(sbGDSFileName.toString(), sblineageInfo.toString());//Added for SWIMP-31 (Phase-2)
					mpDetectedWMIPsInfoMap.put(sbGDSFileName.toString(), mpIPInfo); //Added for SWIMP-568
				}
				IMP_Utility_mxJPO.mpReturnInstanceCountMap.clear(); //Added for SWIMP-564
				IMP_Utility_mxJPO.lsDetectedMultiLineage.clear(); //Added for SWIMP-564
				//Added for SWIMP-31 (Phase-2) : Starts
				mpBasicInfo.put(IMP_Constants_mxJPO.KEY_HASSTRUCTURE, bStructureAvailable);
				mpWMHasStructure.put(strIMPDesignFile, mpBasicInfo);
				//Added for SWIMP-31 (Phase-2) : Ends
			}
			returnMap.put(IMP_Constants_mxJPO.KEY_REF_COUNTMAP, mDSFilenWMObjIDsnRefCount);
			returnMap.put(IMP_Constants_mxJPO.KEY_WMOBJ_INFOMAP, mDSFilenWMObjIDsnWmObjInfo);
			returnMap.put(IMP_Constants_mxJPO.KEY_WMCHILD_INFOMAP, mDSFilenWMObjIDsnWmChildInfo);
			returnMap.put(IMP_Constants_mxJPO.KEY_ORIGINALCOUNT, mDSFilenWMObjInstanceCount);
			returnMap.put(IMP_Constants_mxJPO.KEY_NOT_AVAILABLE_WM, mDSFilenNotAvailableWM);
			returnMap.put(IMP_Constants_mxJPO.KEY_MISSINGPROGENY, mDSFilenMissingProgenyInstance);
			returnMap.put(IMP_Constants_mxJPO.KEY_META_DATA_INPUT, mDsFileNamenHIPId);
			returnMap.put(IMP_Constants_mxJPO.KEY_LINEAGEINFO, mpDSLineageInfo);//Added for SWIMP-31 (Phase-2)
			returnMap.put(IMP_Constants_mxJPO.KEY_WM_BASIC_INFO, mpWMHasStructure);//Added for SWIMP-31 (Phase-2)
			returnMap.put(IMP_Constants_mxJPO.KEY_DETECTED_IP_INFO, mpDetectedWMIPsInfoMap);//Added for SWIMP-568

			//Added for SWIMP-570 : Starts
			if (IMP_Constants_mxJPO.EVENTOPERATION_QUERY.equalsIgnoreCase(strOperation)) {
				Map<String, Object> mpVRInfo = getLatestNonDryRunVerifyObjectDetails(context, IMP_Constants_mxJPO.STR_HIP, sProjectName, sTag);
				returnMap.put(IMP_Constants_mxJPO.KEY_QUERY_CONSUMED_IPS_VRINFO, mpVRInfo);
			}
			//Added for SWIMP-570 : Ends
		} else {
			returnMap.put(IMP_Constants_mxJPO.KEY_REF_COUNTMAP, null);
		}
		return returnMap;
	}
	//Modified for SWIMP-31(Phase-2) : Ends
	// Added for SWIMP-31: Ends


	//Added for SWIMP-568 : Starts
	/**
	 * This method is to get the latest revision of an IP.
	 *
	 * @param context, the context
	 * @param sIPObjId, the IP Object ID
	 * @returns String, the latest revision of the given IP
	 * @throws MatrixException/ParseException, if method fails
	 */
	@SuppressWarnings("unchecked")
	public static String getLatestRevisionofIP(Context context, String sIPObjId) throws MatrixException, ParseException {

		String sIPLatestRevision = "";
		try {
			SimpleDateFormat formatter =
					new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);
			String sOriginated = "";
			Date date = null;
			TreeMap<Date, Object> mpLatestTagData = new TreeMap<>(Collections.reverseOrder());
			DomainObject domIPObj = DomainObject.newInstance(context, sIPObjId);
			Pattern relPattern = new matrix.util.Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);

			Pattern typePattern = new matrix.util.Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);

			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_CURRENT);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			slObjSelects.add(DomainConstants.SELECT_ORIGINATED);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);

			String sWhere = "current==Active";

			MapList mlRevList = domIPObj.getRelatedObjects(context, relPattern.getPattern(), // relationship pattern
					typePattern.getPattern(), // type pattern
					false, // from
					true, // to
					(short) 3, // expand level
					slObjSelects, // Object selects
					null, // relationship selects
					sWhere, // object where
					null, // relationship where
					0, // limit
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // postRelPattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // postTypePattern
					null); // postPatterns


			if (!mlRevList.isEmpty()) {
				Iterator<Map<String, Object>> objectListItr = mlRevList.iterator();
				Map<String, Object> mpRev;
				String sRevTag = "";
				String sType = "";

				while (objectListItr.hasNext()) {
					mpRev = objectListItr.next();
					sType = (String) mpRev.get(DomainConstants.SELECT_TYPE);
					if (UIUtil.isNotNullAndNotEmpty(sType) && IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equalsIgnoreCase(sType)) {
						sRevTag = (String) mpRev.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
						if (UIUtil.isNotNullAndNotEmpty(sRevTag) && !"Other Top Branches".equals(sRevTag)) {
							sOriginated = (String) mpRev.get(DomainConstants.SELECT_ORIGINATED);
							date = formatter.parse(sOriginated);
							mpLatestTagData.put(date, sRevTag);
						}
					}
				}
			}

			for (Map.Entry<Date, Object> entry : mpLatestTagData.entrySet()) {
				sIPLatestRevision = (String) entry.getValue();
				break;
			}


		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPReleaseUtil_mxJPO : getLatestRevisionofIP" + me);
		}
		return sIPLatestRevision;
	}


	/**
	 * This method is to check and get if the revision is declared for the usage.
	 *
	 * @param context, the context
	 * @param sProjectID, the HIP/SOC object ID
	 * @param sDetectedIPReleaseID, the Revision object ID
	 * @returns String, Yes or No
	 * @throws MatrixException, if method fails
	 */
	public String getDeclaredForUsage(Context context, String sProjectID, String sDetectedIPReleaseID) throws MatrixException {
		String sIsRevisionDeclaredForUse = IMP_Constants_mxJPO.STR_NO;
		IMP_IPVerification_mxJPO classIMPIPVerificationJPO = new IMP_IPVerification_mxJPO();
		MapList mlLogicalProducts = classIMPIPVerificationJPO.getLogicalProducts(context, sProjectID);
		if (UIUtil.isNotNullAndNotEmpty(sProjectID) && !mlLogicalProducts.isEmpty() && UIUtil.isNotNullAndNotEmpty(sDetectedIPReleaseID)) {
			sIsRevisionDeclaredForUse = IMP_IPProductUtil_mxJPO.getDeclared(context, sDetectedIPReleaseID, mlLogicalProducts, "CLI");
		}
		return sIsRevisionDeclaredForUse;
	}
	//Added for SWIMP-568 : Ends


	//Added for SWIMP-570 : Starts
	/**
	 * This method is to get the latest non-dry run verify information for SoC or HIP.
	 * Added for SWIMP-570
	 *
	 * @param context, the context
	 * @param sProjectType, the object type, SoC or HIP
	 * @param sProjectName, the name of the project
	 * @param sTag, the Revision tag
	 * @returns Map, Latest Non-DryRun VerifyRun information for the Project
	 * @throws MatrixException, if method fails
	 */
	private Map<String, Object> getLatestNonDryRunVerifyObjectDetails(Context context, String sProjectType,
			String sProjectName, String sTag) throws MatrixException, Exception {
		String sVerifyRunObject = "";
		String sVerifyRunObjectID = "";
		String sVerifyRunObjectOwner = "";
		String sSoCorHIPWMID = "";
		Map<String, Object> mpVerifyRunInfo = new HashMap<>();
		StringList slObjSelects = new StringList(DomainConstants.SELECT_ID);
		if (IMP_Constants_mxJPO.STR_HIP.equalsIgnoreCase(sProjectType)) {
			StringBuilder sbWhere = new StringBuilder();
			sbWhere.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG).append("=='").append(sTag).append("'&&")
			.append(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPID).append("=='").append(sProjectName).append("'");
			MapList mlWMObjects = IMP_Utility_mxJPO.impFindObjects(context, IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, sbWhere.toString(), slObjSelects, 0); //Modified for SWIMP-824
			if (!mlWMObjects.isEmpty()) {
				Map<String, String> mpTemp = (Map<String, String>) mlWMObjects.get(0);
				sSoCorHIPWMID = mpTemp.get(DomainConstants.SELECT_ID);
			}
		} else {
			sProjectType = IMP_Constants_mxJPO.TYPE_IMP_SOC;
			BusinessObject boProject = new BusinessObject(sProjectType, //Type
					sProjectName, //Name
					"", //Revision
					IMP_Constants_mxJPO.PROD_VAULT); //Vault
			if(boProject.exists(context)) {
				boProject.open(context);
				sSoCorHIPWMID = DomainObject.newInstance(context, boProject).getInfo(context, DomainConstants.SELECT_ID);
			}
		}

		//get Latest non-dry-run Verifyrun
		StringList slBusSelects = new StringList();
		slBusSelects.add(DomainConstants.SELECT_NAME);
		slBusSelects.add(DomainConstants.SELECT_ID);
		slBusSelects.add(DomainConstants.SELECT_ORIGINATED);
		slBusSelects.add(DomainConstants.SELECT_OWNER);
		String sWhereOnBus = IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DRYRUN + IMP_Constants_mxJPO.EQUALS_APOSTROPHE
				+ IMP_Constants_mxJPO.STR_NO + IMP_Constants_mxJPO.APOSTROPHE;
		String sRelationshipPattern = (IMP_Constants_mxJPO.TYPE_IMP_SOC).equals(sProjectType)
				? IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_FORSOC
						: IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUNFORHIP;

		try {
			MapList mlVerifyRunObjects = DomainObject.newInstance(context, sSoCorHIPWMID).getRelatedObjects(
					context, sRelationshipPattern, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, // type pattern
					slBusSelects, // Object selects
					null, // relationship selects
					true, // from
					false, // to
					(short) 0, // expand level
					sWhereOnBus, // object where
					null, // relationship where
					0);// limit

			mlVerifyRunObjects.sort(DomainConstants.SELECT_ORIGINATED, IMP_Constants_mxJPO.SORTORDER_DESCENDING, IMP_Constants_mxJPO.SORTORDER_KEYDATE);
			if (!mlVerifyRunObjects.isEmpty()) {
				Map<String, String> mpVR = (Map<String, String>) mlVerifyRunObjects.get(0);
				sVerifyRunObject = mpVR.get(DomainConstants.SELECT_NAME);
				sVerifyRunObjectID = mpVR.get(DomainConstants.SELECT_ID);
				sVerifyRunObjectOwner = mpVR.get(DomainConstants.SELECT_OWNER);
				mpVerifyRunInfo.put(IMP_Constants_mxJPO.KEY_VERIFYRUN_NAME, sVerifyRunObject);
				mpVerifyRunInfo.put(IMP_Constants_mxJPO.KEY_VERIFYRUN_OBJID, sVerifyRunObjectID);
				mpVerifyRunInfo.put(IMP_Constants_mxJPO.KEY_VERIFYRUN_OWNER, sVerifyRunObjectOwner);
			}
		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPReleaseUtil_mxJPO:getLatestNonDryRunVerifyObjectDetails: " + me);
		}
		return mpVerifyRunInfo;
	}


	/**
	 * This method is to get the SoC IP Hierarchy structure detected in latest non-dry run verify run.
	 * Added for SWIMP-570
	 *
	 * @param context, the context
	 * @param args, holds Project name, Project ID and Event operation
	 * @throws Exception
	 * @returns Map, which contains all the detected Watermark information for the latest Non-DryRun verify run
	 */
	public Map<String, Map> getSoCHierarchyStructure(Context context, String[] args) throws Exception {
		HashMap hmData = JPO.unpackArgs(args);
		String sProjectName = (String) hmData.get(IMP_Constants_mxJPO.STR_PROJECT_NAME);
		String sProjectID = (String) hmData.get(IMP_Constants_mxJPO.KEY_ID);
		sCLIOperation = (String) hmData.get(IMP_Constants_mxJPO.KEY_OPERATION);
		Map<String, String> mpWMStrings = new HashMap<>();
		try {
			mpQueryConsumedIPsMap = getLatestNonDryRunVerifyObjectDetails(context, IMP_Constants_mxJPO.STR_SOC, sProjectName, "");
			if (!mpQueryConsumedIPsMap.isEmpty()) {
				String sVerifyObjectId = (String) mpQueryConsumedIPsMap.get(IMP_Constants_mxJPO.KEY_VERIFYRUN_OBJID);

				DomainObject doVerifyRun = new DomainObject(sVerifyObjectId);
				StringList slBusSelects = new StringList(DomainObject.SELECT_ID);
				slBusSelects.add(DomainObject.SELECT_NAME);
				slBusSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
				slBusSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
				slBusSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DESIGN_FILE);
				StringList slRelSelects = new StringList(DomainRelationship.SELECT_ID);
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
				MapList mplWMFromVR = doVerifyRun.getRelatedObjects(context, IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS , // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
						slBusSelects, // Object selects
						slRelSelects, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0);

				if (!mplWMFromVR.isEmpty()) {
					String sIPWatermarkID = "";
					String sIPRevisionWatermark = "";
					String sIPXWatermark = "";
					String sIMPNoOfInstances = "";
					String sWatermarkValue = "";

					Map<String, Object> mpWatermarkInfo = new HashMap<>();
					Iterator<Map<String, String>> itrVerifyRunInfo = mplWMFromVR.iterator();
					while (itrVerifyRunInfo.hasNext()) {
						Map<String, String> mpVerifyRun = itrVerifyRunInfo.next();
						sIPWatermarkID = mpVerifyRun.get(DomainObject.SELECT_ID);
						sIPRevisionWatermark = mpVerifyRun.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPREVISIONWATERMARK);
						sIPXWatermark = mpVerifyRun.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPXWATERMARK);
						sIMPNoOfInstances = mpVerifyRun.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
						sWatermarkValue = UIUtil.isNotNullAndNotEmpty(sIPRevisionWatermark) ? sIPRevisionWatermark : "IPXWM-" + sIPXWatermark;

						Map<String, Object> mWMInstanceMap = new HashMap<>();
						if (mpWatermarkInfo.containsKey(sIPWatermarkID)) {
							Map<String, Object> mpTempMap = (Map<String, Object>) mpWatermarkInfo.get(sIPWatermarkID);
							String sWatermarkString = (String) mpTempMap.get(IMP_Constants_mxJPO.KEY_WATERMARK);
							int iPreviousInstanceCount = (int) mpTempMap.get(IMP_Constants_mxJPO.KEY_INSTANCES);
							int iNewInstanceCount = Integer.parseInt(sIMPNoOfInstances) + iPreviousInstanceCount;
							mpTempMap.put(IMP_Constants_mxJPO.KEY_INSTANCES, iNewInstanceCount);
							mpTempMap.put(IMP_Constants_mxJPO.KEY_WATERMARK, sWatermarkString);
							mpWatermarkInfo.remove(sIPWatermarkID);
							mpWatermarkInfo.put(sIPWatermarkID, mpTempMap);
						} else {
							mWMInstanceMap.put(IMP_Constants_mxJPO.KEY_INSTANCES, Integer.parseInt(sIMPNoOfInstances));
							mWMInstanceMap.put(IMP_Constants_mxJPO.KEY_WATERMARK, sWatermarkValue);
							mpWatermarkInfo.put(sIPWatermarkID, mWMInstanceMap);
						}
					}

					StringBuilder sbWMs = new StringBuilder();
					if (!mpWatermarkInfo.isEmpty()) {
						Set<String> stKeys = mpWatermarkInfo.keySet();
						for (String sKey : stKeys) {
							String sWMValue = (String) ((Map<String, Object>) mpWatermarkInfo.get(sKey)).get(IMP_Constants_mxJPO.KEY_WATERMARK);
							int iInstances = (int) ((Map<String, Object>) mpWatermarkInfo.get(sKey)).get(IMP_Constants_mxJPO.KEY_INSTANCES);
							String sRefCountWatermark = String.valueOf(iInstances) + "-RF-" + sWMValue;
							if (UIUtil.isNotNullAndNotEmpty(sbWMs.toString())) {
								sbWMs.append(",").append(sRefCountWatermark);
							} else {
								sbWMs.append(sRefCountWatermark);
							}
						}
					}
					mpWMStrings.put(sProjectName, sbWMs.toString());
				}
			}
		} catch (MatrixException me) {
			throw new MatrixException ("Exception in the method IMP_IPReleaseUtil:getSoCHierarchyStructure: " + me);
		}
		return getSoCHIPStructure(context, mpWMStrings, sProjectID);
	}
	//Added for SWIMP-570 : Ends

    // Added for SWIMP-512 : Starts
		/**
		 * This method checks whether the IMP_IPRelease object is set as Default or
		 * Recommended if yes then the Promotion will get blocked.
		 * @param context the eMatrix <code>Context</code> object
		 * @param sReleaseID   holds IP Release object id
		 * @throws FrameworkException
		 * @returns integer
		 */
		public static int isRevisionDefaultOrRecommended(Context context, String[] args) throws FrameworkException  {
			int iReturn = 0;
			String sReleaseID = args[0];

			StringList slObjSelects = new StringList(3);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_DEFAULT_REVISION_FROM_RELEASE);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_RECOMMENDED_REVISION_FROM_RELEASE);
			Map<String, String> mpReleaseData = null;
			try {
				mpReleaseData = DomainObject.newInstance(context, sReleaseID).getInfo(context, slObjSelects);
				String sIPDefaultRevision = mpReleaseData.get(IMP_Constants_mxJPO.SELECT_DEFAULT_REVISION_FROM_RELEASE);
				String sBranchRecommendedRevision = mpReleaseData.get(IMP_Constants_mxJPO.SELECT_RECOMMENDED_REVISION_FROM_RELEASE);
				String sIPTagName = mpReleaseData.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPTAG);
				if (UIUtil.isNotNullAndNotEmpty(sIPTagName) && (sIPTagName.equalsIgnoreCase(sIPDefaultRevision) || sIPTagName.equalsIgnoreCase(sBranchRecommendedRevision))) {
					MqlUtil.mqlCommand(context, false, "Notice " + IMP_Constants_mxJPO.DEFAULT_OR_RECOMMENDED_IP_RELEASE_CANNOT_BE_PROMOTED,false);
					iReturn = 1;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new FrameworkException(ex);
			}
			return iReturn;
		}
		//Added for SWIMP-512 : Ends
		
	  //Added for SWIMP-848: Starts
	  /**
		 * This method checks whether the TechStack is same for HIP
		 * SOC and IP for verify-ip call for createVerificationMetaData
		 * from webservice endpoint.
		 * @param context the eMatrix <code>Context</code> object
		 * @param ProjectID and IPID
		 * @throws Exception
		 * @returns boolean
	  */
	public boolean isWebServiceSocHIPIPTechStackSame(Context context, String[] args) throws Exception {
    boolean isSame = false;
	if(context==null){
		throw new IllegalArgumentException("Context must not be null");
	}
	try {
		@SuppressWarnings("unchecked")
		Map hmData = (Map) JPO.unpackArgs(args);
		String sProjectID = hmData.get("ProjectID") != null ? hmData.get("ProjectID").toString().trim() : "";
		String sIPID = hmData.get("IPProductID") != null ? hmData.get("IPProductID").toString().trim() : "";
		if (sProjectID.isEmpty() || sIPID.isEmpty()) {
			throw new IllegalArgumentException("Missing required argument(s): ProjectID or IPProductID");
		}
		// call to existing helper method (assumed to be defined elsewhere)
		isSame = isSocHIPIPTechStackSame(context, sProjectID, sIPID);
	} catch(Exception e){
		// Chain the original exception so stacktrace is preserved
		throw new Exception("Exception occurred in IMP_IPReleaseUtil_mxJPO:isWebServiceSocHIPIPTechStackSame", e);
	}
	return isSame;
}
//Added for SWIMP-848: Ends
	
//Added for SWIMP-882: Starts
	private Map getSSGQICfgYamlUpLoadStatus(Context context, String sUserName, String ipName, String sTag, String sFTPSSGQICfgPath, String sFTPSSGQICfgFileName) throws Exception {
	HashMap hmUpdateData = new HashMap();
	try {
		  hmUpdateData.put("sUser", sUserName);
		  hmUpdateData.put("sIPName", ipName);
		  hmUpdateData.put("sTag", sTag);
		  hmUpdateData.put("sSSGQICfgPath", sFTPSSGQICfgPath);
		  hmUpdateData.put("sSSGQICfgFile", sFTPSSGQICfgFileName);
		  Map mpReturnData = JPO.invoke(context, "IMP_IPVerification", null, "checkinSSGQICfgYamlToIMP",
				  JPO.packArgs(hmUpdateData), Map.class);
		  String sSSGQIUpLoadStatus = (String) mpReturnData.get("SSGQI Status");
		  String sSSGQIUploadFileName = (String) mpReturnData.get("SSGQI FileName");
		  hmUpdateData.put("SSGQI Status", sSSGQIUpLoadStatus);
		  hmUpdateData.put("SSGQI FileName", sSSGQIUploadFileName);
	} catch (Exception e) {
		  e.printStackTrace();
	}
	  return hmUpdateData;
   }
//Added for SWIMP-882: Ends
}
