
/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : IMP_IPVerification.java
 * 
 * DESCRIPTION  : This program contains utility IP Verification flow
 *        
 * CREATED      : 10-OCT-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * History
 * Modified By				Modified On			Description
 * Mahammed Irshad K S		19-May-2020			Modified methods getIPVerifications, displayIPReleaseObjects, getVerifyRelID, updateVerifyRunAppInfo, 
 * 												getVerifyRunRevisions, getVerifyRunWMs, getStatusWithIcon and getComments for SWIMP-322
 * Mahammed Irshad K S		25-Aug-2020			Modified the method updateVerifyRunAppInfo for SWIMP-500
 * Mahammed Irshad K S		02-Jul-2021			Modified the method updateAuditRecords and added connectAuditRecordsAndUpdateHistory & mqlHistoryOff for SWIMP-576
 *------------------------------------------------------------------------------------------------------------------------------------------
 */

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.nio.file.*;
import java.util.TreeMap;
import java.util.Vector;
import java.util.List; //Added for SWIMP-31 (Phase-2)
import java.util.Map.Entry;
import java.util.Hashtable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.matrixone.apps.common.MultipleOwner;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException; //Added for SWIMP-322
import matrix.util.Pattern;//Added for SWIMP-31
import matrix.util.StringList;
import matrix.db.RelationshipType; // Added for SWIMP-882

import org.apache.log4j.Logger;// Added for SWIMP-882
import matrix.db.BusinessInterface; // Added for SWIMP-882
import matrix.db.Environment; // Added for SWIMP-882
import matrix.db.MQLCommand; // Added for SWIMP-882





import java.util.UUID;



import org.apache.commons.lang.StringUtils;



import matrix.db.JPO;



import matrix.util.StringList;










public class IMP_IPVerification_mxJPO {
	/** A string constant with the value emxSemiTeamCollabStringResource. */
	private static final String RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR = "emxSemiTeamCollabStringResource";
	private static String sMessage = "Message";
	public static final String INPUT_HIDDEN_TAG = "<input type='hidden' name='";
	//SWIMP-231
	protected static final	Map<String , String> ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE = new HashMap<>();
					
			static {
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED, "1");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED, "2");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING, "3");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED, "4");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED, "5");
				ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN, "6");
			}
			//Added For SWIMP-231: End
	//Added for SWIMP-882
	private static Logger logger = Logger.getLogger(IMP_IPVerification_mxJPO.class);
	private static String sSSGQIStatus = "SSGQI Status";
	private static String sSSGQFileName = "SSGQI FileName";
	//Added for SWIMP-882
	/**
	 * This method is executed if a specific method is not specified.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds no arguments
	 * @returns nothing
	 * @throws Exception if the operation fails
	 */

	public int mxMain(Context context, String[] args) throws Exception {
		if (!context.isContextSet())
			throw new Exception("must specify method on IMP_SoC invocation");
		return 0;
	}

	/**Modified for SWIMP-321
	 * Method added for get the connected verify objects from SoC
	 * Modified method for SWIMP-322
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the objectID
	 * @return MapList
	 * @throws Exception if the operations fails
	 */

	@SuppressWarnings("rawtypes")
	public static MapList getIPVerifications(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		String parentOID = (String) programMap.get("parentOID");
		DomainObject masterObject = new DomainObject(parentOID);
		MapList mlVerifyObjList = new MapList();
		//Added for SWIMP-31 Start
		if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(masterObject.getInfo(context, DomainConstants.SELECT_TYPE))) {
			//Added for SWIMP-31 End
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(DomainConstants.SELECT_CURRENT);
			objectSelects.add(DomainConstants.SELECT_ORIGINATED);
			// Modified for user story 224
			objectSelects.add(DomainConstants.SELECT_OWNER);
			objectSelects.add("attribute[IMP_Status].value");
			objectSelects.add("attribute[IMP_DryRun].value");
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			objectSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
			//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs': Starts
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.attribute[IMP_IPTag]");
			objectSelects.add("from[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS + "].to.to["+ IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.to["
					+ IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH + "].from.name");
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.id");
			objectSelects.add("from["+IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS+"].to.type");

			mlVerifyObjList = masterObject.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_FORSOC, IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, objectSelects, null, true, false,
					(short) 1, null, null, 0);
		}
		else {
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			slObjSelects.add(DomainConstants.SELECT_NAME);
			slObjSelects.add(DomainConstants.SELECT_TYPE);
			
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			slObjSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
			
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUNFORHIP);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN);

			MapList mlVerifyRunList = masterObject.getRelatedObjects(context,
					relPattern.getPattern(), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					null, // relationship selects
					true, // from
					true, // to
					(short) 4, // expand level
					null, // object where
					null, // relationship where
					0); // limit

			if (!mlVerifyRunList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlVerifyRunList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId;
				String strVerifyRunType;
				StringList slIMPVerifyIdsDuplicateCheck = new StringList();
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
					strVerifyRunType = mapVerifyRun.get(DomainConstants.SELECT_TYPE);
					if (IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN.equalsIgnoreCase(strVerifyRunType)  && !slIMPVerifyIdsDuplicateCheck.contains(strVerifyRunId)) {
						slIMPVerifyIdsDuplicateCheck.add(strVerifyRunId);
						mlVerifyObjList.add(mapVerifyRun);
					}
				}
			}
		}
		//Added for SWIMP-31 End

		//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs': Ends
		mlVerifyObjList.sortStructure(DomainConstants.SELECT_NAME, "descending", "string");

		return mlVerifyObjList;

	}

	/**
	 * Method for passing the verify object ID to Release object table
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return Vector
	 * @throws Exception if the operations fails
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getIPReleaseObjects(Context context, String args[]) throws Exception {
		Vector returnVector = new Vector();
		StringBuilder strTableColBuilder = new StringBuilder();
		HashMap programMap = JPO.unpackArgs(args);

		Map mlParamList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sSoCObjId = (String) mlParamList.get("objectId");
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();

		Iterator itrVerifyObjects = verifyMapList.iterator();
		String sTabHeader = EnoviaResourceBundle.getProperty(context, RESOURCE_BUNDLE_SEMITEAMCOLLAB_STR, context.getLocale(), "imp.emxSemiTeamCollab.command.IMP_IPReleaseObjects");

		for (int i = 0; i < iSize; i++) {
			Map map = (Map) itrVerifyObjects.next();
			String strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
			DomainObject db = new DomainObject(strVerifyID);
			String strVerifyName = db.getInfo(context, DomainConstants.SELECT_NAME);
			//Modification for "in chrome clicking on the IP verificaion verify id the page goes up and contents are hidden" Starts
			strTableColBuilder.append("<a onClick=\"highlight(this);\" href=\"javascript:showReleaseObjects('" + strVerifyID + "')\"; title=name>" +strVerifyName + "</a>");
			//Modification for "in chrome clicking on the IP verificaion verify id the page goes up and contents are hidden" Ends
			if (i == iSize - 1) {
				strTableColBuilder.append("<script>");
				strTableColBuilder.append("function showReleaseObjects(VerifyID) { ");
				strTableColBuilder.append("window.parent.parent.frames[1].location.href=");
				strTableColBuilder.append(
						"'../common/emxTable.jsp?table=IMP_IPReleaseSummaryTable&program=IMP_IPVerification:displayIPReleaseObjects&portalMode=true&hideLaunchButton=false&sortColumnName=Status");
				strTableColBuilder.append("&sortDirection=ascending&selection=multiple&toolbar=IMP_SoCIPApprovalToolbar");
				strTableColBuilder.append("&header="+sTabHeader);
				strTableColBuilder.append("&VerifyID='+VerifyID");

				strTableColBuilder.append("+'&objectId=" + sSoCObjId);
				strTableColBuilder.append("';");
				strTableColBuilder.append("}");

				strTableColBuilder.append("function highlight(ctrl) { ");
				strTableColBuilder.append("var table = document.getElementById('IMP_IPVerificationSummaryTable');");
				strTableColBuilder.append("for (var i = 0; i<table.rows.length; i++) {");
				strTableColBuilder.append("var trClassName = table.rows[i].className;");
				strTableColBuilder.append("if(trClassName != '' && trClassName.includes('IMP_highlight')) {");
				strTableColBuilder.append("var newClassName = trClassName.replace(' IMP_highlight', '');");
				strTableColBuilder.append("table.rows[i].className = newClassName;");
				strTableColBuilder.append("}");
				strTableColBuilder.append("}");
				strTableColBuilder.append("ctrl.parentNode.parentNode.className = ctrl.parentNode.parentNode.className+' IMP_highlight';");
				strTableColBuilder.append("}");

				strTableColBuilder.append("</script>");

				strTableColBuilder.append("<style>");
				strTableColBuilder.append("tr.IMP_highlight {");
				strTableColBuilder.append("font-weight: bold;");
				strTableColBuilder.append("}");
				strTableColBuilder.append("</style>");

			}
			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
		return returnVector;
	}

	/**
	 * method to show the IP revisions connected to Verification objects as part of Verify run
	 * Modified for SWIMP-31 (Phase-2)
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return MapList
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList displayIPReleaseObjects(Context context, String[] args) throws FrameworkException {
		//Modified For SWIMP-531 Starts
		MapList objReturnList = new MapList();
		MapList mlFinalLPConnectedObjects = new MapList();
		//Modified For SWIMP-531 Ends
		try {
			HashMap programMap = JPO.unpackArgs(args);
			//Modified key VerifyID with constant, for SWIMP-322
			if (programMap.containsKey(IMP_Constants_mxJPO.KEY_VERIFYID)) {
				String strVerifyID = (String) programMap.get(IMP_Constants_mxJPO.KEY_VERIFYID);
				StringList objectSelects = new StringList();
				objectSelects.add(DomainConstants.SELECT_ID);
				objectSelects.add(DomainConstants.SELECT_NAME);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_WATERMARK);
				objectSelects.add(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_VERIFYRUN);   //Added for SWIMP-541
				//Modified For SWIMP-31 Starts
				StringList slRelSelects = new StringList();
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
				slRelSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS); //Added for SWIMP-31 (Phase-2)
				slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES); //Added for SWIMP-31 (Phase-2)
				
				//Modified For SWIMP-31 Ends

				DomainObject domVerifyObj = new DomainObject(strVerifyID);

				//Modified for SWIMP-322: Replaced existing relationship 'IMP_VerifyRun' with relationship 'IMP_VerifyRunDetectedIPs'
				MapList mReturnMap = domVerifyObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
						objectSelects, // Object selects
						slRelSelects, // relationship selects 	//Added For SWIMP-31
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit
				//Modified For SWIMP-531 Starts
				if(!mReturnMap.isEmpty()) {
					Map mapProject;
					mlFinalLPConnectedObjects = getLogicalProducts(context,(String) programMap.get(IMP_Constants_mxJPO.OBJECTID));
					Iterator<Map<String,String>> objectListItr = mReturnMap.iterator();
					while (objectListItr.hasNext()) {
						mapProject = objectListItr.next();
						mapProject.put("allConnectedLogicalProducts",mlFinalLPConnectedObjects);

						objReturnList.add(IMP_Utility_mxJPO.getAccessMap(context, (String) mapProject.get(IMP_Constants_mxJPO.SELECT_IP_ID_FROM_VERIFYRUN),mapProject));  //Added for SWIMP-541
					}
				}
				//Modified For SWIMP-531 Ends
			}
		}
		catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return objReturnList;
	}
	
	/**
	 * method to get the owner of the verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Vector getVerificationSubBy(Context context, String[] args) throws Exception {
		Vector lSubmittedBy = new Vector();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator objectListItr = relBusObjPageList.iterator();
			Map mVerify;
			String strObjectId;
			DomainObject domVerifyObj;
			String sOwner;
			while (objectListItr.hasNext()) {
				mVerify = (Map) objectListItr.next();
				strObjectId = (String) mVerify.get(DomainConstants.SELECT_ID);
				domVerifyObj = DomainObject.newInstance(context, strObjectId);
				sOwner = domVerifyObj.getInfo(context, DomainConstants.SELECT_OWNER);
				if (sOwner != null && sOwner.length() > 0) {
					lSubmittedBy.add(PersonUtil.getFullName(context, sOwner));
				} else {
					lSubmittedBy.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lSubmittedBy;

	}

	/**
	 * This method gets the name of the IP for the IP Revision table in IP Verification
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getName(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");

		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		HashMap paramMap = (HashMap) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sReportFormat = (String) paramMap.get("reportFormat");
		Vector lName = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		String sURL;
		String sIPObjId;
		StringBuilder sbOutput = new StringBuilder();

        try {
            Map mapProject = null;
            while (objectListItr.hasNext()) {
                mapProject = (Map) objectListItr.next();
                String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
                DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
                String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
                String sDesignFileName = domWMObj.getInfo(context, "attribute[IMP_Design_File]");
                DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
                String strName = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.name");
                sIPObjId = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.id");
                StringList slWMObjs = domRevObj.getInfoList(context, "from[IMP_IP_Watermark].to.name");
                if (slWMObjs.size() > 1)
                    sDesignFileName = "/"+sDesignFileName;
                else
                    sDesignFileName = "";
            //Added for SWIMP-1 ends
				if (UIUtil.isNullOrEmpty(strName)) {
					ContextUtil.pushContext(context);
					strName = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.name");
					if (UIUtil.isNotNullAndNotEmpty(strName)) {
						lName.add(strName);
					} else {
						lName.add("");
					}
					ContextUtil.popContext(context);
				} else {
					if (UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
						lName.add(strName);
					} else {
						sURL = "../common/emxTree.jsp?objectId=" + sIPObjId + "&DefaultCategory=IMP_IPSOCsLink";
                        sbOutput.append("<a href=\"javascript:showNonModalDialog('" + sURL + "',800,600)\">" + strName + sDesignFileName + "</a>");//Modified for SWIMP-1
						lName.add(sbOutput.toString());
						sbOutput.setLength(0);
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("Error getting the IP ID for the detected revision " + e);
		}
		return lName;
	}

	/**
	 * This method gets the approval/rejection comments for IP Verification requests
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the verify objectID
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getComments(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector lApprovalComments = new Vector();

		String sRevObjId;
		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sVerifyObjId = (String) paramList.get("VerifyID"); 
		Map mapProject;
		String strApprovalComments;
		String sVerifyRelId;

		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			sRevObjId = (String) mapProject.get(DomainConstants.SELECT_ID);
			sVerifyRelId = getVerifyRelID(context, sVerifyObjId, sRevObjId);
			DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
			domVerifyRel.open(context);
			strApprovalComments = domVerifyRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS);//Modified for SWIMP-322 Replaced the old attribute
			domVerifyRel.close(context);

			if (strApprovalComments != null && strApprovalComments.length() > 0) {
				strApprovalComments = strApprovalComments.replaceAll("\\<.*?\\>", " ");
				lApprovalComments.add(strApprovalComments);
			} else {
				lApprovalComments.add("");
			}
		}
		return lApprovalComments;

	}

	/**
	 * This method hides the checkbox in the Verification table for requests having status other than Pending.
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector showCheckbox(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector enableCheckBox = new Vector();

		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sSoCObjId = (String) paramList.get("objectId");
		String strObjectId;
		Map mapProject;
		String strApprovalStatus = "";
		//Modified for SWIMP-31 Starts
		String sVerificationStatusRelId ="";
		DomainObject domIPOrSoC = DomainObject.newInstance(context, sSoCObjId);
		String strTypeIPOrSoC = domIPOrSoC.getInfo(context, DomainConstants.SELECT_TYPE);
		MapList mlWMList = new MapList();
		String strLineage ;
		if(IMP_Constants_mxJPO.TYPE_IMP_IP_RPODUCT.equalsIgnoreCase(strTypeIPOrSoC)) {
			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
			slRelSelects.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_WATERMARK);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP);

			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_BRANCH);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE);
			typePattern.addPattern(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK);


			mlWMList = domIPOrSoC.getRelatedObjects(context,
					relPattern.getPattern(), // relationship
					typePattern.getPattern(), // type pattern
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 4, // expand level
					null, // object where
					null, // relationship where
					0); // limit
		}
		//Modified for SWIMP-31 Ends
		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
			strLineage =(String) mapProject.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
			//Modified for SWIMP-31 Starts
			if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(strTypeIPOrSoC)) {
				sVerificationStatusRelId = getRelID(context, sSoCObjId, strObjectId);
			}else {
				strApprovalStatus = getVerificationStatusForHIPApprovalStatus(mlWMList, strObjectId, strLineage);
			}
			//Modified for SWIMP-31 Ends
			if( UIUtil.isNotNullAndNotEmpty(sVerificationStatusRelId)) {
				DomainRelationship domRel = new DomainRelationship(sVerificationStatusRelId);
				domRel.open(context);
				//Modified for SWIMP-322: Replaced attribute IMP_IPSoCApprovalStatus with IMP_ApprovalStatus
				strApprovalStatus = domRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
				domRel.close(context);
			}
			if (strApprovalStatus != null && strApprovalStatus.length() > 0 && strApprovalStatus.equalsIgnoreCase("Pending")) {
				enableCheckBox.add("true");
			} else {
				enableCheckBox.add("false");
			}
		}
		return enableCheckBox;
	}

	/**
	 * This method gets status of the IP Verification objects pertaining to the IP with matching status icon
	 * Modified for SWIMP-31 (Phase-2)
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getStatusWithIcon(Context context, String[] args) throws Exception {
		Vector lStatusICons = new Vector();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			String sReportFormat = (String) paramList.get("reportFormat");
			Iterator objectListItr = lstobjectList.iterator();

			Map mapProject;
			String strApprovalStatus;
			String sVerifyRelId;

			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				sVerifyRelId = (String) mapProject.get(DomainConstants.SELECT_RELATIONSHIP_ID);//Added for SWIMP-31 (Phase-2) : Replace getting verify-rel id mechanism 
				DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
				domVerifyRel.open(context);
				//Modified for SWIMP-322: Replaced attribute IMP_IPSoCApprovalStatus with IMP_ApprovalStatus
				strApprovalStatus = domVerifyRel.getAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
				domVerifyRel.close(context);

				if (UIUtil.isNullOrEmpty(sReportFormat)) {
					StringList slReturnList = (StringList) getVerificationStatusList(context, strApprovalStatus);
					lStatusICons.add(slReturnList.get(0));
				} else {
					lStatusICons.add(strApprovalStatus);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lStatusICons;
	}	

	/**
	 * This method gets the relationship id exists between given SoC Object and Revision Object
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param sSoCHIPObjId - SOC ObjectId, sRevObjId - Revision object Id
	 * @return String
	 * @throws FrameworkException if the operations fails
	 */
	@SuppressWarnings("unchecked")
	public static String getRelID(Context context, String sSoCHIPObjId, String sRevObjId, String sType, String sLineage) throws FrameworkException {
		String sReturn = "";
		try {
			DomainObject domSoCHIP = DomainObject.newInstance(context, sSoCHIPObjId);
			//Modified for SWIMP-46
			String sRelIPVerificationForSoCorHIP = "";
			boolean from;
			boolean to;
			if((IMP_Constants_mxJPO.STR_HIP).equalsIgnoreCase(sType)) {
				sRelIPVerificationForSoCorHIP = IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORHIP;
				from = false;
				to = true;
			} else {
				sRelIPVerificationForSoCorHIP = IMP_Constants_mxJPO.RELATIONSHIP_IMP_IPVERIFICATIONSTATUSFORSOC;
				from = true;
				to = false;
			}

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			String sWhere = "";
			if(UIUtil.isNotNullAndNotEmpty(sLineage))
				sWhere = IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE + " == '" + sLineage + "'"; //Added for SIMP-31 (Phase-2)

			MapList mlRevList = domSoCHIP.getRelatedObjects(context,
					sRelIPVerificationForSoCorHIP, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					from, // from
					to, // to
					(short) 1, // expand level
					null, // object where
					sWhere, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Iterator<Map<String, Object>> itrRevList = mlRevList.iterator();
				String sRevId = "";
				while (itrRevList.hasNext()) {
					Map<String, Object> mRev = itrRevList.next();
					sRevId = (String) mRev.get(DomainConstants.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(sRevId) && sRevId.equalsIgnoreCase(sRevObjId)) {
						sReturn = (String) mRev.get(DomainRelationship.SELECT_ID);
						break;
					}
				}
			}
		} catch (FrameworkException e) {
			throw new FrameworkException("Exception in the method IMP_IPVerification_mxJPO::getRelID: " + e);
		}
		return sReturn;
	}
	
	public static String getRelID(Context context, String sSoCHIPObjId, String sRevObjId) throws FrameworkException {
		return getRelID(context,sSoCHIPObjId,sRevObjId,"","");
	}

	/**
	 * This method gets the relationship id exists between given Verification Object and Revision Object
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param SoCObjId - SOC ObjectId, sRevObjId - Revision object Id
	 * @return String
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings("rawtypes")
	public static String getVerifyRelID(Context context, String sVerification, String sRevObjId) throws FrameworkException {
		String sReturn = "";
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerification);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);
			StringList slObjSelects = new StringList();
			slObjSelects.add(DomainConstants.SELECT_ID);
			String sWhere = "";

			//Modified for SWIMP-322: Replaced with new relationship
			MapList mlRevList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern //Modified for SWIMP-1
					slObjSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Iterator itrRevList = mlRevList.iterator();
				Map mRev;
				String sRevId;
				while (itrRevList.hasNext()) {
					mRev = (Map) itrRevList.next();
					sRevId = (String) mRev.get(DomainConstants.SELECT_ID);
					if (sRevId != null && sRevId.length() > 0 && sRevId.equalsIgnoreCase(sRevObjId)) {
						sReturn = (String) mRev.get(DomainRelationship.SELECT_ID);
						break;
					}
				}
			}

		} catch (FrameworkException e) {
			throw e;
		}
		return sReturn;
	}
	/**
	 * This method gets status of the IP Verification objects pertaining to the IP with matching status icon
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param strApprovalStatus - Approval Status
	 * @return List
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings("unchecked")
	public static List<String> getVerificationStatusList(Context context, String strApprovalStatus) {
		List<String> lStatusICons = new StringList();
		StringBuilder sbHtmlTag = new StringBuilder();
		if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED)+"'></input><img src='../common/images/utilWorkflowGreenArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_APPROVED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN)+"'></input><img src='../common/images/utilWorkflowGrayArrow.gif' border='0'  align='middle'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_DRY_RUN);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED)+"'></input><img src='../common/images/utilWorkflowGreenArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_PREAPPROVED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PRE_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED)+"'></input><img src='../common/images/utilWorkflowRedArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_RETRACTED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_NOT_APPROVED);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING)+"'></input><img src='../common/images/utilWorkflowGrayArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_PENDING_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_PENDING);
		} else if (IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED.equalsIgnoreCase(strApprovalStatus)) {
			sbHtmlTag.append(INPUT_HIDDEN_TAG+ATTRIBUTE_IMP_IP_APPROVAL_SORT_SEQUANCE.get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED)+"'></input><img src='../common/images/utilWorkflowRedArrow.gif' border='0'  align='middle' title='" + IMP_Constants_mxJPO.SOC_REJECTED_MSG + "'></img>").append("\t").append(IMP_Constants_mxJPO.ATTRIBUTE_IMP_IP_APPROVAL_STATUS_RANGE_REJECTED);
		} else {
			sbHtmlTag.append(strApprovalStatus);
		}
		
		lStatusICons.add(sbHtmlTag.toString());
		return lStatusICons;
	}

	

	/**
	 * This method gets the Tag of the revision objects for which IP Verify was run
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getRevision(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lRevTag = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
                //Added for SWIMP-1 starts
                DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
                String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
                DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
                //Added for SWIMP-1 ends
				String sRevTag = domRevObj.getAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPTag"));

				if (sRevTag != null && sRevTag.length() > 0) {
					lRevTag.add(sRevTag);
				} else {
					lRevTag.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return lRevTag;
	}


	//Modified for SWIMP-31 (Phase-2) : Starts
	/**
	 * Method to display No Of Instances of the revision in IP Verification
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return StringList
	 * @throws FrameworkException, if the operations fails
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public StringList getNoOfInstances(Context context, String[] args) throws FrameworkException {
		//Added for SWIMP-31 (Phase-2) : Starts
		StringList slNoOfInstances = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrWMObjs = mlWMObjs.iterator();
			Map<String,String> mapWM;
			String strNoOfInstances;
			while (itrWMObjs.hasNext()) {
				mapWM = itrWMObjs.next();
				strNoOfInstances = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_NOOFINSTANCES);
				slNoOfInstances.add(UIUtil.isNullOrEmpty(strNoOfInstances) ? "" : strNoOfInstances);
			}
		} catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:getNoOfInstances: " + e.getMessage());
		}
		return slNoOfInstances;
		//Added for SWIMP-31 (Phase-2) : Ends
	}
	//Modified for SWIMP-31 (Phase-2) : Ends


	/**
	 * This methods gets the IP Source attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getIPSource(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);

		String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
		String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");
		String attrIPSource = PropertyUtil.getSchemaProperty(context, "attribute_IMP_IPSource");
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPSourceList = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			DomainObject domRevObj;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
				
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");

					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					String strIPSource = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.attribute[" + attrIPSource + "]");

					if (strIPSource != null && strIPSource.length() > 0) {
						lIPSourceList.add(strIPSource);
					} else {
						ContextUtil.pushContext(context);
						strIPSource = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.attribute[" + attrIPSource + "]");
						if (UIUtil.isNotNullAndNotEmpty(strIPSource)) {
							lIPSourceList.add(strIPSource);
						} else {
							lIPSourceList.add("");						
						}
						ContextUtil.popContext(context);
					}
				} else {
					lIPSourceList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Error getting IP Source of the IP Product " + e);
		}
		return lIPSourceList;
	}

	/**
	 * This methods gets the IP Source attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getDesignStatus(Context context, String[] args) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);

		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPDesignStatus = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					String strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					//Added for SWIMP-1 ends
					DomainObject domRevObj = DomainObject.newInstance(context, strRelObjectId);
					String sBranchLifeCycle = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.attribute[IMP_Branch_Lifecycle]");

					if (sBranchLifeCycle != null && sBranchLifeCycle.length() > 0) {
						lIPDesignStatus.add(sBranchLifeCycle);
					} else {
						lIPDesignStatus.add("");
					}
				} else {
					lIPDesignStatus.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw e;
		}
		return lIPDesignStatus;
	}

	/**
	 * This methods gets the IP Type attribute value for the IP revisions connected to Verification objects
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getIPType(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Vector lIPTypeList = new Vector();
		Iterator objectListItr = relBusObjPageList.iterator();
		try {
			Map mapProject;
			DomainObject domRevObj;
			String strObjectId;
			String strIPType;
			while (objectListItr.hasNext()) {
				mapProject = (Map) objectListItr.next();
				strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					strIPType = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");

					if (strIPType != null && strIPType.length() > 0) {
						lIPTypeList.add(strIPType);
					} else {
						ContextUtil.pushContext(context);
						strIPType = domRevObj.getInfo(context, "to[IMP_IPBranchRelease].from.to[IMP_IPBranch].from.attribute[IMP_IPType]");
						if (UIUtil.isNotNullAndNotEmpty(strIPType)) {
							lIPTypeList.add(strIPType);
						} else {
							lIPTypeList.add("");
						}
						ContextUtil.popContext(context);
					}
				} else {
					lIPTypeList.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Error getting IP Type of the IP Product " + e);
		}
		return lIPTypeList;
	}
	
	/**
	 * This methods gets the IP Deprecated by
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return Vector
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public Vector getDeprecatedBy(Context context, String args[]) throws Exception {
		Vector vDeprecatedby = new Vector();
		boolean bContextPushed = false;
		try {
			ContextUtil.pushContext(context);
			bContextPushed = true;
			HashMap programMap = JPO.unpackArgs(args);
			MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			HashMap paramMap = (HashMap) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			String sReportFormat = (String) paramMap.get("reportFormat");
			Iterator objectListItr = relBusObjPageList.iterator();

			String relIPBranchRelease = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranchRelease");
			String relIPBranch = PropertyUtil.getSchemaProperty(context, "relationship_IMP_IPBranch");

			Map mapProject;
			DomainObject domRevObj;
			String strObjectId;
			String sIPObjId;
			ArrayList<String> lsDeprecatedBy = new ArrayList<>();
			String sDeprecatedBy;
			StringBuilder sbDeprecatedBy = new StringBuilder();
			String sDeprecatedList;

			while (objectListItr.hasNext()) {
				sDeprecatedBy = "";
				mapProject = (Map) objectListItr.next();
				
				if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
					strObjectId = (String) mapProject.get(DomainConstants.SELECT_ID);
					//Added for SWIMP-1 starts
					DomainObject domWMObj = DomainObject.newInstance(context, strObjectId);
					String strRelObjectId = domWMObj.getInfo(context, "to[IMP_IP_Watermark].from.id");
					domRevObj = DomainObject.newInstance(context, strRelObjectId);
					//Added for SWIMP-1 ends
					sIPObjId = domRevObj.getInfo(context, "to[" + relIPBranchRelease + "].from.to[" + relIPBranch + "].from.id");

					lsDeprecatedBy = (ArrayList<String>) IMP_IPDeprecate_mxJPO.getDeprecatedBy(context, sIPObjId);
					if (!lsDeprecatedBy.isEmpty() && UIUtil.isNullOrEmpty(sReportFormat)) {
						for (int i = 0; i < lsDeprecatedBy.size(); i++) {
							sDeprecatedBy = lsDeprecatedBy.get(i);
							sbDeprecatedBy.append("<font color='red'>");
							sbDeprecatedBy.append(sDeprecatedBy);
							sbDeprecatedBy.append("</font>");
							sbDeprecatedBy.append(", ");
						}

						sDeprecatedList = sbDeprecatedBy.toString();
						if (UIUtil.isNotNullAndNotEmpty(sDeprecatedList) && sDeprecatedList.length() > 2) {
							sDeprecatedList = sDeprecatedList.substring(0, sDeprecatedList.length() - 2);
							vDeprecatedby.add(sDeprecatedList);
						} else {
							vDeprecatedby.add("");
						}

					} else if (!lsDeprecatedBy.isEmpty() && UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
						sDeprecatedBy = (lsDeprecatedBy.toString().substring(1, lsDeprecatedBy.toString().length() - 1)).trim();
						sDeprecatedBy = sDeprecatedBy.replaceAll(", ", "|");
						vDeprecatedby.add(sDeprecatedBy);
					} else {
						vDeprecatedby.add("");
					}

					sbDeprecatedBy.setLength(0);
				} else {
					vDeprecatedby.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
				}
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification :  getDeprecatedBy " + e);
		} finally {
			if (bContextPushed) {
				ContextUtil.popContext(context);
			}
		}
		return vDeprecatedby;
	}

	/**
	 * This methods gets approvers for the given IP Revision for IP Verification approvals
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds objectList
	 * @return List
	 * @throws Exception if the operations fails
	 */	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector getApprover(Context context, String args[]) throws Exception {
		HashMap programMap = JPO.unpackArgs(args);
		MapList lstobjectList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		Iterator objectListItr = lstobjectList.iterator();
		Vector lApprover = new Vector();
		String sRevObjId;

		Map paramList = (Map) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
		String sVerifyObjId = (String) paramList.get("VerifyID");
		Map mapProject;
		String sApprover;
		String sVerifyRelId;

		while (objectListItr.hasNext()) {
			mapProject = (Map) objectListItr.next();
			sRevObjId = (String) mapProject.get(DomainConstants.SELECT_ID);
			sVerifyRelId = getVerifyRelID(context, sVerifyObjId, sRevObjId);
			DomainRelationship domVerifyRel = new DomainRelationship(sVerifyRelId);
			domVerifyRel.open(context);
			sApprover = domVerifyRel.getAttributeValue(context, PropertyUtil.getSchemaProperty(context, "attribute_Approver"));
			domVerifyRel.close(context);

			if (sApprover != null && sApprover.length() > 0) {
				lApprover.add(PersonUtil.getFullName(context, sApprover));
			} else {
				lApprover.add("");
			}
		}
		return lApprover;

	}

  
 
  /**
   * Update audit records.
   *
   * @param context the context
   * @param args the args
   * @throws Exception the exception
   */
  @SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
  public void updateAuditRecords(Context context, String[] args) throws Exception {
    HashMap programMap = JPO.unpackArgs(args);
    String strTag = (String) programMap.get("Tag");
    String strIPID = (String) programMap.get("IPID");
    String strRelID = (String) programMap.get("RELID");
    String strComments = (String) programMap.get("COMMENTS");
    String strProject = (String) programMap.get("PROJECT");
    String strOperation = (String) programMap.get("OPERATION");
    String strConsumedRecord =
        PropertyUtil.getSchemaProperty(context, "relationship_IMP_ConsumedRecords");
    String strAuditRecord =
        PropertyUtil.getSchemaProperty(context, "relationship_IMP_ReleaseAuditRecords");
    String sIPAuditRecordPolicyAlias =
        FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_POLICY,
            PropertyUtil.getSchemaProperty(context, "policy_IMP_IPAuditRecords"), true);
    String sIPAuditRecTypeAdminAlias =
        FrameworkUtil.getAliasForAdmin(context, DomainObject.SELECT_TYPE,
            PropertyUtil.getSchemaProperty(context, "type_IMP_IPAuditRecords"), true);
    try {
      String sIPAuditRecId =
          FrameworkUtil.autoName(context, sIPAuditRecTypeAdminAlias, "", sIPAuditRecordPolicyAlias,
              PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"));
      Map mpAttrUpdate = new HashMap<>();
      mpAttrUpdate.put("IMP_Comment", strComments);
      mpAttrUpdate.put("IMP_ProjectName", strProject);
      mpAttrUpdate.put("IMP_IPTag", strTag);
      mpAttrUpdate.put("IMP_IPOperation", strOperation);
      DomainObject domAudit = new DomainObject(sIPAuditRecId);
      domAudit.setAttributeValues(context, mpAttrUpdate);
      DomainObject domIP = new DomainObject(strIPID);
      DomainObject domRelease = new DomainObject(strRelID);

      //Added for SWIMP-576 : Starts
      String sComment = strComments;
      if ("download".equals(strOperation)) {
    	  sComment = "--project: " + strProject + "; --ipid: "
    			  + domIP.getInfo(context, DomainConstants.SELECT_NAME) + "; --tag: " + strTag + "; --comment: "
    			  + strComments;
    	  connectAuditRecordsAndUpdateHistory(context, domRelease, strAuditRecord, domAudit, strRelID, strOperation, sComment);
      }
      connectAuditRecordsAndUpdateHistory(context, domIP, strConsumedRecord, domAudit, strIPID, strOperation, sComment);
      //Added for SWIMP-576 : Ends
    } catch (Exception e) {
      throw new Exception(e);
    }
  }


	/**
	 * Method for getting the co-owners list for the given object Id
	 * 
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds the objectID and New Value
	 * @return MapList
	 * @throws Exception if the operations fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static MapList getCoOwners(Context context, String sObjectId) throws Exception {
		MapList mlRetrunList = new MapList();
		MapList mlUserList = new MapList();
		try {
			DomainObject domIPObj = DomainObject.newInstance(context, sObjectId);
			MultipleOwner mulOwner = new MultipleOwner(domIPObj);
			String strPersonID;
			mlUserList = mulOwner.getCoOwners(context, null, null, true);

			if (mlUserList != null && !mlUserList.isEmpty()) {
				Map map = (Map) mlUserList.get(0);
				String name = (String) map.get(DomainConstants.SELECT_NAME);
				if (name != null && !"".equals(name)) {
					String[] names = name.split("~");

					for (int i = 0; i < names.length; i++) {
						strPersonID = PersonUtil.getPersonObjectID(context, names[i]);
						HashMap hmObjectMap = new HashMap();
						hmObjectMap.put(DomainConstants.SELECT_ID, strPersonID);
						hmObjectMap.put(DomainConstants.SELECT_NAME, names[i]);
						mlRetrunList.add(hmObjectMap);
					}
				}
			}
		} catch (Exception e) {
			throw new FrameworkException(e);
		}
		return mlRetrunList;
	}

  // Modified for the bug IMPBRCM-985
  /**
   * This method checks in the public documents into given IP
   *
   * @param context the eMatrix <code>Context</code> object
   * @param sIPName - IP ID
   * @param sPath - Path in the Enovia server for the files
   * @param
   * @return nothing
   * @throws Exception if the operations fails
   */
  @SuppressWarnings({"rawtypes", "deprecation", "unchecked"})
  public static Map checkinPublicDocumentsToIP(Context context, String args[]) throws Exception {
    // DO NOT REMOVE ANY SYSOUTS FROM THIS METHOD, THIS IS TO CHECK THE FAILURE -- JIRA 1205
    System.out.println("-- START -- PUBLIC DOCUMENTS CHECKIN --");
    Map mpReturnMap = new HashMap();
    try {
      String strDesignSpecificationID = "";
      HashMap programMap = (HashMap) JPO.unpackArgs(args);
      String strIPIDName = (String) programMap.get("sIPName");
      String sFTPWorkingDirectory = (String) programMap.get("sPath");
      String sDocPublisher = (String) programMap.get("sUser");
      System.out.println("-- PUBLIC DOCUMENTS PUBLISHER --: "+sDocPublisher);
      sFTPWorkingDirectory = sFTPWorkingDirectory + "/";
      System.out.println("-- FTP WORKING DIR --: " + sFTPWorkingDirectory);
      String strRel = PropertyUtil.getSchemaProperty(context, "relationship_ProductSpecification");
      String strDesignSpecificationType =
          PropertyUtil.getSchemaProperty(context, "type_DesignSpecification");
      StringBuilder sbFileList = new StringBuilder();

      // Added for IMPBRCM-695 Starts
      String strVersionPolicy = PropertyUtil.getSchemaProperty(context, "policy_Version");
      String strRelActiveVersion =
          PropertyUtil.getSchemaProperty(context, "relationship_ActiveVersion");
      String strRelLatestVersion =
          PropertyUtil.getSchemaProperty(context, "relationship_LatestVersion");
      String strAttrTitle = PropertyUtil.getSchemaProperty(context, "attribute_Title");
      String attrIsVersionObj =
          PropertyUtil.getSchemaProperty(context, "attribute_IsVersionObject");

      // Added for IMPBRCM-695 Ends
      String strAutoNameType = "type_DesignSpecification";
      String strAutoNamePolicy = "policy_SoftwareDesignSpecification";
      StringList objectSelect = new StringList();
      objectSelect.add(DomainConstants.SELECT_ID);
      objectSelect.add(DomainConstants.SELECT_OWNER);
      String typePattern = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
      // Added for IMPBRCM-695 Starts
      DomainObject designSpecificationObject = new DomainObject();
      DomainObject domDocObj = new DomainObject();
      String sName = null;
      String sRevision = null;
      String sFileName = null;
      // Added for IMPBRCM-695 Ends
      boolean isDocObjPresent = false;

      com.matrixone.apps.common.WorkspaceVault workspaceVault =
          (com.matrixone.apps.common.WorkspaceVault) DomainObject.newInstance(context,
              DomainConstants.TYPE_WORKSPACE_VAULT);

      MapList mMapList = DomainObject.findObjects(context, typePattern, strIPIDName, "A", "*", "*",
          null, false, objectSelect);
      if (!mMapList.isEmpty()) {
        Map mapIPID = (Map) mMapList.get(0);
        String strIPID = (String) mapIPID.get(DomainConstants.SELECT_ID);
        System.out.println("-- IPID --: " + strIPID);
        String sMqlCommand = "";
        StringList objectSelects = new StringList();
        objectSelects.add(DomainConstants.SELECT_ID);
        objectSelects.add(DomainConstants.SELECT_ORIGINATOR);
        DomainObject masterObject = new DomainObject(strIPID);
        System.out.println("-- GETTING PRODUCT SPEC --: ");
        MapList mReturnMap = masterObject.getRelatedObjects(context, strRel,
            strDesignSpecificationType, objectSelects, null, true, true, (short) 1, null, null, 0);

        if (!mReturnMap.isEmpty()) {
          System.out.println("-- PRODUCT SPEC EXISTS--: ");
          Map mapDesignSpecification = (Map) mReturnMap.get(0);
          strDesignSpecificationID = (String) mapDesignSpecification.get(DomainConstants.SELECT_ID);
          designSpecificationObject = new DomainObject(strDesignSpecificationID);
          System.out.println("-- SPEC ID --: " + strDesignSpecificationID);
          StringList slObjSelects = new StringList();
          slObjSelects.add(DomainConstants.SELECT_ID);
          slObjSelects.add(DomainConstants.SELECT_REVISION);
          slObjSelects.add("attribute[Title]");
          String sWhere = "revision==last";

          MapList docObjList = designSpecificationObject.getRelatedObjects(context,
              PropertyUtil.getSchemaProperty(context, "relationship_LatestVersion"), // relationship
                                                                                     // pattern
              strDesignSpecificationType, // type pattern
              slObjSelects, // Object selects
              null, // relationship selects
              false, // from
              true, // to
              (short) 1, // expand level
              sWhere, // object where
              null, // relationship where
              0); // limit
          System.out.println("-- DOC LIST --: " + docObjList);
          docObjList.sortStructure(DomainConstants.SELECT_REVISION, "descending", "string");          
          Map mDocObjMap;
          String sDocObjId;
          String sDocObjTitle;
          int sDocObjRevision;
          int sDocObjNewRevision;
          DomainObject domDocumentObj;
          BusinessObject busNewRevision;
          DomainObject domNewRevision;

          File file = new File(sFTPWorkingDirectory);
          // Added for SWIMP-81: Starts
          System.out.println("-- "+ sFTPWorkingDirectory +" FILE EXISTS--: " + file.exists());
          System.out.println("-- " + sFTPWorkingDirectory +" IS A DIRECTORY --: " + file.isDirectory());
          // Added for SWIMP-81: Ends
          if (file.isDirectory() && file.listFiles() !=null) {
            File[] files = file.listFiles();
            // Added for SWIMP-81
            System.out.println("-- NUMBER OF FILES IN " + sFTPWorkingDirectory+ " --: " +files.length);
            for (int i = 0; i < files.length; i++) {
              String strPath = "";
              if (files[i].isFile()) {
                isDocObjPresent = false;
                strPath = sFTPWorkingDirectory + files[i].getName();
                sFileName = files[i].getName();
                // Added for SWIMP-81: Starts
                System.out.println("-- FILENAME --: " + sFileName);
                sbFileList.append(sFileName);
                sbFileList.append(",");
                try {
                  // Pushing context user to super user
                  ContextUtil.pushContext(context);
                  // Modified for IMPBRCM-695 Starts
                  // Creating a design specification object and connecting with active and current
                  // version to parent design specification object                  
                  sMqlCommand = "checkin businessobject " + strDesignSpecificationID + " append "
                      + strPath + ";";
                  System.out.println("-- COMMAND --: "+sMqlCommand);
                  MqlUtil.mqlCommand(context, sMqlCommand, false, false);
                  System.out.println("-- COMMAND EXECUTED SUCCESSFULLY --: ");
                  Iterator itrDocObjList = docObjList.iterator();
                  while (itrDocObjList.hasNext()) {
                    mDocObjMap = (Map) itrDocObjList.next();
                    sDocObjId = (String) mDocObjMap.get(DomainConstants.SELECT_ID);
                    System.out.println("-- DOC OBJ ID --: " + sDocObjId);
                    sDocObjTitle = (String) mDocObjMap.get("attribute[Title]");
                    System.out.println("-- DOC OBJ TITLE --: " + sDocObjTitle);
                    sDocObjRevision =
                        Integer.valueOf(mDocObjMap.get(DomainConstants.SELECT_REVISION).toString());
                    System.out.println("-- DOC OLD OBJ REVISION --: " + sDocObjRevision);
                    mpReturnMap.put("Old_Revision", sDocObjRevision);
                    if (sDocObjTitle != null && sDocObjTitle.length() > 0
                        && sFileName.equalsIgnoreCase(sDocObjTitle)) {
                      System.out.println("-- START DOC OBJ UPDATE/REVISE --: ");
                      domDocumentObj = DomainObject.newInstance(context, sDocObjId);
                      busNewRevision = domDocumentObj.reviseObject(context, false);
                      domNewRevision = new DomainObject(busNewRevision);
                      domNewRevision.setOwner(context, sDocPublisher);
                      domNewRevision.setAttributeValue(context,
                          PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                          sDocPublisher);
                      domNewRevision.setAttributeValue(context, attrIsVersionObj, "True");
                      isDocObjPresent = true;
                      sDocObjNewRevision = Integer.valueOf(domNewRevision.getRevision());
                      System.out.println("-- DOC OBJ UPDATED/REVISED --: ");
                      System.out.println("-- DOC OBJ NEW REVISION --: " + sDocObjNewRevision);
                      if (sDocObjNewRevision > sDocObjRevision) {
                        mpReturnMap.put(sMessage, "Success");
                        mpReturnMap.put("New Revision", sDocObjNewRevision);
                        mpReturnMap.put("Files_List", sbFileList);
                      } else {
                        mpReturnMap.put(sMessage, "Failed to revise");
                      }
                      System.out.println("-- DOC OBJ UPDATED/REVISED --: ");
                      break;
                    } else {
                      System.out.println("-- DOC OBJ NOT UPDATE/REVISED --: ");
                      System.out.println("-- CREATE NEW DOC OBJECT? --: " + isDocObjPresent);
                    }
                  }
                  if (!isDocObjPresent) {
                    System.out.println("-- START NEW DOC OBJ CREATE --: ");
                    sName = workspaceVault.getUniqueName(DomainConstants.EMPTY_STRING);
                    sRevision = "1";
                    domDocObj.createAndConnect(context, strDesignSpecificationType, sName,
                        sRevision, strVersionPolicy,
                        PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
                        strRelActiveVersion, designSpecificationObject, true);
                    DomainRelationship.connect(context, designSpecificationObject,
                        strRelLatestVersion, domDocObj);
                    domDocObj.setAttributeValue(context, strAttrTitle, sFileName);
                    domDocObj.setOwner(context, sDocPublisher);
                    domDocObj.setAttributeValue(context,
                        PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                        sDocPublisher);
                    domDocObj.setAttributeValue(context, attrIsVersionObj, "True");
                    isDocObjPresent = true;
                    mpReturnMap.put(sMessage, "Success");
                    mpReturnMap.put("New_Object_Created", isDocObjPresent);
                    // Added for SWIMP-81
                    mpReturnMap.put("Files_List", sbFileList);
                    System.out.println("-- NEW DOC OBJ CREATED --: " + isDocObjPresent);
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                  throw new Exception(e);
                } finally {
                  if (context != null) {
                    ContextUtil.popContext(context);
                  }
                } // Modified for IMPBRCM-695 Ends
              }
            }
          // Added for SWIMP-81: Starts
          } else {
              System.out.println("-- " + sFTPWorkingDirectory + " Does not exist---"+ !file.isDirectory());
              mpReturnMap.put(sMessage, "Failure");
          }
          // Added for SWIMP-81: Starts
        } else {
          System.out.println("-- PRODUCT SPEC NOT EXISTS, CREATE NEW--: ");
          try {
            ContextUtil.pushContext(context);
            strDesignSpecificationID =
                FrameworkUtil.autoName(context, strAutoNameType, strAutoNamePolicy);
            designSpecificationObject = new DomainObject(strDesignSpecificationID);
            designSpecificationObject.setOwner(context, sDocPublisher);
            designSpecificationObject.setAttributeValue(context,
                PropertyUtil.getSchemaProperty(context, "attribute_Originator"), sDocPublisher);
            designSpecificationObject.setAttributeValue(context, strAttrTitle, strIPIDName);
            DomainRelationship.connect(context,masterObject, strRel,  designSpecificationObject);
            System.out.println("-- PRODUCT SPEC CREATED--: " + strDesignSpecificationID);
            System.out.println("-- FTP WORKING DIRECTORY--: " + sFTPWorkingDirectory);
            File file = new File(sFTPWorkingDirectory);
            System.out.println("-- "+ sFTPWorkingDirectory +" FILE EXISTS--: " + file.exists());
            System.out.println("-- " + sFTPWorkingDirectory +" IS A DIRECTORY --: " + file.isDirectory());
            if (file.isDirectory()) {
              File[] files = file.listFiles();
              System.out.println("-- NUMBER OF FILES IN " + sFTPWorkingDirectory+ " --: " +files.length);
              for (int i = 0; i < files.length; i++) {
                String strPath = "";
                if (files[i].isFile()) {
                  strPath = sFTPWorkingDirectory + files[i].getName();
                  sFileName = files[i].getName();
                  System.out.println("-- FILENAME --: " +sFileName);
                  sbFileList.append(sFileName);
                  sbFileList.append(",");
                  // Modified for IMPBRCM-695 Starts
                  // Creating a dummy desgin specification object and connecting with active and
                  // current version to parent design specification object
                  sMqlCommand = "checkin businessobject " + strDesignSpecificationID + " append "
                      + strPath + ";";
                  System.out.println("-- COMMAND--: " + sMqlCommand);
                  MqlUtil.mqlCommand(context, sMqlCommand, false, false);
                  System.out.println("-- COMMAND EXECUTED SUCCESSFULLY--: ");
                  sName = workspaceVault.getUniqueName(DomainConstants.EMPTY_STRING);
                  sRevision = "1";
                  System.out.println("-- CREATE DESIGN SPEC OBJ--: ");
                  domDocObj.createAndConnect(context, strDesignSpecificationType, sName, sRevision,
                      strVersionPolicy,
                      PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction"),
                      strRelActiveVersion, designSpecificationObject, true);
                  System.out.println("-- DESIGN SPEC OBJ CREATED--: " + domDocObj.getObjectId());
                  DomainRelationship.connect(context, designSpecificationObject,
                      strRelLatestVersion, domDocObj);
                  domDocObj.setAttributeValue(context, strAttrTitle, sFileName);
                  domDocObj.setOwner(context, sDocPublisher);
                  domDocObj.setAttributeValue(context,
                      PropertyUtil.getSchemaProperty(context, "attribute_Originator"),
                      sDocPublisher);
                  domDocObj.setAttributeValue(context, attrIsVersionObj, "True");
                  System.out.println("-- DESIGN SPEC OBJ UPDATED--: ");
                  mpReturnMap.put("New_Spec_Object_Created", true);
                  mpReturnMap.put("Files_List", sbFileList);
				  mpReturnMap.put(sMessage, "Success");
                  // Modified for IMPBRCM-695 Ends
                }
              }
           // Added for SWIMP-81: Starts
            } else {
              System.out.println("-- " + sFTPWorkingDirectory + " Does not exist---"+ !file.isDirectory());
              mpReturnMap.put(sMessage, "Failure");
            }
           // Added for SWIMP-81: Starts
          } catch (Exception e) {
            e.printStackTrace();
            throw new Exception(e);
          } finally {
            if (context != null) {
              ContextUtil.popContext(context);
            }
          }
        }
      } else {
        System.out.println("-- IPID NOT FOUND --: ");
        mpReturnMap.put(sMessage, "No IP Found");
      }
    } catch (Exception ex) {
      ex.printStackTrace();
      mpReturnMap.put("Exception", ex.getMessage());
    }
    System.out.println("-- END -- PUBLIC DOCUMENTS CHECKIN --");
    return mpReturnMap;
  }
	
	/**
	 * This method is created for migrating public documents to IP Product
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sIPName - IP ID
	 * @param sPath - Path in the Enovia server for the files
	 * @param sUser - IP Publisher
	 * @return nothing
	 * @throws Exception if the operations fails
	 */	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void checkinPublicDoc(Context context, String[] args) throws Exception{			
		HashMap argsMap = new HashMap<>();
		argsMap.put("sIPName", args[0]);
		argsMap.put("sPath", args[1]);
		argsMap.put("sUser", args[2]);	
		try {			
			checkinPublicDocumentsToIP(context, JPO.packArgs(argsMap));
		} catch (Exception e) {
			throw new Exception("JPO : IMP_IPVerification :: checkinPublicDoc"+e);
		}
		
	}
	
  /**
   * This method gets the latest revision of the IP for the IP Revision table in IP Verification
   * 
   * @param context the eMatrix <code>Context</code> object
   * @param args holds objectList
   * @return Vector
   * @throws Exception if the operations fails added for IMPBRCM-1093
   */

  @SuppressWarnings({"rawtypes", "unchecked"})
  public Vector getIPLatestRevision(Context context, String[] args) throws Exception {
	  //Added for SWIMP-90 starts
	  Vector latestRevisionVector = new Vector();
	  try {
		  HashMap programMap = JPO.unpackArgs(args);
		  MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		  ContextUtil.pushContext(context, IMP_Constants_mxJPO.PERSON_USERAGENT, DomainConstants.EMPTY_STRING,IMP_Constants_mxJPO.PROD_VALUT);
		  Iterator objectListItr = relBusObjPageList.iterator();
		  Map mapProject = null;
		  String strIPObjectId ="";
		  String strLatestRevision="";
		  String strType="";
		  DomainObject domObj = new DomainObject();
		  while (objectListItr.hasNext()) {
			  mapProject = (Map) objectListItr.next();
			  
			  if (!IMP_Constants_mxJPO.STR_FALSE.equals((String) mapProject.get(IMP_Constants_mxJPO.KEY_HAS_READ_ACCESS))) {   //Added for SWIMP-541
				  //Modified for SWIMP-31 Start
				  String strObjectId = (String) mapProject.get("sRevObjID");
				  strObjectId = UIUtil.isNotNullAndNotEmpty(strObjectId) ? strObjectId : (String) mapProject.get(DomainConstants.SELECT_ID);
				  //Modified for SWIMP-31 End
				  domObj.setId(strObjectId);
				  strType=domObj.getInfo(context,DomainConstants.SELECT_TYPE);
				  if(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK.equals(strType))
				  {
					//Added For SWIMP-578 Start
					strIPObjectId = domObj.getInfo(context, "to["+IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK+"].from.to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
					//Added For SWIMP-578 End
					} else if(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(strType)){
					  //Added For SWIMP-578 Start
					 strIPObjectId = domObj.getInfo(context, "to[" + IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE + "].from.id");
					  //Added For SWIMP-578 End
				  }
				  if(UIUtil.isNotNullAndNotEmpty(strIPObjectId)){
					  HashMap mpIPMap = new HashMap();
					  mpIPMap.put("IPID",strIPObjectId);
					  //Added For SWIMP-578 Start
					  mpIPMap.put("isBranch",IMP_Constants_mxJPO.STR_TRUE);
					  //Added For SWIMP-578 End
					  strLatestRevision=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
							  JPO.packArgs(mpIPMap), String.class);
				  }
				  latestRevisionVector.add(strLatestRevision);
			  } else {
				  latestRevisionVector.add(IMP_Constants_mxJPO.CONSTANT_NO_ACCESS);    //Added for SWIMP-541
			  }
		  }
	  } finally {
		  ContextUtil.popContext(context);
	  }
	  return latestRevisionVector;
  }
  //Added for SWIMP-90 Ends
  
  /**
   * This method gets the latest revision of the IP for the IP Revision table in IP Verification
   * 
   * @param context the eMatrix <code>Context</code> object
   * @param args holds objectList
   * @return Vector
   * @throws Exception if the operations fails added for IMPBRCM-1093
   */
	//Added for SWIMP-541 --START
  @SuppressWarnings({"rawtypes", "unchecked"})
  public Vector getIPLatestRevisionApprovalPage(Context context, String[] args) throws Exception {
	  //Added for SWIMP-90 starts
	  Vector latestRevisionVector = new Vector();
	  try {
		  HashMap programMap = JPO.unpackArgs(args);
		  MapList relBusObjPageList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		  ContextUtil.pushContext(context, IMP_Constants_mxJPO.PERSON_USERAGENT, DomainConstants.EMPTY_STRING,IMP_Constants_mxJPO.PROD_VALUT);
		  Iterator objectListItr = relBusObjPageList.iterator();
		  Map mapProject = null;
		  String strIPObjectId ="";
		  String strLatestRevision="";
		  String strType="";
		  DomainObject domObj = new DomainObject();
		  while (objectListItr.hasNext()) {
			  mapProject = (Map) objectListItr.next();
			  
			  //Modified for SWIMP-31 Start
			  String strObjectId = (String) mapProject.get("sRevObjID");
			  strObjectId = UIUtil.isNotNullAndNotEmpty(strObjectId) ? strObjectId : (String) mapProject.get(DomainConstants.SELECT_ID);
			  //Modified for SWIMP-31 End
			  domObj.setId(strObjectId);
			  strType=domObj.getInfo(context,DomainConstants.SELECT_TYPE);
			  if(IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK.equals(strType))
			  {
				  strIPObjectId = domObj.getInfo(context, IMP_Constants_mxJPO.SELECT_IP_ID_FROM_IMP_IP_WATERMARK);
			  } else if(IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE.equals(strType)){
				  strIPObjectId = domObj.getInfo(context, IMP_Constants_mxJPO.IPID);
			  }
			  if(UIUtil.isNotNullAndNotEmpty(strIPObjectId)){
				  HashMap mpIPMap = new HashMap();
				  mpIPMap.put("IPID",strIPObjectId);
				  strLatestRevision=JPO.invoke(context, "IMP_FabricationApprovals", null, "getLatestRevisionofIP",
						  JPO.packArgs(mpIPMap), String.class);
			  }
			  latestRevisionVector.add(strLatestRevision);
		  }
	  } finally {
		  ContextUtil.popContext(context);
	  }
	  return latestRevisionVector;
  }
  //Added for SWIMP-541 --END
	/**
	 * This method updated the approval info in the relationship attributes between verify run and IP Release.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args holds approval info
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void updateVerifyRunAppInfo(Context context, String[] args) throws Exception {
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			String strSoCObjID = (String) programMap.get("SocID");
			String sStatus = (String) programMap.get("status");
			String sReason = (String) programMap.get("Reason");
			String sUser = (String) programMap.get("ContextUser");
			String sRevObjId = (String) programMap.get("RevObjId");
			String sApprovedDate = (String) programMap.get("ApprovedDate");
			
			//Modified For SWIMP-31 Start
			Pattern relPattern = new Pattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUNFORHIP);
			relPattern.addPattern(IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_FORSOC);
			Pattern typePattern = new Pattern(IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN);
			//Modified For SWIMP-31 End
			sStatus = UIUtil.isNullOrEmpty(sStatus) ? "" : sStatus;
			sReason = UIUtil.isNullOrEmpty(sReason) ? "" : sReason;
			sApprovedDate = UIUtil.isNullOrEmpty(sApprovedDate) ? "" : sApprovedDate;
			sUser = UIUtil.isNullOrEmpty(sUser) ? "" : sUser;

			if (UIUtil.isNotNullAndNotEmpty(sStatus) && ("Retracted").equalsIgnoreCase(sStatus)) {
				sStatus = "Not Approved";
			}

			TreeMap<Date, Object> mpVerifyIdData = new TreeMap<>();
			SimpleDateFormat formatter = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat(), Locale.US);

			String attrDryRun = PropertyUtil.getSchemaProperty(context, "attribute_IMP_DryRun");

			DomainObject domSoC = DomainObject.newInstance(context, strSoCObjID);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_NAME);
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainConstants.SELECT_ORIGINATED);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = "attribute[" + attrDryRun + "]!='Yes'";

			//Modified for SWIMP-322:Replaced relationship 'IMP_VerifyRun' with new 'relationship_IMP_VerifyRunForSoC'
			MapList mlVerification = domSoC.getRelatedObjects(context,
					relPattern.getPattern(), // relationship //Modified for SWIMP-31
					typePattern.getPattern(), // type pattern //Modified for SWIMP-31
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					true, // from
					false, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit


			if (!mlVerification.isEmpty()) {
				Iterator objectListItr = mlVerification.iterator();
				Map mVerifyID;
				Date date;
				String sOriginated;
				String sVerifyObjId;

				while (objectListItr.hasNext()) {
					mVerifyID = (Map) objectListItr.next();
					sVerifyObjId = (String) mVerifyID.get(DomainConstants.SELECT_ID);
					sOriginated = (String) mVerifyID.get(DomainConstants.SELECT_ORIGINATED);
					date = formatter.parse(sOriginated);
					mpVerifyIdData.put(date, sVerifyObjId);
				}
				String sLastVerifyObjId = (String) mpVerifyIdData.get(mpVerifyIdData.lastKey());
				List<String> lsLastVerifyRelId = getVerifyRunWMs(context, sLastVerifyObjId, sRevObjId); //Modified for SWIMP-31 (Phase-2)
				for (String sLastVerifyRelId : lsLastVerifyRelId) {
					if (UIUtil.isNotNullAndNotEmpty(sLastVerifyRelId)) {
						Map attrMap = new HashMap();
						//Modified for SWIMP-322: Starts
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS, sStatus);
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVE_REJECT_COMMENTS, sReason);
						attrMap.put(IMP_Constants_mxJPO.ATTRIBUTE_APPROVED_DATE, sApprovedDate);
						//Modified for SWIMP-322: Ends

						DomainRelationship domVerifyRel = new DomainRelationship(sLastVerifyRelId);
						domVerifyRel.open(context);
						String sRelAppStatus = (String) (domVerifyRel.getAttributeMap(context)).get(IMP_Constants_mxJPO.ATTRIBUTE_IMP_APPROVAL_STATUS);
						//Updating Approver before other attributes to keep the approver for updating the history of the IP on verify Approval/Rejection/Retract
						if (!sRelAppStatus.equalsIgnoreCase(sStatus)) {
							domVerifyRel.setAttributeValue(context, IMP_Constants_mxJPO.ATTRIBUTE_APPROVER, sUser);//Added for SWIMP-500
							domVerifyRel.setAttributeValues(context, attrMap);
						}
						domVerifyRel.close(context);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Exception in IMP_IPVerification : updateVerifyRunAppInfo " + e);
		}
	}

	/**
	 * Gets the verify run revisions.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sVerifyObjId the verify object id
	 * @param sRevObjId the revision object id
	 * @return String
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings("rawtypes")
	public String getVerifyRunRevisions(Context context, String sVerifyObjId, String sRevObjId) throws Exception {
		String sVerifyRunRelId = "";
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerifyObjId);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = DomainConstants.SELECT_ID + "==" + sRevObjId;

			//Modified for SWIMP-322: Replaced old relationship 'IMP_VerifyRun' with new 'IMP_VerifyRunDetectedIPs'
			MapList mlRevList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlRevList.isEmpty()) {
				Map mRev = (Map) mlRevList.get(0);
				sVerifyRunRelId = (String) mRev.get(DomainRelationship.SELECT_ID);
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification : getVerifyRunRevisions " + e);
		}
		return sVerifyRunRelId;
	}
	
	/**
	 * Gets the verify run revisions.
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param sVerifyObjId the verify object id
	 * @param sRevObjId the revision object id
	 * @return String
	 * @throws Exception if the operation fails
	 */
	@SuppressWarnings("unchecked")
	public List<String> getVerifyRunWMs(Context context, String sVerifyObjId, String sWMObjID) throws Exception {
		String sVerifyRunRelId = "";
		List<String> lsVerifyDetectedIPRelIDs = new ArrayList<>(); //Added for SWIMP-31 (Phase-2)
		try {
			DomainObject domVerifyObj = DomainObject.newInstance(context, sVerifyObjId);

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);

			StringList slRelSelects = new StringList();
			slRelSelects.add(DomainRelationship.SELECT_ID);

			String sWhere = DomainConstants.SELECT_ID + "==" + sWMObjID;

			//Modified for SWIMP-322: Replaced old relationship 'IMP_VerifyRun' with new 'IMP_VerifyRunDetectedIPs'
			MapList mlWMList = domVerifyObj.getRelatedObjects(context,
					IMP_Constants_mxJPO.RELATIONSHIP_IMP_VERIFYRUN_DETECTEDIPS, // relationship pattern
					IMP_Constants_mxJPO.TYPE_IMP_IP_WATERMARK, // type pattern
					slObjectSelects, // Object selects
					slRelSelects, // relationship selects
					false, // from
					true, // to
					(short) 1, // expand level
					sWhere, // object where
					null, // relationship where
					0); // limit

			if (!mlWMList.isEmpty()) {
				Iterator<Map<String, String>> itrWMList = mlWMList.iterator();
				while (itrWMList.hasNext()) {
					Map<String, String> mpVerifyDetectedIPs = itrWMList.next();
					sVerifyRunRelId = mpVerifyDetectedIPs.get(DomainRelationship.SELECT_ID);
					lsVerifyDetectedIPRelIDs.add(sVerifyRunRelId);
				}
			}

		} catch (Exception e) {
			throw new Exception("Exception in IMP_IPVerification : getVerifyRunRevisions " + e);
		}
		return lsVerifyDetectedIPRelIDs;
	}
	//Added for SWIMP-31 Start
	public StringList getIPRevision(Context context, String[] args) throws FrameworkException {
		StringList slIPRevision = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlVerifyRunObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrVerifyRunObjs = mlVerifyRunObjs.iterator();
			Map <String,String> mVerifyRun;
			String strVerifyRunObjectId;
			DomainObject domVerifyObj;
			while (itrVerifyRunObjs.hasNext()) {
				mVerifyRun = itrVerifyRunObjs.next();
				strVerifyRunObjectId = mVerifyRun.get(DomainConstants.SELECT_ID);
				domVerifyObj = DomainObject.newInstance(context, strVerifyRunObjectId);
				slIPRevision.add(domVerifyObj.getInfo(context, IMP_Constants_mxJPO.SELECT_IPRELEASE_FROM_VERIFYOBJECT));
			}
		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return slIPRevision;
	}


	/**
	 * This method gets the relationship id exists between given SoC Object and Revision Object
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param SoCObjId - HIP ObjectId, swatermarkobjectid
	 * @return String
	 * @throws Exception if the operations fails
	 */

	public static String getVerificationStatusForHIPApprovalStatus(MapList mlWMList, String sWMObjId,String strLineage) throws FrameworkException {
		String strVerificationStatusForHIPApprovalStatus = "";
		try {
			if (!mlWMList.isEmpty()) {
				Iterator <Map <String,String>> itrWMList = mlWMList.iterator();
				Map <String,String> mapWM;
				String sWMId;
				String strVerificationStatusForHIPAttrLineage;
				while (itrWMList.hasNext()) {
					mapWM = itrWMList.next();
					sWMId = mapWM.get(DomainConstants.SELECT_ID);
					strVerificationStatusForHIPAttrLineage = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
					if (UIUtil.isNotNullAndNotEmpty(strVerificationStatusForHIPAttrLineage) && sWMId.equalsIgnoreCase(sWMObjId)  && strVerificationStatusForHIPAttrLineage.equalsIgnoreCase(strLineage)) {
						strVerificationStatusForHIPApprovalStatus =  mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_APPROVAL_STATUS);
						break;
					}
				}
			}

		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return strVerificationStatusForHIPApprovalStatus;
	}

	public StringList getLineage(Context context, String[] args) throws FrameworkException {
		StringList slLineage = new StringList();
		try {
			HashMap programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Iterator<Map <String,String>> itrWMObjs = mlWMObjs.iterator();
			Map <String,String> mapWM;
			String strLineage;
			while (itrWMObjs.hasNext()) {
				mapWM = itrWMObjs.next();
				strLineage = mapWM.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LINEAGE);
				slLineage.add(UIUtil.isNullOrEmpty(strLineage) ? "" : strLineage);
			}
		} catch (Exception e) {
			throw new FrameworkException (e.getMessage());
		}
		return slLineage;
	}
	//Added for SWIMP-31 End



	//Added for SWIMP-531 : Starts
	/**
	 * This method is to get Declared Usage information
	 * Added for SWIMP-531
	 *
	 * @param context the eMatrix <code>Context</code> object
	 * @param args - holds Arguments passed
	 * @return StringList
	 * @throws FrameworkException, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public static StringList isDeclaredInIPRevision(Context context, String[] args) throws FrameworkException {
		StringList slIsDeclared = new StringList();
		try {
			Map<String, Object> programMap = JPO.unpackArgs(args);
			MapList mlWMObjs = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
			Map<String, Object> paramMap = (Map<String, Object>) programMap.get(IMP_Constants_mxJPO.PARAM_LIST);
			String sReportFormat = (String) paramMap.get(IMP_Constants_mxJPO.KEY_REPORTFORMAT);
			Iterator<Map <String, Object>> itrWMObjs = mlWMObjs.iterator();
			Map<String, Object> mapWM = new HashMap<>();
			Map <String,String> mapLP = new HashMap<>();
			String strReleaseId = "";
			String strBranchId = "";
			MapList mlLogicalProducts;
			Iterator<Map <String,String>> itrLogicalProducts;
			while (itrWMObjs.hasNext()) {
				boolean isDeclared = false;
				mapWM = itrWMObjs.next();
				//get the IP Revision, revision loading in the table and its branch compare against allConnectedLogicalProducts ids if matches send green else send red
				strReleaseId = (String)mapWM.get(IMP_Constants_mxJPO.SELECT_IMP_IPRELEASEID_FROM_WATERMARK) ;
				strBranchId = (String)mapWM.get(IMP_Constants_mxJPO.SELECT_BRANCH_ID_FROM_WATERMARK);
				mlLogicalProducts = (MapList)mapWM.get("allConnectedLogicalProducts");
				itrLogicalProducts = mlLogicalProducts.iterator();
				while (itrLogicalProducts.hasNext()) {
					mapLP = itrLogicalProducts.next();
					if(strReleaseId.equalsIgnoreCase(mapLP.get(DomainConstants.SELECT_ID)) || strBranchId.equalsIgnoreCase(mapLP.get(DomainConstants.SELECT_ID))) {
						isDeclared = true;
						break;
					}
				}

				if (UIUtil.isNotNullAndNotEmpty(sReportFormat)) {
					slIsDeclared.add(isDeclared ? IMP_Constants_mxJPO.STR_YES : IMP_Constants_mxJPO.STR_NO);
				} else {
					slIsDeclared.add(isDeclared
							? "<img src='../common/images/iconBigDiamondGreenApprove.png' border='0'  align='middle'></img>"
									: "<img src='../common/images/iconActionDelete.png' border='0'  align='middle'></img>");
				}
			}
		} catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:isDeclaredInIPRevision: " + e.getMessage());
		}
		return slIsDeclared;
	}


	/**
	 * This method is to get Logical Products relationship / Subscriptions
	 * Added for SWIMP-531
	 *
	 * @param context, the Context
	 * @param strProjectID - holds Product Object ID
	 * @return MapList
	 * @throws FrameworkException, if operation fails
	 */
	@SuppressWarnings("unchecked")
	public MapList getLogicalProducts(Context context, String strProjectID) throws FrameworkException {
		MapList mlFinalLPConnectedObjects = new MapList();
		try {
			Map<String, Object> mapProject = new HashMap<>();
			MapList mlBranchObjList;
			MapList mlRevList;
			MapList mlLPConnectedObjects;

			StringList slObjectSelects = new StringList();
			slObjectSelects.add(DomainConstants.SELECT_ID);
			slObjectSelects.add(DomainConstants.SELECT_NAME);
			StringList slRelationshipSelects = new StringList();
			slRelationshipSelects.add(DomainConstants.SELECT_RELATIONSHIP_ID);
			IMP_BlockIP_mxJPO classBlockIPObject = new IMP_BlockIP_mxJPO();

			if(IMP_Constants_mxJPO.TYPE_IMP_SOC.equalsIgnoreCase(new DomainObject(strProjectID).getInfo(context, DomainConstants.SELECT_TYPE))){
				mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context, strProjectID);
				mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
			}else {
				mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context, strProjectID);
				mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
				//get LP of branch and Its revision
				DomainObject domIPObj = DomainObject.newInstance(context, strProjectID);
				mlBranchObjList = (MapList) domIPObj.getRelatedObjects(context,
						IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH, // relationship pattern
						IMP_Constants_mxJPO.TYPE_IMP_BRANCH, // type pattern
						slObjectSelects, // Object selects
						slRelationshipSelects, // relationship selects
						false, // from
						true, // to
						(short) 1, // expand level
						null, // object where
						null, // relationship where
						0); // limit

				Iterator<Map <String, Object>> objectBranchListItr = mlBranchObjList.iterator();
				Iterator<Map <String, Object>> objectRevisionListItr ;
				while (objectBranchListItr.hasNext()) {
					mapProject = objectBranchListItr.next();
					mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context,(String) mapProject.get(DomainConstants.SELECT_ID));
					mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);

					DomainObject domBranch = DomainObject.newInstance(context, (String) mapProject.get(DomainConstants.SELECT_ID));
					mlRevList = domBranch.getRelatedObjects(context,
							IMP_Constants_mxJPO.RELATIONSHIP_IMP_IP_BRANCH_RELEASE, // relationship pattern
							IMP_Constants_mxJPO.TYPE_IMP_IP_RELEASE, // type pattern
							slObjectSelects, // Object selects
							slRelationshipSelects, // relationship selects
							false, // from
							true, // to
							(short) 1, // expand level
							null, // object where//SWIMP-1
							null, // relationship where
							0); // limit

					objectRevisionListItr = mlRevList.iterator();
					while (objectRevisionListItr.hasNext()) {
						mapProject = objectRevisionListItr.next();
						mlLPConnectedObjects = classBlockIPObject.getLogicalProducts(context,(String) mapProject.get(DomainConstants.SELECT_ID));
						mlFinalLPConnectedObjects.addAll(mlLPConnectedObjects);
					}

				}

			}
		}
		catch (Exception e) {
			throw new FrameworkException("Exception in IMP_IPVerification:getLogicalProducts: " + e.getMessage());
		}
		return mlFinalLPConnectedObjects;
	}
	//Added for SWIMP-531 : Ends



	//Added for SWIMP-576 : Starts
	/**
	 * This method is to connect AuditRecords and Update History of IP
	 * Added for SWIMP-576
	 *
	 * @param context, the Context
	 * @param domObj - DomainObject of IP/IPRelease
	 * @param strAuditRelationship - ConsumedRecord relationship name
	 * @param domAudit - DomainObject of Audit Records object
	 * @param strIPID - IP ID
	 * @param strOperation - CLI Operation
	 * @param sComment - History update comment
	 * @return Nothing
	 * @throws MatrixException, if operation fails
	 */
	private void connectAuditRecordsAndUpdateHistory(Context context, DomainObject domObj, String strAuditRelationship,
			DomainObject domAudit, String strIPorReleaseID, String strOperation, String sComment) throws MatrixException {
		String sContextUser = PersonUtil.getFullName(context);
		boolean isContextPushed = false;
		try {
			mqlHistoryOff(context, true);
			DomainRelationship.connect(context, domObj, strAuditRelationship, domAudit);
			mqlHistoryOff(context, false);
			sComment = sComment + "; by user: " + sContextUser;
			ContextUtil.pushContext(context, IMP_Constants_mxJPO.ADMINUSER_BCADMIN, "", IMP_Constants_mxJPO.PROD_VAULT);
			isContextPushed = true;
			MqlUtil.mqlCommand(context, IMP_Constants_mxJPO.MQLCOMMAND_ADDHISTORY, false, strIPorReleaseID, "CLI "+strOperation, sComment);
		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPVerification:connectAuditRecordsAndUpdateHistory: connect & update audit records and update history: \n\t"+me);
		} finally {
			if (isContextPushed) {
				ContextUtil.popContext(context);
			}
		}
	}



	/**
	 * This method is do mql history off/on
	 * Added for SWIMP-576
	 *
	 * @param context, the Context
	 * @param bHistoryOff - history to off/on as true or false
	 * @return Nothing
	 * @throws MatrixException, if operation fails
	 */
	private void mqlHistoryOff(Context context, boolean bHistoryOff) throws MatrixException {
		boolean isContextPushed = false;
		try {
			ContextUtil.pushContext(context, IMP_Constants_mxJPO.ADMINUSER_BCADMIN, "", IMP_Constants_mxJPO.PROD_VAULT);
			isContextPushed = true;
			if (bHistoryOff) {
				MqlUtil.mqlCommand(context, false, IMP_Constants_mxJPO.MQLCOMMAND_HISTORYOFF, false);
			} else {
				MqlUtil.mqlCommand(context, false, IMP_Constants_mxJPO.MQLCOMMAND_HISTORYON, false);
			}
		} catch (MatrixException me) {
			throw new MatrixException("Exception in IMP_IPVerification:mqlHistoryOff: failed to history off/on:  \n\t"+me);
		} finally {
			if (isContextPushed) {
				ContextUtil.popContext(context);
			}
		}
	}
	//Added for SWIMP-576 : Ends
	
		@SuppressWarnings("unchecked")
	public void setDLCAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
		    StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);
			 String sVerifyid =  hmData.get("sVerifyid");
			 String iDCLCDLResult =  hmData.get("iDCLCDLResult");
			 String strDCLCDLOutput =  hmData.get("strDCLCDLOutput");
			 String iDCLOASResult =  hmData.get("iDCLOASResult");
			 String strDCLOASOutput =  hmData.get("strDCLOASOutput");
			 MapList mlIPObjectList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
				  null, false, slObjDetails);
				  if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				  Map mpAttrUpdate = new HashMap<>();
				  mpAttrUpdate.put("IMP_DLC_CDLReturnValue", iDCLCDLResult);
				  mpAttrUpdate.put("IMP_DLC_CDLOutput", strDCLCDLOutput);
				  mpAttrUpdate.put("IMP_DLC_OASISReturnValue", iDCLOASResult);
				  mpAttrUpdate.put("IMP_DLC_OASISOutput", strDCLOASOutput);
				  DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				  domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setDLCAttributesToVerifyid: " + e);
		}
	}




	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getDLCResultsOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_DLCCDLRETURN = "";
		String ATTRIBUTE_IMP_DLCCDLOUTPUT = "";
		String ATTRIBUTE_IMP_DLCOASISRETURN = "";
		String ATTRIBUTE_IMP_DLCOASISOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyID = "";
		
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
		while (itrVerifyObjects.hasNext()){
			StringBuilder strTableColBuilder = new StringBuilder();
			Map map = (Map) itrVerifyObjects.next();
			ATTRIBUTE_IMP_DLCCDLRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLRETURN);
			ATTRIBUTE_IMP_DLCCDLOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCCDLOUTPUT);
			ATTRIBUTE_IMP_DLCOASISRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISRETURN);
			ATTRIBUTE_IMP_DLCOASISOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_DLCOASISOUTPUT);
			strVerifyID = (String) map.get(DomainConstants.SELECT_ID);


					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_DLCOASISRETURN)) {
						if(ATTRIBUTE_IMP_DLCOASISRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showDLCOutputForOasis('" + strVerifyID + "')\" href=\"\"; title=name>" + "Oasis" + "</a>");
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showDLCOutputForOasis('" + strVerifyID + "')\" href=\"\"; title=name>" + "Oasis" + "</a>");
						}
						strTableColBuilder.append("<input type=\"hidden\" name=\"Outputvalue\" id="+strVerifyID+" value='<div> "+ATTRIBUTE_IMP_DLCOASISOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showDLCOutputForOasis(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementById(VerifyID).value");
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("");
					}

					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_DLCCDLRETURN)) {
						strTableColBuilder.append(" | ");
						if(ATTRIBUTE_IMP_DLCCDLRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showDLCOutputForCDL('" + strVerifyID + "')\" href=\"\"; title=name>" + "CDL" + "</a>");
					
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showDLCOutputForCDL('" + strVerifyID + "')\" href=\"\"; title=name>" + "CDL" + "</a>");
						

						}
						strTableColBuilder.append("<input type=\"hidden\" name="+strVerifyID+" value='<div> "+ATTRIBUTE_IMP_DLCCDLOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showDLCOutputForCDL(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementsByName(VerifyID)[0].value");
						
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
				
						
					}else{
						strTableColBuilder.append("");
					}



			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getDLCResultsOutput " + e);
		}
		return returnVector;
	}
	
	
	@SuppressWarnings("unchecked")
	public void setLLCAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
		    StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);
			 String sVerifyid =  hmData.get("sVerifyid");
			 String iLLCOASResult =  hmData.get("iLLCOASResult");
			 String strLLCOASOutput =  hmData.get("strLLCOASOutput");;
			 MapList mlIPObjectList = DomainObject.findObjects(context,
				  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
				  null, false, slObjDetails);
				  if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				  Map mpAttrUpdate = new HashMap<>();
				  mpAttrUpdate.put("IMP_LLC_OASISReturnValue", iLLCOASResult);
				  mpAttrUpdate.put("IMP_LLC_OASISOutput", strLLCOASOutput);
				  DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				  domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setLLCAttributesToVerifyid: " + e);
		}
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getLLCResultsOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_LLCOASISRETURN = "";
		String ATTRIBUTE_IMP_LLCOASISOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyID = "";
		
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
		while (itrVerifyObjects.hasNext()){
			StringBuilder strTableColBuilder = new StringBuilder();
			Map map = (Map) itrVerifyObjects.next();
			ATTRIBUTE_IMP_LLCOASISRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISRETURN);
			ATTRIBUTE_IMP_LLCOASISOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_LLCOASISOUTPUT);
			strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
					if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_LLCOASISRETURN)) {
						if(ATTRIBUTE_IMP_LLCOASISRETURN.equalsIgnoreCase("pass")){
						strTableColBuilder.append("<a style=color:green; onClick=\"showLLCOutputForOasis('" + strVerifyID +"_strLlcResults" + "')\" href=\"\"; title=name>" + "Passed" + "</a>");
						}else{
						strTableColBuilder.append("<a style=color:red; onClick=\"showLLCOutputForOasis('" + strVerifyID +"_strLlcResults"+ "')\" href=\"\"; title=name>" + "Failed" + "</a>");
						}
						strTableColBuilder.append("<input type=\"hidden\" name=\"Outputvalue\" id="+strVerifyID+"_strLlcResults"+" value='<div> "+ATTRIBUTE_IMP_LLCOASISOUTPUT+" </div>'>");
						strTableColBuilder.append("<script>");
						strTableColBuilder.append("function showLLCOutputForOasis(VerifyID) { ");
						strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
						strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
						strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementById(VerifyID).value");
						strTableColBuilder.append("}");
						strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("");
					}
			returnVector.add(strTableColBuilder.toString());
			strTableColBuilder.setLength(0);
		}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getLLCResultsOutput " + e);
		}
		return returnVector;
	}
	

	@SuppressWarnings("unchecked")
	public void setIpScoreAttributesToVerifyid(Context context, String[] args) throws Exception {
		MapList mpTechStackList = new MapList();
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
			StringList slObjDetails = new StringList();
			StringBuilder ipBuild = new StringBuilder();
			slObjDetails.add(DomainConstants.SELECT_ID);
			String sVerifyid =  hmData.get("sVerifyid");
			String sIpScoreOutput =  hmData.get("mIpScoreOutput");

			MapList mlIPObjectList = DomainObject.findObjects(context,
			IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
			null, false, slObjDetails);
			if (!mlIPObjectList.isEmpty()) {
				Iterator <Map <String,String>> itrVerifyRunList = mlIPObjectList.iterator();
				Map <String,String> mapVerifyRun;
				String strVerifyRunId = "";
				while (itrVerifyRunList.hasNext()) {
					mapVerifyRun = itrVerifyRunList.next();
					strVerifyRunId = mapVerifyRun.get(DomainConstants.SELECT_ID);
				}
				Map mpAttrUpdate = new HashMap<>();
				mpAttrUpdate.put("IMP_IpScoreOutput", sIpScoreOutput);
				DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
				domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}

		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setIpScoreAttributesToVerifyid: " + e);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Vector getIpScoreOutput(Context context, String args[]) throws Exception {
		String ATTRIBUTE_IMP_IPSCOREOUTPUT = "";
		Vector returnVector = new Vector();
		String strVerifyName = "";
		HashMap programMap = JPO.unpackArgs(args);
		MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
		int iSize = verifyMapList.size();
		Iterator itrVerifyObjects = verifyMapList.iterator();
		try{
			while (itrVerifyObjects.hasNext()){
				StringBuilder strTableColBuilder = new StringBuilder();
				StringBuilder strTableRowBuilder = new StringBuilder();
				Map map = (Map) itrVerifyObjects.next();
				ATTRIBUTE_IMP_IPSCOREOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_IPSCOREOUTPUT);
				strVerifyName = (String) map.get(DomainConstants.SELECT_NAME);
				if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_IPSCOREOUTPUT)) {
					if (ATTRIBUTE_IMP_IPSCOREOUTPUT.contains("<br>")) {
						String lines[] = ATTRIBUTE_IMP_IPSCOREOUTPUT.split("<br>");
						for (String line: lines) {
							String sVendor = "";
							String ipProductName = "";
							if (line.contains(":")) {
								ipProductName = line.substring(0,line.indexOf(":"));
								sVendor = line.substring(line.indexOf(":")+1);
								strTableRowBuilder.append(ipProductName+"<span>&emsp; &emsp; &emsp; &emsp; &emsp; </span>"+sVendor+"<br>");
							}else{
								strTableRowBuilder.append(line+"<br>");
							}
						}
						ATTRIBUTE_IMP_IPSCOREOUTPUT = strTableRowBuilder.toString();
					}
					
					strTableColBuilder.append("<a style=color:red; onClick=showIPScoreOutput('" + strVerifyName+"_strKeyUnknow3PIPs" + "') title=IPS> Yes </a>");
					strTableColBuilder.append("<input type=hidden name=strOutputvalue id="+strVerifyName+"_strKeyUnknow3PIPs"+" value='<div> "+ATTRIBUTE_IMP_IPSCOREOUTPUT+" </div>'>");
					strTableColBuilder.append("<script>");
					strTableColBuilder.append("function showIPScoreOutput(VerifyobjID) { ");
					strTableColBuilder.append("var y = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
					strTableColBuilder.append("y.document.write('<div id=Unknow3PIPs> </div>');");
					strTableColBuilder.append("y.document.getElementById(\"Unknow3PIPs\").innerHTML = \"IP Name <span> &emsp; &emsp; &emsp; &emsp;&emsp; &emsp;&emsp; &emsp;&emsp; &emsp;&emsp; &emsp; </span>Vendor Name <br>\" + document.getElementById(VerifyobjID).value");
					strTableColBuilder.append("}");
					strTableColBuilder.append("</script>");
					}else{
						strTableColBuilder.append("<h4 style=color:green; title=name> No </h4>");
						}
				returnVector.add(strTableColBuilder.toString());
				strTableColBuilder.setLength(0);
				strTableRowBuilder.setLength(0);
			}
	} catch (Exception e) {
			throw new Exception("Exception occured in IMP_IPVerification:getIpScoreOutput " + e);
		}
		return returnVector;
	}
	
	@SuppressWarnings("unchecked")
	public static String getVerifyIPLogsForEPSWithVerifyid(Context context, String args[]) throws Exception {
		System.out.println("**** services has invoked getVerifyIPLogsForEPSWithVerifyid **** ");
		MapList mlIPVerifications = new MapList();
		String verifyIPLogs = "";
		try {
			Map<String, String> hmData = JPO.unpackArgs(args);
			String sVerifyid =  hmData.get("sVerifyid");
			System.out.println("*** sVerifyid  - "+sVerifyid);
			StringList slObjDetails = new StringList();
		    slObjDetails.add("attribute[IMP_VerifyIP_LogsForEPS]");

		    mlIPVerifications = DomainObject.findObjects(context,
					  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
					  null, false, slObjDetails);
				     
		    for (Object obj : mlIPVerifications) {
				HashMap mapIPVerifyObj = (HashMap) obj;
				verifyIPLogs = (String) mapIPVerifyObj.get("attribute[IMP_VerifyIP_LogsForEPS]");
		    }
		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:getVerifyIPLogsForEPSWithVerifyid: " + e);
		}
		
		return verifyIPLogs;
	}
	
	@SuppressWarnings("unchecked")
	public static void setVerifyIPLogsToVerifyid(Context context, String sVerifyid, String sVerifyIPLogs) throws Exception {
		MapList mlIPVerifications = new MapList();
		try {
			System.out.println("===== setVerifyIPLogsToVerifyid =====");
			StringList slObjDetails = new StringList();
		    slObjDetails.add(DomainConstants.SELECT_ID);

		    mlIPVerifications = DomainObject.findObjects(context,
					  IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN, sVerifyid, "*", "*", "*",
					  null, false, slObjDetails);
		    if (mlIPVerifications != null && !mlIPVerifications.isEmpty()) {
		    	System.out.println("==MapList is not empty====");
		    }
			for (Object obj : mlIPVerifications) {
				HashMap mapIPVerifyObj = (HashMap) obj;
				String objectId = (String) mapIPVerifyObj.get(DomainObject.SELECT_ID);
				System.out.println("==== found object id - "+objectId);
				Map mpAttrUpdate = new HashMap<>();
				mpAttrUpdate.put("IMP_VerifyIP_LogsForEPS", sVerifyIPLogs);
				DomainObject domVerifyRun = new DomainObject(objectId);
				domVerifyRun.setAttributeValues(context, mpAttrUpdate);
			}
			System.out.println("==== after updating verifyLogs in DB === ");
		} catch (MatrixException e) {
			throw new MatrixException("Exception occured in IMP_IPVerification:setVerifyIPLogsToVerifyid: " + e);
		}
	}
	
	public static void test(Context context, String []arg) {
		try {
			//25664.47740.61850.7650
			
		}catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	


        //Added for SWIMP-882:START
	public static Map checkinSSGQICfgYamlToIMP(Context context, String args[]) throws Exception {
	// DO NOT REMOVE ANY SYSOUTS FROM THIS METHOD, THIS IS TO CHECK THE FAILURE -- SWIMP-882 -- START
	boolean error = false;
	System.out.println("-- START -- SSGQI YAML CONFIGURATION FILE CHECKIN --");
	Map mpReturnMap = new HashMap();
	StringList objectSelects = new StringList();
    objectSelects.add(DomainConstants.SELECT_ID);
    objectSelects.add(DomainConstants.SELECT_ORIGINATOR);
    
    String sIPType = PropertyUtil.getSchemaProperty(context, "type_IMP_IPProduct");
    String sPolicy = PropertyUtil.getSchemaProperty(context, "policy_IMP_DirectoryTreeSpec");
    String sVault = PropertyUtil.getSchemaProperty(context, "vault_eServiceProduction");
    String sRelationship = PropertyUtil.getSchemaProperty(context, "relationship_IMP_PrivateDocuments");
    
    System.out.println("--sIPType-- "+sIPType);
    System.out.println("--sPolicy-- "+sPolicy);
    System.out.println("--sVault-- "+sVault);
    System.out.println("--sRelationship-- "+sRelationship);
    
    
    String sStatus = "Failure";
    String sSSGQIID = null;
    String sNewSSGQIName = null;
    String sMqlCmd = "print bus $1 $2 $3 select $4 dump";
    String sMqlCommand = "checkin bus $1 $2 format $3 append $4";
    String sMqlRelCommand = "connect bus $1 $2 $3 $4 $5";
    String direction = "to";
    ContextUtil.pushContext(context);
	try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
		    String sIPName = (String) programMap.get("sIPName");
		    System.out.println("-- sIPName --: " + sIPName);
		    String sUser = (String) programMap.get("sUser");
		    System.out.println("-- sUser --: " + sUser);
		    String sTag = (String) programMap.get("sTag");
		    System.out.println("-- sTag --: " + sTag);
		    String sSSGQICfgFile = (String) programMap.get("sSSGQICfgFile");
		    System.out.println("-- sSSGQICfgFile --: " + sSSGQICfgFile);
		    String sSSGQICfgPath = (String) programMap.get("sSSGQICfgPath");
		    System.out.println("-- sSSGQICfgPath --: " + sSSGQICfgPath);
		    MapList mpIPIDList = DomainObject.findObjects(context, sIPType, sIPName, "A", "*", "*", null, false, objectSelects);
		    System.out.println("-- mpIPIDList --: \n" + mpIPIDList);
		    MQLCommand mql = new MQLCommand();
	        mql.open(context);
		    if (!mpIPIDList.isEmpty() && mpIPIDList.size() != 0) {
		    Map mapIPID = (Map) mpIPIDList.get(0);
		    System.out.println("-- mapIPID --: \n" + mapIPID);
		    String strIPID = (String) mapIPID.get(DomainConstants.SELECT_ID);
		    System.out.println("-- strIPID --: \n" + strIPID);
		    try {
		    DomainObject domObject = new DomainObject();
		    sNewSSGQIName = DomainObject.getAutoGeneratedName(context, "type_IMP_IP_SSGQI_CFG", "");
		    domObject.createObject(context, "IMP_IP_SSGQI_CFG", sNewSSGQIName, "-", sPolicy, sVault);
		    System.out.println("-- sNewSSGQIName---AUTONAME--GENERATED --: \n" + sNewSSGQIName);
		    } catch (Exception e) {
				logger.error("Exception while saving "+sSSGQICfgFile+"  in IMP");
				e.getMessage();
			}
		    System.out.println("-- FTP WORKING DIR --: " + sSSGQICfgPath);
		    File file = new File(sSSGQICfgPath);
		    if (file.isDirectory() && file.listFiles() != null) {
	            File[] files = file.listFiles();	
	            for (int i = 0; i < files.length; i++) {
	              String strPath = "";
	              if (files[i].isFile()) {
	                strPath = sSSGQICfgPath + file.separator + files[i].getName();
	                System.out.println("-- strPath --: " + strPath.trim());
	                String sFileName = files[i].getName();
	                System.out.println("-- sFileName --: " + sFileName);
	                if(sFileName.trim().equals(sSSGQICfgFile.trim())) {
	                	System.out.println("-- "+ sSSGQICfgPath +" FILE EXISTS AND MATCHES: " + file.exists());
	                	try {
	                	sSSGQIID = MqlUtil.mqlCommand(context, sMqlCmd, "IMP_IP_SSGQI_CFG", sNewSSGQIName, "-", "id");
	                	System.out.println("-- sSSGQIID --: " + sSSGQIID);
	                	if (UIUtil.isNotNullAndNotEmpty(sSSGQIID)) {
	                	mql.executeCommand(context, sMqlCommand, sSSGQIID, "unlock", "yaml", sSSGQICfgPath+java.io.File.separatorChar+sFileName);
	                	System.out.println("-- SSGQI CHECKIN COMMAND EXECUTED SUCCESSFULLY FOR OBJ --: "+sSSGQIID);
	                	mql.executeCommand(context, sMqlRelCommand, strIPID, "rel", sRelationship, direction, sSSGQIID);
	            		System.out.println("-- strIPID --:"+strIPID+" -- CONNECTED TO -- sSSGQIObjId --:"+sSSGQIID+"  -- WITH REL -- :"+sRelationship);
	            		if (mql.getError() != null && !mql.getError().equals("")) throw new Exception(mql.getError());
	            		else {
		                sStatus = "Success";
	            		}
	                   }
	                  } catch (Exception e) {
	        				logger.error("Exception while checkin "+sFileName+" from  :"+sSSGQICfgPath+"  in IMP");
	        				e.getMessage();
	                	}
	                break;
	                }
	             }
	          }
	       }
	   }
	   mql.close(context);
	   mpReturnMap.put(sSSGQIStatus, sStatus);
	   mpReturnMap.put(sSSGQFileName, sSSGQICfgFile);
	} catch (Exception ex) {
		ex.printStackTrace();
    } finally {
		ContextUtil.popContext(context);
	}
	// DO NOT REMOVE ANY SYSOUTS FROM THIS METHOD, THIS IS TO CHECK THE FAILURE -- SWIMP-882 -- END
	return mpReturnMap;
	//Added for SWIMP-882:ENDED
  }
  // Added for SWIMP-883

@SuppressWarnings({ "rawtypes", "unchecked" })
public static Map checkoutSSGQICfgYamlFromIMP(Context context, String[] args) throws Exception {

    final String K_STATUS = "ssgqiCfgStatus";
    final String K_MSG = "message";
    final String K_DIR = "ssgqiCfgCheckoutDir";
    final String K_FILE = "ssgqiCfgFileName";
    final String K_FALLBACK = "ssgqiCfgFallbackUsed";

    final String ST_SUCCESS = "Success";
    final String ST_NOT_FOUND = "NOT_FOUND";
    final String ST_AMBIGUOUS = "AMBIGUOUS";
    final String ST_ERROR = "ERROR";

    Map mpReturnMap = new HashMap();

    try {
        HashMap programMap = (HashMap) JPO.unpackArgs(args);

        String ipObjectId = (String) programMap.get("ipObjectId");
        String cfgFileName = (String) programMap.get("cfgFileName");

        if (StringUtils.isBlank(ipObjectId)) throw new Exception("ipObjectId is null/empty");
        if (StringUtils.isBlank(cfgFileName)) throw new Exception("cfgFileName is null/empty");

        DomainObject ipObj = new DomainObject(ipObjectId);
        String ipName = ipObj.getInfo(context, DomainConstants.SELECT_NAME);

        // Normalize if caller passed "null-..."
        String targetFileName = cfgFileName.trim();
        if (targetFileName.startsWith("null-")) {
            targetFileName = ipName + "-" + targetFileName.substring("null-".length());
        }

        // allow .yaml vs .yml (compute once)
        final String targetYml = targetFileName.endsWith(".yaml")
                ? targetFileName.substring(0, targetFileName.length() - 5) + ".yml"
                : targetFileName;

        String relSSGQIForIP = PropertyUtil.getSchemaProperty(context, "relationship_IMP_SSGQIConfigforIP");
        String typeSSGQI = PropertyUtil.getSchemaProperty(context, "type_IMP_IP_SSGQI_CONFIG");

        StringList objectSelects = new StringList();
        objectSelects.add(DomainConstants.SELECT_ID);
        objectSelects.add(DomainConstants.SELECT_NAME);
        objectSelects.add(DomainConstants.SELECT_TYPE);

        StringList relSelects = new StringList();
        relSelects.add(DomainRelationship.SELECT_ID);

        // Single direction only (removed second call per your observation/logs)
        MapList connectedObjects = ipObj.getRelatedObjects(
                context,
                relSSGQIForIP,
                typeSSGQI,
                objectSelects,
                relSelects,
                false,  // getTo
                true,   // getFrom
                (short) 1,
                null,
                null,
                0
        );

        int count = (connectedObjects == null) ? 0 : connectedObjects.size();
        System.out.println("SWIMP-883: connectedObjects(getTo=false,getFrom=true,level=1) count=" + count
                + " ip=" + ipName + " ipObjectId=" + ipObjectId);

        if (connectedObjects == null || connectedObjects.isEmpty()) {
            mpReturnMap.put(K_STATUS, ST_NOT_FOUND);
            mpReturnMap.put(K_MSG, "No related SSGQI config object for IP " + ipName);
            return mpReturnMap;
        }

        DomainObject exactObj = null;
        String exactFile = null;
        String exactFormat = null;

        DomainObject soleObj = null;
        String soleFile = null;
        String soleFormat = null;
        int attachmentCount = 0;

        // Search attachments across all connected objects
        for (int i = 0; i < connectedObjects.size() && exactObj == null; i++) {
            Map objMap = (Map) connectedObjects.get(i);
            String objId = (String) objMap.get(DomainConstants.SELECT_ID);
            DomainObject tmpObj = new DomainObject(objId);

            StringList yamlFiles = tmpObj.getInfoList(context, "format[yaml].file.name");
            if (yamlFiles == null) yamlFiles = new StringList();

            StringList ymlFiles = tmpObj.getInfoList(context, "format[yml].file.name");
            if (ymlFiles == null) ymlFiles = new StringList();

            // Scan YAML files
            for (int j = 0; j < yamlFiles.size(); j++) {
                String f = String.valueOf(yamlFiles.get(j)).trim();
                if (f.isEmpty()) continue;

                if (f.equals(targetFileName)) {
                    exactObj = tmpObj; exactFile = f; exactFormat = "yaml";
                    break;
                }

                attachmentCount++;
                if (attachmentCount == 1) { soleObj = tmpObj; soleFile = f; soleFormat = "yaml"; }
                else { soleObj = null; soleFile = null; soleFormat = null; }
            }

            // Scan YML files
            for (int j = 0; j < ymlFiles.size() && exactObj == null; j++) {
                String f = String.valueOf(ymlFiles.get(j)).trim();
                if (f.isEmpty()) continue;

                if (f.equals(targetFileName) || f.equals(targetYml)) {
                    exactObj = tmpObj; exactFile = f; exactFormat = "yml";
                    break;
                }

                attachmentCount++;
                if (attachmentCount == 1) { soleObj = tmpObj; soleFile = f; soleFormat = "yml"; }
                else { soleObj = null; soleFile = null; soleFormat = null; }
            }
        }

        DomainObject ssgqiObj;
        String foundFileName;
        String foundFormat;
        boolean fallbackUsed = false;

        if (exactObj != null) {
            ssgqiObj = exactObj;
            foundFileName = exactFile;
            foundFormat = exactFormat;
        } else if (attachmentCount == 1 && soleObj != null && StringUtils.isNotBlank(soleFile)) {
            ssgqiObj = soleObj;
            foundFileName = soleFile;
            foundFormat = soleFormat;
            fallbackUsed = true;
        } else if (attachmentCount > 1) {
            mpReturnMap.put(K_STATUS, ST_AMBIGUOUS);
            mpReturnMap.put(K_MSG, "Multiple YAML/YML attachments; cannot choose safely. Requested=" + targetFileName);
            return mpReturnMap;
        } else {
            mpReturnMap.put(K_STATUS, ST_NOT_FOUND);
            mpReturnMap.put(K_MSG, "No YAML/YML attachment found. Requested=" + targetFileName);
            return mpReturnMap;
        }

        // Checkout into IMP server working dir (SFTP-visible) like SWIMP-882
        String workingDir = System.getProperty("imp.cli.server.working.dir", "/projects/imp/tmp");
        String ssgqiFolder = System.getProperty("imp.cli.ssgqi.temp.cfg.folder", "ssgqi");

        String checkoutDir =
                workingDir + File.separator
                        + ssgqiFolder + File.separator
                        + "imp-ssgqi-cfg-checkout" + File.separator
                        + UUID.randomUUID().toString() + File.separator;

        File dir = new File(checkoutDir);
        if (!dir.exists() && !dir.mkdirs()) {
            mpReturnMap.put(K_STATUS, ST_ERROR);
            mpReturnMap.put(K_MSG, "Failed to create checkout dir: " + checkoutDir);
            return mpReturnMap;
        }

        try {
            ContextUtil.startTransaction(context, true);

            MqlUtil.mqlCommand(
                    context,
                    "checkout bus $1 server format $2 file $3 $4",
                    ssgqiObj.getObjectId(),
                    foundFormat,
                    foundFileName,
                    checkoutDir
            );

            ContextUtil.commitTransaction(context);

            mpReturnMap.put(K_STATUS, ST_SUCCESS);
            mpReturnMap.put(K_DIR, checkoutDir);
            mpReturnMap.put(K_FILE, foundFileName);
            mpReturnMap.put(K_FALLBACK, String.valueOf(fallbackUsed));
            mpReturnMap.put(K_MSG, fallbackUsed
                    ? ("Exact filename not found; checked out single available file: " + foundFileName)
                    : ("Checked out file: " + foundFileName));

            return mpReturnMap;

        } catch (Exception e) {
            ContextUtil.abortTransaction(context);
            mpReturnMap.put(K_STATUS, ST_ERROR);
            mpReturnMap.put(K_MSG, "Checkout failed: " + e.getMessage());
            throw e;
        }

    } catch (Exception e) {
        mpReturnMap.put(K_STATUS, ST_ERROR);
        mpReturnMap.put(K_MSG, String.valueOf(e.getMessage()));
        return mpReturnMap;
    }
}


@SuppressWarnings({ "unchecked", "rawtypes" })
public void setSSGQIAttributesToVerifyid(Context context, String[] args) throws Exception {

    System.out.println("\n[SSGQI_SET] ENTER setSSGQIAttributesToVerifyid");
    System.out.println("[SSGQI_SET] context is null? " + (context == null));
    System.out.println("[SSGQI_SET] args is null? " + (args == null));
    System.out.println("[SSGQI_SET] args length=" + (args == null ? -1 : args.length));

    try {
        System.out.println("[SSGQI_SET] unpackArgs...");
        Map hmData = JPO.unpackArgs(args);
        System.out.println("[SSGQI_SET] hmData is null? " + (hmData == null));
        System.out.println("[SSGQI_SET] hmData keys=" + (hmData == null ? "null" : hmData.keySet()));

        System.out.println("[SSGQI_SET] build slObjDetails...");
        StringList slObjDetails = new StringList();
        slObjDetails.add(DomainConstants.SELECT_ID);
        System.out.println("[SSGQI_SET] slObjDetails=" + slObjDetails);

        String sVerifyid = hmData == null ? null : (String) hmData.get("sVerifyid");
        String iSSGQIResult = hmData == null ? null : (String) hmData.get("iSSGQIResult"); // "pass"/"fail"
        String strSSGQIOutput = hmData == null ? null : (String) hmData.get("strSSGQIOutput"); // HTML output
        String strSSGQIReportPath = hmData == null ? null : (String) hmData.get("strSSGQIReportPath"); // optional

        System.out.println("[SSGQI_SET] sVerifyid=" + sVerifyid);
        System.out.println("[SSGQI_SET] iSSGQIResult=" + iSSGQIResult);
        System.out.println("[SSGQI_SET] strSSGQIOutput len=" + (strSSGQIOutput == null ? -1 : strSSGQIOutput.length()));
        System.out.println("[SSGQI_SET] strSSGQIOutput preview=" + (strSSGQIOutput == null ? "null"
                : (strSSGQIOutput.length() > 200 ? strSSGQIOutput.substring(0, 200) + "..." : strSSGQIOutput)));
        System.out.println("[SSGQI_SET] strSSGQIReportPath=" + strSSGQIReportPath);

        System.out.println("[SSGQI_SET] findObjects inputs:");
        System.out.println("[SSGQI_SET]   type=" + IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN);
        System.out.println("[SSGQI_SET]   namePattern(sVerifyid)=" + sVerifyid);

        MapList mlIPObjectList = DomainObject.findObjects(
                context,
                IMP_Constants_mxJPO.TYPE_IMP_VERIFY_RUN,
                sVerifyid, "*", "*", "*",
                null, false, slObjDetails
        );

        System.out.println("[SSGQI_SET] findObjects returned null? " + (mlIPObjectList == null));
        System.out.println("[SSGQI_SET] findObjects size=" + (mlIPObjectList == null ? -1 : mlIPObjectList.size()));
        System.out.println("[SSGQI_SET] findObjects raw=" + mlIPObjectList);

        if (mlIPObjectList != null && !mlIPObjectList.isEmpty()) {
            System.out.println("[SSGQI_SET] iterating results...");
            Iterator itrVerifyRunList = mlIPObjectList.iterator();
            String strVerifyRunId = null;
            int hit = 0;

            while (itrVerifyRunList.hasNext()) {
                hit++;
                Map mapVerifyRun = (Map) itrVerifyRunList.next();
                System.out.println("[SSGQI_SET] hit#" + hit + " map keys=" + (mapVerifyRun == null ? "null" : mapVerifyRun.keySet()));
                strVerifyRunId = (mapVerifyRun == null) ? null : (String) mapVerifyRun.get(DomainConstants.SELECT_ID);
                System.out.println("[SSGQI_SET] hit#" + hit + " SELECT_ID=" + strVerifyRunId);
            }

            System.out.println("[SSGQI_SET] final chosen strVerifyRunId=" + strVerifyRunId);

            System.out.println("[SSGQI_SET] building mpAttrUpdate...");
            Map mpAttrUpdate = new HashMap();
            mpAttrUpdate.put("IMP_SSGQI_ReturnValue", iSSGQIResult);
            mpAttrUpdate.put("IMP_SSGQI_Output", strSSGQIOutput);
            mpAttrUpdate.put("IMP_SSGQI_ReportPath", strSSGQIReportPath);

            System.out.println("[SSGQI_SET] mpAttrUpdate keys=" + mpAttrUpdate.keySet());
            System.out.println("[SSGQI_SET] mpAttrUpdate ReturnValue=" + mpAttrUpdate.get("IMP_SSGQI_ReturnValue"));
            Object outVal = mpAttrUpdate.get("IMP_SSGQI_Output");
            System.out.println("[SSGQI_SET] mpAttrUpdate Output len=" + (outVal == null ? -1 : String.valueOf(outVal).length()));
            System.out.println("[SSGQI_SET] mpAttrUpdate ReportPath=" + mpAttrUpdate.get("IMP_SSGQI_ReportPath"));

            System.out.println("[SSGQI_SET] setAttributeValues start...");
            DomainObject domVerifyRun = new DomainObject(strVerifyRunId);
            domVerifyRun.setAttributeValues(context, mpAttrUpdate);
            System.out.println("[SSGQI_SET] setAttributeValues done.");

            // Read-back (confirms persistence)
            try {
                System.out.println("[SSGQI_SET] read-back verification start...");
                StringList sels = new StringList();
                sels.add(DomainConstants.SELECT_ID);
                sels.add("attribute[IMP_SSGQI_ReturnValue]");
                sels.add("attribute[IMP_SSGQI_Output]");
                sels.add("attribute[IMP_SSGQI_ReportPath]");

                Map after = domVerifyRun.getInfo(context, sels);
                System.out.println("[SSGQI_SET] AFTER id=" + (after == null ? "null" : after.get(DomainConstants.SELECT_ID)));
                System.out.println("[SSGQI_SET] AFTER return=" + (after == null ? "null" : after.get("attribute[IMP_SSGQI_ReturnValue]")));
                Object afterOut = (after == null ? null : after.get("attribute[IMP_SSGQI_Output]"));
                System.out.println("[SSGQI_SET] AFTER output len=" + (afterOut == null ? -1 : String.valueOf(afterOut).length()));
                System.out.println("[SSGQI_SET] AFTER report=" + (after == null ? "null" : after.get("attribute[IMP_SSGQI_ReportPath]")));
                System.out.println("[SSGQI_SET] read-back verification end.");
            } catch (Exception rbEx) {
                System.out.println("[SSGQI_SET] read-back exception: " + rbEx);
            }

        } else {
            System.out.println("[SSGQI_SET] No VerifyRun found; nothing updated.");
        }

        System.out.println("[SSGQI_SET] EXIT setSSGQIAttributesToVerifyid");

    } catch (MatrixException e) {
        System.out.println("[SSGQI_SET] MatrixException=" + e);
        throw new MatrixException("Exception occured in IMP_IPVerification:setSSGQIAttributesToVerifyid: " + e);
    }
}
@SuppressWarnings({ "unchecked", "rawtypes" })
public static Vector getSSGQIResultsOutput(Context context, String args[]) throws Exception {

    String ATTRIBUTE_IMP_SSGQIRETURN = "";
    String ATTRIBUTE_IMP_SSGQIOUTPUT = "";

    Vector returnVector = new Vector();
    String strVerifyID = "";

    HashMap programMap = JPO.unpackArgs(args);
    MapList verifyMapList = (MapList) programMap.get(IMP_Constants_mxJPO.OBJECT_LIST);
    Iterator itrVerifyObjects = (verifyMapList == null) ? null : verifyMapList.iterator();

    try {
        while (itrVerifyObjects != null && itrVerifyObjects.hasNext()) {

            StringBuilder strTableColBuilder = new StringBuilder();
            Map map = (Map) itrVerifyObjects.next();

            strVerifyID = (String) map.get(DomainConstants.SELECT_ID);
            if (UIUtil.isNullOrEmpty(strVerifyID)) {
                strVerifyID = (String) map.get("id");
            }

            ATTRIBUTE_IMP_SSGQIRETURN = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);
            ATTRIBUTE_IMP_SSGQIOUTPUT = (String) map.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);

            // Fallback DB read (trigger on NULL OR EMPTY) - ONLY 2 attributes
            if (UIUtil.isNotNullAndNotEmpty(strVerifyID)
                    && (UIUtil.isNullOrEmpty(ATTRIBUTE_IMP_SSGQIRETURN)
                        || UIUtil.isNullOrEmpty(ATTRIBUTE_IMP_SSGQIOUTPUT))) {

                DomainObject dObj = new DomainObject(strVerifyID);

                StringList sels = new StringList();
                sels.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);
                sels.add(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);

                Map info = dObj.getInfo(context, sels);

                if (UIUtil.isNullOrEmpty(ATTRIBUTE_IMP_SSGQIRETURN))
                    ATTRIBUTE_IMP_SSGQIRETURN =
                        (String) info.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIRETURN);

                if (UIUtil.isNullOrEmpty(ATTRIBUTE_IMP_SSGQIOUTPUT))
                    ATTRIBUTE_IMP_SSGQIOUTPUT =
                        (String) info.get(IMP_Constants_mxJPO.SELECT_ATTRIBUTE_IMP_SSGQIOUTPUT);
            }

            if (UIUtil.isNotNullAndNotEmpty(ATTRIBUTE_IMP_SSGQIRETURN)) {

                String popupId = strVerifyID + "_strSsgqiResults";

                if (ATTRIBUTE_IMP_SSGQIRETURN.equalsIgnoreCase("pass")) {
                    strTableColBuilder.append("<a style=color:green; onClick=\"showSSGQIOutput('")
                                      .append(popupId)
                                      .append("')\" href=\"\" title=name>Passed</a>");
                } else {
                    strTableColBuilder.append("<a style=color:red; onClick=\"showSSGQIOutput('")
                                      .append(popupId)
                                      .append("')\" href=\"\" title=name>Failed</a>");
                }

                String out = (ATTRIBUTE_IMP_SSGQIOUTPUT == null) ? "" : ATTRIBUTE_IMP_SSGQIOUTPUT;
                out = out.replace("'", "&#39;");

                strTableColBuilder.append("<input type=\"hidden\" name=\"Outputvalue\" id=\"")
                                  .append(popupId)
                                  .append("\" value='<div>")
                                  .append(out)
                                  .append("</div>'>");

                strTableColBuilder.append("<script>");
                strTableColBuilder.append("function showSSGQIOutput(VerifyID) { ");
                strTableColBuilder.append("var x = window.open('','popUpWindow','height=500,width=400,left=100,top=100');");
                strTableColBuilder.append("x.document.write('<div id=\"div\"> </div>');");
                strTableColBuilder.append("x.document.getElementById(\"div\").innerHTML =document.getElementById(VerifyID).value");
                strTableColBuilder.append("}");
                strTableColBuilder.append("</script>");

            } else {
                strTableColBuilder.append("");
            }

            returnVector.add(strTableColBuilder.toString());
            strTableColBuilder.setLength(0);
        }

    } catch (Exception e) {
        throw new Exception("Exception occured in IMP_IPVerification:getSSGQIResultsOutput " + e);
    }

    return returnVector;
}
// Added for SWIMP-883

}