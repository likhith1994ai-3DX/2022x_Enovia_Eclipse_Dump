/*------------------------------------------------------------------------------------------------------------------------------------------
 * 
 * NAME         : Publish.java
 * DESCRIPTION  : Publish the IP into IMP from the IMP/DesignSync staging area. This means updating information about
 *                the IP in IMP and updating the design data in the associated DM with the new version's files,
 *                running QA, and, pushing it to the published state if QA passes, adding/removing any new/deleted
 *                files since the last module version and then checking in the module with --tag, if supplied.
 *                
 * USAGE        : java -jar ${PATH}/CLI.jar 
 * 
 *                Sample input as below format
 *                imp publish -h
 *                imp publish --help
 *                imp publish -i [--ip-id]
 *              
 * CREATED      : 17-August-2016
 * 
 * AUTHOR       : TECHMAHINDRA
 * 
 * HISTORY:
 * 
 * Name                     Modified Date                 Description
 * 
 * Sai Prasad               17-Aug-2016                   Initial version.
 * Sai Prasad               02-Sep-2016                   Added system exit status for the bug #IMPBRCM-167
 * Aravala Raju             06-Sep-2016                   Replaced sun.misc.BASE64Encoder with Java 8 equivalent
 * Sai Prasad               07-Sep-2016                   Added system exit status for the bug #IMPBRCM-167
 * Aravala Raju             14-Sep-2016                   IMPBRCM-88 and IMPBRCM-27
 * Aravala Raju             15-Sep-2016                   IMPBRCM-88 & 27 - updated tech stack and QA summary as per the changed spec
 * Aravala Raju             16-Sep-2016                   Fixed Tag with brach defect   
 * Sai Prasad               16-Sep-2016                   Help text updated 
 * Avinash                  19-Oct-2016                   Added preapproved list for user story 248
 * Sai Prasad               31-Oct-2016                   Bug fix for check-bom
 * Sai Prasad               14-Nov-2016                   Added water-marking and public documents
 * Sai Prasad               16-Nov-2016                   Added to set ip id to export-bom: bug-570 and modified for fail fast case.
 * Harish Telanakula        21-Nov-2016                   IMPBRCM-60 
 * Sai Prasad               24-Nov-2016                   Fix for the bug 617
 * Sai Prasad               02-Dec-2016                   Changed getWaterMarkString to public for bug 712, added info message for bug 359
 * Sai Prasad               08-Dec-2016                   Bug fix for 724.
 * Sai Prasad               12-Dec-2016                   Handling null pointer exception when IPICA fails for bug 743
 * Aravala Raju             26-Dec-2016                   Fix for IMPBRCM-574
 * Sai Prasad               12-Jan-2017                   Fix for 919
 * Madhusmita Mohapatra     13-July-2017                  Fix for SWIMP-5
 * Madhusmita Mohapatra     17-July-2017                  Fix for SWIMP-19 - Relaced Modroot with ipBaseDir
 * Madhusmita Mohapatra     19-July-2017                  Added to handle exception if -o option is provided in staging area
 * Madhusmita Mohapatra     31-July-2017                  Fix for SWIMP-37
 * KrishnaD                 08-Aug-2017                   Added for Watermarking Multiple GDS files SWIMP-1
 * Madhusmita Mohapatra     25-Oct-2017                   Add checks to make sure public documents are indeed uploaded
 * Madhusmita Mohapatra     11-07-2017                    Fix for SWIMP-108
 * Mahammed Irshad K S		03-Jan-2019					  Modified for SWIMP-262
 * Mahammed Irshad K S		21-Apr-2020					  Modified method watermarkFiles for SWIMP-348
 * Mahammed Irshad K S		22-Feb-2020					  Modified method publishIP for SWIMP-425
 * Mahammed Irshad K S		10-Mar-2020					  Added methods performCheckLayerForDesignFile, getDesignFiles and writeCheckLayersFile for SWIMP-425
 * Mahammed Irshad K S		21-Apr-2020					  Modified method watermarkFiles for SWIMP-348
 * Mahammed Irshad K S		05-May-2020					  Added the method deleteFiles for SWIMP-425
 * Mahammed Irshad K S		10-Jun-2020					  Modified the method performCheckLayerForDesignFile, listAllDesignFiles and setGDSFile,for SWIMP-471
 * Mahammed Irshad K S      10-Jun-2020                   Removed methods getDesignFiles, writeCheckLayersFile and deleteFiles and Moved these to Utility JPO for SWIMP-471
 * Mahammed Irshad K S      26-Jun-2020                   Modified the method publishIP for SWIMP-488
 * Mahammed Irshad K S      13-Jul-2020                   Modified the methods performCheckLayerForDesignFile and listAllDesignFiles for SWIMP-492
 * Mahammed Irshad K S      14-Aug-2020                   Added an option to skip checklayers execution for Hard 3PIPs and modified method publishIP for SWIMP-502
 * Mahammed Irshad K S      26-Aug-2020                   Added method checkForChecklayersfilesAndDeleteOnExists and modified performCheckLayerForDesignFile for SWIMP-502
 * Mahammed Irshad K S      07-Sep-2020                   Added method validateTARArchiveExtraction and modified method publishIP and performCheckLayerForDesignFile for SWIMP-501
 * Mahammed Irshad K S      24-Jul-2020                   Modified the method checkPreApproved for SWIMP-31
 *------------------------------------------------------------------------------------------------------------------------------------------
 */
package com.broadcom.impcli.subcommands;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map.Entry; //Added for SWIMP-568
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.nio.file.*;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.kohsuke.args4j.Argument;
import org.kohsuke.args4j.Option;
import org.kohsuke.args4j.spi.StopOptionHandler;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import com.broadcom.bom.ConfigValidator.CheckBomResult;
import com.broadcom.bom.ExpandedDeliverable;
import com.broadcom.bom.configuration.ComponentConfiguration;
import com.broadcom.bom.specification.Specification;
import com.broadcom.impcli.client.IMPCommon;
import com.broadcom.impcli.client.IMPException;
import com.broadcom.impcli.client.IMPLog;
import com.broadcom.impcli.client.IMPTempDirectory;
import com.broadcom.impcli.enovia.IMPEnoviaClientWrapper;
import com.broadcom.impcli.stclc.IMPStclcWrapper;
import com.broadcom.utility.GDSFileUtility;
import com.broadcom.utility.OutputFile;
import com.broadcom.utility.Utility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.broadcom.impcli.client.IMPConstants;
import java.util.regex.*;
import java.util.*;

/**
 * The Class Publish
 */

public class Publish extends AbstractSubcommand {
  
  /** The bhelp. */
  @Option(name = "--help", required = false, help = true, aliases = {"-h", "--help"},
      usage = "Print this message.")
  private boolean bHelp;

  /** The s output file. */
  @Option(name = "--ofile", required = false, aliases = {"-o", "--ofile"},
      usage = "output-file. unix path name to a file where structured results data will be placed.Default to stdout")
  private String sOutputFile = "";

  /** The s verbose. */
  @Option(name = "--verbose", usage = "Turns on additional messaging.", aliases = "-v",
      required = false)
  private int iVerbose = 4;

  /** The specified IP dir. */
  @Option(name = "--ip-dir",
      usage = "The directory containing the design data for the IP. Defaults to CWD.",
      aliases = "-I", required = false)
  private String sIPDir;

  /** The sa comment. */
  @Option(name = "--comment", usage = "Comment associated with the release", aliases = {"--comment","-c"}, required = true)
  private String saComment;
  
  /** The s tag. */
  @Option(name = "--tag", usage = "The tag name to check in the files under", aliases = {"--tag","-t"}, required = true)
  private String sTag;

  /** The is prefixed. */
  @Option(name = "--is-uniquified", required = false,
      usage = "The IP being published has already been prefixed (uniquified)",aliases = {"--is-uniquified"})
  private boolean isPrefixed;

  /** The s quality class. */
  @Option(name = "--quality-class", required = false, aliases = {"-q","--quality-class"},
      usage = "Quality class for the revision")
  private String sQualityClass = "";

  /** The s GDS version. */
  @Option(name = "--gds-version", required = false,
      usage = "Specify the GDS file version associated with the GDS file being published",aliases = {"--gds-version"})
  private String sGDSVersion = "";

  /** The b dry run. */
  @Option(name = "--dry-run",
      usage = "Do everything that prepare-sa would do, but not actually make or populate the staging area.",
      aliases = {"-D", "--dry-run"}, required = false)
  private boolean bDryRun;
  
  /** The b force. */
  @Option(name = "--force", required = false,usage = "Publish the IP even in case of QA failures", aliases = {"--force"})
  private boolean bForce;
  
  /** The b pre-approved. */
  @Option(name = "--pre-approved", required = false,aliases = {"-p", "--pre-approved"},usage = "An IP owner should be able to pre-approve the revision being published for use in specific or all projects.")
  private String sPreapproveList;
  
  /** Recommended revision. */
  @Option(name = "--recommended", required = false,usage = "Make the newly published revision the recommended revision for the branch", aliases = {"--recommended"})
  private boolean bRecommended;
  
  /** Default revision. */
  @Option(name = "--default", required = false,usage = "Make the newly published revision the default revision of the IP Product", aliases = {"--default"})
  private boolean bDefaultRev;
  
  /** Alert Attribute */
  @Option(name = "--alert", required = false,usage = "alert attribute for IP revision", aliases = {"--alert"})
  private String sAlert;
  
  
  /** skip-tag-validation. */
  @Option(name = "--skip-tag-validation", required = false,usage = "Skip tag Validation as enfoced by the Dtree Spec.", aliases = {"--skip-tag-validation"})
  private boolean bSkipTagValid;

  //Added for SWIMP-502
  /** skip check layers execution. */
  @Option(name = "--skip-check-layers", required = false,usage = "Skip bad GDS/OAS layers check for Hard 3PIPs via checklayers tool", aliases = {"--skip-check-layers"})
  private boolean bSkipCheckLayers;

  /** The s Queue Name. */
  @Option(name = "--queue-name", usage = "The queue name to invoke ipinfo for large .oas/.gds files",
      required = false)
  private String sQueueName; //Added for SWIMP-31
  
  //Added for SWIMP-849
  //Modified for SWIMP-850
  /** Lightweight Publish */
  @Option(name = "--lightweight", usage = "Lightweight Publish (no check-bom, no IPICA, no checklayers, no new watermarks)", aliases = {"-lw", "--lightweight"}, required = false)
  private boolean bLightWeight;

  //Added for SWIMP-632 -S
  /** The b force unlock. */
  @Option(name = "--force-unlock", required = false,usage = "Publish the IP even if IP is locked for publish", aliases = {"--force-unlock"})
  private boolean bForceIPPublishUnlock;
  //Added for SWIMP-632 -E
  @Argument
  @Option(name = "--", handler = StopOptionHandler.class)
  List<String> lCmdArgs;
  
  /** The s QA failure base. */
  private static String sQAFailureBase = "/imp/QA-Failures";
  
  /** The s QA failed. */
  private static String sQAFailed = "QA Validation Failed. Aborting operation";
  
  /** The s proc name. */
  private static String sProcName = "publish";  
  /** The o file obj. */
  private OutputFile oFileObj;  
  /** The stcl args list. */
  private List<String> stclArgsList;
  private static String strHostName;
  private static String sTRUNK = "Trunk";
  private static String strSuccess = "success";  
  //Added for CR IMPBRCM-1043: Starts
  private static String sWatermark;
  private static String strMediaType = "application/json";
  private static String sTechnologyStacks = "technology_stacks";//Added for SWIMP-281

  /** The s CHECKLAYERS failed. */
  //Modified for SWIMP-501: Starts
  private static String sCheckLayersProcessFailureMessage = "checklayers process Failed. Aborting publish operation. Please refer to the file ../imp/checklayers.err for more details."; //Added for SWIMP-425
  private static String sCheckLayersProcessFailureMessageForce = "checklayers process Failed. Please refer to the file ../imp/checklayers.err for more details."; //Addded for SWIMP-605
  private static String sCheckLayersStatusFAIL = "checklayers status: FAIL";
  private static String sCheckLayersStatusPASS = "checklayers status: PASS";
  //Modified for SWIMP-501: Ends

  //Added for SWIMP-31: Starts
  GDSFileUtility gdsFileUtility; //SWIMP-31
  private static Map<String, String> gdsSpecificChildInfoMap = new HashMap<>();
  private static Map<String, Map<String, String>> gdsSpecificLineageMap = new HashMap<>();
  private static String sBlockIP="Block IP";
  private static final String STR_FAILED = "Failed";
  private static String sCOUNT = "count";

  List<ExpandedDeliverable> delivsToWatermark = new ArrayList<>();
  //Added for SWIMP-31: Ends


  //Added for SWIMP-568 : Starts
  private static Map<String, Object> yamlOut = new LinkedHashMap<>();
  private static Object sOutput;

  //Added for SWIMP-632 -S
  private static final String  KEY_PUBLISH_LOCK_STRING = "PUBLISH_LOCK_STRING";
  private String sIPPublishLockString;
  private boolean bIsIPLockedForPublish = false;
  private static final String KEY_OLD_PUBLISH_LOCK_STRING = "OLD_PUBLISH_LOCK_STRING";
  //Added for SWIMP-632 -E
  private String sWMDerivedFromRevision;
  //private boolean bLightWeight = false; // SWIMP-870
  private List<String> modifiedFileNames = new ArrayList<String>();
  private boolean isMarkerFileExists; // SWIMP-850
  
  //SWIMP-882
  private static long tStart = System.currentTimeMillis();
  private boolean bRunSSGQI = false;
  private boolean bCfgFileExistsinDTree = false;
  private static Pattern UNKNOWN_OPTION;
  private String isSSGQICfgValue;

  /**
   * Gets the s Output.
   *
   * @return the s Output
   */
  public static Object getsOutput() {
	  return sOutput;
  }

  /**
   * Sets the s Output.
   *
   * @param sOutput the new s output
   */
  public static void setsOutput(Object sOutput) {
	  Publish.sOutput = sOutput;
  }
  //Added for SWIMP-568 : Ends


  /**
   * This is a constructor.
   * 
   */
  public Publish() {
    this(new String[1]);
    stclArgsList = new ArrayList<>();
    stclArgsList.add(sProcName);
  }

  /**
   * This is a constructor.
   *
   * @param args the args
   */
  public Publish(String[] args) {
    super(args);
  }

  /**
   * This is a execute method for subcommand.
   *
   * @return void
   */
  @Override
  public void execute() {
	  int iExit = 0;
	  IMPCommon commonObj = new IMPCommon();
	  try {
		  if (this.bHelp) {
			  printUsage();
		  } else {
			  IMPLog.start(sProcName, iVerbose, lCmdArgs);
			  iExit = publishIP();
			  yamlOut.put("msg", IMPCommon.displayExitCode(iExit));
			  setsOutput(yamlOut);
			//Added for SWIMP-568 : Ends
			  IMPLog.writeMessage(oFileObj, getsOutput(), iExit); //Modified for SWIMP-568
		  }
	  } catch (IMPException | IOException e) {
		  iExit = 1;
		  IMPLog.error("", e);
	  }  finally {
		  commonObj.exitSystem(iExit); //SWIMP-262
	  }
  }

  /**
   * This is help method
   *
   * @return void
   */
  @Override
  public void printUsage() {
    String sHelp = IMPCommon.getHelpContent(HELP_PUBLISH);
    IMPCommon.displayMessage(sHelp, false);
  }

  /**
   * Publish IP.
   *
   * @return the int
   * @throws IMPException the IMP exception
   * @throws IOException Signals that an I/O exception has occurred.
   */
  @SuppressWarnings({ "rawtypes", "unchecked" })
  private int publishIP() throws IMPException, IOException {
    int iReturn = 0;
    //Added for SWIMP-882
    String sFTPSSGQICfgPath = "";
    String sFTPSSGQICfgFileName = "";
    ProcessBuilder pSSGQIBuilder = null;
    String sSSGQIErrorOutput = "";
    String ssgqi_ip_foundry = "";
	String ssgqi_ip_process = "";
	String ssgqi_ip_subprocess = "";
	String ssgqi_ip_metalstack = "";
	String ssgqi_ip_source = "";
    String ssgqi_ip_type = "";
    String sSSGQIConfigFile = "";
    String sUserHomeSSGQIConfigFile = "";
    String sUserDirSSGQIConfigFile = "";
    Path sourceCfgPath = null;
    Exception lastFailure = null;
    //Added for SWIMP-882
    try {
      String sModRoot = Utility.getIPDir(this.sIPDir);
      Path sModRootPath = Paths.get(sModRoot);
      LocalDateTime dateTime = LocalDateTime.now();
      String sTimeStamp = dateTime.format(DateTimeFormatter.ofPattern(TIME_STAMP));
      String strPreApprove = null;
      IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
      String strIPID;
      String strBranch = "";
      String ipBaseDir;
      String ipMarkerFileDir; // SWIMP-850
      String ipModSel;
      String sModValues = Utility.getModuleInfo(sModRoot);
      
      if (!IMP_ERROR.startsWith(sModValues)) {
        strIPID = IMPStclcWrapper.getStrIPID();
        strBranch = IMPStclcWrapper.getStrBranch();
        ipBaseDir = IMPStclcWrapper.getStrDIR();
        ipModSel = IMPStclcWrapper.getStrModSelector();
      } else {
        strIPID = sModValues;
        ipModSel = sModValues;
        ipBaseDir=sModRootPath.toAbsolutePath().toString();
      }

      if (StringUtils.isNotBlank(this.sOutputFile)) { //Added for SWIMP-262
    	  oFileObj = new OutputFile();
    	  try {
    		  oFileObj.init("publish", this.sOutputFile, ipBaseDir);
    	  } catch (IMPException e) {
    		  IMPLog.error(e.getMessage());
    		  iReturn = 2;
    		  return iReturn;
    	  }
      }

      Path ipPath = Paths.get(ipBaseDir);
      IMPCommon.setIpDIR(ipBaseDir);
      if (!ipPath.toFile().exists()   || !ipPath.toFile().isDirectory()) {
        iReturn = 20;
        return iReturn;
      }
      File fIPICAPath = new File(IPICA_BASE_PATH);
      if (!fIPICAPath.exists()) { // Modified for bug 791
        int i = automountIPICAWrapper(ipBaseDir);
        if (i != 0) {
          iReturn = 21;
          return iReturn;
        }
      }
      if (strIPID.isEmpty()) {
        iReturn = 54; //Modified for bug IMPBRCM-912
        return iReturn;
      } else if (IMP_ERROR.equals(strIPID)) {
        iReturn = 52;
        return iReturn;
      }   
      
      IMPCommon.setIpID(strIPID); //Added for SWIMP-262
      IMPLog.trace("IP ID for this operation: " + strIPID);      
      IMPCommon.setsTag(sTag);      
      IMPLog.info("Branch: " + strBranch);
      String sActualTag = this.sTag.substring(this.sTag.lastIndexOf('/') + 1);
      if (!"ERROR".equals(strBranch)) {
        String strBranchFromTag = "";
        if (sTRUNK.equalsIgnoreCase(strBranch)) {
          if (this.sTag.contains("/")) {
            IMPLog.error("'" + this.sTag
                + "' is not a valid revision tag - '/' cannot be used in a revision tag for Trunk");
            return 2;
          } else if (sTRUNK.equalsIgnoreCase(this.sTag)) {
            IMPLog.error("'" + this.sTag + "' is not a valid revision tag");
            return 2;
          }
        } else {
          if (this.sTag.contains("/")) {
            strBranchFromTag = this.sTag.substring(0, this.sTag.indexOf('/'));
          }
          
          if (this.sTag.endsWith("/") || !this.sTag.contains("/")) {
            IMPLog.error("Invalid tag '" + this.sTag + "' specified - it must be of the form '"
                + strBranch
                + "/<tag_name>' where <tag-name> can contain letters, numbers, underscores (_), periods (.) and hyphens (-), and must begin with a letter");
            return 2;
          } else if (!strBranchFromTag.equals(strBranch)) {
            IMPLog.error("Invalid tag '" + this.sTag + "' specified - it must be of the form '"
                + strBranch + "/" + sActualTag + "'");
            return 2;
          }
        }
        // Modified for Bug 1047 : Start
        int count = StringUtils.countMatches(this.sTag, "/");
        if (!sActualTag.matches("^[A-Za-z][\\w\\-.\\/]*") || sActualTag == "" || count > 1) {
          iReturn = 22;
          return iReturn;
        }
        // Modified for Bug 1047 : end
      } else {
        iReturn = 52;
        return iReturn;
      }

      IMPLog.debug("Module Selector: " + ipModSel);

      if (ipModSel != null && !ipModSel.isEmpty() && !strBranch.equalsIgnoreCase(ipModSel)) {
        iReturn = 65;
        return iReturn;
      }

      if (this.sAlert != null && this.sAlert.isEmpty()) {
        iReturn = 62;
        return iReturn;
      }
    //Added for SWIMP-838: Starts
      String errorOutput = "";
	  IMPLog.trace("Ensuring world read permissions for staging area before check-in");
	  ProcessBuilder pB = new ProcessBuilder("chmod", "-R", "a+r", ipPath.toString()); 
	  pB.redirectErrorStream(true);
	  Process process = pB.start();
	  int processVal = process.waitFor();
      if (processVal == 0) {
    	  IMPLog.debug("'chmod -R a+r' on the staging area is successful!" + System.lineSeparator() + "File permissions changed successfully");
        } else {
		  errorOutput = new BufferedReader(new InputStreamReader(process.getInputStream()))
               .lines()
               .collect(Collectors.joining(System.lineSeparator()));
          IMPLog.debug("'chmod -R a+r' on the staging area failed!" + System.lineSeparator() + errorOutput);
        }	
      //Added for SWIMP-838: Ends
      org.codehaus.jettison.json.JSONObject jsQAVal = null;
      org.codehaus.jettison.json.JSONObject jsIPAttInfo = null;//Added for SWIMP-425
      IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
      //Modified for SWIMP-1
      String sUniqueTag = "";
      Map <String,String> mWMFile = new HashMap<>();//SWIMP-1
      
      //Added for SWIMP-262: Starts
      //Check for user access for the IPID and get QA_VAL_INPUT data
      org.codehaus.jettison.json.JSONObject jsOwnerData = enoClient.checkAccessForObject(IMPCommon.getImpUser(),
    		  IMP_CONST_TYPE_IPPRODUCT, strIPID, sProcName, null);
      int iAccess = jsOwnerData.getInt("code");
      if (iAccess > 0) {
    	  IMPLog.debug(IMP_CONST_AUTHENTICATIONFAILED);
    	  return IMPCommon.relatedIntCodeForReturnedCodeFromJPO(iAccess);
      }
      IMPLog.debug(IMP_CONST_AUTHENTICATIONSUCCESS);
      //Added for SWIMP-262: Ends
      //Added for SWIMP-632 -S
      if (!getIPPublishLock()) {
    	  return 2;
      }
      //Added for SWIMP-632 -E

      if (null != jsOwnerData) {
    	  jsQAVal = (org.codehaus.jettison.json.JSONObject) jsOwnerData.get("QA_VAL_INPUT");
    	  jsIPAttInfo = (org.codehaus.jettison.json.JSONObject) jsOwnerData.get("ip_attributeValues_info"); //Added for SWIMP-425
      }
      
      boolean bRequireQualityClass = jsQAVal.getBoolean("REQUIRE_QUALITY_CLASS"); // Added for SWIMP-432

      //Added for SWIMP-432: Starts
      if(bRequireQualityClass && StringUtils.isEmpty(this.sQualityClass)) {
    	  iReturn = 85;
          return iReturn;
      }
      //Added for SWIMP-432: Ends
      // Modified for bug 1002
      IMPLog.debug("Quality Class: " + this.sQualityClass);
      IMPLog.debug("Tag: " + this.sTag);

      List<String> lsDeprecatedBy = enoClient.getDeprecatedBy(strIPID);
	  if (lsDeprecatedBy != null && !lsDeprecatedBy.isEmpty()) {
		IMPLog.warn(strIPID + " has been deprecated by "
			+ lsDeprecatedBy.toString().substring(1, lsDeprecatedBy.toString().length() - 1));
	  }
      
      String publisherEmail = "";
      String publisherFullName = "";
      if(jsOwnerData.get("USER_DATA") !=null){

		HashMap<String,Object> result =
    		        new ObjectMapper().readValue(jsOwnerData.getString("USER_DATA"), HashMap.class);
    	  publisherFullName = (String)result.get("attribute[IMP_EMP_DISPLAY_NAME]");
    	  publisherEmail = (String)result.get("attribute[Email Address]");
      }
      
      IMPEnoviaClientWrapper impEnoClientmodurl = new IMPEnoviaClientWrapper();
      String sModuleUrl = impEnoClientmodurl.getModuleUrlvalue(strIPID);
      if (sModuleUrl == null || sModuleUrl.isEmpty()) {
        iReturn = 27;
        return iReturn;
      }

      IMPLog.debug("jsOwnerData: " + jsOwnerData);
      //Updated for SWIMP-849
      // 1. Get the latest revision sequence for the given branch
      org.codehaus.jettison.json.JSONObject jsonIPRevLastTags =
          (org.codehaus.jettison.json.JSONObject) jsOwnerData.get("IP_REVISIONS");

      IMPLog.debug("Branch LastRevision: " + jsonIPRevLastTags);
      
      String sBranch = "Trunk";
      String strLastetTag = null;
      String key = null;
      String latestBranchAndRevision = "";

      if (jsonIPRevLastTags != null && jsonIPRevLastTags.length() > 0) {
        // 2. get the last revision and compare it with the new revision supplied
        int iIndex = sTag.lastIndexOf('/');

        if (iIndex != -1) {
          sBranch = this.sTag.substring(0, iIndex);
          sActualTag = this.sTag.substring(iIndex + 1, sTag.length());
        }

        Iterator itrBrachLastTags = jsonIPRevLastTags.keys();

        while (itrBrachLastTags.hasNext()) {
          key = (String) itrBrachLastTags.next();
          if (sBranch.equalsIgnoreCase(key)) {
            strLastetTag = (String) jsonIPRevLastTags.get(key);
            latestBranchAndRevision = key +"/"+strLastetTag;
            IMPLog.trace(key);
            IMPLog.trace(strLastetTag);
            IMPLog.trace(latestBranchAndRevision);
            break;
          }
        }
        IMPLog.debug(
                "Branch: " + key + "\t Latest tag: " + strLastetTag + "\t Given tag: " + sActualTag);
        if(StringUtils.isEmpty(strLastetTag) && bLightWeight) {
        	IMPLog.error("Lightweight publish not allowed for the first revision of a branch");
  	      	iReturn = 2;
  	      	return iReturn;
        }
      }
      // Changes related to IMPBRCM-980 - start
      if (this.sQualityClass.startsWith("ML")) {
          // 3.if new revision is not greater than the last revision throw error
 
          if (strLastetTag != null) {
            int iCompare = compareRevisionTag(sActualTag, strLastetTag);
            if (iCompare == -1) {
              // New tag is lesser than the last tag
              iReturn = 2;
              IMPLog.error("Specified revision tag '" + sActualTag
                  + "' is lower than the last revision tag of '" + strLastetTag
                  + "' - Please retry with a different tag");
              return iReturn;
            } else if (iCompare == 0) {
              // New tag is same as that if last tag
              iReturn = 2;
              IMPLog.error("Specified revision tag '" + sActualTag
                  + "' is same as the last revision tag of '" + strLastetTag
                  + "' - Please retry with a different tag");
              return iReturn;
            }
            IMPLog.debug("compareRevisionTag: " + iCompare);
          }else {
          IMPLog
              .debug("IP_REVISIONS json is empty..this must be a new IP Rev: " + jsonIPRevLastTags);
        }
      }
      // Changes related to IMPBRCM-980 -end
      String sIPIDWMSeed = "";
      // Fix for bug 617 ends
      org.codehaus.jettison.json.JSONObject jsQAData = enoClient.getQAFailureMsg(strIPID, sTag, true);
      if (jsQAData.length() != 0) {
        sUniqueTag = (String) jsQAData.get("IPTAG");
        sIPIDWMSeed = (String) jsQAData.get("sIPIDWMSeed");
      }

      if (!sUniqueTag.isEmpty() && sUniqueTag.equals(this.sTag)) {
        iReturn = 25;
        return iReturn;
      }
    //Check the staging area excluding imp,ipicarun,QAFailure folder and bom.yaml file before publishing- SWIMP-36
    //Added for SWIMP-850:START
       isMarkerFileExists = false;
       ipMarkerFileDir = ipBaseDir + File.separator + IMPConstants.IMP_CLI_IMP_FOLDER + File.separator;
       String markerFileName = SYMBOL_DOT + IMP_CLI_REQUIRES_LIGHTWEIGHT_PUBLISH;
       File markerFile = new File(ipMarkerFileDir, markerFileName);
       if (markerFile.exists()) {
    	    IMPLog.trace(IMP_CLI_PUBLISH_MARKER_EXISTS_KEY + markerFile.getAbsolutePath());
    	    isMarkerFileExists = true;
       }
       int retResult = checkStagingAreaForChanges(ipBaseDir,strIPID,isMarkerFileExists);
       if (retResult != 0) {
         iReturn = 2;
         return iReturn;
       }
       if (!bLightWeight && isMarkerFileExists) {
   	    IMPLog.warn(IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_WARN_KEY);
   	   }
       
 	   //Added for SWIMP-882
 	   ssgqi_ip_source = jsIPAttInfo.getString("attribute[IMP_IPSource]");
       ssgqi_ip_type = jsIPAttInfo.getString("attribute[IMP_IPType]");
       if (ssgqi_ip_type.contains("Hard IP") && ssgqi_ip_source.equalsIgnoreCase("Internal")) {
           bRunSSGQI = true;
           IMPLog.info("The following IP: "+strIPID+" is Internal Hard IP");
       }
       if (bRunSSGQI) {
       Map<String, Object> oSSGQIFileResMap = new LinkedHashMap<>();
       Map<String, Object> ssgqi_specMap = new LinkedHashMap<>();
       String ssgqi_impversion = Version.getIMPVersion();
       String ssgqi_starttime = new SimpleDateFormat(IMP_DATE_FORMAT).format(tStart);
       String ssgqi_userlogin = IMPCommon.getImpUser()+"@"+IMPCommon.getImpDomain();
       String ssgqi_product_division = jsQAVal.getString("bu");
       String ssgqi_ip_owner = jsQAVal.getString("IP_OWNER");
       List<Map<String, Object>> ssgqi_lTechStackInfo = new ArrayList<>();
       if(jsQAVal.getJSONArray(sTechnologyStacks)!=null) {
     	  ssgqi_lTechStackInfo =  new ObjectMapper()
     			  .readValue(jsQAVal.getJSONArray(sTechnologyStacks).toString(), ArrayList.class);
       }
       if(ssgqi_lTechStackInfo != null && ssgqi_lTechStackInfo.size() > 0) {
     	  Map<String, Object> ssgqiObjMap = ssgqi_lTechStackInfo.get(0);
     	  ssgqi_ip_foundry = (String) ssgqiObjMap.get(IMPConstants.IMP_TECHSTACK_ATTR_FOUNDRY);
     	  ssgqi_ip_process = (String) ssgqiObjMap.get(IMPConstants.IMP_TECHSTACK_ATTR_PROCESSNODE);
     	  ssgqi_ip_subprocess = (String) ssgqiObjMap.get(IMPConstants.IMP_TECHSTACK_ATTR_SUBPROCESS);
     	  ssgqi_ip_metalstack = (String) ssgqiObjMap.get(IMPConstants.IMP_TECHSTACK_ATTR_METALSTACK);
        }
       ssgqi_specMap.put("impversion", ssgqi_impversion);
       ssgqi_specMap.put("starttime", ssgqi_starttime);
       ssgqi_specMap.put("userlogin@hostname", ssgqi_userlogin);
       ssgqi_specMap.put("ipid", strIPID);
       ssgqi_specMap.put("owner", ssgqi_ip_owner);
       ssgqi_specMap.put("bu", ssgqi_product_division);
       ssgqi_specMap.put("foundry", ssgqi_ip_foundry);
       ssgqi_specMap.put("process", ssgqi_ip_process);
       ssgqi_specMap.put("subprocess", ssgqi_ip_subprocess);
       ssgqi_specMap.put("metalstack", ssgqi_ip_metalstack);
       
       if(!ssgqi_specMap.isEmpty() && ssgqi_specMap != null) {
       oSSGQIFileResMap.put("ssgqi_info", ssgqi_specMap);
       String expFileName = ipPath.resolve("imp/ssgqi-spec.yaml").toString();
       final DumperOptions options = new DumperOptions();
       options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
       options.setPrettyFlow(true);
       Yaml exportYamFile = new Yaml(options);
       exportYamFile.dump(oSSGQIFileResMap, new FileWriter(expFileName));
       }
      }
      //Added for SWIMP-882
       
      //Added for SWIMP-850:END
      String sComment = String.join(" ", this.saComment);
      // Checkbom functionality
      ExportBom exportCheck = new ExportBom();
      //Added for SWIMP-850:START
      exportCheck.setsLightWeightValue(bLightWeight);
      exportCheck.setsMarkerFile(isMarkerFileExists);
      //Added for SWIMP-850:END
      exportCheck.setsIPDir(ipBaseDir);
      exportCheck.setsIPId(strIPID); // Added for bug 570
      exportCheck.setsQualityClass(sQualityClass);
      exportCheck.setPublish(true); // Set as publish for bug 683
	  // Added for SWIMP-281: Starts
      List<Map<String, Object>> lTechStackInfo = new ArrayList<>();
      if(jsQAVal!=null && jsQAVal.getJSONArray(sTechnologyStacks)!=null) {
    	  lTechStackInfo =  new ObjectMapper()
    			  .readValue(jsQAVal.getJSONArray(sTechnologyStacks).toString(), ArrayList.class);
      }
      // Added for SWIMP-281: Ends
      exportCheck.setReleaseData(sTag,sComment,publisherFullName,publisherEmail,lTechStackInfo );//Modified for SWIMP-281: to support Tech Stack Info
      // Added for SWIMP-720: Starts     
      String imp_ip_source=jsIPAttInfo.getString("attribute[IMP_IPSource]");
      String imp_product_division = jsQAVal.getString("bu");
      String imp_ip_type = jsIPAttInfo.getString("attribute[IMP_IPType]");
      String imp_ip_library = jsIPAttInfo.getString("attribute[IMP_Library]");
      String imp_ip_stype = "";
      if(imp_ip_type.contains("Hard"))
    	  imp_ip_stype="hard";
      if(imp_ip_type.contains("Soft") || imp_ip_type.contains("Other"))
    	  imp_ip_stype="soft";
      
      String imp_ip_foundry = "";
      String imp_ip_process = "";
      String imp_ip_subprocess = "";

      if(lTechStackInfo!=null && lTechStackInfo.size() > 0) {
    	  Map<String, Object> objTechMap = lTechStackInfo.get(0);
    	  imp_ip_foundry = (String) objTechMap.get(IMPConstants.IMP_TECHSTACK_ATTR_FOUNDRY);
  	  	  imp_ip_process = (String) objTechMap.get(IMPConstants.IMP_TECHSTACK_ATTR_PROCESSNODE);
  	  	  imp_ip_subprocess = (String) objTechMap.get(IMPConstants.IMP_TECHSTACK_ATTR_SUBPROCESS);
      }
      
      Map<String, String> guiVariableMap  = new HashMap<String, String>();
      guiVariableMap.put(IMPConstants.STR_IMP_IPID, strIPID);
      guiVariableMap.put(IMPConstants.STR_IMP_IPNAME, strIPID.substring(0, strIPID.length()-4));
      guiVariableMap.put(IMPConstants.STR_IMP_IPSOURCE, imp_ip_source);
      guiVariableMap.put(IMPConstants.STR_IMP_DIVISON, imp_product_division);
      guiVariableMap.put(IMPConstants.STR_IMP_IPTYPE, imp_ip_type);
      guiVariableMap.put(IMPConstants.STR_IMP_IPLIB, imp_ip_library);
      guiVariableMap.put(IMPConstants.STR_IMP_IPSTYPE, imp_ip_stype);
      guiVariableMap.put(IMPConstants.STR_IMP_IPFOUNDRY, imp_ip_foundry);
      guiVariableMap.put(IMPConstants.STR_IMP_IPPROCESS, imp_ip_process);
      guiVariableMap.put(IMPConstants.STR_IMP_IPSUBPROCESS, imp_ip_subprocess);
      
	  exportCheck.setGuiVariableMap(guiVariableMap);
	  // Added for SWIMP-720: Ends 
      int iExport = exportCheck.exportBom();
      if (iExport != 0) {
        iReturn = 2;
        return iReturn;
      } else {
      // Added for SWIMP-850:START
      if (!bLightWeight && !isMarkerFileExists) {
         IMPLog.info("check-bom passed");
      }}
      // Added for SWIMP-850:ENDS
      //Added for SWIMP-432: Starts
      iReturn = exportCheck.validateIfRevisionMatchesQualityClass(sTag,sQualityClass);
      if(iReturn != 0) {
    	  return iReturn;
      }
      //Added for SWIMP-432: Ends
      // Fix for bug 617 starts -- Moved if conditions to make fail fast case      
      // Check for public documents upfront before executing publish 
      IMPLog.trace("IP Base Dir: "+ipBaseDir);
      Set<String> sfinalPubDocSet=new HashSet<>();
      CheckBomResult bomResult = exportCheck.getExportBomResult();  
      String tagMsg =  isTagValidPerSpec(sActualTag,bomResult.getSpecs()); 
      if(!tagMsg.isEmpty()) {
    	  	IMPLog.error(tagMsg);
    	  	iReturn = 2;
    	  	return iReturn;
      }
      Set<String> pubDocs = new HashSet<>(bomResult.getConfiguration().getPublicDoc()); // User defined public docs
      // TODO cast to Boolean is a little unsafe, need type-checking of public_doc: true/false in DTree JAR?
      try(Stream<String> strPath =  bomResult.getDeliverables().stream().filter(d -> d.getAttributes().containsKey("public_doc")
    		  && ((Boolean) d.getAttributes().get("public_doc"))).map(d -> d.getPath())){
    	  if(strPath !=null)
    		  pubDocs.addAll(strPath.collect(Collectors.toSet()));
      }
      for(String pubD : pubDocs) {
    	  if(ipPath.resolve(pubD).toFile().exists())
    		  sfinalPubDocSet.add(pubD);
      }
      
      //Added for SWMP-87: Starts
      for (ComponentConfiguration c : bomResult.getConfiguration().getComponents()) { //Formatted the for loop as part of SWIMP-442
    	  String compName = c.getComponentName();
    	  List<ExpandedDeliverable> delivsToUniquify = new ArrayList<>();
    	  try (Stream<ExpandedDeliverable> strExpDel = bomResult.getDeliverables().stream()
    			  .filter(d -> d.getComponentID().equals(compName)
    					  && d.getAttributes().containsKey("needs_uniquification")
    					  && Boolean.TRUE.equals(d.getAttributes().get("needs_uniquification")))) {
    		  delivsToUniquify.addAll(strExpDel.collect(Collectors.toList()));
    	  }
    	  if(bRunSSGQI) { //Added for SWIMP-882
    		List<ExpandedDeliverable> ssgqiDeliverables = new ArrayList<>();
			try (Stream<ExpandedDeliverable> strExpDel = bomResult.getDeliverables().stream()
      			        .filter(d -> d.getComponentID().equals(compName)
      			        && d.getAttributes().containsKey("is_ssgqi_cfg")
      			        && Boolean.TRUE.equals(d.getAttributes().get("is_ssgqi_cfg")))) {
				ssgqiDeliverables.addAll(strExpDel.collect(Collectors.toList()));	
      		}
			// Get the paths of SSGQI deliverables where attribute is_ssgqi_cfg is true
			for (ExpandedDeliverable deliverablePath : ssgqiDeliverables) {
				isSSGQICfgValue = String.valueOf(deliverablePath.getPath());
			    break; // only keep the single value
			}
			if(!isSSGQICfgValue.isEmpty() && isSSGQICfgValue != null) {
      		   IMPLog.trace("isSSGQICfgValue: "+isSSGQICfgValue);
      		   bCfgFileExistsinDTree = true;
    	    } else {
    	       bCfgFileExistsinDTree = false;
    	       IMPLog.trace("The path to the ssgqi cfg file in the dtree spec is not specified");
    	    }
    	  }
    	  //Added for SWIMP-882
    	  //Added for SWIMP-869
    	  if(bLightWeight) {
				List<ExpandedDeliverable> lightWeightDeliverables = new ArrayList<>();
				try (Stream<ExpandedDeliverable> strExpDel = bomResult.getDeliverables().stream()
						.filter(d -> d.getComponentID().equals(compName)
								&& d.getAttributes().containsKey("is_lightweight")
								&& Boolean.TRUE.equals(d.getAttributes().get("is_lightweight")))) {
					lightWeightDeliverables.addAll(strExpDel.collect(Collectors.toList()));
				}

				// Get the paths of deliverables where attribute is_lightweight is true
				List<String> listOfDeliverablePaths = new ArrayList<String>();
				for (ExpandedDeliverable deliverablePath : lightWeightDeliverables) {
					listOfDeliverablePaths.add(deliverablePath.getPath().toString());
				}
				
				// listOfDeliverableForLW.forEach(System.out::println); //SWIMP-869
				List<String> modFileNames = new ArrayList<String>();
				modFileNames = getModifiedFileNames();

				if (modFileNames != null && !modFileNames.isEmpty()) {
					List<String> fileNotDeclaredinDtee = modFileNames.stream()
							.filter(filePath -> !listOfDeliverablePaths.contains(filePath))
							.filter(filePath -> { //SWIMP-850
						        java.nio.file.Path fullPath = java.nio.file.Paths.get(ipBaseDir, filePath);
						        return java.nio.file.Files.exists(fullPath);
						    }) //SWIMP-850
							.collect(Collectors.toList());

					if (!fileNotDeclaredinDtee.isEmpty()) {
						String message = "Error: Lightweight publish (-lw) failed. The following files in the staging area are not marked with is_lightweight=true and cannot be published with -lw:\n"
								+ fileNotDeclaredinDtee.stream().collect(Collectors.joining("\n    ", "    ", ""))
								+ "\nOnly the following files can be modified for a lightweight publish:\n"
								+ listOfDeliverablePaths.stream().collect(Collectors.joining("\n    ", "    ", ""));
						IMPLog.error(message);
						iReturn = 2;
						return iReturn;
					}
			   }
    	  }
    	  if (bRunSSGQI) { //Added for SWIMP-882
    		  IMPLog.info("SSGQI invocation started");
    		  sFTPSSGQICfgFileName = strIPID+"--"+this.sTag+"--ssgqi-cfg.yaml";
    		  String stempPath = System.getProperty("java.io.tmpdir");
    		  String stempCfgFile = stempPath + File.separator + sFTPSSGQICfgFileName;
    		  File sSSGQIdestCfgFile = new File(stempCfgFile);
    		  String sSSGQISpecFile = ipPath.resolve("imp/ssgqi-spec.yaml").toString();
    		  String sSSGQIReportFile = ipPath.resolve("imp/SSG_report").toString();
    		  if (isSSGQICfgValue == null || isSSGQICfgValue.isEmpty()) {
    			  bCfgFileExistsinDTree = false; 
    		  } else {
    			  bCfgFileExistsinDTree = true;
    			  List<String> sSSGQIConfigFiles = new ArrayList<String>();
    		      try {
    		      String sUserHomeDir = System.getProperty("user.home");
    		      sUserHomeSSGQIConfigFile = sUserHomeDir + File.separator + isSSGQICfgValue;
    		      sSSGQIConfigFiles.add(sUserHomeSSGQIConfigFile.trim());
    		      
    		      String sCurrentDir = System.getProperty("user.dir");
    		      sUserDirSSGQIConfigFile = sCurrentDir + File.separator + isSSGQICfgValue; 
    		      sSSGQIConfigFiles.add(sUserDirSSGQIConfigFile.trim());
    		      
    		      for (String sSSGQIConfigFilePath : sSSGQIConfigFiles){
    		            try {
    		            	sourceCfgPath = validateSSGQIConfigFile(sSSGQIConfigFilePath); // success => stop iterating
    		            	lastFailure = null; // clear any previous failure
    		                break;
    		            } catch (Exception e) {
    		                lastFailure = e;
    		            }
    		      }
                  if (sourceCfgPath == null && lastFailure != null) {
                	  IMPLog.error("SSGQI config file is invalid :" +lastFailure.getMessage());
                	  iReturn = 2;
    		        } 
    		      } catch (Exception ex) {
    		      IMPLog.error("Exception while checking the file: "+isSSGQICfgValue+"  "+ex.getMessage());
    		      iReturn = 2;
    		      }
    		  }
    		  if (bCfgFileExistsinDTree) {
        		  Path destCfgPath = sSSGQIdestCfgFile.toPath();
        		  Files.copy(sourceCfgPath, destCfgPath, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        		  IMPLog.trace("Copied to: " + destCfgPath);
        		  sSSGQIConfigFile = destCfgPath.toString();
    			  pSSGQIBuilder = new ProcessBuilder(IMP_CLI_SSGQI_TOOL_PATH, IMP_CLI_SSGQI_IMPID_OPTION, strIPID, IMP_CLI_SSGQI_EXTRA_FILE_OPTION, sSSGQIConfigFile, IMP_CLI_SSGQI_SPEC_FILE_OPTION, sSSGQISpecFile, IMP_CLI_SSGQI_REPORT_OPTION, sSSGQIReportFile);
    		     } else {
    			  IMPLog.warn("SSGQI extra file not found; Please see the following page for details\n: "+IMP_CLI_SSGQI_USERGUIDE_URL);
    			  pSSGQIBuilder = new ProcessBuilder(IMP_CLI_SSGQI_TOOL_PATH, IMP_CLI_SSGQI_IMPID_OPTION, strIPID, IMP_CLI_SSGQI_SPEC_FILE_OPTION, sSSGQISpecFile, IMP_CLI_SSGQI_REPORT_OPTION, sSSGQIReportFile);
    		      }
    		      pSSGQIBuilder.redirectErrorStream(true);
    			  Process p = pSSGQIBuilder.start();
    			  int processValue = p.waitFor();
    			  if (processValue == 0) {
    				  File fSSGQIReportPath = new File(sSSGQIReportFile.trim());
    				  IMPLog.info("SSGQI Report generated : "+fSSGQIReportPath.getAbsolutePath());  
    			  } else {
    				  sSSGQIErrorOutput = new BufferedReader(new InputStreamReader(p.getInputStream()))
    			               .lines()
    			               .collect(Collectors.joining(System.lineSeparator()));
    				       if (!sSSGQIErrorOutput.contains("Report generated")) {
    				    	  IMPLog.error("SSGQI : "+IMP_CLI_SSGQI_TOOL_PATH +" invocation failed due to "+ System.lineSeparator() + sSSGQIErrorOutput);  
    				      }
    			  }
    			  if (bCfgFileExistsinDTree) {
    				String strSSGQIDir = IMP_CLI_SSGQI_TEMP_CFG_FOLDER;
    			    Path pTempPath = Utility.createTempDir(IMP_CLI_SERVER_HOST, strSSGQIDir);
    			    if (pTempPath == null) {
    					IMPLog.error(sSSGQIConfigFile+ "failed to transfer to" + IMP_CLI_SERVER_HOST);
    				} else {
    					sFTPSSGQICfgPath = pTempPath.toAbsolutePath().toString();
    				}
    				if (pTempPath != null) {
    					setStrHostName(IMP_CLI_SERVER_HOST);
    					iReturn = uploadFile(sSSGQIConfigFile, sFTPSSGQICfgPath, sFTPSSGQICfgFileName);//Modified for SWIMP-742
    					if (iReturn == 0) {
    						IMPLog.trace("Copied " + sFTPSSGQICfgFileName + " to IMP server " + pTempPath.toAbsolutePath().toString());
    					} else {
    						IMPLog.error("Copying " + sFTPSSGQICfgFileName + " to IMP server failed");
    					}
    				} else {
    					IMPLog.error("The following SSGQI file(s) are not uploaded to the server" + sFTPSSGQICfgFileName);
    				  }
    			    }
    				sSSGQIdestCfgFile.deleteOnExit();
    				IMPLog.trace("deleted file(s) on exit: " + sSSGQIdestCfgFile);
    				IMPLog.info("SSGQI invocation ended");
    	  } //Added for SWIMP-882
    	  boolean bShouldCreateManifestFile = false; // Added for SWIMP-442
    	  boolean bShouldGenerateManifestFile = false; // Added for SWIMP-583
    	  String sManifestFilePath = ipPath.resolve("imp/" + compName + "-manifest.yaml").toString(); // Added for SWIMP-442
    	  Map<String, Object> uniquificationFileMap = new LinkedHashMap<>(
    			  getUniquificationData(Paths.get(ipBaseDir), delivsToUniquify, compName));
	  
    	  if (!uniquificationFileMap.isEmpty()) {
    		  if (!c.getLeaveCells().isEmpty() && c.getLeaveCells() != null) {
    			  uniquificationFileMap.put("leave_cells", new ArrayList<>(c.getLeaveCells()));
    		  }
    		  bShouldGenerateManifestFile = true; // Added for SWIMP-583
    	  } else {
    		  IMPLog.warn(
    				  "No uniquification data has been specified in the directory tree specification for the component: "
    						  + compName);
    	  }
    	  // SWIMP-442: Starts
    	  File compManifestfile = new File(sManifestFilePath); // Creating a file Object to Read
    	  if (compManifestfile.exists()) { // Validating if the file exists
    		  String strCurrentLine;
    		  try (BufferedReader bufferedReader = new BufferedReader(new FileReader(compManifestfile))) { // If the file exists reading it line by line
    			  while ((strCurrentLine = bufferedReader.readLine()) != null) {
    				  if (strCurrentLine.startsWith("# Created")
    						  && strCurrentLine.contains("using imp version")) {// Checking if the line starts with # Created and contains string "using imp version"
    					  bShouldCreateManifestFile = true; // instructing to overwrite manifest file because the file is system generated
    					  IMPLog.info("Existing manifest file "+sManifestFilePath+" was generated by IMP, WILL be overwritten");
    				  }
    			  }
    		  }
    	  } else { // if no file exists instructing to create an empty manifest file
    		  bShouldCreateManifestFile = true;
    	  }
    	  if (bShouldCreateManifestFile) {
    		  IMPLog.info("Generating manifest file  "+ sManifestFilePath);
    		  ////Added for SWIMP-636 -S
    		  int iManifestFileGenerateCode = Utility.createManifestYaml(sManifestFilePath, ipPath, uniquificationFileMap);  // SWIMP-442: Ends
    		  if (iManifestFileGenerateCode != 0 ) {
    			  return iManifestFileGenerateCode; 
    		  }//Added for SWIMP-636 -E
    	  } else { // Added for SWIMP-583
    		  if (bShouldGenerateManifestFile) {
    			  // This warning message for case where we have some files to uniquify in Dtree specification, but we are not creating system generated manifest file because we found manual manifest file
    			  IMPLog.warn("Existing manifest file "+sManifestFilePath+" was NOT generated by IMP, will NOT be overwritten");
    		  }
    	  }
      } //Added for SWMP-87: Ends

      String strIPProductType = null; // Added for SWIMP-31
      //Added for SWIMP-425: Starts
      //checklayers process starts
      //Added for SWIMP-850: STARTS
      if (jsIPAttInfo != null && !bLightWeight && !isMarkerFileExists) {
    	  String strIPSource = (String) jsIPAttInfo.get(IMP_ATTRIBUTE_IPSOURCE);
    	  String strIPType = (String) jsIPAttInfo.get(IMP_ATTRIBUTE_IPTYPE);
    	  strIPProductType = (String) jsIPAttInfo.get(ATTRIBUTE_IMP_PRODUCTTYPE); //Added for SWIMP-31
    	  if ((IMP_ATTRIBUTE_IPTYPE_HARDCUSTOM.equalsIgnoreCase(strIPType) || IMP_ATTRIBUTE_IPTYPE_HARDSTD.equalsIgnoreCase(strIPType)) && 
    			  IMP_ATTRIBUTE_IPSOURCE_3PIP.equalsIgnoreCase(strIPSource)) {
    		  //Modified for SWIMP-502: Starts
    		  //Skip check layers execution for Hard 3PIP if --skip-check-layers option is used. - Added for SWIMP-502
    		  if (bSkipCheckLayers) {
    			  IMPLog.info("Skipping checklayers as '--skip-check-layers' is specified.");
    			  //Check for checklayers.err and checklayers.out files in previous release
    			  //This is to avoid the check-in of previous release's checklayers output and error files to current revision where the --skip-check-layers is used.
    			  checkForChecklayersfilesAndDeleteOnExists(ipPath);
    		  } else {
    			  IMPLog.info("Started 'checklayers' process for checking GDS layers.");

    			  //Added for SWIMP-501: Starts
    			  boolean bCheckLayerFailed = false;
    			  boolean bExtractionFailed = false;
    			  //Added for SWIMP-501: Ends

    			  List<String> lToolBasedIPTechStacks = new ArrayList<>();
    			  IMPCommon.setTechStackList(lTechStackInfo);
    			  lToolBasedIPTechStacks = Utility.getTechStackMappingsForExternalTools(strIPID, TOOL_CHECKLAYERS);//Get tech stack map
    			  if (!lToolBasedIPTechStacks.isEmpty() &&  lToolBasedIPTechStacks != null) {
    				  IMPLog.trace("IP tech stack mapping: "+lToolBasedIPTechStacks.toString());
    				  int iCheckLayersProcess = performCheckLayerForDesignFile(sModRoot, lToolBasedIPTechStacks);

    				  //Modified for SWIMP-501: Starts
    				  if (iCheckLayersProcess > 0) {
    					  IMPLog.error(sCheckLayersStatusFAIL);
    					  bCheckLayerFailed = true;
    					  if (bForce) {
    						  IMPLog.info("Publishing tag in spite of checklayers failure because --force is used.");
    					  }
    				  } else {
    					  IMPLog.info(sCheckLayersStatusPASS);
    				  }
    				  //Modified for SWIMP-501: Ends

    				  //Added for SWIMP-501: Starts
    				  //Validate the TAR Archive Extractions
    				  //Force option will be used for file extraction failure
    				  bExtractionFailed = validateTARArchiveExtraction(Paths.get(sModRoot));
    				  if (bExtractionFailed) {
    					  IMPLog.error("File extraction failed");
    					  if (bForce) {
    						  IMPLog.info("Publishing tag in spite of file extraction failure because --force is used.");
    					  }
    				  }

    				  if ((bCheckLayerFailed || bExtractionFailed) && !bForce) {
    					  return 2;
    				  }
    				  //Added for SWIMP-501: Ends
    			  } else {
    				  return 2;
    			  }
    		  }
    		  //Modified for SWIMP-502: Ends
    	  }
      }
      //Added for SWIMP-850: ENDS
      //checklayers process Ends
      //Added for SWIMP-425: Ends

      // SWIMP-31: Implementation Starts
      processFilestoWatermark(bomResult);
      StringBuilder sbNegInstanceCount = new StringBuilder();
      StringBuilder sbIMPUnknownComponentWatermark = new StringBuilder();
      boolean bIsRevisionPublishedAsHIP = false;
      if (sBlockIP.equalsIgnoreCase(strIPProductType)) {
    	  iReturn = readDesignFilesNBuildHIPStructure(ipBaseDir, sbNegInstanceCount,sbIMPUnknownComponentWatermark);
    	  if (iReturn != 0)
    		  return iReturn;
    	  bIsRevisionPublishedAsHIP = true;
      }
      // SWIMP-31: Implementation Ends
     if (!bLightWeight && isMarkerFileExists) {
    	  IMPLog.info(IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_CHECKLAYERS_MSG);   
     } else {
    	 if (bLightWeight) {
    		 if(!isMarkerFileExists) {
    			 IMPLog.info(IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_CHECKLAYERS_MSG);
    	     } else {
    	    	 IMPLog.info(IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_CHECKLAYERS_MSG); 
    	     }
     }}
      
      //Modified for CR IMPBRCM-1043: Starts
   	  // Start watermarking for GDS files
      
      int iWMGDS = 0;
      if (bDryRun) {
          IMPLog.trace("Not inserting watermark because of the use of --dry-run");
      }else if(bLightWeight || (!bLightWeight && isMarkerFileExists)) { // SWIMP-850
    	  if(!bLightWeight) {
    	  IMPLog.info(IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_WATERMARK_MSG);  
    	  } else {
    	  IMPLog.info(IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_WATERMARK_MSG);
    	  }
    	  if(latestBranchAndRevision!=null && !latestBranchAndRevision.isEmpty() && latestBranchAndRevision.contains("Trunk")) {
    		  int iIndex = latestBranchAndRevision.lastIndexOf('/');
    		  latestBranchAndRevision = latestBranchAndRevision.substring(iIndex + 1, latestBranchAndRevision.length());
    	  }
    	  IMPLog.info("Latest revision is " + latestBranchAndRevision);
    	  int status = ProcessLightWeightRevision(mWMFile, latestBranchAndRevision, strIPID);
    	  if (status!=0)
    		  return status;
      }else {
		  
         iWMGDS = watermarkFiles(Paths.get(ipBaseDir), sIPIDWMSeed);//SWIMP-1
         if (iWMGDS == 1) {
            iReturn = 24;
            return iReturn;
         } else if (iWMGDS == 2){
            iReturn = 53;
            IMPCommon.setOperation("watermark");
            return iReturn;
         } else if(iWMGDS ==3){
          //Added for SWIMP-1 starts
            mWMFile = getFileWMMap();
            
            Iterator it = mWMFile.entrySet().iterator();
            StringBuilder sbRevisionWaterMarkIDInfo = new StringBuilder();
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                sbRevisionWaterMarkIDInfo.append(pair.getKey());
                sbRevisionWaterMarkIDInfo.append(":");
                sbRevisionWaterMarkIDInfo.append(pair.getValue());
                sbRevisionWaterMarkIDInfo.append(";");
            }
            IMPLog.info("WaterMark:   " + sbRevisionWaterMarkIDInfo.toString());
          //Added for SWIMP-1 ends
         }
      }
      //Modified for CR IMPBRCM-1043: Ends
      
      /*
       * below code checking the Pre Approve List
       */
      HashMap<String, String> hmPreApprovedData = (HashMap<String, String>) checkPreApproved();
      if (!hmPreApprovedData.isEmpty()) {
        if (hmPreApprovedData.containsKey("failed")) {
          return 2;
        } else {
          strPreApprove = hmPreApprovedData.get(strSuccess);
        }
        IMPLog.info("Preapproved List: " + strPreApprove);
      }

      // Run QA -Start
      // input.json
      // Skip QA VAlidation if IP is 3PIP Soft IP

      String ipName = enoClient.getIPAttributeValue(strIPID, "attribute[IMP_IPName]");
      
      if(getFileWMMap().isEmpty()) {
    	  mWMFile.put("singleDesignFile", Utility.getWaterMarkString(sIPIDWMSeed));
      }

      String sIPICAStatus = "";
      String sQASummary = "";

      //Removed the existing condition for SWIMP-488 which checks the IP Type and IP Source
      //Now, IPICA will run for all the IPs irrespective of IP Type and IP Source.
      //Added light weight check for SWIMP-849
      if(!bLightWeight && !isMarkerFileExists) { // SWIMP-850
    	  IMPLog.trace("Publish QA validation start");
    	  org.codehaus.jettison.json.JSONObject jsQAValResults = null;
    	  try {
    		  jsQAValResults = executeQAValidation(strIPID, ipBaseDir, sTimeStamp, jsQAVal, ipName,strBranch);//SWIMP-230
    	  } catch (IMPException ime) {
    		  iReturn = 2;
    		  IMPLog.trace("IPICA exception: ", ime);
    		  if (!bForce) { // not force
    			  return iReturn;
    		  } else {
    			  IMPLog.error(sQAFailed);
    		  }
    	  }
    	  if (jsQAValResults != null) {
    		  sIPICAStatus = jsQAValResults.getString("status");
    		  IMPLog.info("IPICA Status:  " + sIPICAStatus);
    		  sQASummary = jsQAValResults.getString("summary_file_content");
    		  IMPLog.info("Publish QA validation using IPICA completed");
    	  } else {
    		  iReturn = 44;
    		  return iReturn;
    	  }
    	  if ((bForce) && ("fail".equalsIgnoreCase(sIPICAStatus))) { // Modified for SWIMP-606
    		  IMPLog.info("Publishing tag in spite of QA failure because --force is used");
    	  }
      } else {
    	  if (!bLightWeight && isMarkerFileExists) {
          IMPLog.info(IMP_CLI_PUBLISH_FORCE_LIGHTWEIGHT_SKIP_IPICA_MSG); // SWIMP-850  
    	  } else {
    	  IMPLog.info(IMP_CLI_PUBLISH_LIGHTWEIGHT_SKIP_IPICA_MSG); // SWIMP-850
        }
      }
      // Good to execute publish stcl proc

      stclArgsList.add("-c");
      stclArgsList.add("\"" + sComment + "\"");
      stclArgsList.add("-tag");
      stclArgsList.add(sTag);
      stclArgsList.add("-I");
      stclArgsList.add(ipBaseDir);
      stclArgsList.add("-debug");

      // DO NOT CHANGE THIS EXCLUDE IPICARUN VALUE OR ADD ADDITIONAL VALUES
      // without changing updateModManifest in imp.stcl. 
      // It is hard to implement the semantics of -exclude in updateModManifest
      // We probably should be using -filter instead of -exclude which we could
      // then past through to updateModManifest.
      
      if (!bLightWeight && !isMarkerFileExists) { // SWIMP-850
      stclArgsList.add("-exclude");
      stclArgsList.add("ipicarun");
      stclArgsList.add("-lw");
      stclArgsList.add("false");
      stclArgsList.add("-markerFile");
  	  stclArgsList.add("false");
      }
      if (!bLightWeight && isMarkerFileExists) {  // SWIMP-850
          stclArgsList.add("-exclude");
          stclArgsList.add("ipicarun,imp/.requires_lightweight_publish");
          stclArgsList.add("-markerFile");
      	  stclArgsList.add("true");
      	  stclArgsList.add("-lw");
          stclArgsList.add("false"); 
      }
      if (bLightWeight && isMarkerFileExists) {  // SWIMP-850
          stclArgsList.add("-exclude");
          stclArgsList.add("ipicarun,imp/.requires_lightweight_publish");
          stclArgsList.add("-markerFile");
      	  stclArgsList.add("true");
      	  stclArgsList.add("-lw");
          stclArgsList.add("true"); 
      }
      if (this.bDryRun) {
        stclArgsList.add("-D");
      }      
      //Added for SWIMP-850
      if (bLightWeight && !isMarkerFileExists) {
    	stclArgsList.add("-lw");
    	stclArgsList.add("true");
    	stclArgsList.add("-markerFile");
    	stclArgsList.add("false");
      }
      //Added for SWIMP-850
      ProcessBuilder pb = stclWrapper.getStclProcessBuilder(stclArgsList);
	  Set<String> setWMFileKey = mWMFile.keySet();
      Map<String, String> mGDSSpecificLineageInfo = new HashMap<>();
      for(String sWMFileKey : setWMFileKey) {
    	  StringBuilder sbLineage = new StringBuilder();

    	  Map<String, String> lineageMap = gdsSpecificLineageMap.get(sWMFileKey);
    	  if (lineageMap!=null && !lineageMap.isEmpty())
    	  {
    		  for(Map.Entry<String,String> mLineageInfo : lineageMap.entrySet()){
    			  sbLineage.append(mLineageInfo.getKey()).append("^").append(mLineageInfo.getValue()).append("$"); 
    		  }
    		  mGDSSpecificLineageInfo.put(sWMFileKey, sbLineage.substring(0, sbLineage.length()-1));
    	  }
      }	
      
      try {
	      // Pass form field values
	      com.sun.jersey.api.representation.Form formData =
	          new com.sun.jersey.api.representation.Form();
	      //Added for SWIMP-882
	      if (bRunSSGQI && bCfgFileExistsinDTree) {
	      formData.putSingle("sFTPSSGQICfgPath", sFTPSSGQICfgPath);
	      formData.putSingle("sFTPSSGQICfgFileName", sFTPSSGQICfgFileName);
	      } else {
	      formData.putSingle("sFTPSSGQICfgPath", "");
		  formData.putSingle("sFTPSSGQICfgFileName", "");
	      }
	      //Added for SWIMP-882
	      formData.putSingle("IMP_IsPrefixed", this.isPrefixed);
	      formData.putSingle("IMP_QualityClass", this.sQualityClass);
	      formData.putSingle("IMP_GDSVersion", this.sGDSVersion);
	      formData.putSingle("IMP_IPTag", this.sTag);
	      formData.putSingle("IMP_IPQAStatus", sIPICAStatus);
	      formData.putSingle("IMP_IPQASummary", sQASummary);
	      formData.putSingle("IMP_IPPublishComments", sComment);
	      //Added for SWIMP-1 for changinge attribute name to IMP_IPRevisionWatermark
	      formData.putSingle("IMP_IPRevisionWatermark", Utility.convertWMMapToString(mWMFile)); 
	      formData.putSingle("IMP_WMDerivedFrom", getsWMDerivedFromRevision());
	      formData.putSingle("IMP_Preapprove", strPreApprove); // Added for the user story #IMPBRCM-205
	      formData.putSingle("IMP_ENV", IMP_CLI_ENV);
	      formData.putSingle("RecommendedRevision", bRecommended);
	      formData.putSingle("DefaultRevision", bDefaultRev);	  
		  formData.putSingle("IMP_Alert",this.sAlert);
	      // Start Post publish operations
		  
		  //Added for SWIMP-385 - s
		  formData.putSingle("IMP_Version", Version.getIMPVersion());
		  formData.putSingle("IMP_Commandline", IMPCommon.getStrCommand());
		  formData.putSingle("IMP_IPDir",IMPCommon.getIpDIR());
		  formData.putSingle("IMP_UsernameDomain",IMPCommon.getImpUser()+"@"+IMPCommon.getImpDomain());
		  //Added for SWIMP-385 - e
		  formData.putSingle("IsRevisionPublishedAsHIP", bIsRevisionPublishedAsHIP);
		  if(gdsSpecificChildInfoMap!=null && !gdsSpecificChildInfoMap.isEmpty()) {
			  formData.putSingle("childIPsToConnect", gdsSpecificChildInfoMap.toString());
			  formData.putSingle("LineageInfo", mGDSSpecificLineageInfo.toString());
			  formData.putSingle("IMP_MISSING_PROGENY_INSTANCE_WARNING", sbNegInstanceCount.toString());
			  formData.putSingle("IMPUnknownComponentWatermark", sbIMPUnknownComponentWatermark.toString());
		  }
		    iReturn = executePostPublish(pb, formData, strIPID, ipPath, sfinalPubDocSet, sModuleUrl);
	  } catch (Exception e) {
		    IMPLog.trace("Exception in post publish operation:   " , e);
		    iReturn = 1;
		    IMPLog.error(e.getMessage());
	  }
      //Added for SWIMP-425: Starts
     } catch (InterruptedException exp) {
    	IMPLog.error(exp.getMessage());
    	iReturn = 1;
    	Thread.currentThread().interrupt();
    	//Added for SWIMP-425: Ends
    } catch (IOException | ClientHandlerException | UniformInterfaceException | JSONException | IMPException exp) {
    	IMPLog.error(exp.getMessage()); // commented/Added for IMPBRCM-1100 // Added to handle exception if -o option is provided in staging area
    	iReturn = 1;
    }
    return iReturn;
  }

	/**
	 * @param sTag
	 * @param specs
	 * @return
	 * purpose: check the publish tag against the Spec used
	 */
	private String isTagValidPerSpec(String sTag, Map<String, Specification> specs) {
		String retMsg = "";
		if (!bSkipTagValid) {
			for (Specification spec : specs.values()) {
				String tagRegEx = spec.getSpecificationInformation().getTagRegEx();
				if (!StringUtils.isEmpty(tagRegEx) && !sTag.matches(tagRegEx)) {
					retMsg = spec.getSpecificationInformation().getTagValMsg();
					break;
				}
			}
		}
		return retMsg;
	}

/**
   * Execute QA validation.
   *
   * @param sValue the Name of the IP object
   * @param ipBaseDir the staging dir
   * @param sTimeStamp the s time stamp
   * @param jsQAVal the JSON with QA input details
   * @return the org.codehaus.jettison.json. JSON object
   * @throws Exception the exception
   */
  private org.codehaus.jettison.json.JSONObject executeQAValidation(String sValue, String ipBaseDir,
      String sTimeStamp, org.codehaus.jettison.json.JSONObject jsQAVal, String sIPName, String strBranch)
      throws IMPException {

    org.codehaus.jettison.json.JSONObject jsQAResults = null;
    try {
      File fRunPath = new File(ipBaseDir + File.separator + IPICA_RUNPATH);
      IMPLog.trace("IPICA runpath --->" + fRunPath);
      // if re-running the publish, delete the ipicarun folder and re-create
      IMPLog.trace("Is ipicarun folder exists ?:" + fRunPath.exists());
      if (fRunPath.exists()) {
        FileUtils.forceDelete(fRunPath);
        IMPLog.trace("Deleted existing ipicarun:" + fRunPath);
      }

      FileUtils.forceMkdir(fRunPath);
      IMPLog.trace("Re-created-ipicarun folder:" + fRunPath);
      
      // Added for bug 992
      File fQAFailture = new File(ipBaseDir + sQAFailureBase);
      
      if (fQAFailture.exists()) {
        FileUtils.forceDelete(fQAFailture);
        IMPLog.trace("Deleted existing QAFailure folder:" + fQAFailture);
      }
      // -- End -- bug 992
      String sRequestId = sValue + "-" + sTimeStamp;
	  // Added for SWIMP-281: Starts
      if(jsQAVal.has(sTechnologyStacks)) {
    	  org.codehaus.jettison.json.JSONArray jaTechStack =  (JSONArray) jsQAVal.get(sTechnologyStacks);
    	  for (int i = 0; i < jaTechStack.length(); i++) {
    		  org.codehaus.jettison.json.JSONObject jEachTechStack=(JSONObject) jaTechStack.get(i);
    		  jEachTechStack.remove("io_type");
    	  }
      }
      // Added for SWIMP-281: Ends
      jsQAVal.put("request_id", sRequestId);
      jsQAVal.put("workspace_path", ipBaseDir);
      jsQAVal.put("run_path", fRunPath.getAbsolutePath());
      jsQAVal.put("ip_name", sIPName);
      jsQAVal.put("ip_id", sValue);
      //Added for SWIMP-230 : Starts
      jsQAVal.put("branch",strBranch);
      jsQAVal.put("Tag",this.sTag);
      jsQAVal.put("dry_run",this.bDryRun);
      jsQAVal.put("force_publish",this.bForce);
      jsQAVal.put("imp_environment",IMP_CLI_ENV);
      //Added for SWIMP-230 : Ends
      IMPLog.trace("IPICA input.json value: " + jsQAVal);

      String ipicaPath = String.join(File.separator, IPICA_BASE_PATH, IPICA_EXEC_NAME);
      File fInputJson = new File(fRunPath.getAbsolutePath() + File.separator + "input.json");

      IMPLog.trace("IPICA input.json path: " + fInputJson.getAbsolutePath());

      // Input.json
      Files.write(Paths.get(fInputJson.getAbsolutePath()), jsQAVal.toString().getBytes(),
          StandardOpenOption.CREATE);

      IMPLog.trace(ipicaPath + " " + fInputJson.getAbsolutePath());
      // Run IPICA with Input.json
      ProcessBuilder ipicaProcessBuilder =
          new ProcessBuilder(ipicaPath, fInputJson.getAbsolutePath());
      ipicaProcessBuilder.redirectErrorStream(true);

      Process ipicaProcess = ipicaProcessBuilder.start();
      IMPLog.trace("IPICA process O/P:");

      // print the near real time process output
      processRealTimeOutput(ipicaProcess);

      int iIPICAret = ipicaProcess.waitFor();
      IMPLog.trace("IPICA Process exit status: " + iIPICAret);

      String sQAStatus = "";
      String sQASummary = "";
      String sQASummaryFile = "";

      // Graceful exit
      if (iIPICAret == 0) {
        File fResultJson =
            new File(fRunPath.getAbsolutePath() + File.separator + sRequestId + ".json");
        IMPLog.trace("Is IPICA output.json exists?: " + fResultJson.exists());
        String sResultJson = "";
        try (BufferedReader brResultJSON = new BufferedReader(new FileReader(fResultJson))) {
          sResultJson = brResultJSON.lines().collect(Collectors.joining(System.lineSeparator()));
        }

        IMPLog.trace("IPICA output text: " + sResultJson);

        jsQAResults = new org.codehaus.jettison.json.JSONObject(sResultJson);

        IMPLog.trace("IPICA output.json: " + jsQAResults);
        String sResultFile = "";
        org.codehaus.jettison.json.JSONArray jaResultFiles =
            jsQAResults.getJSONArray("result_file");
        for (int i = 0; i < jaResultFiles.length(); i++) {
          String sTgzFileName = jaResultFiles.getString(i);
          if ("tgz".equalsIgnoreCase(sTgzFileName.substring(sTgzFileName.lastIndexOf('.') + 1))) {
            sResultFile = sTgzFileName;
            break;
          }
        }
        sQAStatus = jsQAResults.getString("status");
        IMPLog.trace("IPICA status: " + sQAStatus);
        String sMessage = jsQAResults.getString(IMP_MESSAGE);

        // This is the placeholder entry for QA Summary file
        sQASummaryFile = jsQAResults.getString("summary_file");

        File fQASummary = new File(fRunPath.getAbsolutePath() + File.separator + sQASummaryFile);
        IMPLog.trace("IPICA QA summary file: " + fQASummary + " -exists??--" + fQASummary.exists());

        try (BufferedReader brQASummary = new BufferedReader(new FileReader(fQASummary))) {
          sQASummary = brQASummary.lines().collect(Collectors.joining(System.lineSeparator()));
        }
        jsQAResults.put("summary_file_content", sQASummary);
        if (! ("pass".equalsIgnoreCase(sQAStatus) || "pass-minor".equalsIgnoreCase(sQAStatus))) {
          // Force publish with QA failure
          IMPLog.trace("Is force publish on QA failure?: " + bForce);
          if (bForce) {
            createQAFailureFolder(ipBaseDir, fRunPath, sResultFile, fQASummary);
            IMPLog.info("IPICA Message: " + sMessage);
            IMPLog.trace("QA Summary: " + sQASummary);
          } else {
            IMPLog.trace("IPICA Status: " + sQAStatus);
            IMPLog.info("IPICA Message: " + sMessage);
            IMPLog.trace("QA Summary: " + sQASummary);
            IMPLog.error(sQAFailed);
            throw new IMPException(sQAFailed);
          }
        }
      } else {
        throw new IMPException("Error in QA Validation. IPICA Process exit code: " + iIPICAret);
      }
      return jsQAResults;

    } catch (IOException | JSONException | InterruptedException ioExp) {
      IMPLog.error("Exception in QA Validation:  " + ioExp);
      throw new IMPException("Exception in QA Validation", ioExp);
    }
  }

  

  /**
   * Checks if is alive.
   *
   * @param p the p
   * @return true, if is alive
   */
  private boolean isProcessAlive(Process p) {
    try {
      p.exitValue();
      return false;
    } catch (IllegalThreadStateException e) {
      return true;
    }
  }

  /**
   * Process nearly - real time output.
   *
   * @param process the process
   * @throws IOException Signals that an I/O exception has occurred.
   */
  private void processRealTimeOutput(Process process) throws IOException {
    if (!process.isAlive()) {
      IMPLog.trace("Process is not alive..returning..");
      return;
    }
    InputStream processOutput = process.getInputStream();
    StringBuilder sbStreamLogs = new StringBuilder();//Added for SWIMP-96
    try {
      byte[] buf = new byte[1024 * 1024];
      while (isProcessAlive(process)) {
        int noBytes = processOutput.available();
        if (noBytes > 0) {
          int n = processOutput.read(buf, 0, Math.min(noBytes, buf.length));
          String sBufStr = new String(buf, 0, n).trim();
          System.out.println(sBufStr);//Added for SWIMP-96
          System.out.flush();//Added for SWIMP-96
          sbStreamLogs.append(sBufStr).append(System.lineSeparator());//Added for SWIMP-96
        }
        try {
          Thread.sleep(10);
        } catch (Exception e) {
          IMPLog.error(e.getLocalizedMessage(), e);
        }
      }
      IMPLog.trace(sbStreamLogs.toString());//Added for SWIMP-96
    } finally {
      processOutput.close();
    }
    IMPLog.debug("Process exit code : " + process.exitValue());
  }

  /**
   * Creates the QA failure folder.
   *
   * @param ipBaseDir the staging area diretory
   * @param fRunPath the f run path
   * @param sResultFile the s result file
   * @param fQASummary the f QA summary
   * @throws IMPException the IMP exception
   */
  private void createQAFailureFolder(String ipBaseDir, File fRunPath, String sResultFile,
      File fQASummary) throws IMPException {
    try {
      File fQAFailture = new File(ipBaseDir + sQAFailureBase);
      IMPLog.trace("IPICA QA Failure folder: " + fQAFailture.getAbsolutePath());
      IMPLog.trace("IPICA cleaned QA failure folder...");
      File fQARestults = new File(fRunPath.getAbsolutePath() + File.separator + sResultFile);
      IMPLog.trace("IPICA result file: " + fQARestults.getAbsolutePath() + "-exists??-"
          + fQARestults.exists());
      // overwrites existing with preserving created timestamp
      FileUtils.copyFileToDirectory(fQARestults, fQAFailture, true);
      IMPLog.trace("Copied -- " + fQARestults + " -- to-- " + fQAFailture);
      FileUtils.copyFileToDirectory(fQASummary, fQAFailture, true);
      IMPLog.trace("Copied -- " + fQASummary + " -- to-- " + fQAFailture);
    } catch (IOException ioexp) {
      IMPLog.error("Exception in creating QA Failure folder: " + ioexp.getMessage());
      throw new IMPException("Exception in creating QA Failure folder", ioexp);
    }
  }
  // Modified for the bug IMPBRCM-985 - START
  /**
   * publicDocuments
   * 
   * @throws IOException
   *
   * 
   * @throws IMPException the IMP exception
   */
  private int uploadFile(String strPath, String strTempDir, String strNewFileName) throws IOException {
    int iReturn = 0;
    String sFTPHost = getHostName();
    int sFTPPort = 22;
    String sFTPUser = IMP_CLI_SERVER_USER;
    String sFTPPass = Utility.getDecodePass();
    FileInputStream fileStream = null;
    Session session = null;
    Channel channel = null;
    ChannelSftp channelSftp = null;
    try {
      JSch jsch = new JSch();
      session = jsch.getSession(sFTPUser, sFTPHost, sFTPPort);
      session.setPassword(sFTPPass);
      java.util.Properties config = new java.util.Properties();
      config.put("StrictHostKeyChecking", "no");
      session.setConfig(config);
      session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
      session.connect();
      boolean bConnected = session.isConnected();
      if (!bConnected) {
        iReturn = 1;
      } else {
        channel = session.openChannel("sftp");
        channel.connect();
        channelSftp = (ChannelSftp) channel;
        channelSftp.cd(strTempDir);
        File f = new File(strPath);
        fileStream = new FileInputStream(f);
		//Modified for SWIMP-742
		String strTargetFileName = "";
		if(strNewFileName!= null && !"".equals(strNewFileName)) {
			strTargetFileName = strNewFileName;
		} else {
			strTargetFileName = f.getName();
		}
        channelSftp.put(fileStream, strTargetFileName);
      }
	  //Modified for SWIMP-742
    } catch (Exception ex) {
      IMPLog.trace("Exception in uploading files: " + ex);
    } finally {
      if (session != null) {
        session.disconnect();
      }
      if (fileStream != null) {
        fileStream.close();
      }
    }
    return iReturn;
  }

  //Modified for CR IMPBRCM-1043
  /**
   * This method is to insert watermark
   * Modified for SWIMP-348
   *
   * @param iPath, IP path
   * @param sIPIDWMSeed, IP watermarkseed
   * @param result, checkbom result
   * @throws IOException, if fails
   */
  private int watermarkFiles(Path iPath, String sIPIDWMSeed) throws IOException {
	  int iReturn = 0;
	  String ipInfoPath= "";
	  List<String> slipInfo = new ArrayList<>();
	  File fPath;
	  List<String> stclArgsLists;
	  List<String> stclFileList;
	  IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
	  FileWriter fWrite = null;
	  BufferedWriter output = null;
	  gdsFileUtility = new GDSFileUtility();
	  try {
		  slipInfo = Utility.getIPinfoPathAndOptions();
		  ipInfoPath = slipInfo.get(0);
		  fPath = new File(ipInfoPath);
		  if (fPath.exists()) {
			  String ipInfoFile = iPath.resolve("imp").resolve("ipinfo.log").toString();
			  StringBuilder ipInfoLogData = new StringBuilder();
			  ipInfoLogData.append("------------------------------\n");
			  ipInfoLogData.append(
					  new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a").format(System.currentTimeMillis()));
			  ipInfoLogData.append(": ");
			  ipInfoLogData.append(IMPCommon.getStrCommand().replaceAll("\n|\r", ""));
			  ipInfoLogData.append("\n");

			  Map <String,String> mWMFile = new HashMap<>(); // Added for SWIMP-1
			  String strWaterMarkString = "";
			  if (!delivsToWatermark.isEmpty()) { //Modified for SWIMP-348
				  for (ExpandedDeliverable toWatermark : delivsToWatermark) {
					  IMPLog.trace("Watermark expanded deliv: " + toWatermark.getPath());
					  IMPCommon.setStrFileName(toWatermark.getPath()); //Added for SWIMP-348
					  String sFilePath = iPath + File.separator + toWatermark.getPath();
					  String actualFName = Paths.get(sFilePath).getFileName().toString();
					  if (Paths.get(sFilePath).toFile().exists()) {
						  strWaterMarkString = Utility.getWaterMarkString(sIPIDWMSeed);//Modified for SWIMP-1
						  if (strWaterMarkString.isEmpty()) {
							  
							  return 60;
						  }

						  mWMFile.put(actualFName,strWaterMarkString);
						  iReturn = 3;
						  setWatermark(strWaterMarkString);// Added for CR IMPBRCM-1043
						  List<String> stclArgsList = new ArrayList<>();
						  stclArgsLists = new ArrayList<>();
						  stclArgsLists.addAll(slipInfo);

						  stclArgsLists.add("-insert");
						  stclArgsLists.add("-wm");
						  stclArgsLists.add("TYP=IMP");
						  stclArgsLists.add("-wm");
						  stclArgsLists.add("BLMK="+strWaterMarkString);
						  stclArgsLists.add(sFilePath);

						  String sCommands = StringUtils.join(stclArgsLists, ' ');
						  ipInfoLogData.append(sCommands).append("\n");
						  IMPLog.trace(sCommands);
						  //command to run, queue name, list of files , insert sfilePath
						  //stclArgsLists= Utility.verifyFileSizeandQueueName(stclArgsLists,sQueueName,stclFileList);//Added for LSF change
						  boolean appendedBsub = gdsFileUtility.verifyQueueNameAndUseBsub(stclArgsList,sQueueName,sFilePath);
						  stclArgsList.addAll(stclArgsLists);
						  String [] argsArray = new String[stclArgsList.size()];
						  stclArgsList.toArray(argsArray);
						  ProcessBuilder pb = stclWrapper.getStclProcessBuilder(argsArray);
						  pb.redirectErrorStream(true); // Added for 1048 bug.
						  Process process = pb.start();
						  String sOut = stclWrapper.outputForYaml(process);
						  int iProcess = process.waitFor();
						  ipInfoLogData.append("Exit Status:").append(iProcess).append("\n");
						  if (iProcess != 0) {
							  if (!sOut.isEmpty()) {
								  IMPLog.error(sOut); // Fix for 724
								  ipInfoLogData.append(sOut);
							  }
							  iReturn = 1;
							  break;
						  }
					  }
				  }
			  }
			  setFileWMMap(mWMFile);//Added for SWIMP-1
			  Utility.writeInFile(ipInfoFile, ipInfoLogData.toString());
		  } else {
			  IMPLog.error(ipInfoPath + " not exists");
			  iReturn = 1;
		  }
	  } catch (IOException | InterruptedException | IMPException e) {
		  iReturn = 1;
		  IMPLog.error("Exception while inserting watermark: " + e);//Modified for SWIMP-348
		  Thread.currentThread().interrupt(); //Added for SWIMP-348
	  }
	  return iReturn;
  }
  
  //Added for SWIMP-849
  @SuppressWarnings("unused")
private int ProcessLightWeightRevision(Map<String, String> mWMFile, String latestRevisionForIP, String strIPID) throws IMPException, JSONException {
	  int iReturn = 0; 
	  try {
		  IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		  org.codehaus.jettison.json.JSONObject jsData = enoClient.getQAFailureMsg(strIPID, latestRevisionForIP, true);
		  if (jsData.length() != 0) {
			  if(((String) jsData.get("CURRENT")).equalsIgnoreCase("Active")) {
				  IMPLog.info("Extracting the watermark details from the latest published version " + latestRevisionForIP);
				  JSONObject designFileMappingToWM = jsData.getJSONObject("DesignFileMappingToWM");
				  String wmDerivedFromRevision = (String) jsData.get("WMDerivedFrom");
				  if (StringUtils.isEmpty(wmDerivedFromRevision)) {
					  setsWMDerivedFromRevision(latestRevisionForIP);
				  }else {
					  setsWMDerivedFromRevision(wmDerivedFromRevision);
				  }
				  if (designFileMappingToWM.length() != 0) {
					  Iterator<String> keys = designFileMappingToWM.keys();
					  while (keys.hasNext()) {
						  String key = keys.next();
						  String value = designFileMappingToWM.getString(key);
						  mWMFile.put(key, value);
					  }
				  }
				  //Update the field WMDerivedFrom
				  
			  }else {
				  IMPLog.error("Previous revision "+latestRevisionForIP+" is inactive - Lightweight publish not allowed based on an inactive revision");
				  iReturn = 2;
			  }

		  }
		  setFileWMMap(mWMFile);
		  
	  } catch (ClientHandlerException | UniformInterfaceException e) {
		  IMPLog.trace("ERROR in setPreviousRevisionWM", e);
		  throw new IMPException("ERROR in setPreviousRevisionWM: " + e.getMessage());
	  }
	return iReturn;
  }

  //Modified for SWIMP-31, Code alignment and logic corrections done: Starts
  private Map<String, String> checkPreApproved() throws IMPException {
	  HashMap<String, String> hmReturn = new HashMap<>();
	  String strPreApprove;
	  String strPreApprovedList = ""; //Added for SWIMP-31
	  try {
		  IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		  //Modified for SWIMP-31: Starts
		  if (StringUtils.isNotBlank(this.sPreapproveList)) {
			  if ("all".equalsIgnoreCase(this.sPreapproveList)) {
				  hmReturn.put(strSuccess, this.sPreapproveList);
				  //Modified for SWIMP-31: Ends
			  } else {
				  /*
				   * below Call Enovia service to update meta-data
				   */
				  WebResource webResource = enoClient.getIMPServiceWebResource("isPreApproveList");

				  //Added for SWIMP-31: Starts
				  StringBuilder sbPreapprovedList = new StringBuilder();
				  if (this.sPreapproveList.contains(IMPCommon.getIpID())) {
					  IMPLog.warn("Warning: An IP cannot be pre-approved for use by itself; ignoring it from the specified list.");
					  List<String> lsPreApprovedList = new ArrayList<>(Arrays.asList(this.sPreapproveList.split(",")));
					  lsPreApprovedList.remove(IMPCommon.getIpID());
					  if (!lsPreApprovedList.isEmpty()) {
						  for (String strPL : lsPreApprovedList) {
							  sbPreapprovedList.append(strPL).append(",");
						  }
						  strPreApprovedList = sbPreapprovedList.deleteCharAt(sbPreapprovedList.lastIndexOf(",")).toString();
					  }
					  this.sPreapproveList = strPreApprovedList;
				  }
				  //Added for SWIMP-31: Ends

				  //Modified for SWIMP-31: Starts
				  if (StringUtils.isNotBlank(this.sPreapproveList)) {
					  // Pass multiple Query Params
					  MultivaluedMapImpl queryParams = new MultivaluedMapImpl();
					  // Pass form field values
					  com.sun.jersey.api.representation.Form formData =
							  new com.sun.jersey.api.representation.Form();
					  formData.putSingle("PreapproveList", this.sPreapproveList); //Modified for SWIMP-31
					  ClientResponse response = webResource.queryParams(queryParams).accept(strMediaType)
							  .header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
							  .post(ClientResponse.class, formData);

					  if (response.getStatus() != 200) {
						  throw new IMPException("Failed : HTTP error code : " + response.getStatus());
					  }
					  // Capture the return JSON with code and message
					  org.codehaus.jettison.json.JSONObject retJson =
							  new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
					  strPreApprove = (String) retJson.get(IMP_MESSAGE);
					  //Modified for SWIMP-31: Starts
					  if (strPreApprove.length() > 0) {
						  String strInvalidProjects = strPreApprove.substring(1, strPreApprove.length());
						  String[] saInvalidProjects = strInvalidProjects.trim().split(",");
						  String strReturnMessage = "";
						  if (saInvalidProjects.length > 1) {
							  strReturnMessage = "'" + strInvalidProjects + "' are not projects (SoC or HIP) in IMP.";
						  } else {
							  strReturnMessage = "'" + strInvalidProjects + "' is not a project (SoC or HIP) in IMP.";
						  }
						  IMPLog.error(strReturnMessage);
						  hmReturn.put("failed", strReturnMessage);
					  } else {
						  hmReturn.put(strSuccess, this.sPreapproveList); //Modified for SWIMP-31
					  }
				  }
				  //Modified for SWIMP-31: Ends
			  }
		  }
	  } catch (IMPException | ClientHandlerException | UniformInterfaceException | JSONException e) {
		  IMPLog.trace("ERROR in checkPreApproved", e);
		  throw new IMPException("ERROR in checkPreApproved: " + e.getMessage());
	  }
	  return hmReturn;
  }
  //Modified for SWIMP-31, Code alignment and logic corrections done: Ends


  private static class ImpPublishOutputProcessor implements Consumer<String> {
    boolean startedProgress = false;
    String partialLine = "";

    public void accept(String output) {
      if (startedProgress) {
        if (! output.contains("\n")) {
          System.out.print(partialLine + output);
          System.out.flush();
          partialLine = "";
          return;
        } else {
          // There are no newlines printed while the DS progress is being printed...
          String partial = output.substring(0, output.indexOf("\n"));
          String rest = output.substring(output.indexOf("\n"), output.length());
          System.out.print(partialLine + partial + output);
          startedProgress = false;
          // Recurse, we may get a progress message followed by a non-progress followed by a new progress message;
          accept(rest);
          return;
        }
      }
      if (! output.contains("\n")) {
        partialLine += output;
        // If the bytes we just got make the partial line match a progress line, then start printing progress messages
        // otherwise just save the partial string since we ma receive "Pro" and "gres ..." at different calls.
        if (partialLine.matches("(?s).*Progress:.*?% complete.*")) {
          System.out.print("\n" + partialLine + output);
          System.out.flush();
          partialLine = "";
          startedProgress = true;
        }
        return;
      }

      // Line contains "\n" either it will be a progress message followed by something else, or partialLine + what we
      // just got on the rest of the line is not interesting and discard it, then recurse on the remainder of the
      // line(s)
      String[] lines = output.split("\\n", 2);

      // Construct a full line, print if necessary, then discard the line
      partialLine += lines[0];
      if (partialLine.matches("(?s).*Progress:.*?% complete.*")) {
        System.out.println("\n" + partialLine + output);
        System.out.flush();
        // No started progress since another newline printed meaning the following message may not be a progress
        // message
      }
      partialLine = "";

      if (lines.length > 1) { // TODO Not sure if split on "\n" produces 1 or 2 strings, if may not be necessary
        // Recurse with the rest of the line to start processing the next line
        accept(lines[1]);
      }
      return;
    }
  }

  private int executePostPublish(ProcessBuilder pBuilder,
      com.sun.jersey.api.representation.Form formData, String strIPID, Path ipPath,
      Set<String> sPubDocs, String sModuleUrl) throws IMPException, IOException {
      IMPLog.trace("Start execution executePostPublish");
	  IMPLog.trace("User: " + IMPCommon.getImpUser());
	  int iReturn;
	  IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
	  if (! this.bDryRun) {
		  IMPLog.info("Start publishing design data into DesignSync");
	  }
	  try {
		  ImpPublishOutputProcessor p = new ImpPublishOutputProcessor();
		  pBuilder.redirectErrorStream(true);
		  IMPLog.trace("set redirect error...");
		  Process pPublish = pBuilder.start();
		  String sOuterror = stclWrapper.processOutput(pPublish, p);
		  int pValue = pPublish.waitFor();
		  IMPLog.trace("Process State: " + pValue);
		  if (pValue == 0) {
			  if (this.bDryRun) {
				  //SWIMP-5 : Starts
				  IMPLog.debug("Publish with Dry-run "+System.lineSeparator() + sOuterror);
				  sOuterror = stclWrapper.getSoutValue(sOuterror);
				  if(!sOuterror.trim().startsWith("Error:")) {
					  String rStatus = sOuterror.substring(sOuterror.indexOf("__START__"), sOuterror.indexOf("__END__"));
					  rStatus = rStatus.replaceAll("__START__", "").trim();

					  if(rStatus !=null && !rStatus.isEmpty() && rStatus.contains("Status")) {
						  IMPLog.info("Status of Staging area: Out-of-date");
						  IMPLog.info(rStatus);
					  } else {
						  IMPLog.info("Status of Staging area: Up-to-date");
					  }
					  iReturn =0;
				  } else {
					  sOuterror = sOuterror.replace("Error: ", "");
					  iReturn = 2;
					  IMPLog.error(sOuterror);
					  return iReturn;
				  }//SWIMP-5: Ends
				  IMPLog.trace("Will not publish data because --dry-run is used");
			  } else {
				  IMPLog.trace("Design Sync: " + System.lineSeparator() + sOuterror);
				  sOuterror = stclWrapper.getSoutValue(sOuterror).trim();
				  if (sOuterror.trim().startsWith("Error:")) {
					  sOuterror = sOuterror.replace("Error:", "");
					  iReturn = 2;
					  IMPLog.error(sOuterror);
					  return iReturn;
				  } else {
					  String sTagExists = stclWrapper.getModValue("CheckTagExists", sModuleUrl + ";" + sTag);
					  IMPLog.debug("Tag Exists Design Sync Out: \n" + sTagExists);
					  sTagExists = stclWrapper.getSvalue(sTagExists);
					  if (sTagExists.trim().startsWith("Error:")) {
						  sTagExists = sTagExists.replace("Error: ", "");
						  iReturn = 2;
						  IMPLog.error(sTagExists);
						  return iReturn;
					  } else {
						  //Added for SWIMP-81
						  IMPLog.info("Design data successfully published in DesignSync");

						  IMPEnoviaClientWrapper impEnoClient = new IMPEnoviaClientWrapper();
						  /*
						   * below Call Enovia service to update meta-data
						   */
						  WebResource webResource =
								  impEnoClient.getIMPServiceWebResource("ipPublishPostProcess");

						  // Pass multiple Query Params
						  MultivaluedMapImpl queryParams = new MultivaluedMapImpl();

						  // Pass the IP name
						  queryParams.add("IPName", strIPID);
						  queryParams.add("UserName", IMPCommon.getImpUser());
						  queryParams.add("Event", sProcName);
						  // Call for uploading the public documents
						  if(!sPubDocs.isEmpty()){       	  
							  String strPath=setFTPDirectoryUpLoadPath(ipPath, strIPID, sPubDocs);
							  formData.putSingle("sPath", strPath);
							  formData.putSingle("sPubDocs", sPubDocs);					
						  }else{
							  formData.putSingle("sPath", "");
							  formData.putSingle("sPubDocs", "");
						  }		  

						  // Added pre-approve revision list for the user story #IMPBRCM-205
						  ClientResponse response = webResource.queryParams(queryParams)
								  .accept(strMediaType).header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER)
								  .post(ClientResponse.class, formData);
						  IMPLog.trace("Meta Data to be updated: " + formData);
						  IMPLog.trace("Publish PostProcess Response status: " + response.getStatus());

						  // Capture the return JSON with code and message
						  org.codehaus.jettison.json.JSONObject retJson =
								  new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
						  // Fixed for 995.
						  if (response.getStatus() != 200) {
							  iReturn = 2;
							  IMPLog.trace("Error: " + retJson.getString(IMP_MESSAGE));
						  } else {
							  IMPLog.trace("Publish PostProcess: " + retJson);
							  String sHostName = (String) retJson.get("canonical");
							  setStrHostName(sHostName);
							  iReturn=postPublishDocumentStatus(retJson);
					  }
					  // Added for SWIMP-113 starts 
					  return iReturn;
				  }
			  }
		  }
	  } else {
		  iReturn = 2;
		  int iIndex = sOuterror.indexOf("IMP Stcl designsync output");
		  if (iIndex > -1) {
			  sOuterror = sOuterror.substring(0, iIndex);
		  }
		  IMPLog.error(sOuterror);
	  }
  }catch(IMPException|IOException|ClientHandlerException|UniformInterfaceException|JSONException|

	InterruptedException e)
	{
		IMPLog.trace("ERROR in Post Publish operations: " + e);
		throw new IMPException(IMPCommon.displayExitCode(64));
	}return iReturn;
  }
  
  //Added for SWIMP-850
  public static List<String> extractDifferentStatesOnlyObjectNames(String output) {
	    Pattern p = Pattern.compile("Different states\\s+(.+?)\\s*$");
	    List<String> names = new ArrayList<>();

	    for (String line : output.split("\\R")) {
	        Matcher m = p.matcher(line);
	        if (m.find()) names.add(m.group(1).trim());
	    }
	    return names;
  }
  
  /**
   * Checks the staging area for any change in file(s)/folder(s)excluding imp,ipicarun,<IPID>_bom.yaml, QAFailureFolder
   * @param ipBaseDir the staging area directory
   * @param strIPID the  IPID
   * @return the int
   * @throws InterruptedException the Interrupted exception
   */
  private int checkStagingAreaForChanges(String ipBaseDir, String strIPID, boolean isMarkerFileExists) {   //Added for SWIMP-850
	    int iReturn = 0;
	    String status = "";
	    List<String> sCommands = new ArrayList<>();
	    List<String> modFileNames = new ArrayList<>();
	    String[] lines;
	   
	    sCommands.add("compareDesignDataBeforePublish");
	    sCommands.add("-I");
	    sCommands.add(ipBaseDir);
	    //Added for SWIMP-850
	    if(!isMarkerFileExists) {
	    sCommands.add("-exclude");
	    sCommands.add("ipicarun,imp/QA-Failures,imp/bcm_uniquify.d,imp/"+strIPID+"_bom.yaml,imp/ipinfo.log");
	    } else {
	    sCommands.add("-exclude");
	    sCommands.add("ipicarun,imp/QA-Failures,imp/bcm_uniquify.d,imp/"+strIPID+"_bom.yaml,imp/ipinfo.log,imp/.requires_lightweight_publish");
	    }
	    //Added for SWIMP-850
	    try {
	      IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
	      ProcessBuilder pbStcl = stclWrapper.getStclProcessBuilder(sCommands);
	      pbStcl.redirectErrorStream(true);
	      Process process = pbStcl.start();
	      String sValue = stclWrapper.processOutput(process);
	      int pValue = process.waitFor();
	      IMPLog.trace("Process State: " + pValue);
	      if (pValue == 0) {
	        sValue = stclWrapper.getSoutValue(sValue);
	        IMPLog.debug("Checking for changes in staging area before publish: "+System.lineSeparator() + sValue);
	        if(!sValue.trim().startsWith("Error:")) {
	          status = sValue.substring(sValue.indexOf("__START__"),sValue.length());
	          status = status.replaceAll("__START__", "");
	        //Added for SWIMP-850
	          if (isMarkerFileExists) {
	              modFileNames = extractDifferentStatesOnlyObjectNames(status.toString());
	              if (!modFileNames.isEmpty() && modFileNames != null) {
	              IMPLog.debug("Changes found in the staging area: proceeding with publish");
	              setModifiedFileNames(modFileNames);
	              } else {
	                  IMPLog.info("No changes found in the staging area; Nothing to publish");
	                  iReturn = 2;
	              }
	          } else {
	          if(status != null && !status.isEmpty() && status.contains("Status")) {
	            IMPLog.debug("Changes found in the staging area: proceeding with publish");
	            //Added for SWIMP-869: start
	            lines = sValue.split("\\r?\\n");

	            Pattern pattern = Pattern.compile("^\\d+\\.\\d+.*\\s(\\S+)$");

	            for (String line : lines) {
	                Matcher matcher = pattern.matcher(line.trim());
	                if (matcher.matches()) {
	                	modFileNames.add(matcher.group(1)); // The last field is the file path and name
	                }
	            }
	            setModifiedFileNames(modFileNames);

	          //Added for SWIMP-869: end
	          } else {
	            IMPLog.info("No changes found in the staging area; Nothing to publish");
	            iReturn = 2;
	          }} //Added for SWIMP-850
	        } else {
	          sValue = sValue.replace("Error: ", "");
	          iReturn = 2;
	          IMPLog.error(sValue);
	        }
	      } else {
	        iReturn = 2;
	        int iIndex = sValue.indexOf("IMP Stcl designsync output");
	        if (iIndex > -1) {
	          sValue = sValue.substring(0, iIndex);
	        }
	        IMPLog.error(sValue);
	      }
	    } catch (IOException | InterruptedException ie) {
	      iReturn = 1;
	      IMPLog.error("Exception while checking changes in staging area "+ ie.getMessage() );
	    }
	      return iReturn;
	  }
  //Added for SWIMP-87: Starts
  /**
   * Gets the files marked as uniquification equals to true from spec file
   * @param ipBaseDir the staging area directory
   * @param List<ExpandedDeliverable> the deliverables from spec file
   * @param String component-name from cfg file
   * @return the resMap Map containg uniquification data
   */
  
@SuppressWarnings("unchecked")
private Map<String, Object> getUniquificationData(Path ipBasedir, List<ExpandedDeliverable> delivs, String componentName) {

	  Map<String, Object> resMap = new LinkedHashMap<>();
	  List<String> slFileTypeList;
	  String sFileType ="";
	  String sFilePath = "";
	  String sFileBasePath = "";

	  String refLayoutFile = "";
	  String refnetListFile = "";

	  //Updated for SWIMP-87
	  //Below file type list updated for SWIMP-367
	  List<String> fileTypeList= Arrays.asList(IMPConstants.IMP_FILE_TYPES_UNIQUIFICATION.split(","));
		for (ExpandedDeliverable toUniquify : delivs) {
				sFilePath = ipBasedir + File.separator + toUniquify.getPath();
				sFileBasePath = toUniquify.getPath();
				if (Paths.get(sFilePath).toFile().exists() && toUniquify.getAttributes().containsKey("file_type")) {
						sFileType = toUniquify.getAttributes().get("file_type").toString();
						if (fileTypeList.contains(sFileType)) {
							slFileTypeList = new ArrayList<>();
							if (resMap.containsKey(sFileType)) {
								slFileTypeList = (List<String>) resMap.get(sFileType);
								slFileTypeList.add(sFileBasePath);
							} else {
								slFileTypeList.add(sFileBasePath);
							}
							resMap.put(sFileType, slFileTypeList);					
						} else {
							IMPLog.warn(sFileBasePath + " is of type '"+ sFileType + "' and is marked as needs_uniquification for component "+componentName+"; this file type cannot be uniquified.");
						}
				}
		}
		refLayoutFile = getUnirefFiles(delivs,ipBasedir,componentName,"uniquification_reference_layout");
		refnetListFile = getUnirefFiles(delivs,ipBasedir,componentName,"uniquification_reference_netlist");
		
		if (!StringUtils.isEmpty(refLayoutFile)) {
			resMap.put("ref_layout", refLayoutFile);
		}

		if (!StringUtils.isEmpty(refnetListFile)) {
			resMap.put("ref_netlist",refnetListFile);
		}
		
	  return resMap;
  }
   private String getUnirefFiles(List<ExpandedDeliverable> delivs, Path ipBasedir, String compName, String uniRefType) {
	   String refNum;
	   String minRef = "";
	   String refFile = "";
	   List<ExpandedDeliverable> refDelList = new ArrayList<>();
	   try(Stream<ExpandedDeliverable> strExpDel = delivs.stream().filter(d -> d.getAttributes().containsKey(uniRefType) && d.getAttributes().get(uniRefType) !=null && Paths.get(ipBasedir.resolve(d.getPath()).toString()).toFile().exists())){
		   refDelList.addAll(strExpDel.collect(Collectors.toList()));
	   }
	   
	   for(ExpandedDeliverable del : refDelList) {
		   refNum = del.getAttributes().get(uniRefType).toString();					
				if (minRef.isEmpty() ||  refNum.compareTo(minRef) < 0) {
					minRef = refNum;
					refFile = del.getPath();
				}
	   }
	   if(refFile.isEmpty())
		   IMPLog.warn(uniRefType+" has not been specified in the directory tree specification for component "+ compName);
	return refFile;
}

//Added for SWIMP-87: Ends
  
  // Added for the fix 724
  
  // Added for bug 791
  private int automountIPICAWrapper(String sCurrentWD) {
    IMPLog.debug("CWD - " + sCurrentWD); // Show workspace path
    String strChangedDir;
    String sUserDir = "user.dir";
    int iReturn = 0;
    System.setProperty(sUserDir, IPICA_BASE_PATH);
    strChangedDir = System.getProperty("user.dir");
    if (strChangedDir.equals(IPICA_BASE_PATH)) {
      IMPLog.debug("Changed directory to wrapper directory to force auto mount");
    } else {
      iReturn = 1;
      IMPLog.error("Not able to switch to wrapper directory.");
    }
    System.setProperty(sUserDir, sCurrentWD);
    strChangedDir = System.getProperty(sUserDir);
    if (strChangedDir.equals(sCurrentWD)) {
      IMPLog.debug("Changed directory back to " + sCurrentWD);
    } else {
      iReturn = 1;
      IMPLog.error("Not able to switch back to the workspace directory - " + sCurrentWD);
    }
    return iReturn;
  }

  /**
   * Compare revision tag.
   *
   * @param sTag1 the s tag 1
   * @param sTag2 the s tag 2
   * @return the int
   * 
   *  sTag1 > sTag2 ->1
   *  sTag1 = sTag2 -> 0
   *  sTag1 < sTag2 -> -1
   *  
   *  Added for IMPBRCM-980
   */
  private int compareRevisionTag(String sTag1, String sTag2) {
    String[] spltTag1 = sTag1.split("\\.");
    String[] spltTag2 = sTag2.split("\\.");
    int maxLen = 0;
    for (String str : spltTag1)
      maxLen = Math.max(maxLen, str.length());
    for (String str : spltTag2)
      maxLen = Math.max(maxLen, str.length());
    int iCompare = normalizeRevisionTag(spltTag1, maxLen).compareTo(normalizeRevisionTag(spltTag2, maxLen));
    return iCompare > 0 ? 1 : (iCompare < 0 ? -1 : 0);
  }
  
  /**
   * Appends zeros if string from the array
   * has length smaller than the maxLen.
   * 
   * Added for IMPBRCM-980
   **/
  private String normalizeRevisionTag(String[] split, int maxLen) {
    StringBuilder sb = new StringBuilder("");
    for (String s : split) {
      for (int i = 0; i < maxLen - s.length(); i++)
        sb.append('0');
      sb.append(s);
    }
    return sb.toString();
  }
  
  /**
   * Gets the watermark.
   *
   * @return the watermark
   */
  public static String getWatermark() {
    return sWatermark;
  }

  /**
   * Sets the watermark.
   *
   * @param watermark the watermark to set
   */
  public static void setWatermark(String watermark) {
    Publish.sWatermark = watermark;
  }
  //Added for CR IMPBRCM-1043: Ends

  /**
   * Gets the host name.
   *
   * @return the host name
   */
  public static String getHostName() {
    return strHostName;
  }

  /**
   * Sets the str host name.
   *
   * @param strHostName the new str host name
   */
  public static void setStrHostName(String strHostName) {
    Publish.strHostName = strHostName;
  }
  


  //Added for SWIMP-1 Starts
 private static Map<String, String> fileWMMap = new HashMap<>();

 public static Map<String, String> getFileWMMap() {
    return fileWMMap;
}

public static void setFileWMMap(Map<String, String> fileWMMap) {
    Publish.fileWMMap = fileWMMap;
}
//Added for SWIMP-1 ends
//Added for SWIMP-113 starts
	private String setFTPDirectoryUpLoadPath(Path ipPath, String sIPID, Set<String> pubDocSet) throws IMPException {
		Path pTempPath = null;

		String sPath = "";
		try {
			int iReturn = 0;
			String strERRMsg = "Public documents failed to transfer to ";
			String strTempDir = sIPID + System.nanoTime();
			pTempPath = Utility.createTempDir(IMP_CLI_SERVER_HOST, strTempDir);
			if (pTempPath == null) {
				IMPLog.error(strERRMsg + IMP_CLI_SERVER_HOST);
			} else {
				sPath = pTempPath.toAbsolutePath().toString();
			}		
			//SWIMP-742 Start- Added this check for duplicate and rename file for public document
			Set<String> fileNamesCheck = new HashSet<>();
			Map<String, String> hFileMap = new HashMap<>();
			Map<String, String> hFileNameMap = new HashMap<>();
			Set<String> sFinalPubDocs = new HashSet<>();
	
			for (String strFile : pubDocSet) {
				if (strFile.contains("/")) {
				String sFileName = strFile.substring(strFile.lastIndexOf('/') + 1);
				Path path = Paths.get(strFile);
				Path pathBeforeFile = path.getParent();
				String sFileNameafterpath = pathBeforeFile.toString().replace("/", "_-_");
				sFileName = sFileName.replace("/", "").trim();
					if (fileNamesCheck.contains(sFileName)) {
						String sActualFileName = sFileNameafterpath + "_-_" + sFileName;
						String sBasePath = strFile.substring(0, strFile.lastIndexOf('/'));
						String newFilePath = sBasePath + "/" + sActualFileName;				
						sFinalPubDocs.add(sBasePath + "/" + sActualFileName);
						hFileNameMap.put(strFile.replaceAll("/", "_"), sActualFileName);
						String sduplicateFile = hFileMap.get(sFileName);
						sBasePath = sduplicateFile.substring(0, sduplicateFile.lastIndexOf('/'));
						path = Paths.get(sduplicateFile);
						pathBeforeFile = path.getParent();
						sFileNameafterpath = pathBeforeFile.toString().replace("/", "_-_");
						sActualFileName = sFileNameafterpath + "_-_" + sFileName;
						sFinalPubDocs.remove(sduplicateFile);
						sFinalPubDocs.add(sBasePath + "/" + sActualFileName);
						hFileNameMap.put(sduplicateFile.replaceAll("/", "_"), sActualFileName);
					} else {
						fileNamesCheck.add(sFileName);
						sFinalPubDocs.add(strFile);
					}
					hFileMap.put(sFileName, strFile);
				} else {
					strFile = strFile.trim();
					sFinalPubDocs.add(strFile);
				}	
			} 				
			for (String strFile : pubDocSet) {	
				String strPath = ipPath + File.separator + strFile;
				String strNewFileName = hFileNameMap.get(strFile.replaceAll("/", "_"));
				if (pTempPath != null) {
					setStrHostName(IMP_CLI_SERVER_HOST);
					iReturn = uploadFile(strPath, pTempPath.toAbsolutePath().toString(), strNewFileName);//Modified for SWIMP-742
					if (iReturn == 0) {
						IMPLog.trace("Copied " + strFile + " to IMP server " + pTempPath.toAbsolutePath().toString());
					} else {
						IMPLog.trace("Copied " + strFile + " to IMP server Failed");
					}
				} else {
					IMPLog.error("Public documents not uploaded to the server" + strFile);
				}
			}
			pubDocSet.clear();
			pubDocSet.addAll(sFinalPubDocs);
			//SWIMP-742 End
		} catch (IOException ie) {
			IMPLog.error("Exception while reading public documents:   " + ie);
			throw new IMPException(ie.getMessage());
		}
		return sPath;
	}
	
	private int postPublishDocumentStatus(org.codehaus.jettison.json.JSONObject retJson) throws JSONException {
		int iReturn = 0;
		StringBuilder sbOutput = new StringBuilder();
		try {
			String sUploadStatus = (String) retJson.get("sUploadStatus");
			String sSSGQIStatus =  (String) retJson.get("SSGQI Status");
			String sSSGQIFileName =  (String) retJson.get("SSGQI FileName");
			IMPLog.trace("sUploadStatus: " + sUploadStatus);
			IMPLog.trace("sSSGQIStatus: " + sSSGQIStatus);
			if(!StringUtils.isEmpty(sUploadStatus)){
				org.codehaus.jettison.json.JSONArray jFinalResultFiles =
						retJson.getJSONArray("lsFinalDocuments");
				if("Success".equals(sUploadStatus)){
					iReturn = 0;
				}else if("Partial".equals(sUploadStatus)){
					sbOutput.append("Unable to upload the following public documents to the IP: \n");
					for (int i = 0; i < jFinalResultFiles.length(); i++) {
						sbOutput.append(jFinalResultFiles.getString(i) + "\n");
					}
					iReturn = 2;
					IMPLog.error(sbOutput.toString());
				}else {
					iReturn = 2;
					IMPLog.error("Error in Uploading public documents: "+sUploadStatus);
				}
			}
			//SWIMP-882
			if(!StringUtils.isEmpty(sSSGQIStatus)){
				if("Success".equals(sSSGQIStatus)){
					iReturn = 0;
			    } else if("Failure".equals(sSSGQIStatus)) {
			    	iReturn = 2;
			    	IMPLog.error("Failed to save the file:  "+sSSGQIFileName+" in the IMP");
			    } else {
			    	iReturn = 2;
			    	IMPLog.error("Error in saving the file:  "+sSSGQIFileName+" in the IMP");
			    }
			}}catch(JSONException je){
			IMPLog.error("Exception while displaying unloaded public documents:   " + je);
			//SWIMP-882
		}
		return iReturn;
	  }
//Added for SWIMP-113 ends


	//Added for SWIMP-425: Starts
	/**
	 * This method is to process Technology Stacks for external tools
	 * Added for SWIMP-425 JIRA ticket, Modified for SWIMP-471, 502 and 501
	 *
	 * @param sModRoot, IP base directory
	 * @param List lToolBasedIPTechStacks, List of CHECKLAYERS tool TechStack maps
	 * @return integer, return code 0 or 2 , 0 - success, 2 - failure
	 * @throws IOException / InterruptedException, if there is any failures
	 */
	private int performCheckLayerForDesignFile(String sModRoot, List<String> lToolBasedIPTechStacks) throws IOException, InterruptedException {
		int iRet = 0;
		boolean bCheckLayerFailed = false;
		Path ipPath = Paths.get(sModRoot);
		Map<String, StringBuilder> mpCLFile = new HashMap<>();
		StringBuilder sbReturnMessage = new StringBuilder();
		StringBuilder sbErrorMessage = new StringBuilder();
		IMPStclcWrapper stclWrapper = new IMPStclcWrapper();
		String strReturnCodeMessage = "";
		try {
			if (Paths.get(IMP_CHECKLAYER_TOOL_PATH).toFile().exists()) {
				//Modified for SWIMP-471: Starts
				Utility.getDesignFiles(ipPath); //Get Design Files
				Set <Path> stDesignFiles = IMPCommon.getDesignFilesList();
				if (!stDesignFiles.isEmpty()) {
					listAllDesignFiles(stDesignFiles); //Added for SWIMP-471
					for (Path pthFile : stDesignFiles) {
						//Modified for SWIMP-471: Ends
						setGDSFile(pthFile.toString()); //Added for SWIMP-471
						for (String strMetalStackMap : lToolBasedIPTechStacks) {
							if(strMetalStackMap.contains(" ")){
								strMetalStackMap=strMetalStackMap.substring(0, strMetalStackMap.indexOf(" "));
							}
							IMPCommon.setMetalStack(strMetalStackMap);
							String[] argsArray = Utility.getCheckLayerProcessCommand(IMP_CHECKLAYER_TOOL_PATH, pthFile, strMetalStackMap);

							ProcessBuilder pb = stclWrapper.getStclProcessBuilder(argsArray);
							IMPLog.trace("checklayers command: "+Arrays.toString(argsArray));

							pb.redirectErrorStream(true);
							Process process = pb.start();
							String sOut = stclWrapper.outputForYaml(process).trim();
							int iProcess = process.waitFor();
							strReturnCodeMessage = IMPCommon.errorCodeForCheckLayersFailure(iProcess);
							if (iProcess != 0) {
								bCheckLayerFailed = true;
								IMPLog.error(strReturnCodeMessage + System.getProperty(CONST_LINESPEPARATOR)
								+ System.getProperty(CONST_LINESPEPARATOR) + sOut
								+ System.getProperty(CONST_LINESPEPARATOR));
								sbErrorMessage.append(System.getProperty(CONST_LINESPEPARATOR)+sOut+System.getProperty(CONST_LINESPEPARATOR));
							} else {
								IMPLog.trace(strReturnCodeMessage + System.getProperty(CONST_LINESPEPARATOR)
								+ System.getProperty(CONST_LINESPEPARATOR) + sOut
								+ System.getProperty(CONST_LINESPEPARATOR));
								sbReturnMessage.append(System.getProperty(CONST_LINESPEPARATOR)+sOut+System.getProperty(CONST_LINESPEPARATOR));
							}
						}
					}
					mpCLFile.put(IMP_CHECKLAYER_OUTPUTFILE, sbReturnMessage);
					mpCLFile.put(IMP_CHECKLAYER_ERRORFILE, sbErrorMessage);
					Utility.writeCheckLayersFile(ipPath, mpCLFile); //Write output/error file, Modified for SWIMP-471
					IMPLog.trace("checklayers output messages saved in '" + ipPath.resolve(IMP_CLI_IMP_FOLDER).resolve(IMP_CHECKLAYER_OUTPUTFILE)
							+ "' and error messages saved in '" + ipPath.resolve(IMP_CLI_IMP_FOLDER).resolve(IMP_CHECKLAYER_ERRORFILE));

					//Delete temporarily created folders for checklayers unTar/extracted folders
					Utility.deleteFolders(IMPCommon.getDirPathList());//Added for SWIMP-471

					if (bCheckLayerFailed) {
						if(bForce)//added for SWIMP-605
						{
							IMPLog.error(sCheckLayersProcessFailureMessageForce);
						}
						else
						{
							IMPLog.error(sCheckLayersProcessFailureMessage);
						}
						return 2;
					}
				} else {
					IMPLog.info("No design files found for IP '"+IMPCommon.getIpID()+"'.");
					//Added for SWIMP-502: Starts
					//Detect the checklayers.out and checklayers.err files in <IPBASEDIR>/imp and delete if exists.
					//Remove previous release's checklayers.out and checklayers.err files if Design files are not found
					//for current release or --skip-check-layers option is used
					checkForChecklayersfilesAndDeleteOnExists(ipPath);
					//Added for SWIMP-502: Ends
				}
			} else {
				IMPLog.error(IMP_CHECKLAYER_TOOL_PATH + " not exists");
				iRet = 2;
			}
		} catch (IOException e) {
			IMPLog.error("Exception while performing gds checklayers: " + e);
			iRet = 2;
		}
		return iRet;
	}
	//Added for SWIMP-425: Ends


	//Added for SWIMP-471: Starts
	/**
	 * This method is to display list of unique design files
	 * Added for SWIMP-471 JIRA ticket, addition to JIRA ticket SWIMP-425, Modified for SWIMP-492
	 * @param stDesignFiles, list of files
	 * @return Nothing
	 */
	private void listAllDesignFiles(Set<Path> stDesignFiles) {
		StringBuilder sbFileList = new StringBuilder();
		sbFileList.append("List of design files to be processed for 'checklayers':\n");
		String strIPBaseFolderName = Paths.get(IMPCommon.getIpDIR()).getFileName().toString(); //Added for SWIMP-492
		for (Path pDesignFilePath : stDesignFiles) {
			//Added for SWIMP-492: Starts
			if (pDesignFilePath.toString().contains(File.separator+strIPBaseFolderName+File.separator)) {
				Path ipPath = Paths.get(pDesignFilePath.toString().substring(0, pDesignFilePath.toString().indexOf(strIPBaseFolderName+File.separator)) + File.separator +IMPCommon.getIpID());
				sbFileList.append("\t"+ipPath.relativize(pDesignFilePath).toString()+"\n");
			} else {
				sbFileList.append("\t../"+ pDesignFilePath +"\n");
			}
			//Added for SWIMP-492: Ends
		}
		IMPLog.trace(sbFileList.toString());
	}

	/**
	 * This method is to set processed design file
	 * Added for SWIMP-471 JIRA ticket, addition to JIRA ticket SWIMP-425
	 *
	 * @param strFilePath, file path
	 * @return Nothing
	 */
	private void setGDSFile(String strFilePath) {
		Map<String, String> mpFileMap = IMPCommon.getFileMap();
		if (!mpFileMap.isEmpty() && mpFileMap.containsKey(strFilePath)) {
			String sFilePath = mpFileMap.get(strFilePath);
			IMPCommon.setGDSFile(sFilePath);
		} else {
			IMPCommon.setGDSFile(strFilePath);
		}
	}
	//Added for SWIMP-471: Ends

	//Added for SWIMP-502: Starts
	/**
	 * This method is to detect the checklayers.out and checklayers.err files in <IPBASEDIR>/imp and delete if exists.
	 * Added for SWIMP-502
	 * @param ipPath, IP Staging area path
	 * @return Nothing
	 */
	public void checkForChecklayersfilesAndDeleteOnExists(Path ipPath) {
		try {
			List<String> lsCheckLayersFiles = new ArrayList<>();
			lsCheckLayersFiles.add(IMP_CHECKLAYER_OUTPUTFILE);
			lsCheckLayersFiles.add(IMP_CHECKLAYER_ERRORFILE);
			//Remove previous release's checklayers.out and checklayers.err files if Design files are not found for current release
			Utility.deleteFiles(ipPath.resolve(IMP_CLI_IMP_FOLDER), lsCheckLayersFiles);//Modified for SWIMP-471
		} catch (IOException io) {
			IMPLog.error("Failed to detect checklayers.out and checklayers.err files in the path '"+ipPath.resolve(IMP_CLI_IMP_FOLDER)+"'. " + io);
		}
	}
	//Added for SWIMP-502: Ends

	//Added for SWIMP-501: Starts
	/**
	 * This method is to Validated the extraction of TAR archive file(s)
	 * And write checklayers.err file for any broken files
	 * Added for SWIMP-501
	 *
	 * @param Path ipPath, IP Path
	 * @return boolean bFailed, if there is any Invalid TARZIP file exists
	 */
	private boolean validateTARArchiveExtraction(Path ipPath) {
		boolean bFailed = false;
		try {
			List<String> lsInvalidExtractionFiles = IMPCommon.getInvalidTarZIPFile();
			if (!lsInvalidExtractionFiles.isEmpty()) {
				bFailed = true;
				StringBuilder sbBrokenTarArchives = new StringBuilder("Broken tar archive file(s) found - Unable to check contents:");
				for (String strFileErrMessage : lsInvalidExtractionFiles) {
					sbBrokenTarArchives.append(System.getProperty(CONST_LINESPEPARATOR)).append("\t"+strFileErrMessage);
				}
				IMPLog.error(sbBrokenTarArchives.toString());

				//Write the Broken tar archive file(s) list into checklayers.err file.
				Utility.writeOutputOrErrorFile(ipPath.resolve(IMPConstants.IMP_CLI_IMP_FOLDER), IMP_CHECKLAYER_ERRORFILE, System.getProperty(CONST_LINESPEPARATOR)
								+ System.getProperty(CONST_LINESPEPARATOR) + sbBrokenTarArchives.toString(), true);
			}
		} catch (IOException io) {
			IMPLog.error("Unable to validate the extraction of TAR archive file(s).");
			bFailed = true;
		}
		return bFailed;
	}
	//Added for SWIMP-501: Ends
	
	//Added for SWIMP-31: Starts

	private void processFilestoWatermark(CheckBomResult bomResult) {
		// Should probably still search for file_type: gds|oasis and also type_checking on needs_watermark
		try (Stream<ExpandedDeliverable> strExpDel = bomResult.getDeliverables().stream()
				.filter(d -> d.getAttributes().containsKey("needs_watermark")
						&& Boolean.TRUE.equals(d.getAttributes().get("needs_watermark")))) {
			delivsToWatermark.addAll(strExpDel.collect(Collectors.toList()));
		}
	}

	private int getDesignFilesAndWatermarkInfo(Map<String, String> mWaterMarks, String ipBaseDir) throws ConcurrentModificationException{
		int iReturn = 0;
		if (!delivsToWatermark.isEmpty()) {
			for (ExpandedDeliverable toWatermark : new ArrayList<>(delivsToWatermark)) {
				String sWaterMarks = "";
				String sFilePath = Paths.get(ipBaseDir) + File.separator + toWatermark.getPath();
				String actualFName = Paths.get(sFilePath).getFileName().toString();
				if (Paths.get(sFilePath).toFile().exists()) {
					gdsFileUtility = new GDSFileUtility();
					try {

						iReturn = this.gdsFileUtility.createTempFile(sFilePath);
						sWaterMarks = gdsFileUtility.executeDetectWaterMark(Paths.get(sFilePath), sQueueName,
								sFilePath);
						if (!STR_FAILED.equalsIgnoreCase(sWaterMarks) && !sWaterMarks.isEmpty()) {
							mWaterMarks.put(actualFName, sWaterMarks);
						} else if (STR_FAILED.equalsIgnoreCase(sWaterMarks)) {
							return 2;
						} else if (sWaterMarks.isEmpty()) {
							IMPLog.warn("No watermarks detected in file "+actualFName);
						} else {
							IMPLog.error("No watermarks detected. Please contact the IMP admin");
							return 2;
						}
					} catch (IMPException | IOException e) {
						return 2;
					} finally {
						gdsFileUtility.deleteTempFile();
					}
				} else {
					delivsToWatermark.remove(toWatermark);
				}
			}
		}
		return iReturn;
	}

	@SuppressWarnings("unchecked")
	private int readDesignFilesNBuildHIPStructure(String ipBaseDir, StringBuilder sbNegInstanceCount,
			StringBuilder sbIMPUnknownComponentWatermark)
					throws IMPException, IOException, JSONException {
		int iReturn = 0;
		Map<String, String> mDesignFileNameNWaterMarkInfo = new HashMap<>();
		iReturn = getDesignFilesAndWatermarkInfo(mDesignFileNameNWaterMarkInfo, ipBaseDir);
		int iUndetectedWaterMarks = 0; //Added for SWIMP-570
		Map<String, List<String>> mpList = new HashMap<>(); //Added for SWIMP-570
		if (iReturn != 0)
			return iReturn;
		if (!mDesignFileNameNWaterMarkInfo.isEmpty()) {
			IMPEnoviaClientWrapper enoviaWrapper = new IMPEnoviaClientWrapper();
			org.codehaus.jettison.json.JSONObject jsHIPData = enoviaWrapper.getHIPData(mDesignFileNameNWaterMarkInfo, IMPCommon.getIpID()); //Modified for SWIMP-568

			if (jsHIPData != null && jsHIPData.length() > 0) {
				Map<String, Map<String, String>> mDesignFileNCalculatedIPInstanceCountRef = new ObjectMapper().readValue(jsHIPData.getJSONObject("refCountMap").toString(), Map.class);
				Map<String, Map<String, Map<String, String>>> mDesignFileNameNwmObjInfoRef = new ObjectMapper().readValue(jsHIPData.getJSONObject("wmObjInfoMap").toString(), Map.class);
				Map<String, Map<String, Object>> mDesignFileNHIPChildInfoRef = new ObjectMapper().readValue(jsHIPData.getJSONObject("wmChildInfoMap").toString(), Map.class);
				Map<String, Map<String, String>> mDSFileNWMOrigInstanceCountRef = new ObjectMapper().readValue(jsHIPData.getJSONObject("OriginalCount").toString(), Map.class);
				Map<String, String> mDSFilenNotAvailableWMRef = new ObjectMapper().readValue(jsHIPData.getJSONObject("NotAvaiableWM").toString(), Map.class);
				Map<String, Map<String, Object>> mpLatestRevAndDeclaredUsageInfo = new ObjectMapper().readValue(jsHIPData.getJSONObject("detected_ip_info").toString(), Map.class); //Added for SWIMP-568

				for (Map.Entry<String, Map<String, String>> mDSFilenCountInfo : mDesignFileNCalculatedIPInstanceCountRef.entrySet()) {

					StringBuilder sbMissingProgenyCount = new StringBuilder();
					StringBuilder sbUnknownWaterMark = new StringBuilder();
					String sDesignFileName = mDSFilenCountInfo.getKey();
					List<String> lsUnDetectedWMs = new ArrayList<>(); //Added for SWIMP-570

					IMPLog.info("The following structure has been extracted from '" + sDesignFileName + "' with the expected instance count of the detected IPs:");
					Utility.buildHIPStructure4EachDesignFile(mDSFilenCountInfo.getValue(), mDesignFileNameNwmObjInfoRef,
							mDesignFileNHIPChildInfoRef, mDSFileNWMOrigInstanceCountRef, sDesignFileName,
							sbMissingProgenyCount, gdsSpecificChildInfoMap, gdsSpecificLineageMap,
							mpLatestRevAndDeclaredUsageInfo); // Modified for SWIMP-568

					if (!StringUtils.isBlank(sbMissingProgenyCount.toString())) {
						IMPLog.warn(sbMissingProgenyCount.toString());
						sbNegInstanceCount.append(sbMissingProgenyCount);
					}
					String sIMPUnknownComponentWatermark = mDSFilenNotAvailableWMRef.get(mDSFilenCountInfo.getKey());
					if (!StringUtils.isBlank(sIMPUnknownComponentWatermark)) {
						sbUnknownWaterMark.append(sDesignFileName).append(": ");
						Utility.warnUnDetectedWMandGetCount(sIMPUnknownComponentWatermark, sbUnknownWaterMark,
								lsUnDetectedWMs); //Modified for SWIMP-570
						sbIMPUnknownComponentWatermark.append(sbUnknownWaterMark).append("\r\n");
						if (!lsUnDetectedWMs.isEmpty()) {
							List<String> lsUnknownWMs = new ArrayList<>();
							for (String sUnWM : lsUnDetectedWMs) {
								lsUnknownWMs.add(sUnWM);
								iUndetectedWaterMarks = iUndetectedWaterMarks + 1;
							}
							mpList.put(sDesignFileName, lsUnknownWMs);
						}
					}
				}
			}
		}
		Map<String, Object> mpYamlDetectedIPsList = Utility.getDetectedIPsFromMap();
		Map<String, Object> yamlDetectedIPs = new LinkedHashMap<>();
		Map<String, Object> yamlInternalIPs = new LinkedHashMap<>();
		Map<String, Object> yaml3PIPs = new LinkedHashMap<>();
		Map<String, Object> countData = new LinkedHashMap<>();
		
		int internalIPCount = 0;
		int pipIPCount = 0;
		
		if (!mpYamlDetectedIPsList.isEmpty()) {
			for (Entry<String, Object> mpTempDetectedIPsData : mpYamlDetectedIPsList.entrySet()) {
				String sKeyIPID = mpTempDetectedIPsData.getKey();
				Map<String, Object> mpTempData = (Map<String, Object>) mpTempDetectedIPsData.getValue();
				String sIPSource = (String) mpTempData.get(IMPConstants.CONST_IPSOURCE);
				Map<String, Object> mpFillerMap = new LinkedHashMap<>();
				Map<String, Object> mpInstanceDataMap = new LinkedHashMap<>();
				Map<String, Object> mpWatermarkMap = new LinkedHashMap<>();
				String sLineage = (String) mpTempData.get(IMPConstants.CONST_LINEAGE);
				sLineage = sLineage.replaceAll("\\,", ", ");

				if (IMPConstants.CONST_3PIP.equalsIgnoreCase(sIPSource)) {
					mpFillerMap.put(IMPConstants.CONST_OWNER, mpTempData.get(IMPConstants.CONST_OWNER));
					mpFillerMap.put(IMPConstants.CONST_VENDOR, mpTempData.get(IMPConstants.CONST_VENDOR));
					mpFillerMap.put(IMPConstants.CONST_REVISION, mpTempData.get(IMPConstants.CONST_REVISION));
					mpFillerMap.put(IMPConstants.CONST_LATESTREVISION, mpTempData.get(IMPConstants.CONST_LATESTREVISION));
					mpFillerMap.put(IMPConstants.CONST_DECLATEDFORUSE, mpTempData.get(IMPConstants.CONST_DECLATEDFORUSE));
					mpFillerMap.put(IMPConstants.CONST_DEPRECATEDBY, mpTempData.get(IMPConstants.CONST_DEPRECATEDBY));
					mpFillerMap.put(IMPConstants.CONST_ALERT, mpTempData.get(IMPConstants.CONST_ALERT));
					mpWatermarkMap.put(IMPConstants.CONST_LINEAGE, sLineage);
					mpWatermarkMap.put(IMPConstants.CONST_INSTANCECOUNT, mpTempData.get(IMPConstants.CONST_INSTANCECOUNT));
					mpWatermarkMap.put(IMPConstants.CONST_DESIGNFILE, mpTempData.get(IMPConstants.CONST_DESIGNFILE));
					mpInstanceDataMap.put((String) mpTempData.get(IMPConstants.CONST_WATERMARK), mpWatermarkMap);
					mpFillerMap.put(IMPConstants.CONST_INSTANCES, mpInstanceDataMap);
					yaml3PIPs.put(sKeyIPID, mpFillerMap);
					pipIPCount = pipIPCount + 1;
				} else {
					mpFillerMap.put(IMPConstants.CONST_OWNER, mpTempData.get(IMPConstants.CONST_OWNER));
					mpFillerMap.put(IMPConstants.CONST_BU, mpTempData.get(IMPConstants.CONST_BU));
					mpFillerMap.put(IMPConstants.CONST_REVISION, mpTempData.get(IMPConstants.CONST_REVISION));
					mpFillerMap.put(IMPConstants.CONST_LATESTREVISION, mpTempData.get(IMPConstants.CONST_LATESTREVISION));
					mpFillerMap.put(IMPConstants.CONST_DECLATEDFORUSE, mpTempData.get(IMPConstants.CONST_DECLATEDFORUSE));
					mpFillerMap.put(IMPConstants.CONST_DEPRECATEDBY, mpTempData.get(IMPConstants.CONST_DEPRECATEDBY));
					mpFillerMap.put(IMPConstants.CONST_ALERT, mpTempData.get(IMPConstants.CONST_ALERT));
					mpWatermarkMap.put(IMPConstants.CONST_LINEAGE, sLineage);
					mpWatermarkMap.put(IMPConstants.CONST_INSTANCECOUNT, mpTempData.get(IMPConstants.CONST_INSTANCECOUNT));
					mpWatermarkMap.put(IMPConstants.CONST_DESIGNFILE, mpTempData.get(IMPConstants.CONST_DESIGNFILE));
					mpInstanceDataMap.put((String) mpTempData.get(IMPConstants.CONST_WATERMARK), mpWatermarkMap);
					mpFillerMap.put(IMPConstants.CONST_INSTANCES, mpInstanceDataMap);
					yamlInternalIPs.put(sKeyIPID, mpFillerMap);
					internalIPCount = internalIPCount + 1;
				}
			}
			countData.put("total_detected_ips", mpYamlDetectedIPsList.size());
			countData.put("total_detected_3pips", pipIPCount);
			countData.put("total_detected_internal_ips", internalIPCount);
			countData.put("total_detected_ips_with_zero_instance_count", IMPCommon.getZeroInstanceIPCount());
			countData.put("undetected_watermarks", iUndetectedWaterMarks);
			yamlOut.put(sCOUNT, countData);
			
			//Added for SWIMP-568 : Starts
			Map<String, Object> yamlIpHierarchy = new LinkedHashMap<>();
			Map<String, Object> mpIpHierarchyDataMap = (Map<String, Object>) IMPCommon.getStructureFromIPHierarchyMap();
			if(mpIpHierarchyDataMap != null && !mpIpHierarchyDataMap.isEmpty()) {
				for (Map.Entry<String, Object> mpTempStructureData : mpIpHierarchyDataMap.entrySet()) {
					Map<String, Object> mpTempData = (Map<String, Object>) mpTempStructureData.getValue();
					yamlIpHierarchy.put(mpTempStructureData.getKey(), mpTempData);
				}
				yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, yamlIpHierarchy);
			} else {
				yamlOut.put(IMPConstants.KEY_IP_HIERARCHY, "");
			}
			yamlDetectedIPs.put(CONST_INTERNAL, !yamlInternalIPs.isEmpty() ? yamlInternalIPs : "");
			yamlDetectedIPs.put(CONST_3PIP, !yaml3PIPs.isEmpty() ? yaml3PIPs : "");
			yamlOut.put(KEY_DETECTEDIPS, !yamlDetectedIPs.isEmpty() ? yamlDetectedIPs : "");
		}
		yamlOut.put(KEY_UNDETECTED_WATERMARKS, mpList.isEmpty() ? "" : mpList);
		yamlOut.put("warning", !(IMPCommon.getWarnMessage().isEmpty()) ? IMPCommon.getWarnMessage() : "");
		//Added for SWIMP-568 : Ends
		return iReturn;
	}
	// Added for SWIMP-31: Ends

	//Added for SWIMP-632 -S
	private void releaseIPPublishLockOnExit() {
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				try {
					if (bIsIPLockedForPublish) {
						releaseIPPublishLock();
					}
				} catch (Exception e) {
					IMPLog.trace("Exception in releaseIPPublishLockOnExit :  ", e); // ignore any exception while releasing lock
				}
			}
		});
	}
	private void releaseIPPublishLock() throws  ClientHandlerException, UniformInterfaceException {
		IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		WebResource webResource = enoClient.getIMPServiceWebResource("releaseIPPublishLock");
		com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
		formData.putSingle(KEY_PUBLISH_LOCK_STRING,  getIPPublishLockString());
		formData.putSingle(IMP_CONST_IP_NAME,IMPCommon.getIpID());
		webResource.accept(strMediaType).header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
	}
	private boolean getIPPublishLock() throws IMPException, ClientHandlerException, UniformInterfaceException, JSONException {
		IMPEnoviaClientWrapper enoClient = new IMPEnoviaClientWrapper();
		WebResource webResource = enoClient.getIMPServiceWebResource("getIPPublishLock");
		com.sun.jersey.api.representation.Form formData = new com.sun.jersey.api.representation.Form();
		formData.putSingle(KEY_PUBLISH_LOCK_STRING,  getIPPublishLockString());
		formData.putSingle(IMP_CONST_IP_NAME,IMPCommon.getIpID());
		formData.putSingle("force",bForceIPPublishUnlock);

		ClientResponse response = webResource.accept(strMediaType).header(IMP_AUTHORIZATION, "Basic " + IMP_AUTH_USER).post(ClientResponse.class, formData);
		if (response.getStatus() != 200) {
			throw new IMPException("Failed : HTTP error code : " + response.getStatus());
		}
		org.codehaus.jettison.json.JSONObject retJson = new org.codehaus.jettison.json.JSONObject(response.getEntity(String.class));
		String sIMPLockString = retJson.optString(KEY_PUBLISH_LOCK_STRING);
		IMPLog.trace("IP Publish Lock String from IMP: "+sIMPLockString);
		if (getIPPublishLockString().equalsIgnoreCase(sIMPLockString)) {//if lock string passed is same as lock string we got from IMP, that means we got the lock.
			bIsIPLockedForPublish = true;
			releaseIPPublishLockOnExit();
			if(bForceIPPublishUnlock) {
				String sOldIPPublishLockStringFromIMP = retJson.optString(KEY_OLD_PUBLISH_LOCK_STRING);
				if(!StringUtils.isEmpty(sOldIPPublishLockStringFromIMP)) {
					IMPLog.info("--force-unlock used; removing lock: "+sOldIPPublishLockStringFromIMP);
				} else {
					IMPLog.info("Ignoring --force-unlock since the "+IMPCommon.getIpID()+" is not locked for publishing");
				}
			}
		} else {
			displayIPPublishLockError(sIMPLockString);
		}
		return bIsIPLockedForPublish;
	}
	private void displayIPPublishLockError(String sIMPIPPublishLockString) {
		StringBuilder sbErrorMessage = new StringBuilder();
		sbErrorMessage.append("The publish command for ");
		sbErrorMessage.append(IMPCommon.getIpID());
		sbErrorMessage.append(" is currently blocked");
		if(!StringUtils.isEmpty(sIMPIPPublishLockString)) {
			String[] aIMPLockString = sIMPIPPublishLockString.trim().split("[|]");
			if (aIMPLockString.length == 3) {
				sbErrorMessage.append(" - user ");
				sbErrorMessage.append(aIMPLockString[0]);
				sbErrorMessage.append(" is in the process of publishing revision ");
				sbErrorMessage.append(aIMPLockString[1]);
				sbErrorMessage.append(" as of ");
				sbErrorMessage.append(aIMPLockString[2]);
			} 
		}
		sbErrorMessage.append(". If that publish process has been killed and this is a stale lock, please try again using the --force-unlock option to the publish command.");
		IMPLog.error(sbErrorMessage.toString());
	}
	private String generateIPPublishLockSrting() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a z");
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		String currentUTCDateTime = sdf.format(new Date());
		String sGeneratedIPPublishLockString = new StringBuilder().append(IMPCommon.getImpUser()).append("@").append(IMPCommon.getImpDomain()).append("|").append(sTag).append("|").append(currentUTCDateTime).toString();
		IMPLog.trace("Generated IP Publish Lock String: "+ sGeneratedIPPublishLockString);
		return sGeneratedIPPublishLockString;
	}
	public String getIPPublishLockString () {
		if(StringUtils.isEmpty(sIPPublishLockString)) {
			setIPPublishLockString(generateIPPublishLockSrting());
		} 
		return sIPPublishLockString;
	}
	public void setIPPublishLockString (String sNewIPPublishLockString) {
		sIPPublishLockString = sNewIPPublishLockString; 
	}
	//Added for SWIMP-632 -S

	public String getsWMDerivedFromRevision() {
		return sWMDerivedFromRevision;
	}

	public void setsWMDerivedFromRevision(String sWMDerivedFromRevision) {
		this.sWMDerivedFromRevision = sWMDerivedFromRevision;
	}
	//Added for SWIMP-869: start
	public List<String> getModifiedFileNames() {
		return modifiedFileNames;
	}

	public void setModifiedFileNames(List<String> modifiedFileNames) {
		this.modifiedFileNames = modifiedFileNames;
	}
	//Added for SWIMP-869: end
	
	//Added for SWIMP-882
	public static Optional<String> extractUnknownOptionValue(String output) {
	    Matcher m = UNKNOWN_OPTION.matcher(output);
	    if (m.find()) {
	      return Optional.of(m.group(1).trim()); // e.g., "spec-file"
	    }
	    return Optional.empty();
	  }
	
    //Added for SWIMP-882
	public static Path validateSSGQIConfigFile(String sSSGQIConfigFile) throws Exception {
        
        final Path cfgPath;
        try {
            cfgPath = Paths.get(sSSGQIConfigFile).normalize();
        } catch (InvalidPathException ipe) {
            throw ipe;
        }
        Path parent = cfgPath.getParent();
        if (parent == null) {
            throw new NotDirectoryException("No parent directory in path: " + cfgPath);
        }
        if (!Files.exists(parent)) {
            throw new NoSuchFileException("No such directory: " + parent);
        }
        if (!Files.isDirectory(parent)) {
            throw new NotDirectoryException("Parent is not a directory: " + parent);
        }
        if (!Files.exists(cfgPath)) {
            throw new NoSuchFileException("No such file: " + cfgPath);
        }
        if (!Files.isRegularFile(cfgPath)) {
            throw new NoSuchFileException("Not a regular file: " + cfgPath);
        }
        return cfgPath;
    }
	//Added for SWIMP-882
}
